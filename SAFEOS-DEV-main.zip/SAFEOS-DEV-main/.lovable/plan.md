
# Plano: Correção de Custos Fixos (RLS), Mapa do Brasil e Arquivamento de Clientes

## Resumo Executivo
Este plano resolve os três problemas identificados para deixar o sistema pronto para publicação.

---

## PARTE A: Corrigir RLS de `custos_fixos`

### Problema Identificado
O usuário atual possui role `administrativo`. A policy de **SELECT** da tabela `custos_fixos` permite apenas `admin` e `gestor`, excluindo o `administrativo`. Resultado: o usuário pode inserir, mas não consegue visualizar os dados, gerando erro na interface.

### Solução
Atualizar a policy de SELECT para incluir `administrativo`:

```sql
-- Remover policy atual restritiva
DROP POLICY IF EXISTS "Role based custos_fixos select" ON public.custos_fixos;

-- Criar nova policy incluindo administrativo
CREATE POLICY "Role based custos_fixos select"
  ON public.custos_fixos FOR SELECT
  USING (
    has_role(auth.uid(), 'admin'::app_role) OR 
    has_role(auth.uid(), 'gestor'::app_role) OR
    has_role(auth.uid(), 'administrativo'::app_role)
  );
```

### Resultado Esperado
- `admin`, `gestor` e `administrativo` podem ver, inserir e editar custos fixos
- Apenas `admin` pode deletar (hard delete)
- Vendedores não têm acesso a custos fixos

---

## PARTE B: Melhorar Mapa do Brasil

### Problema Identificado
O mapa atual usa um contorno SVG muito simplificado e genérico. Os estados aparecem como círculos posicionados manualmente, sem o formato real do território brasileiro.

### Solução
1. **Substituir contorno atual** por um SVG mais detalhado do Brasil com contornos reais dos estados
2. **Melhorar contraste** usando cores mais visíveis e bordas mais definidas
3. **Ajustar viewBox** para garantir que todos os estados fiquem visíveis sem cortes
4. **Adicionar efeito de glow/sombra** nos pins para melhor visibilidade

### Alterações no Componente `BrazilMapPanel.tsx`:
- Usar um path SVG real do mapa do Brasil com contornos dos estados
- Aumentar contraste do preenchimento e bordas
- Melhorar a responsividade do container
- Adicionar filtro de sombra para pins/clusters

### Alterações no `brazilGeoData.ts`:
- Ajustar as posições X/Y dos estados para corresponder ao novo mapa
- Garantir que estados menores (RJ, SE, AL, ES, DF) tenham posições precisas

---

## PARTE C: Validar Arquivamento de Clientes

### Status Atual
A lógica já está implementada em `useClients.tsx`:
- `useArchiveClient()` com validação de vínculos (apólices, sinistros)
- `useRestoreClient()` para restaurar clientes arquivados
- Filtro `includeArchived` no hook `useClients()`
- Toggle "Ver arquivados" visível apenas para managers

### Validações a Confirmar
1. O botão "Arquivar" aparece no menu de ações
2. A validação de vínculos bloqueia corretamente
3. O contador atualiza automaticamente após arquivar/restaurar
4. A invalidação de queries está funcionando

### Ajustes Necessários
- Melhorar mensagem de erro quando há vínculos (mais clara e amigável)
- Garantir que o toggle "Ver arquivados" funcione corretamente
- Adicionar confirmação visual antes de arquivar

---

## Arquivos a Modificar

| Arquivo | Alteração |
|---------|-----------|
| Migração SQL | Corrigir policy SELECT de `custos_fixos` |
| `src/components/dashboard/BrazilMapPanel.tsx` | Novo SVG do Brasil com contornos reais |
| `src/data/brazilGeoData.ts` | Ajustar posições dos estados |
| `src/hooks/useCustosFixos.tsx` | Melhorar mensagens de erro |
| `src/pages/Clientes.tsx` | Pequenos ajustes de UX no arquivamento |

---

## Detalhes Técnicos

### Migração SQL para `custos_fixos`
```sql
-- Permitir que administrativo também veja custos fixos
DROP POLICY IF EXISTS "Role based custos_fixos select" ON public.custos_fixos;

CREATE POLICY "Role based custos_fixos select"
  ON public.custos_fixos FOR SELECT
  USING (
    has_role(auth.uid(), 'admin'::app_role) OR 
    has_role(auth.uid(), 'gestor'::app_role) OR
    has_role(auth.uid(), 'administrativo'::app_role)
  );
```

### Novo Mapa do Brasil
O componente será atualizado para usar paths SVG reais dos 27 estados brasileiros, com:
- Preenchimento escuro (`hsl(var(--muted))`) para estados sem clientes
- Preenchimento primário (`hsl(var(--primary))`) para estados com clientes
- Bordas visíveis entre estados
- Tooltip com informações ao hover
- Escala automática para caber no container

### Invalidação de Cache
A função `invalidateEntityQueries(queryClient, "clients")` já invalida:
- `clients` (lista)
- `dashboard-stats`
- `client_growth_data`
- `client_map_data`
- `priority_queue`

---

## Testes de Validação

### Teste 1: Custos Fixos
1. Login com usuário `administrativo`
2. Navegar para Financeiro > Custos Fixos
3. Clicar "Adicionar"
4. Preencher: Categoria=Aluguel, Descrição=Escritório, Valor=4500, Recorrência=Mensal
5. Confirmar que aparece na lista
6. Confirmar que Total Mensal atualiza

### Teste 2: Mapa do Brasil
1. Dashboard > Mapa de Clientes
2. Confirmar que todos os 27 estados são visíveis
3. Confirmar que estados com clientes aparecem destacados
4. Hover em estado com clientes → tooltip com detalhes
5. Alternar entre visualização "Por Estado" e "Por Cidade"

### Teste 3: Arquivamento de Clientes
1. Criar cliente novo (sem apólices)
2. Menu "..." > Arquivar
3. Confirmar que some da lista imediatamente
4. Confirmar que contador atualiza
5. Clicar "Ver arquivados"
6. Localizar cliente arquivado
7. Clicar "Restaurar"
8. Confirmar que volta para lista ativa

### Teste 4: Bloqueio por Vínculo
1. Selecionar cliente com apólice ativa
2. Tentar arquivar
3. Confirmar mensagem: "Não é possível arquivar: existem apólices vinculadas"

---

## Ordem de Implementação
1. Aplicar migração SQL (RLS custos_fixos)
2. Atualizar BrazilMapPanel.tsx e brazilGeoData.ts
3. Validar fluxo de arquivamento
4. Testes end-to-end
