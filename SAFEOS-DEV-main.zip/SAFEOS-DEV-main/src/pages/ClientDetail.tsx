import { useMemo, useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useClient, useUpdateClient, safeParseMetadata } from "@/hooks/useClients";
import { getExpectedClientStatus } from "@/hooks/useClientStatusSync";
import { useClientPolicies } from "@/hooks/useClientPolicies";
import { useSinistros } from "@/hooks/useSinistros";
import { useClientNotes } from "@/hooks/useClientNotes";
import { ClientFormModal, ClientNotesModal } from "@/components/clients";
import { useClientCommissionHistory, useClientActiveCommissions, useCreateClientCommission } from "@/hooks/useClientCommission";
import { useClientDocuments, useUploadClientDocument, useDeleteClientDocument, useDocumentUrl } from "@/hooks/useClientDocuments";
import { ApoliceFormModal, ApoliceDocumentsModal } from "@/components/apolices";
import { useAuth } from "@/hooks/useAuth";
import { useArchiveApolice } from "@/hooks/useApolices";
import { toast } from "sonner";
import { AppLayout } from "@/components/layout";
import { logSensitiveAccess } from "@/lib/audit";
import { calculateClientFinancials, calculatePolicyCommission } from "@/lib/commissionUtils";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  Briefcase, 
  Stethoscope, 
  ShieldCheck, 
  AlertTriangle, 
  TrendingUp, 
  DollarSign, 
  Clock, 
  FileText, 
  MessageSquare, 
  Plus, 
  Pencil, 
  ChevronLeft,
  ArrowUpRight,
  Target,
  Percent,
  History,
  AlertCircle,
  Wallet,
  ArrowRightLeft,
  Paperclip,
  Trash2
} from "lucide-react";
import { useClientComissoes } from "@/hooks/useComissoes";
import { ClientCommissionSection } from "@/components/clients/ClientCommissionSection";
import { CommissionAdjustmentDialog } from "@/components/clients/CommissionAdjustmentDialog";
import { useLtvSettings, calculateLtvValue } from "@/hooks/useLtvSettings";
import { format, differenceInDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Loader2 } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip as RechartsTooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from "recharts";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export default function ClientDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const formatDate = (dateValue: any, formatStr: string, options?: any) => {
    if (!dateValue) return "N/D";
    try {
      const d = typeof dateValue === "string" || typeof dateValue === "number" ? new Date(dateValue) : dateValue;
      if (!d || isNaN(d.getTime())) return "N/D";
      return format(d, formatStr, options);
    } catch (e) {
      return "N/D";
    }
  };
  
  const { data: client, isLoading: loadingClient } = useClient(id!);
  const { data: policies, isLoading: loadingPolicies } = useClientPolicies(id!);
  const { data: sinistros, isLoading: loadingSinistros } = useSinistros({ clientId: id! });
  const { data: notes } = useClientNotes(id!);
  const { data: commissions } = useClientCommissionHistory(id!);
  const { data: activeCommissions } = useClientActiveCommissions(id!);
  const { data: documents } = useClientDocuments(id!);
  const { data: commissionEntries, isLoading: loadingEntries } = useClientComissoes(id!);
  const [isAdjustmentOpen, setIsAdjustmentOpen] = useState(false);
  const [isPolicyModalOpen, setIsPolicyModalOpen] = useState(false);
  const [editingPolicy, setEditingPolicy] = useState<any | null>(null);
  const [isEditClientModalOpen, setIsEditClientModalOpen] = useState(false);
  const updateClient = useUpdateClient();
  const createCommission = useCreateClientCommission();
  const { user } = useAuth();
  const archiveApolice = useArchiveApolice();
  const [policyToDelete, setPolicyToDelete] = useState<any | null>(null);

  const uploadDocument = useUploadClientDocument();
  const deleteDocument = useDeleteClientDocument();
  const getDocumentUrl = useDocumentUrl();
  const [isUploadingDoc, setIsUploadingDoc] = useState(false);

  const handleDocUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      toast.error("Arquivo muito grande. Máximo 10MB");
      return;
    }

    setIsUploadingDoc(true);
    try {
      await uploadDocument.mutateAsync({
        clientId: id!,
        file,
        tipo: file.name.split('.').pop() || "unknown",
      });
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsUploadingDoc(false);
      e.target.value = "";
    }
  };

  const handleDocView = async (url: string) => {
    try {
      const signedUrl = await getDocumentUrl.mutateAsync(url);
      window.open(signedUrl, "_blank");
    } catch (err: any) {
      toast.error("Erro ao abrir documento.");
    }
  };

  const handleOpenCreate = () => {
    setEditingPolicy(null);
    setIsPolicyModalOpen(true);
  };

  const handleOpenEdit = (policy: any) => {
    setEditingPolicy(policy);
    setIsPolicyModalOpen(true);
  };

  const handleOpenEmit = (policy: any) => {
    setEditingPolicy({
      ...policy,
      _transitionToActive: true
    });
    setIsPolicyModalOpen(true);
  };
  
  const handleDeletePolicy = async () => {
    if (!policyToDelete) return;

    if (!user?.id) {
      toast.error("Usuário não identificado.");
      return;
    }

    try {
      await archiveApolice.mutateAsync({
        id: policyToDelete.id,
        userId: user.id,
      });
      setPolicyToDelete(null);
    } catch (err: any) {
      console.error(err);
      // Hook might have shown its own error message, but fallback in case
    }
  };
  
  // Registrar visualização de dados sensíveis para auditoria
  useEffect(() => {
    if (id) {
      logSensitiveAccess('clients', id, 'SELECT');
    }
  }, [id]);

  // Synchronize client status based on active policies
  useEffect(() => {
    if (!client || !policies) return;

    const syncResult = getExpectedClientStatus(client.status, policies);

    if (syncResult.hasDivergence && syncResult.expectedStatus !== client.status) {
      updateClient.mutate({
        id: client.id,
        status: syncResult.expectedStatus,
      }, {
        onSuccess: () => {
          toast.success(syncResult.reason);
        },
        onError: () => {
          toast.error("Erro ao sincronizar status cadastral do cliente.");
        }
      });
    }
  }, [client, policies, updateClient]);

  // Chart Data from real entries
  const commissionChartData = useMemo(() => {
    if (!commissionEntries) return [];
    
    // Group by competency (YYYY)
    const yearly = commissionEntries.reduce((acc: Record<string, number>, entry) => {
      const year = entry.competencia.split('-')[0];
      acc[year] = (acc[year] || 0) + entry.valorComissao;
      return acc;
    }, {});

    return Object.entries(yearly)
      .map(([year, total]) => ({ year, total }))
      .sort((a, b) => a.year.localeCompare(b.year));
  }, [commissionEntries]);

  // Extrair estágio do CRM das observações se existir
  const crmStage = useMemo(() => {
    if (!client?.observacoes) return null;
    const match = client.observacoes.match(/\[ESTAGIO:([^\]]+)\]/);
    return match ? match[1] : null;
  }, [client?.observacoes]);

  // Parse metadata from observacoes for extra fields like responsavel_comercial
  const clientMetadata = useMemo(() => {
    return safeParseMetadata(client?.observacoes);
  }, [client?.observacoes]);

  const responsavelNome = useMemo(() => {
    return clientMetadata?.responsavel_comercial || "Sem corretor";
  }, [clientMetadata]);

  const responsavelInitials = useMemo(() => {
    const name = responsavelNome;
    if (!name || name === "Sem corretor") return "SC";
    const parts = name.trim().split(/\s+/).filter(Boolean);
    if (parts.length === 0) return "SC";
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    const firstLetter = parts[0]?.[0] || "";
    const lastLetter = parts[parts.length - 1]?.[0] || "";
    return (firstLetter + lastLetter).toUpperCase() || "SC";
  }, [responsavelNome]);

  // Dynamic Timeline Events
  const timelineEvents = useMemo(() => {
    const events: Array<{
      id: string;
      title: string;
      description: string;
      date: Date;
      icon: any;
      color: string;
    }> = [];

    const parseSafeTimelineDate = (dValue: any) => {
      if (!dValue) return new Date();
      const d = new Date(dValue);
      return isNaN(d.getTime()) ? new Date() : d;
    };

    // 1. Client registration
    if (client) {
      events.push({
        id: "client-creation",
        title: "Ficha Cadastral Criada",
        description: `Cliente registrado no sistema como ${(client.tipo_pessoa === "fisica" || client.tipo_pessoa === "pf") ? "Pessoa Física" : "Pessoa Jurídica"}.`,
        date: parseSafeTimelineDate(client.created_at),
        icon: User,
        color: "bg-indigo-600 text-white"
      });
    }

    // 2. Policies
    if (policies && policies.length > 0) {
      policies.forEach((policy) => {
        events.push({
          id: `policy-${policy.id}`,
          title: "Nova Apólice Emitida",
          description: `${policy.produto?.nome || "Seguro"} - ${policy.seguradora || "Seguradora"} [Ref: ${policy.numero_apolice || "N/D"}]`,
          date: parseSafeTimelineDate(policy.created_at),
          icon: ShieldCheck,
          color: "bg-emerald-500 text-white"
        });
      });
    }

    // 3. Notes/Anotações
    if (notes && notes.length > 0) {
      notes.forEach((note) => {
        events.push({
          id: `note-${note.id}`,
          title: "Anotação Interna",
          description: `"${note.conteudo}"`,
          date: parseSafeTimelineDate(note.created_at),
          icon: MessageSquare,
          color: "bg-amber-500 text-white"
        });
      });
    }

    // 4. Sinistros
    if (sinistros && sinistros.length > 0) {
      sinistros.forEach((sinistro) => {
        events.push({
          id: `sinistro-${sinistro.id}`,
          title: `Sinistro Comunicado`,
          description: `Sinistro Nº ${sinistro.numero_sinistro} (${sinistro.descricao_resumida}) registrado com status: ${sinistro.status}.`,
          date: parseSafeTimelineDate(sinistro.created_at),
          icon: AlertTriangle,
          color: "bg-rose-500 text-white"
        });
      });
    }

    // 5. Documents
    if (documents && documents.length > 0) {
      documents.forEach((doc) => {
        events.push({
          id: `doc-${doc.id}`,
          title: "Documento Anexado",
          description: `Documento "${doc.nome}" adicionado com sucesso.`,
          date: parseSafeTimelineDate(doc.created_at),
          icon: FileText,
          color: "bg-indigo-400 text-white"
        });
      });
    }

    // Sort chronologically descending (most recent first)
    return events.sort((a, b) => b.date.getTime() - a.date.getTime());
  }, [client, policies, notes, sinistros, documents]);

  // Derived Data
  const { settings: ltvSettings } = useLtvSettings();
  
  // Use centralized financial calculation engine supporting policy metadata, active client agreements and product catalog
  const {
    activePolicies,
    totalPremium,
    totalCommissionAnual,
    mrrEquivalente,
    ltvContratado,
    ltvProjetado,
    averagePremiumPerPolicy,
    averageCommission,
  } = useMemo(() => {
    return calculateClientFinancials(policies, activeCommissions, ltvSettings);
  }, [policies, activeCommissions, ltvSettings]);

  const ltvRuleText = useMemo(() => {
    if (ltvSettings.regraCalculo === "anos_retencao") {
      return `Retenção estimada: ${ltvSettings.tempoPermanencia} anos`;
    } else if (ltvSettings.regraCalculo === "taxa_renovacao") {
      return `Taxa renovação: ${ltvSettings.taxaRenovacao}% (Churn ${ltvSettings.churnAnual}%)`;
    } else {
      return `Probabilidade acum. (${ltvSettings.tempoPermanencia} anos a ${ltvSettings.taxaRenovacao}%)`;
    }
  }, [ltvSettings]);

  const nextRenewal = useMemo(() => {
    if (!policies || policies.length === 0) return null;
    const validPolicies = policies.filter(p => p.data_fim && !isNaN(new Date(p.data_fim).getTime()));
    if (validPolicies.length === 0) return null;
    return [...validPolicies].sort((a, b) => new Date(a.data_fim).getTime() - new Date(b.data_fim).getTime())[0];
  }, [policies]);

  const daysToRenewal = useMemo(() => {
    if (!nextRenewal?.data_fim) return null;
    const renewalDate = new Date(nextRenewal.data_fim);
    if (isNaN(renewalDate.getTime())) return null;
    return differenceInDays(renewalDate, new Date());
  }, [nextRenewal]);

  if (loadingClient) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-[70vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AppLayout>
    );
  }

  if (!client) {
    return (
      <AppLayout>
        <div className="flex flex-col items-center justify-center h-[70vh] space-y-4">
          <AlertCircle className="h-12 w-12 text-destructive" />
          <h2 className="text-xl font-bold">Cliente não encontrado</h2>
          <Button onClick={() => navigate("/clientes")}>Voltar para lista</Button>
        </div>
      </AppLayout>
    );
  }

  const getStatusBadge = (status: string) => {
    const rawStatus = (crmStage || status)?.toLowerCase();
    
    switch (rawStatus) {
      case "ativo":
      case "convertido":
        return <Badge className="bg-success/10 text-success border-success/20">Ativo</Badge>;
      case "prospecto":
      case "contato":
      case "lead_quente":
      case "qualificado":
      case "cotacao":
      case "negociacao":
        return <Badge className="bg-warning/10 text-warning border-warning/20">Prospecto</Badge>;
      case "inativo":
      case "perdido":
      case "pos_venda":
        return <Badge className="bg-muted text-muted-foreground border-border">Inativo</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <AppLayout>
      <div className="content-wrapper space-y-6">
        {/* Breadcrumbs & Actions */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={() => navigate("/clientes")}>
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold tracking-tight">{client.nome}</h1>
                {getStatusBadge(client.status)}
              </div>
              <p className="text-sm text-muted-foreground">ID: {client.cpf_cnpj || client.id.slice(0, 8)}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="gap-2"
              onClick={() => setIsEditClientModalOpen(true)}
            >
              <Pencil className="h-4 w-4" /> Editar Ficha
            </Button>
            <Button size="sm" className="gap-2" onClick={handleOpenCreate}>
              <Plus className="h-4 w-4" /> Nova Apólice
            </Button>
          </div>
        </div>

        {/* Divergence Alert Warning Banner */}
        {(() => {
          if (!client || !policies) return null;
          
          const syncResult = getExpectedClientStatus(client.status, policies);
          if (!syncResult.hasDivergence) return null;

          const isProspect = client.status === "prospecto";
          const isAtivo = client.status === "ativo";

          if (syncResult.expectedStatus === "ativo" && (isProspect || client.status === "inativo")) {
            return (
              <div className="p-4 bg-amber-500/10 border border-amber-500/20 text-amber-900 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 animate-in slide-in-from-top-4 duration-300">
                <div className="flex items-start gap-3 text-sm font-medium">
                  <span className="text-lg">⚠️</span>
                  <div className="space-y-1">
                    <p className="font-bold text-amber-950">Inconsistência de Status Cadastral Detectada</p>
                    <p className="text-xs text-amber-800">
                      Este cliente possui apólice **Vigente (Ativa)**, mas o cadastro consta como **{client.status === "prospecto" ? "Prospecto" : "Inativo"}**.
                    </p>
                  </div>
                </div>
                <Button
                  size="sm"
                  onClick={() => updateClient.mutate({ id: client.id, status: "ativo" })}
                  disabled={updateClient.isPending}
                  className="bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition-all shadow-md shrink-0"
                >
                  {updateClient.isPending ? "Corrigindo..." : "Sincronizar para Cliente Ativo"}
                </Button>
              </div>
            );
          }
          
          if (syncResult.expectedStatus === "inativo" && isAtivo) {
            return (
              <div className="p-4 bg-amber-500/10 border border-amber-500/20 text-amber-900 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 animate-in slide-in-from-top-4 duration-300">
                <div className="flex items-start gap-3 text-sm font-medium">
                  <span className="text-lg">⚠️</span>
                  <div className="space-y-1">
                    <p className="font-bold text-amber-950">Divergência Cadastral Baseada em Apólices</p>
                    <p className="text-xs text-amber-800">
                      Todas as apólices deste cliente estão finalizadas (Canceladas ou Expiradas), mas o cadastro permanece como **Ativo**.
                    </p>
                  </div>
                </div>
                <Button
                  size="sm"
                  onClick={() => updateClient.mutate({ id: client.id, status: "inativo" })}
                  disabled={updateClient.isPending}
                  className="bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition-all shadow-md shrink-0"
                >
                  {updateClient.isPending ? "Inativando..." : "Sincronizar para Cliente Inativo"}
                </Button>
              </div>
            );
          }

          return null;
        })()}

        {/* Top KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
          {/* Prêmio Anual */}
          <Card className="bg-card">
            <CardContent className="p-4 flex flex-col justify-between h-full min-h-[110px]">
              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground font-medium">Prêmio Anual</p>
                <div className="h-7 w-7 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                  <ShieldCheck className="h-4 w-4" />
                </div>
              </div>
              <div className="mt-2">
                <p className="text-lg font-bold">R$ {totalPremium.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5" title="Prêmio Médio por Apólice">
                  Médio/Ap: R$ {averagePremiumPerPolicy.toLocaleString("pt-BR", { minimumFractionDigits: 0, maximumFractionDigits: 2 })}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Comissão Anual Bruta */}
          <Card className="bg-card">
            <CardContent className="p-4 flex flex-col justify-between h-full min-h-[110px]">
              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground font-medium">Comissão Anual</p>
                <div className="h-7 w-7 rounded-full bg-success/10 flex items-center justify-center text-success">
                  <DollarSign className="h-4 w-4" />
                </div>
              </div>
              <div className="mt-2">
                <p className="text-lg font-bold">R$ {totalCommissionAnual.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5" title="Ticket Médio de Comissão da Corretora">
                  Ticket Médio: R$ {averageCommission.toLocaleString("pt-BR", { minimumFractionDigits: 0, maximumFractionDigits: 2 })}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* MRR Equivalente */}
          <Card className="bg-card">
            <CardContent className="p-4 flex flex-col justify-between h-full min-h-[110px]">
              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground font-medium">MRR Equivalente</p>
                <div className="h-7 w-7 rounded-full bg-indigo-500/10 flex items-center justify-center text-indigo-500">
                  <Clock className="h-4 w-4" />
                </div>
              </div>
              <div className="mt-2">
                <p className="text-lg font-bold">R$ {mrrEquivalente.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">
                  Receita mensalizada
                </p>
              </div>
            </CardContent>
          </Card>

          {/* LTV Contratado */}
          <Card className="bg-card">
            <CardContent className="p-4 flex flex-col justify-between h-full min-h-[110px]">
              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground font-medium">LTV Contratado</p>
                <div className="h-7 w-7 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-500">
                  <TrendingUp className="h-4 w-4" />
                </div>
              </div>
              <div className="mt-2">
                <p className="text-lg font-bold">R$ {ltvContratado.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">
                  Receita da vigência atual
                </p>
              </div>
            </CardContent>
          </Card>

          {/* LTV Projetado */}
          <Card className="bg-card border-primary/20 bg-primary/5">
            <CardContent className="p-4 flex flex-col justify-between h-full min-h-[110px]">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-primary">LTV Projetado</p>
                <div className="h-7 w-7 rounded-full bg-primary/20 flex items-center justify-center text-primary animate-pulse">
                  <Target className="h-4 w-4" />
                </div>
              </div>
              <div className="mt-2">
                <p className="text-lg font-black text-primary">R$ {ltvProjetado.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                <p className="text-[9px] font-medium text-primary/80 mt-0.5 leading-snug" title={ltvRuleText}>
                  {ltvRuleText}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Vencimento Próximo & Produtos */}
          <Card className="bg-card">
            <CardContent className="p-4 flex flex-col justify-between h-full min-h-[110px]">
              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground font-medium">Situação Geral</p>
                <div className={`h-7 w-7 rounded-full flex items-center justify-center ${daysToRenewal !== null && daysToRenewal <= 45 ? "bg-destructive/10 text-destructive animate-bounce" : "bg-muted text-muted-foreground"}`}>
                  <AlertTriangle className="h-4 w-4" />
                </div>
              </div>
              <div className="mt-2">
                <p className={`text-lg font-bold ${daysToRenewal !== null && daysToRenewal <= 45 ? "text-destructive" : ""}`}>
                  {daysToRenewal !== null ? (daysToRenewal <= 0 ? "Vencido" : `${daysToRenewal} dias`) : "Sem prazos"}
                </p>
                <p className="text-[10px] text-muted-foreground mt-0.5">
                  {activePolicies.length} produto(s) ativo(s)
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Sidebar - Cadastro */}
          <div className="lg:col-span-3 space-y-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold">Dados Cadastrais</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 pt-4">
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12 border-2 border-primary/10">
                    <AvatarFallback className="bg-muted">
                      {client.nome ? client.nome.split(/\s+/).filter(Boolean).map(n => n[0] || "").join("").slice(0, 2).toUpperCase() : "CL"}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-xs text-muted-foreground">Tipo</p>
                    <p className="text-sm font-semibold capitalize">{(client.tipo_pessoa === 'fisica' || client.tipo_pessoa === 'pf') ? 'Pessoa Física' : 'Pessoa Jurídica'}</p>
                  </div>
                </div>

                <div className="space-y-3 pt-2">
                  <div className="flex items-start gap-2 text-sm">
                    <Briefcase className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-xs text-muted-foreground">Profissão</p>
                      <p className="font-medium">{client.profissao || "Não informado"}</p>
                    </div>
                  </div>
                  {client.profissao?.toLowerCase().includes("médic") && (
                    <div className="flex items-start gap-2 text-sm">
                      <Stethoscope className="h-4 w-4 text-primary mt-0.5" />
                      <div>
                        <p className="text-xs text-muted-foreground">Especialidade</p>
                        <p className="font-medium">Cardiologia (Exemplo)</p>
                      </div>
                    </div>
                  )}
                  <div className="flex items-start gap-2 text-sm">
                    <Mail className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div className="overflow-hidden">
                      <p className="text-xs text-muted-foreground">Email</p>
                      <p className="font-medium truncate">{client.email || "Não informado"}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2 text-sm">
                    <Phone className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-xs text-muted-foreground">Telefone</p>
                      <p className="font-medium">{client.telefone || "Não informado"}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2 text-sm">
                    <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-xs text-muted-foreground">Endereço</p>
                      <p className="font-medium text-xs leading-relaxed">
                        {client.endereco ? `${client.endereco}, ${client.cidade}/${client.estado}` : "Sem endereço cadastrado"}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-xs text-muted-foreground">Nascimento</p>
                      <p className="font-medium">
                        {client.data_nascimento ? formatDate(client.data_nascimento, "dd/MM/yyyy") : "Não informado"}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="pt-4 mt-4 border-t border-dashed">
                  <p className="text-xs text-muted-foreground mb-2 font-semibold">RESPONSÁVEL</p>
                  <div className="flex items-center gap-2">
                    <div className="h-6 w-6 rounded-full bg-indigo-100 flex items-center justify-center text-[10px] text-indigo-600 font-bold font-mono">
                      {responsavelInitials}
                    </div>
                    <p className="text-sm font-medium">{responsavelNome}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-primary/5 border-primary/10">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  <Target className="h-4 w-4 text-primary" /> Cross-Selling AI
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 pt-2">
                <div className="p-2 rounded-lg bg-background border border-primary/10">
                  <p className="text-xs font-bold text-primary">OPORTUNIDADE</p>
                  <p className="text-[11px] font-medium leading-tight mt-1">
                    Cliente possui RCP mas não tem Previdência Privada.
                  </p>
                  <Button variant="link" className="p-0 h-auto text-[10px] mt-1 text-primary">
                    Gerar proposta <ArrowUpRight className="h-3 w-3 ml-1" />
                  </Button>
                </div>
                <div className="p-2 rounded-lg bg-background border border-primary/10 opacity-60">
                  <p className="text-xs font-bold text-muted-foreground">OPORTUNIDADE</p>
                  <p className="text-[11px] font-medium leading-tight mt-1">
                    Seguro Residencial vencendo em outro provedor (Informado).
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content Area */}
          <div className="lg:col-span-9">
            <Tabs defaultValue="historico" className="w-full">
              <TabsList className="grid w-full grid-cols-5 mb-6 bg-muted/50 p-1">
                <TabsTrigger value="historico" className="gap-2">
                  <History className="h-4 w-4" /> Resumo
                </TabsTrigger>
                <TabsTrigger value="apolices" className="gap-2">
                  <ShieldCheck className="h-4 w-4" /> Apólices
                </TabsTrigger>
                <TabsTrigger value="financeiro" className="gap-2">
                  <DollarSign className="h-4 w-4" /> Financeiro
                </TabsTrigger>
                <TabsTrigger value="sinistros" className="gap-2">
                  <AlertTriangle className="h-4 w-4" /> Sinistros
                </TabsTrigger>
                <TabsTrigger value="documentos" className="gap-2">
                  <FileText className="h-4 w-4" /> Docs
                </TabsTrigger>
              </TabsList>

              {/* TAB: HISTÓRICO / RESUMO */}
              <TabsContent value="historico" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Timeline */}
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base font-bold flex items-center gap-2">
                        <Clock className="h-5 w-5 text-muted-foreground" />
                        Linha do Tempo
                      </CardTitle>
                      <CardDescription>Eventos e interações recentes</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {timelineEvents.length > 0 ? (
                        <div className="space-y-4 relative before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-0.5 before:bg-muted">
                          {timelineEvents.map((event) => {
                            const IconComponent = event.icon;
                            return (
                              <div key={event.id} className="relative pl-8">
                                <div className={`absolute left-0 top-1 h-6 w-6 rounded-full ${event.color} flex items-center justify-center border-2 border-background`}>
                                  <IconComponent className="h-3 w-3" />
                                </div>
                                <div className="space-y-0.5">
                                  <p className="text-sm font-semibold leading-none">{event.title}</p>
                                  <p className="text-xs text-muted-foreground leading-normal">{event.description}</p>
                                  <p className="text-[9px] text-muted-foreground">
                                    {formatDate(event.date, "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                                  </p>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        <div className="text-center py-6">
                          <Clock className="h-8 w-8 text-muted-foreground/30 mx-auto mb-2" />
                          <p className="text-sm text-muted-foreground">Nenhuma atividade registrada.</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Quick Notes */}
                  <Card>
                    <CardHeader className="pb-2 flex flex-row items-center justify-between">
                      <div>
                        <CardTitle className="text-base font-bold">Anotações Diversas</CardTitle>
                        <CardDescription>Consulte informações rápidas</CardDescription>
                      </div>
                      <ClientNotesModal
                        clientId={client.id}
                        clientName={client.nome}
                        trigger={
                          <Button variant="outline" size="icon" className="h-8 w-8" title="Adicionar / Gerenciar Anotações">
                            <Plus className="h-4 w-4" />
                          </Button>
                        }
                      />
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {notes?.slice(0, 3).map((note) => (
                          <div key={note.id} className="p-3 rounded-lg border bg-muted/10 text-sm">
                            <p className="leading-relaxed">{note.conteudo}</p>
                            <div className="flex items-center justify-between mt-2">
                              <span className="text-[10px] text-muted-foreground">{formatDate(note.created_at, "dd/MM/yyyy HH:mm")}</span>
                              <ClientNotesModal
                                clientId={client.id}
                                clientName={client.nome}
                                trigger={
                                  <Button variant="ghost" size="icon" className="h-5 w-5">
                                    <Pencil className="h-3 w-3 text-muted-foreground" />
                                  </Button>
                                }
                              />
                            </div>
                          </div>
                        ))}
                        {(!notes || notes.length === 0) && (
                          <div className="text-center py-8">
                            <MessageSquare className="h-8 w-8 text-muted-foreground/30 mx-auto mb-2" />
                            <p className="text-sm text-muted-foreground">Sem anotações.</p>
                          </div>
                        )}
                        {notes && notes.length > 0 && (
                          <ClientNotesModal
                            clientId={client.id}
                            clientName={client.nome}
                            trigger={
                              <Button variant="ghost" className="w-full mt-2 text-xs">
                                Gerenciar todas as anotações ({notes.length})
                              </Button>
                            }
                          />
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* TAB: APÓLICES */}
              <TabsContent value="apolices">
                <Card>
                  <CardContent className="p-0">
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead className="text-xs text-muted-foreground uppercase bg-muted/30 border-b">
                          <tr>
                            <th className="px-6 py-3 font-semibold">Produto / Seguradora</th>
                            <th className="px-6 py-3 font-semibold">Status</th>
                            <th className="px-6 py-3 font-semibold text-right">Comissão Prevista</th>
                            <th className="px-6 py-3 font-semibold text-right">Prêmio</th>
                            <th className="px-6 py-3 font-semibold text-center">Início / Fim</th>
                            <th className="px-6 py-3 font-semibold text-right">Ações</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y border-b">
                          {policies?.map((policy) => {
                            const comm = calculatePolicyCommission(policy, activeCommissions);
                            return (
                            <tr key={policy.id} className="hover:bg-muted/10 transition-colors">
                              <td className="px-6 py-4">
                                <p className="font-semibold">{policy.produto?.nome || "Produto"}</p>
                                <p className="text-xs text-muted-foreground">{policy.seguradora || "Seguradora"}</p>
                                <p className="text-[10px] font-mono mt-1">#{policy.numero_apolice}</p>
                              </td>
                              <td className="px-6 py-4">
                                <Badge className={
                                  policy.status === "ativa" ? "bg-emerald-500/10 hover:bg-emerald-500/15 text-emerald-700 border border-emerald-500/20 shadow-none font-semibold text-xs py-0.5 px-2 whitespace-nowrap" :
                                  policy.status === "pendente" ? "bg-amber-500/10 hover:bg-amber-500/15 text-amber-700 border border-amber-500/20 shadow-none font-semibold text-xs py-0.5 px-2 whitespace-nowrap" :
                                  policy.status === "cancelada" ? "bg-rose-500/10 hover:bg-rose-500/15 text-rose-700 border border-rose-500/20 shadow-none font-semibold text-xs py-0.5 px-2 whitespace-nowrap" :
                                  "bg-neutral-500/10 hover:bg-neutral-500/15 text-neutral-600 border border-neutral-500/20 shadow-none font-semibold text-xs py-0.5 px-2 whitespace-nowrap"
                                }>
                                  {policy.status === "ativa" ? "Vigente (Ativa)" :
                                   policy.status === "pendente" ? "Proposta (Pendente)" :
                                   policy.status === "expirada" ? "Vencida" : "Cancelada"}
                                </Badge>
                              </td>
                              <td className="px-6 py-4 text-right">
                                <div className="flex flex-col items-end">
                                  <span className="font-semibold text-emerald-600">
                                    R$ {comm.valor.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                  </span>
                                  <span className="text-[10px] text-muted-foreground">
                                    {comm.percent.toFixed(1)}% comissão
                                  </span>
                                </div>
                              </td>
                              <td className="px-6 py-4 text-right font-medium">
                                R$ {policy.valor_premio?.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                              </td>
                              <td className="px-6 py-4 text-center">
                                <p className="text-xs">{formatDate(policy.data_inicio, "dd/MM/yyyy")}</p>
                                <p className="text-[10px] text-muted-foreground mt-0.5">até {formatDate(policy.data_fim, "dd/MM/yyyy")}</p>
                              </td>
                              <td className="px-6 py-4 text-right">
                                <div className="flex items-center justify-end gap-1">
                                  {policy.status === "pendente" && (
                                    <Button 
                                      variant="outline" 
                                      size="sm" 
                                      className="h-8 gap-1 px-2 bg-emerald-50 hover:bg-emerald-100 hover:text-emerald-800 text-emerald-700 border-emerald-200 font-semibold text-xs mr-2 transition-all"
                                      onClick={() => handleOpenEmit(policy)}
                                      title="Emitir Apólice (Ativar Proposta)"
                                    >
                                      <ShieldCheck className="h-3.5 w-3.5" /> Emitir Apólice
                                    </Button>
                                  )}
                                  <ApoliceDocumentsModal
                                    apoliceId={policy.id}
                                    apoliceNumero={policy.numero_apolice}
                                    trigger={
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-8 w-8 text-muted-foreground hover:text-primary"
                                        title="Documentos da Apólice"
                                      >
                                        <Paperclip className="h-4 w-4" />
                                      </Button>
                                    }
                                  />
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    className="h-8 w-8 text-muted-foreground hover:text-primary"
                                    onClick={() => handleOpenEdit(policy)}
                                    title="Editar Apólice"
                                  >
                                    <Pencil className="h-4 w-4" />
                                  </Button>
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                                    onClick={() => setPolicyToDelete(policy)}
                                    title="Excluir Apólice"
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                          {(!policies || policies.length === 0) && (
                            <tr>
                              <td colSpan={6} className="px-6 py-12 text-center text-muted-foreground">
                                Nenhuma apólice cadastrada.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* TAB: FINANCEIRO / COMISSÕES */}
              <TabsContent value="financeiro" className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Client Commission Terms (The "Agreement") */}
                  <ClientCommissionSection clientId={id!} />

                  {/* Comission History Chart */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base font-bold">Histórico de Receita (Realizado)</CardTitle>
                      <CardDescription>Volume anual de comissões liquidadas</CardDescription>
                    </CardHeader>
                    <CardContent className="h-[250px] pt-4">
                      {commissionChartData.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={commissionChartData}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--muted)/0.3)" />
                            <XAxis 
                              dataKey="year" 
                              axisLine={false} 
                              tickLine={false} 
                              tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} 
                              dy={10}
                            />
                            <YAxis 
                              axisLine={false} 
                              tickLine={false} 
                              tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} 
                              tickFormatter={(val) => `R$ ${val/1000}k`}
                            />
                            <RechartsTooltip 
                              cursor={{ fill: "hsl(var(--muted)/0.1)" }}
                              contentStyle={{ 
                                backgroundColor: "hsl(var(--card))", 
                                borderColor: "hsl(var(--border))",
                                borderRadius: "8px",
                                fontSize: "12px"
                              }}
                            />
                            <Bar dataKey="total" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} barSize={40} />
                          </BarChart>
                        </ResponsiveContainer>
                      ) : (
                        <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                          <DollarSign className="h-10 w-10 mb-2 opacity-20" />
                          <p className="text-sm">Sem histórico financeiro para gerar gráfico.</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>

                {/* Historical Commission Entries (Traceability) */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle className="text-base font-bold">Extrato de Lançamentos</CardTitle>
                      <CardDescription>Rastreabilidade completa de repasses e ajustes</CardDescription>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="gap-2"
                      onClick={() => setIsAdjustmentOpen(true)}
                    >
                       <ArrowRightLeft className="h-4 w-4" /> Ajuste Operacional
                    </Button>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-left">
                        <thead className="text-muted-foreground uppercase bg-muted/30 border-b">
                          <tr>
                            <th className="px-6 py-3 font-semibold">Competência</th>
                            <th className="px-6 py-3 font-semibold">Tipo</th>
                            <th className="px-6 py-3 font-semibold">Origem (Apólice)</th>
                            <th className="px-6 py-3 font-semibold text-right">Comissão</th>
                            <th className="px-6 py-3 font-semibold text-center">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {commissionEntries?.map((entry) => (
                            <tr key={entry.id} className="hover:bg-muted/10 transition-colors">
                              <td className="px-6 py-4 font-medium">
                                {formatDate(entry.competencia ? entry.competencia + "-02" : null, "MMM/yyyy", { locale: ptBR })}
                              </td>
                              <td className="px-6 py-4">
                                <Badge variant="outline" className="capitalize text-[10px]">
                                  {entry.tipo_lancamento.replace('_', ' ')}
                                </Badge>
                              </td>
                              <td className="px-6 py-4">
                                <p className="font-semibold">{entry.produtoNome}</p>
                                <p className="text-[10px] text-muted-foreground">#{entry.numeroApolice}</p>
                              </td>
                              <td className="px-6 py-4 text-right font-bold text-primary">
                                R$ {(entry.valorComissao || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                                {entry.percentualComissao && <span className="text-[10px] ml-1 font-normal text-muted-foreground">({entry.percentualComissao}%)</span>}
                              </td>
                              <td className="px-6 py-4 text-center">
                                <Badge className={
                                  entry.status === 'recebida' ? 'bg-success/10 text-success border-success/20' : 
                                  entry.status === 'atrasada' ? 'bg-destructive/10 text-destructive border-destructive/20' :
                                  'bg-warning/10 text-warning border-warning/20'
                                }>
                                  {entry.status}
                                </Badge>
                              </td>
                            </tr>
                          ))}
                          {(!commissionEntries || commissionEntries.length === 0) && (
                            <tr>
                              <td colSpan={5} className="px-6 py-12 text-center text-muted-foreground">
                                <p>Nenhum lançamento financeiro registrado.</p>
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* TAB: SINISTROS */}
              <TabsContent value="sinistros">
                <Card>
                  <CardContent className="p-0">
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead className="text-xs text-muted-foreground uppercase bg-muted/30 border-b">
                          <tr>
                            <th className="px-6 py-3 font-semibold">Cód / Descrição</th>
                            <th className="px-6 py-3 font-semibold">Status</th>
                            <th className="px-6 py-3 font-semibold">Ocorrência</th>
                            <th className="px-6 py-3 font-semibold text-right">Ações</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y border-b text-sm">
                          {sinistros?.map((sinistro) => (
                            <tr key={sinistro.id} className="hover:bg-muted/10">
                              <td className="px-6 py-4">
                                <p className="font-semibold text-destructive">{sinistro.numero_sinistro}</p>
                                <p className="text-xs text-muted-foreground">{sinistro.descricao_resumida}</p>
                              </td>
                              <td className="px-6 py-4">
                                <Badge variant="outline" className={sinistro.status === 'aberto' ? 'border-destructive text-destructive' : ''}>
                                  {sinistro.status}
                                </Badge>
                              </td>
                              <td className="px-6 py-4">
                                {formatDate(sinistro.data_ocorrencia, "dd/MM/yyyy")}
                              </td>
                              <td className="px-6 py-4 text-right">
                                <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-destructive/10">
                                  <ChevronLeft className="h-4 w-4 rotate-180" />
                                </Button>
                              </td>
                            </tr>
                          ))}
                          {(!sinistros || sinistros.length === 0) && (
                            <tr>
                              <td colSpan={4} className="px-6 py-12 text-center text-muted-foreground">
                                Sem registros de sinistros para este cliente.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* TAB: DOCUMENTOS */}
              <TabsContent value="documentos">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle className="text-base font-bold">Arquivo de Documentos</CardTitle>
                      <CardDescription>Upload de apólices, vistorias e docs pessoais</CardDescription>
                    </div>
                    <div>
                      <input
                        type="file"
                        id="client-doc-upload"
                        className="hidden"
                        onChange={handleDocUpload}
                        disabled={isUploadingDoc}
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-2"
                        disabled={isUploadingDoc}
                        onClick={() => document.getElementById("client-doc-upload")?.click()}
                      >
                         {isUploadingDoc ? (
                           <Loader2 className="h-4 w-4 animate-spin" />
                         ) : (
                           <Plus className="h-4 w-4" />
                         )}
                         {isUploadingDoc ? "Adicionando..." : "Enviar"}
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {documents?.map((doc) => (
                        <div key={doc.id} className="p-4 rounded-xl border bg-card flex items-start gap-3 hover:shadow-md transition-shadow">
                          <div className="h-10 w-10 rounded-lg bg-muted flex items-center justify-center shrink-0">
                            {doc.tipo === 'pdf' ? <FileText className="h-5 w-5 text-red-500" /> : <FileText className="h-5 w-5 text-blue-500" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold truncate">{doc.nome}</p>
                            <p className="text-[10px] text-muted-foreground uppercase">{doc.tipo} • {Math.round((doc.tamanho || 0) / 1024)} KB</p>
                            <div className="flex items-center gap-2 mt-2">
                              <button 
                                onClick={() => handleDocView(doc.url)} 
                                className="text-[10px] font-bold text-primary hover:underline uppercase"
                              >
                                Visualizar
                              </button>
                              <span className="text-[10px] text-muted-foreground/30">•</span>
                              <button 
                                onClick={async () => {
                                  if (confirm("Deseja realmente excluir este documento?")) {
                                    try {
                                      await deleteDocument.mutateAsync({ id: doc.id, clientId: id!, url: doc.url });
                                    } catch (err) {
                                      // error already handled by mutation toast
                                    }
                                  }
                                }}
                                disabled={deleteDocument.isPending}
                                className="text-[10px] font-bold text-destructive hover:underline uppercase disabled:opacity-50"
                              >
                                {deleteDocument.isPending ? "Excluindo..." : "Excluir"}
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                      {(!documents || documents.length === 0) && (
                        <div className="col-span-full py-12 text-center text-muted-foreground">
                          Nenhum documento anexado.
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
        <CommissionAdjustmentDialog 
          clientId={id!} 
          isOpen={isAdjustmentOpen} 
          onOpenChange={setIsAdjustmentOpen} 
        />
        <ApoliceFormModal
          isOpen={isPolicyModalOpen}
          onOpenChange={setIsPolicyModalOpen}
          clientId={id!}
          editingApolice={editingPolicy}
        />
        {client && (
          <ClientFormModal
            open={isEditClientModalOpen}
            onOpenChange={setIsEditClientModalOpen}
            onSubmit={(data, commissionPercent) => {
              updateClient.mutate({ id: client.id, ...data }, {
                onSuccess: () => {
                  if (commissionPercent !== undefined && commissionPercent !== null && !isNaN(commissionPercent) && commissionPercent > 0) {
                    createCommission.mutate({
                      client_id: client.id,
                      model: "percentual",
                      percent: commissionPercent,
                      starts_at: new Date().toISOString().split('T')[0],
                      is_active: true,
                      created_by: user?.id || null,
                    });
                  }
                  setIsEditClientModalOpen(false);
                }
              });
            }}
            editData={client}
            isLoading={updateClient.isPending}
          />
        )}
        <AlertDialog open={!!policyToDelete} onOpenChange={(open) => !open && setPolicyToDelete(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Confirmar exclusão da apólice</AlertDialogTitle>
              <AlertDialogDescription>
                Tem certeza que deseja excluir esta apólice? Esta ação irá remover o registro e arquivá-lo com segurança no sistema.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={archiveApolice.isPending}>Cancelar</AlertDialogCancel>
              <AlertDialogAction 
                onClick={(e) => {
                  e.preventDefault();
                  handleDeletePolicy();
                }}
                disabled={archiveApolice.isPending}
                className="bg-destructive hover:bg-destructive/90 text-destructive-foreground font-semibold"
              >
                {archiveApolice.isPending ? "Excluindo..." : "Excluir"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AppLayout>
  );
}
