import { useState, useEffect } from "react";
import { AppLayout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Settings,
  User,
  Bell,
  Palette,
  Shield,
  Save,
  Loader2,
  Mail,
  Camera,
  FlaskConical,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  Trash2,
  Plus,
  RefreshCw,
  Users,
  History,
  TrendingUp,
  PieChart,
  Sparkles,
  Database,
  Calculator,
  BarChart3,
} from "lucide-react";
import { TeamMembersList } from "@/components/team/TeamMembersList";
import { AuditoriaTab } from "@/components/configuracoes/AuditoriaTab";
import { useAuth } from "@/hooks/useAuth";
import { useTheme } from "@/hooks/useTheme";
import { useLtvSettings, computeSystemMetricsFromDatabase, calculateLtvValue } from "@/hooks/useLtvSettings";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useUserRole } from "@/hooks/useUserRole";
import { useTestDataStatus, useClearAllTestData, usePopulateEverything } from "@/hooks/useTestData";

export default function Configuracoes() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("perfil");
  
  const { data: userRole } = useUserRole();
  const { data: testDataStatus } = useTestDataStatus();
  const clearTestDataMutation = useClearAllTestData();
  const populateEverythingMutation = usePopulateEverything();

  // LTV and Commercial metrics configurations state
  const { 
    settings: ltvSettings, 
    systemMetrics, 
    isLoadingMetrics, 
    saveSettings: saveLtvSettings, 
    isSaving: savingLtvSettings 
  } = useLtvSettings();

  const [metricSettings, setMetricSettings] = useState({
    tempoPermanencia: 3,
    taxaRenovacao: 85,
    churnAnual: 15,
    regraCalculo: "anos_retencao" as "anos_retencao" | "taxa_renovacao" | "probabilidade_acumulada",
    modoCalculo: "automatico" as "automatico" | "manual",
  });

  const [isRecalculating, setIsRecalculating] = useState(false);

  // Sync settings when they load
  useEffect(() => {
    if (ltvSettings) {
      setMetricSettings({
        tempoPermanencia: ltvSettings.tempoPermanencia ?? 3,
        taxaRenovacao: ltvSettings.taxaRenovacao ?? 85,
        churnAnual: ltvSettings.churnAnual ?? 15,
        regraCalculo: ltvSettings.regraCalculo ?? "anos_retencao",
        modoCalculo: ltvSettings.modoCalculo ?? "automatico",
      });
    }
  }, [ltvSettings]);

  const handleRecalculateSystemMetrics = async () => {
    setIsRecalculating(true);
    try {
      const freshMetrics = await computeSystemMetricsFromDatabase();
      const newSettings = {
        ...metricSettings,
        tempoPermanencia: freshMetrics.tempoPermanencia,
        taxaRenovacao: freshMetrics.taxaRenovacao,
        churnAnual: freshMetrics.churnAnual,
        modoCalculo: "automatico" as const,
        lastAutoSync: freshMetrics.calculatedAt,
      };
      setMetricSettings(newSettings);
      await saveLtvSettings(newSettings);
      queryClient.invalidateQueries({ queryKey: ["system_calculated_metrics"] });
      queryClient.invalidateQueries({ queryKey: ["ltv_settings"] });
      toast.success("Indicadores e LTV recalculados automaticamente com sucesso com base na base de dados!");
    } catch (e) {
      console.error(e);
      toast.error("Erro ao recalcular indicadores do sistema");
    } finally {
      setIsRecalculating(false);
    }
  };

  const handleSaveMetricSettings = async () => {
    try {
      await saveLtvSettings(metricSettings);
      toast.success("Configurações comerciais e de LTV atualizadas com sucesso!");
    } catch (e) {
      toast.error("Erro ao salvar as configurações");
    }
  };

  // Buscar perfil do usuário
  const { data: profile, isLoading: loadingProfile } = useQuery({
    queryKey: ["profile", user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  // Estado do formulário de perfil
  const [profileForm, setProfileForm] = useState({
    full_name: "",
    phone: "",
  });

  // Atualizar estado quando profile carrega
  useState(() => {
    if (profile) {
      setProfileForm({
        full_name: profile.full_name || "",
        phone: profile.phone || "",
      });
    }
  });

  // Mutation para atualizar perfil
  const updateProfile = useMutation({
    mutationFn: async (data: { full_name: string; phone: string }) => {
      const { error } = await supabase
        .from("profiles")
        .update({
          full_name: data.full_name,
          phone: data.phone,
          updated_at: new Date().toISOString(),
        })
        .eq("id", user?.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["profile"] });
      toast.success("Perfil atualizado com sucesso");
    },
    onError: () => {
      toast.error("Erro ao atualizar perfil");
    },
  });

  // Estado de notificações (local, seria persistido em tabela de preferências)
  const [notifications, setNotifications] = useState({
    emailRenovacoes: true,
    emailSinistros: true,
    emailClientes: false,
    pushRenovacoes: true,
    pushSinistros: true,
    pushClientes: true,
  });

  const { theme, setTheme } = useTheme();

  // Estado de aparência
  const [appearance, setAppearance] = useState({
    theme: theme,
    compactMode: false,
  });

  const handleAppearanceSave = () => {
    setTheme(appearance.theme as "light" | "dark" | "system");
    toast.success("Aparência salva");
  };

  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile.mutate(profileForm);
  };

  return (
    <AppLayout>
      <div className="content-wrapper space-y-6">
        {/* Header */}
        <div>
          <h1 className="section-title flex items-center gap-2">
            <Settings className="h-6 w-6 text-primary" />
            Configurações
          </h1>
          <p className="section-subtitle">Gerencie suas preferências e configurações do sistema</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-secondary">
            <TabsTrigger value="perfil" className="gap-2">
              <User className="h-4 w-4" />
              Perfil
            </TabsTrigger>
            <TabsTrigger value="notificacoes" className="gap-2">
              <Bell className="h-4 w-4" />
              Notificações
            </TabsTrigger>
            <TabsTrigger value="aparencia" className="gap-2">
              <Palette className="h-4 w-4" />
              Aparência
            </TabsTrigger>
            <TabsTrigger value="seguranca" className="gap-2">
              <Shield className="h-4 w-4" />
              Segurança
            </TabsTrigger>
            <TabsTrigger value="equipe" className="gap-2">
              <Users className="h-4 w-4" />
              Equipe
            </TabsTrigger>
            <TabsTrigger value="auditoria" className="gap-2">
              <History className="h-4 w-4" />
              Auditoria
            </TabsTrigger>
            <TabsTrigger value="metricas" className="gap-2">
              <TrendingUp className="h-4 w-4" />
              Métricas & LTV
            </TabsTrigger>
          </TabsList>

          {/* Perfil */}
          <TabsContent value="perfil" className="space-y-6">
            <Card className="border-border/50 bg-card">
              <CardHeader>
                <CardTitle className="text-lg">Informações do Perfil</CardTitle>
                <CardDescription>Atualize suas informações pessoais</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleProfileSubmit} className="space-y-6">
                  {/* Avatar */}
                  <div className="flex items-center gap-6">
                    <Avatar className="h-20 w-20">
                      <AvatarImage src={profile?.avatar_url || undefined} />
                      <AvatarFallback className="bg-primary/10 text-primary text-2xl">
                        {profile?.full_name?.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase() || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="space-y-2">
                      <Button type="button" variant="outline" size="sm" className="gap-2">
                        <Camera className="h-4 w-4" />
                        Alterar Foto
                      </Button>
                      <p className="text-xs text-muted-foreground">
                        JPG, PNG ou GIF. Máximo 2MB.
                      </p>
                    </div>
                  </div>

                  <Separator />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="full_name">Nome Completo</Label>
                      <Input
                        id="full_name"
                        value={profileForm.full_name || profile?.full_name || ""}
                        onChange={(e) => setProfileForm({ ...profileForm, full_name: e.target.value })}
                        placeholder="Seu nome completo"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">E-mail</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          id="email"
                          value={profile?.email || user?.email || ""}
                          disabled
                          className="bg-muted"
                        />
                        <Badge variant="secondary">Verificado</Badge>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone">Telefone</Label>
                      <Input
                        id="phone"
                        value={profileForm.phone || profile?.phone || ""}
                        onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })}
                        placeholder="(00) 00000-0000"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Função</Label>
                      <div className="flex items-center gap-2 h-10">
                        <Badge className="bg-primary/10 text-primary">Administrador</Badge>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit" disabled={updateProfile.isPending} className="gap-2">
                      {updateProfile.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Save className="h-4 w-4" />
                      )}
                      Salvar Alterações
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notificações */}
          <TabsContent value="notificacoes" className="space-y-6">
            <Card className="border-border/50 bg-card">
              <CardHeader>
                <CardTitle className="text-lg">Preferências de Notificação</CardTitle>
                <CardDescription>Configure como você deseja receber notificações</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h4 className="font-medium mb-4 flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    Notificações por E-mail
                  </h4>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-sm">Renovações</p>
                        <p className="text-xs text-muted-foreground">Alertas sobre apólices próximas do vencimento</p>
                      </div>
                      <Switch
                        checked={notifications.emailRenovacoes}
                        onCheckedChange={(v) => setNotifications({ ...notifications, emailRenovacoes: v })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-sm">Sinistros</p>
                        <p className="text-xs text-muted-foreground">Atualizações sobre sinistros em andamento</p>
                      </div>
                      <Switch
                        checked={notifications.emailSinistros}
                        onCheckedChange={(v) => setNotifications({ ...notifications, emailSinistros: v })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-sm">Novos Clientes</p>
                        <p className="text-xs text-muted-foreground">Notificação quando um novo cliente é cadastrado</p>
                      </div>
                      <Switch
                        checked={notifications.emailClientes}
                        onCheckedChange={(v) => setNotifications({ ...notifications, emailClientes: v })}
                      />
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="font-medium mb-4 flex items-center gap-2">
                    <Bell className="h-4 w-4" />
                    Notificações no Sistema
                  </h4>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-sm">Renovações</p>
                        <p className="text-xs text-muted-foreground">Mostrar badge de renovações pendentes</p>
                      </div>
                      <Switch
                        checked={notifications.pushRenovacoes}
                        onCheckedChange={(v) => setNotifications({ ...notifications, pushRenovacoes: v })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-sm">Sinistros Críticos</p>
                        <p className="text-xs text-muted-foreground">Alertas para sinistros de alta criticidade</p>
                      </div>
                      <Switch
                        checked={notifications.pushSinistros}
                        onCheckedChange={(v) => setNotifications({ ...notifications, pushSinistros: v })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-sm">Atividade de Clientes</p>
                        <p className="text-xs text-muted-foreground">Novas anotações e documentos</p>
                      </div>
                      <Switch
                        checked={notifications.pushClientes}
                        onCheckedChange={(v) => setNotifications({ ...notifications, pushClientes: v })}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button className="gap-2" onClick={() => toast.success("Preferências salvas")}>
                    <Save className="h-4 w-4" />
                    Salvar Preferências
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Aparência */}
          <TabsContent value="aparencia" className="space-y-6">
            <Card className="border-border/50 bg-card">
              <CardHeader>
                <CardTitle className="text-lg">Aparência</CardTitle>
                <CardDescription>Personalize a aparência do sistema</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Tema</Label>
                    <Select
                      value={appearance.theme}
                      onValueChange={(v) => setAppearance({ ...appearance, theme: v })}
                    >
                      <SelectTrigger className="w-60">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="light">Claro</SelectItem>
                        <SelectItem value="dark">Escuro</SelectItem>
                        <SelectItem value="system">Sistema</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      Escolha o tema de cores do sistema
                    </p>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm">Modo Compacto</p>
                      <p className="text-xs text-muted-foreground">Reduz o espaçamento entre elementos</p>
                    </div>
                    <Switch
                      checked={appearance.compactMode}
                      onCheckedChange={(v) => setAppearance({ ...appearance, compactMode: v })}
                    />
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button className="gap-2" onClick={handleAppearanceSave}>
                    <Save className="h-4 w-4" />
                    Salvar
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Segurança */}
          <TabsContent value="seguranca" className="space-y-6">
            <Card className="border-border/50 bg-card">
              <CardHeader>
                <CardTitle className="text-lg">Segurança da Conta</CardTitle>
                <CardDescription>Gerencie a segurança da sua conta</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg border border-border/50">
                    <div>
                      <p className="font-medium">Alterar Senha</p>
                      <p className="text-sm text-muted-foreground">
                        Última alteração: Nunca
                      </p>
                    </div>
                    <Button variant="outline">Alterar</Button>
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-lg border border-border/50">
                    <div>
                      <p className="font-medium">Autenticação em Dois Fatores</p>
                      <p className="text-sm text-muted-foreground">
                        Adicione uma camada extra de segurança
                      </p>
                    </div>
                    <Badge variant="secondary">Desativado</Badge>
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-lg border border-border/50">
                    <div>
                      <p className="font-medium">Sessões Ativas</p>
                      <p className="text-sm text-muted-foreground">
                        1 sessão ativa neste dispositivo
                      </p>
                    </div>
                    <Button variant="outline">Gerenciar</Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {(userRole === "owner" || userRole === "admin") && (
              <div className="space-y-6">
                {/* Populate Demo Data Card */}
                <Card className="border-primary/20 bg-primary/5 dark:bg-primary/10">
                  <CardHeader>
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div>
                        <CardTitle className="text-lg text-primary flex items-center gap-2">
                          <FlaskConical className="h-5 w-5 text-primary" />
                          Ambiente de Demonstração (BI e Financeiro)
                        </CardTitle>
                        <CardDescription className="text-muted-foreground text-xs">
                          Popule o banco de dados com dados fictícios realistas para experimentar gráficos de BI, análises de e-commerce/seguros e projeções
                        </CardDescription>
                      </div>
                      {testDataStatus?.hasTestData ? (
                        <Badge variant="outline" className="text-primary border-primary/20 bg-primary/10 self-start md:self-center font-bold">
                          DADOS DE TESTE ATIVOS
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-muted-foreground self-start md:self-center font-bold">
                          BANCO VAZIO
                        </Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      Esta ferramenta gera automaticamente um pacote completo de dados fictícios para fins de testes e homologação técnica: 
                      <strong> Clientes (Ativos e Leads), Apólices de Seguros com produtos variados, Sinistros ativos, Contas a Pagar/Receber e o histórico de faturamento consolidado (últimos 12 meses)</strong>. 
                      Ideal para experimentar e homologar as ferramentas de Business Intelligence e controle financeiro.
                    </p>
                    
                    <div className="flex justify-end pt-1">
                      <Button
                        variant="default"
                        disabled={populateEverythingMutation.isPending}
                        onClick={() => {
                          populateEverythingMutation.mutate(undefined, {
                            onSuccess: () => {
                              toast.success("Banco de dados populado com sucesso! Seus painéis de BI e Financeiro já possuem dados demonstrativos completos.");
                            }
                          });
                        }}
                        className="gap-2 font-semibold text-xs h-10 px-4 rounded-xl"
                      >
                        {populateEverythingMutation.isPending ? (
                          <>
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            Populando Banco de Dados...
                          </>
                        ) : (
                          <>
                            <RefreshCw className="h-3.5 w-3.5" />
                            Popular Banco com Dados de Demonstração
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Clear Demo Data Card */}
                <Card className="border-destructive/35 bg-destructive/5 dark:bg-destructive/10">
                  <CardHeader>
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div>
                        <CardTitle className="text-lg text-destructive flex items-center gap-2">
                          <AlertTriangle className="h-5 w-5 text-destructive/80" />
                          Limpeza de Dados de Teste (Produção)
                        </CardTitle>
                        <CardDescription className="text-destructive/85 text-xs">
                          Remova permanentemente todos os registros de teste e demonstração do sistema
                        </CardDescription>
                      </div>
                      {testDataStatus?.hasTestData ? (
                        <Badge variant="destructive" className="animate-pulse bg-destructive hover:bg-destructive/90 self-start md:self-center font-bold">
                          {testDataStatus.count} DADOS DETECTADOS
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-emerald-600 border-emerald-500/30 bg-emerald-55 flex items-center gap-1.5 self-start md:self-center font-bold">
                          <CheckCircle2 className="h-3 w-3" />
                          SISTEMA LIMPO
                        </Badge>
                      )}
                    </div>
                  </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    Esta ferramenta de infraestrutura foi projetada para a transição segura ao ambiente de produção. Ela varre as tabelas de 
                    <strong> Clientes, Apólices, Sinistros, Atividades, Contas e Fluxo Financeiro</strong>, removendo de 
                    forma definitiva e irreversível todos os registros marcados ou gerados para fins de testes em qualquer conta de usuário.
                  </p>
                  
                  {testDataStatus?.hasTestData && (
                    <div className="p-3.5 rounded-xl border border-destructive/20 bg-destructive/5 text-xs text-destructive/95 space-y-1">
                      <p className="font-black flex items-center gap-1.5">
                        <AlertCircle className="h-3.5 w-3.5" />
                        Atenção Crucial:
                      </p>
                      <p>Foram localizados registros vinculados a rotinas de teste e demonstração rodando em paralelo.</p>
                    </div>
                  )}

                  <div className="flex flex-col sm:flex-row justify-end gap-3 pt-1">
                    <Button
                      variant="outline"
                      disabled={clearTestDataMutation.isPending}
                      onClick={() => {
                        if (confirm("ATENÇÃO MÁXIMA - PURGA DE PRODUÇÃO:\n\nVocê tem certeza absoluta que deseja zerar COMPLETAMENTE todas as tabelas operacionais do sistema?\n\nIsso apagará TODOS os clientes, apólices, sinistros, históricos, movimentações financeiras, comissões, faturas e produtos cadastrados, deixando o sistema 100% limpo para entrar em produção real.\n\nContas de usuário e acessos serão preservados.\n\nEsta operação é definitiva e IRREVERSÍVEL. Confirmar?")) {
                          clearTestDataMutation.mutate({ purgeAll: true });
                        }
                      }}
                      className="gap-2 font-bold text-xs h-10 px-4 rounded-xl border-destructive/40 text-destructive hover:bg-destructive/10"
                    >
                      {clearTestDataMutation.isPending ? (
                        <>
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          Processando...
                        </>
                      ) : (
                        <>
                          <RefreshCw className="h-3.5 w-3.5 animate-spin-once" />
                          Zerar Todo o Banco (Produção Real)
                        </>
                      )}
                    </Button>

                    <Button
                      variant="destructive"
                      disabled={clearTestDataMutation.isPending || !testDataStatus?.hasTestData}
                      onClick={() => {
                        if (confirm("ATENÇÃO: Você tem certeza absoluta que deseja remover TODOS os dados de teste marcados de todos os usuários do banco em produção? Esta ação não poderá ser desfeita sob hipótese alguma.")) {
                          clearTestDataMutation.mutate({ purgeAll: false });
                        }
                      }}
                      className="gap-2 font-black text-xs h-10 px-4 rounded-xl"
                    >
                      {clearTestDataMutation.isPending ? (
                        <>
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          Limpando Banco de Dados...
                        </>
                      ) : (
                        <>
                          <Trash2 className="h-3.5 w-3.5" />
                          Limpar Apenas Dados de Teste
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

            <Card className="border-destructive/50 bg-destructive/5">
              <CardHeader>
                <CardTitle className="text-lg text-destructive">Zona de Perigo</CardTitle>
                <CardDescription>Ações irreversíveis</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Excluir Conta</p>
                    <p className="text-sm text-muted-foreground">
                      Esta ação é permanente e não pode ser desfeita
                    </p>
                  </div>
                  <Button variant="destructive">Excluir Conta</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Equipe */}
          <TabsContent value="equipe" className="space-y-6">
            <Card className="border-border/50 bg-card">
              <CardHeader>
                <CardTitle className="text-lg">Gestão de Equipe</CardTitle>
                <CardDescription>
                  Gerencie os membros da sua equipe. Membros podem ser atribuídos como responsáveis em sinistros, apólices e outras entidades.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <TeamMembersList />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Auditoria */}
          <TabsContent value="auditoria" className="space-y-6">
            <AuditoriaTab />
          </TabsContent>

          {/* Métricas & LTV */}
          <TabsContent value="metricas" className="space-y-6">
            <Card className="border-border/50 bg-card">
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-primary/10 text-primary border border-primary/20">
                      <Calculator className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <CardTitle className="text-lg">Configurações de Indicadores e LTV</CardTitle>
                        {metricSettings.modoCalculo === "automatico" ? (
                          <Badge variant="outline" className="border-emerald-500/30 text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 font-semibold gap-1 text-[11px]">
                            <Sparkles className="h-3 w-3" />
                            Cálculo Automático Ativo
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="font-medium text-[11px]">
                            Modo Manual
                          </Badge>
                        )}
                      </div>
                      <CardDescription className="mt-1">
                        Indicadores de permanência, renovação, churn e cálculo de Lifetime Value (LTV) baseados automaticamente no histórico real da corretora.
                      </CardDescription>
                    </div>
                  </div>

                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="gap-2 shrink-0 border-primary/30 hover:bg-primary/5"
                    onClick={handleRecalculateSystemMetrics}
                    disabled={isRecalculating || isLoadingMetrics}
                  >
                    <RefreshCw className={`h-4 w-4 text-primary ${isRecalculating || isLoadingMetrics ? "animate-spin" : ""}`} />
                    <span>{isRecalculating ? "Calculando..." : "Recalcular do Sistema"}</span>
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                
                {/* Painel de Indicadores Extraídos da Base de Dados */}
                <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 space-y-3">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <Database className="h-4 w-4 text-primary" />
                      <span className="text-sm font-semibold text-foreground">Indicadores Reais Calculados da Base de Dados</span>
                    </div>
                    {systemMetrics?.calculatedAt && (
                      <span className="text-[11px] text-muted-foreground">
                        Última leitura: {new Date(systemMetrics.calculatedAt).toLocaleTimeString("pt-BR", { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
                    {/* Taxa de Renovação Real */}
                    <div className="p-3 rounded-lg bg-background border border-border/60 shadow-xs space-y-1">
                      <p className="text-xs text-muted-foreground font-medium flex items-center gap-1">
                        <TrendingUp className="h-3 w-3 text-emerald-500" />
                        Taxa Renovação Real
                      </p>
                      <p className="text-xl font-bold text-foreground">
                        {systemMetrics?.taxaRenovacao !== undefined ? `${systemMetrics.taxaRenovacao}%` : "--"}
                      </p>
                      <p className="text-[10px] text-muted-foreground truncate">
                        {systemMetrics?.totalRenewals || 0} renovações analisadas
                      </p>
                    </div>

                    {/* Churn Anual Real */}
                    <div className="p-3 rounded-lg bg-background border border-border/60 shadow-xs space-y-1">
                      <p className="text-xs text-muted-foreground font-medium flex items-center gap-1">
                        <PieChart className="h-3 w-3 text-rose-500" />
                        Churn Anual Real
                      </p>
                      <p className="text-xl font-bold text-foreground">
                        {systemMetrics?.churnAnual !== undefined ? `${systemMetrics.churnAnual}%` : "--"}
                      </p>
                      <p className="text-[10px] text-muted-foreground truncate">
                        Evasão anual estimada
                      </p>
                    </div>

                    {/* Permanência Média Real */}
                    <div className="p-3 rounded-lg bg-background border border-border/60 shadow-xs space-y-1">
                      <p className="text-xs text-muted-foreground font-medium flex items-center gap-1">
                        <Users className="h-3 w-3 text-blue-500" />
                        Permanência Média
                      </p>
                      <p className="text-xl font-bold text-foreground">
                        {systemMetrics?.tempoPermanencia !== undefined ? `${systemMetrics.tempoPermanencia} anos` : "--"}
                      </p>
                      <p className="text-[10px] text-muted-foreground truncate">
                        {systemMetrics?.totalClients || 0} clientes cadastrados
                      </p>
                    </div>

                    {/* ARPU / Comissão Média Anual */}
                    <div className="p-3 rounded-lg bg-background border border-border/60 shadow-xs space-y-1">
                      <p className="text-xs text-muted-foreground font-medium flex items-center gap-1">
                        <BarChart3 className="h-3 w-3 text-primary" />
                        Comissão Média / Cliente
                      </p>
                      <p className="text-xl font-bold text-foreground">
                        {systemMetrics?.avgAnnualCommission 
                          ? `R$ ${systemMetrics.avgAnnualCommission.toLocaleString("pt-BR", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}` 
                          : "R$ 0"}
                      </p>
                      <p className="text-[10px] text-muted-foreground truncate">
                        Anualizada por cliente ativo
                      </p>
                    </div>
                  </div>
                </div>

                {/* Modo de Cálculo Selector */}
                <div className="p-4 rounded-xl border border-border/60 bg-card flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-0.5">
                    <Label className="text-sm font-semibold flex items-center gap-2">
                      <Sparkles className="h-4 w-4 text-primary" />
                      Modo de Cálculo Automático
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Quando ativado, os indicadores de permanência ({metricSettings.tempoPermanencia} anos), taxa de renovação ({metricSettings.taxaRenovacao}%) e churn ({metricSettings.churnAnual}%) são alimentados automaticamente a partir dos dados do sistema.
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <Switch
                      checked={metricSettings.modoCalculo === "automatico"}
                      onCheckedChange={(checked) => {
                        const newMode = checked ? "automatico" : "manual";
                        if (checked && systemMetrics) {
                          setMetricSettings({
                            ...metricSettings,
                            modoCalculo: newMode,
                            tempoPermanencia: systemMetrics.tempoPermanencia,
                            taxaRenovacao: systemMetrics.taxaRenovacao,
                            churnAnual: systemMetrics.churnAnual,
                          });
                        } else {
                          setMetricSettings({
                            ...metricSettings,
                            modoCalculo: newMode,
                          });
                        }
                      }}
                    />
                    <span className="text-xs font-medium">
                      {metricSettings.modoCalculo === "automatico" ? "Automático" : "Manual"}
                    </span>
                  </div>
                </div>

                {/* Campos de Parâmetros */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Tempo Médio de Permanência */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="tempoPermanencia" className="text-sm font-medium">
                        Tempo Médio de Permanência (Anos de Retenção)
                      </Label>
                      {metricSettings.modoCalculo === "automatico" && (
                        <Badge variant="outline" className="text-[10px] text-muted-foreground border-border">
                          Calculado do Sistema
                        </Badge>
                      )}
                    </div>
                    <Input
                      id="tempoPermanencia"
                      type="number"
                      step="0.5"
                      min="1"
                      max="15"
                      disabled={metricSettings.modoCalculo === "automatico"}
                      value={metricSettings.tempoPermanencia}
                      onChange={(e) =>
                        setMetricSettings({
                          ...metricSettings,
                          tempoPermanencia: Math.max(1, parseFloat(e.target.value) || 1),
                        })
                      }
                      placeholder="Ex: 3"
                    />
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      Determina por quantos anos, em média, um cliente permanece ativo na corretora gerando receitas de comissão.
                    </p>
                  </div>

                  {/* Taxa de Renovação */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="taxaRenovacao" className="text-sm font-medium">
                        Taxa Histórica de Renovação (%)
                      </Label>
                      {metricSettings.modoCalculo === "automatico" && (
                        <Badge variant="outline" className="text-[10px] text-muted-foreground border-border">
                          Calculado do Sistema
                        </Badge>
                      )}
                    </div>
                    <Input
                      id="taxaRenovacao"
                      type="number"
                      step="0.5"
                      min="0"
                      max="100"
                      disabled={metricSettings.modoCalculo === "automatico"}
                      value={metricSettings.taxaRenovacao}
                      onChange={(e) => {
                        const val = Math.min(100, Math.max(0, parseFloat(e.target.value) || 0));
                        setMetricSettings({
                          ...metricSettings,
                          taxaRenovacao: val,
                          churnAnual: Math.round((100 - val) * 10) / 10,
                        });
                      }}
                      placeholder="Ex: 85"
                    />
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      Percentual de apólices e clientes retidos a cada ciclo de renovação.
                    </p>
                  </div>

                  {/* Churn Anual */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="churnAnual" className="text-sm font-medium">
                        Churn Anual Estimado (%)
                      </Label>
                      {metricSettings.modoCalculo === "automatico" && (
                        <Badge variant="outline" className="text-[10px] text-muted-foreground border-border">
                          Calculado do Sistema
                        </Badge>
                      )}
                    </div>
                    <Input
                      id="churnAnual"
                      type="number"
                      step="0.5"
                      min="0"
                      max="100"
                      disabled={metricSettings.modoCalculo === "automatico"}
                      value={metricSettings.churnAnual}
                      onChange={(e) => {
                        const val = Math.min(100, Math.max(0, parseFloat(e.target.value) || 0));
                        setMetricSettings({
                          ...metricSettings,
                          churnAnual: val,
                          taxaRenovacao: Math.round((100 - val) * 10) / 10,
                        });
                      }}
                      placeholder="Ex: 15"
                    />
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      Taxa de cancelamento ou não-renovação anual da carteira (complemento da taxa de renovação).
                    </p>
                  </div>

                  {/* Regra de Cálculo do LTV */}
                  <div className="space-y-2">
                    <Label htmlFor="regraCalculo" className="text-sm font-medium">
                      Regra de Projeção para o LTV
                    </Label>
                    <Select
                      value={metricSettings.regraCalculo}
                      onValueChange={(val: any) =>
                        setMetricSettings({
                          ...metricSettings,
                          regraCalculo: val,
                        })
                      }
                    >
                      <SelectTrigger id="regraCalculo">
                        <SelectValue placeholder="Selecione a regra" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="anos_retencao">Retenção Linear (Anos Médios de Carteira)</SelectItem>
                        <SelectItem value="taxa_renovacao">Churn-Based (Fórmula Padrão de SaaS / Recorrência)</SelectItem>
                        <SelectItem value="probabilidade_acumulada">Probabilidade de Renovação Acumulada</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      Escolha a metodologia matemática para estimar o faturamento e LTV futuro dos clientes.
                    </p>
                  </div>
                </div>

                {/* Explicação da Fórmula Ativa com Simulação em Tempo Real */}
                <div className="p-4 rounded-xl border border-muted/60 bg-muted/20 text-xs space-y-3 mt-4">
                  <div className="flex items-center justify-between">
                    <p className="font-semibold text-foreground flex items-center gap-1.5">
                      <Calculator className="h-4 w-4 text-primary" />
                      Simulação e Metodologia da Projeção de LTV
                    </p>
                    <span className="text-[11px] font-medium text-primary">
                      Exemplo com comissão anual de R$ 1.000,00:{" "}
                      <strong className="text-foreground font-bold">
                        R$ {calculateLtvValue(1000, metricSettings).projected.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </strong>
                    </span>
                  </div>
                  <ul className="list-disc pl-4 space-y-1.5 text-muted-foreground leading-relaxed">
                    <li>
                      <strong>Retenção Linear:</strong> <code>LTV = Comissão Anual × Anos de Retenção</code>. Multiplica a comissão anual diretamente pelo tempo médio de permanência ({metricSettings.tempoPermanencia} anos).
                    </li>
                    <li>
                      <strong>Churn-Based:</strong> <code>LTV = Comissão Anual ÷ Taxa de Churn ({metricSettings.churnAnual / 100})</code>. Projeta a perpetuidade com base na taxa de evasão anual ({metricSettings.churnAnual}%).
                    </li>
                    <li>
                      <strong>Probabilidade Acumulada:</strong> Projeta ano a ano aplicando taxas de renovação decrescentes compostas (Ano 1: 100%, Ano 2: {metricSettings.taxaRenovacao}%, Ano 3: {(metricSettings.taxaRenovacao * metricSettings.taxaRenovacao / 100).toFixed(1)}%, etc.), limitando ao tempo de permanência ({metricSettings.tempoPermanencia} anos).
                    </li>
                  </ul>
                </div>

                <div className="flex justify-end pt-2 gap-3">
                  <Button className="gap-2" onClick={handleSaveMetricSettings} disabled={savingLtvSettings || isRecalculating}>
                    {savingLtvSettings ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Salvando...
                      </>
                    ) : (
                      <>
                        <Save className="h-4 w-4" />
                        Salvar Configurações Comerciais
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}

// Removing TestToolsPanel and related imports in next turn or via deletion if it was a separate file, 
// but here it is inlined. I will remove the entire inlined component.

// End of file