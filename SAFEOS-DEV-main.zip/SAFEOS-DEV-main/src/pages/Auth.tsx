import { Navigate } from "react-router-dom";
import { SafeOSLogo } from "@/components/ui/SafeOSLogo";
import { LoginForm } from "@/components/auth/LoginForm";
import { useAuth } from "@/hooks/useAuth";
import { AlertCircle } from "lucide-react";

export default function Auth() {
  const { user, loading } = useAuth();

  const isConfigMissing = !import.meta.env.VITE_SUPABASE_URL || 
                         import.meta.env.VITE_SUPABASE_URL.includes("placeholder-url.supabase.co");

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse">
          <SafeOSLogo size="lg" />
        </div>
      </div>
    );
  }

  if (user) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Left side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
        <div className="absolute inset-0 gradient-primary opacity-10" />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-accent/20" />
        
        <div className="relative z-10 flex flex-col justify-center items-center w-full p-12">
          <SafeOSLogo size="lg" />
          <p className="mt-6 text-xl text-muted-foreground text-center max-w-md">
            Sistema proprietário de gestão para corretoras de seguros
          </p>
          
          <div className="mt-12 grid grid-cols-2 gap-6 text-center">
            <div className="glass rounded-xl p-6">
              <div className="text-3xl font-bold gradient-text">360°</div>
              <div className="text-sm text-muted-foreground mt-1">Visão do Cliente</div>
            </div>
            <div className="glass rounded-xl p-6">
              <div className="text-3xl font-bold gradient-text">100%</div>
              <div className="text-sm text-muted-foreground mt-1">Controle Total</div>
            </div>
          </div>
        </div>

        {/* Decorative elements */}
        <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute -top-20 -right-20 w-80 h-80 bg-accent/10 rounded-full blur-3xl" />
      </div>

      {/* Right side - Auth forms */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-md">
          {isConfigMissing && (
            <div className="mb-8 p-4 bg-destructive/10 border border-destructive/20 rounded-lg flex gap-3 text-destructive shadow-sm animate-fade-in">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <div className="space-y-1">
                <p className="font-bold text-sm">Configuração Incompleta</p>
                <p className="text-xs text-destructive/80 leading-relaxed">
                  As chaves do Supabase não foram detectadas. Por favor, adicione 
                  <strong>VITE_SUPABASE_URL</strong> e 
                  <strong>VITE_SUPABASE_PUBLISHABLE_KEY</strong> nas variáveis de ambiente da Vercel.
                </p>
              </div>
            </div>
          )}

          {/* Mobile logo */}
          <div className="lg:hidden flex justify-center mb-8">
            <SafeOSLogo size="md" />
          </div>

          <LoginForm />
        </div>
      </div>
    </div>
  );
}
