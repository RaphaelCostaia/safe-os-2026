import { SafeOSLogo } from "@/components/ui/SafeOSLogo";
import { ResetPasswordForm } from "@/components/auth/ResetPasswordForm";

export default function RedefinirSenha() {
  return (
    <div className="min-h-screen bg-background flex">
      {/* Left side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
        <div className="absolute inset-0 gradient-primary opacity-10" />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-accent/20" />
        
        <div className="relative z-10 flex flex-col justify-center items-center w-full p-12">
          <SafeOSLogo size="lg" />
          <p className="mt-6 text-xl text-muted-foreground text-center max-w-md">
            Crie uma nova senha segura para sua conta
          </p>
        </div>

        {/* Decorative elements */}
        <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute -top-20 -right-20 w-80 h-80 bg-accent/10 rounded-full blur-3xl" />
      </div>

      {/* Right side - Reset form */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="lg:hidden flex justify-center mb-8">
            <SafeOSLogo size="md" />
          </div>

          <ResetPasswordForm />
        </div>
      </div>
    </div>
  );
}
