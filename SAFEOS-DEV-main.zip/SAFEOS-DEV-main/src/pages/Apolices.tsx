import { useState, useEffect } from "react";
import { AppLayout } from "@/components/layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { logSensitiveAccess } from "@/lib/audit";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, Plus, Filter, MoreHorizontal, Eye, Edit, RefreshCw, FileText, Calendar, Shield, Loader2, Archive, RotateCcw, Paperclip, Percent, Coins } from "lucide-react";
import { useApolices, useCreateApolice, useUpdateApolice, useArchiveApolice, useRestoreApolice, type ApoliceWithRelations } from "@/hooks/useApolices";
import { useClients } from "@/hooks/useClients";
import { useProdutos } from "@/hooks/useProdutos";
import { useClientActiveCommissions, useCreateClientCommission } from "@/hooks/useClientCommission";
import { format, differenceInDays } from "date-fns";
import { ApoliceDocumentsModal, ApoliceFormModal } from "@/components/apolices";
import { useAuth } from "@/hooks/useAuth";
import { usePermissions } from "@/hooks/useUserRole";

const Apolices = () => {
  const [showArchived, setShowArchived] = useState(false);
  const { data: apolices, isLoading } = useApolices({ includeArchived: showArchived });
  const { data: clients } = useClients();
  const { data: produtos } = useProdutos();
  const createApolice = useCreateApolice();
  const updateApolice = useUpdateApolice();
  const archiveApolice = useArchiveApolice();
  const restoreApolice = useRestoreApolice();
  const { user } = useAuth();
  const { hasPermission } = usePermissions();
  const canArchive = hasPermission('apolices', 'delete');

  const [formData, setFormData] = useState({
    numero_apolice: "",
    client_id: "",
    produto_id: "",
    seguradora: "",
    valor_premio: "",
    data_inicio: "",
    data_fim: "",
    status: "ativa",
    comissao_real_percent: "",
    valor_comissao_real: "",
    data_renovacao: "",
    observacoes: "",
  });

  const createClientCommission = useCreateClientCommission();
  const { data: activeCommissions } = useClientActiveCommissions(formData.client_id);
  const [salvarAcordoIndividual, setSalvarAcordoIndividual] = useState(true);

  useEffect(() => {
    logSensitiveAccess('apolices', undefined, 'SELECT');
  }, []);

  const [search, setSearch] = useState("");
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingApolice, setEditingApolice] = useState<ApoliceWithRelations | null>(null);

  const getStatus = (dataFim: string, status: string): "active" | "expiring" | "expired" | "pending" | "canceled" => {
    if (status === "pendente") return "pending";
    if (status === "cancelada") return "canceled";

    const days = differenceInDays(new Date(dataFim), new Date());
    if (days < 0) return "expired";
    if (days <= 30) return "expiring";
    return "active";
  };

  const getStatusBadge = (statusType: "active" | "expiring" | "expired" | "pending" | "canceled") => {
    switch (statusType) {
      case "active":
        return <Badge className="bg-success/10 text-success border-success/20">Vigente (Ativa)</Badge>;
      case "expiring":
        return <Badge className="bg-warning/10 text-warning border-warning/20">Vencendo</Badge>;
      case "expired":
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20">Vencida</Badge>;
      case "canceled":
        return <Badge className="bg-muted text-muted-foreground border-border">Cancelada</Badge>;
      case "pending":
        return <Badge className="bg-indigo-50 text-indigo-700 border-indigo-200">Pendente / Proposta</Badge>;
      default:
        return <Badge variant="outline">Outro</Badge>;
    }
  };

  const parseApoliceObservacoes = (observacoesText: string | null) => {
    const defaultMeta = {
      comissao_real_percent: "",
      valor_comissao_real: "",
      data_renovacao: "",
    };
    if (!observacoesText) return { notes: "", meta: defaultMeta };
    const divider = "-- METADATA_APOLICE_V1 --";
    const parts = observacoesText.split(divider);
    if (parts.length < 2) return { notes: observacoesText, meta: defaultMeta };
    try {
      const meta = JSON.parse(parts[1].trim());
      return { notes: parts[0].trim(), meta: { ...defaultMeta, ...meta } };
    } catch {
      return { notes: observacoesText, meta: defaultMeta };
    }
  };

  const handleOpenCreate = () => {
    setEditingApolice(null);
    setFormData({
      numero_apolice: "",
      client_id: "",
      produto_id: "",
      seguradora: "",
      valor_premio: "",
      data_inicio: "",
      data_fim: "",
      status: "ativa",
      comissao_real_percent: "",
      valor_comissao_real: "",
      data_renovacao: "",
      observacoes: "",
    });
    setSalvarAcordoIndividual(true);
    setShowFormModal(true);
  };

  const handleOpenEdit = (apolice: ApoliceWithRelations) => {
    setEditingApolice(apolice);
    const { notes, meta } = parseApoliceObservacoes(apolice.observacoes);
    setFormData({
      numero_apolice: apolice.numero_apolice,
      client_id: apolice.client_id,
      produto_id: apolice.produto_id,
      seguradora: apolice.seguradora,
      valor_premio: apolice.valor_premio.toString(),
      data_inicio: apolice.data_inicio,
      data_fim: apolice.data_fim,
      status: apolice.status,
      comissao_real_percent: meta.comissao_real_percent || "",
      valor_comissao_real: meta.valor_comissao_real || "",
      data_renovacao: meta.data_renovacao || "",
      observacoes: notes || "",
    });
    setSalvarAcordoIndividual(true);
    setShowFormModal(true);
  };

  const handleSubmit = () => {
    const meta = {
      comissao_real_percent: formData.comissao_real_percent,
      valor_comissao_real: formData.valor_comissao_real,
      data_renovacao: formData.data_renovacao,
    };
    
    const divider = "-- METADATA_APOLICE_V1 --";
    const finalObservacoes = `${formData.observacoes.trim()}\n\n${divider}\n${JSON.stringify(meta)}`;

    const data = {
      numero_apolice: formData.numero_apolice,
      client_id: formData.client_id,
      produto_id: formData.produto_id,
      seguradora: formData.seguradora,
      valor_premio: parseFloat(formData.valor_premio) || 0,
      data_inicio: formData.data_inicio,
      data_fim: formData.data_fim,
      status: formData.status,
      observacoes: finalObservacoes,
    };

    if (editingApolice) {
      updateApolice.mutate({ id: editingApolice.id, ...data }, {
        onSuccess: () => {
          if (salvarAcordoIndividual && formData.comissao_real_percent && formData.client_id && formData.produto_id) {
            const pct = parseFloat(formData.comissao_real_percent);
            if (!isNaN(pct) && pct > 0) {
              createClientCommission.mutate({
                client_id: formData.client_id,
                produto_id: formData.produto_id,
                model: "percentual",
                percent: pct,
                starts_at: formData.data_inicio || new Date().toISOString().split('T')[0],
                notes: `Definido individualmente no contrato de apólice #${formData.numero_apolice}`,
              });
            }
          }
          setShowFormModal(false);
        },
      });
    } else {
      createApolice.mutate(data, {
        onSuccess: () => {
          if (salvarAcordoIndividual && formData.comissao_real_percent && formData.client_id && formData.produto_id) {
            const pct = parseFloat(formData.comissao_real_percent);
            if (!isNaN(pct) && pct > 0) {
              createClientCommission.mutate({
                client_id: formData.client_id,
                produto_id: formData.produto_id,
                model: "percentual",
                percent: pct,
                starts_at: formData.data_inicio || new Date().toISOString().split('T')[0],
                notes: `Definido individualmente no contrato de apólice #${formData.numero_apolice}`,
              });
            }
          }
          setShowFormModal(false);
        },
      });
    }
  };

  const handleArchive = (apolice: ApoliceWithRelations) => {
    if (user?.id && confirm("Tem certeza que deseja arquivar esta apólice?")) {
      archiveApolice.mutate({ id: apolice.id, userId: user.id });
    }
  };

  const handleRestore = (apolice: ApoliceWithRelations) => {
    restoreApolice.mutate(apolice.id);
  };

  const isApoliceArchived = (apolice: ApoliceWithRelations) => {
    return !!(apolice as unknown as { deleted_at?: string | null }).deleted_at;
  };

  const filteredApolices = apolices?.filter(a => 
    a.numero_apolice.toLowerCase().includes(search.toLowerCase()) ||
    a.clients?.nome.toLowerCase().includes(search.toLowerCase()) ||
    a.produtos?.nome.toLowerCase().includes(search.toLowerCase())
  ) || [];

  const stats = {
    total: apolices?.length || 0,
    vigentes: apolices?.filter(a => getStatus(a.data_fim, a.status) === "active").length || 0,
    vencendo: apolices?.filter(a => getStatus(a.data_fim, a.status) === "expiring").length || 0,
    premioTotal: apolices?.reduce((acc, a) => acc + a.valor_premio, 0) || 0,
  };

  return (
    <AppLayout>
      <div className="content-wrapper space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="section-title">Apólices & Propostas</h1>
            <p className="section-subtitle">Gestão de contratos, renovações e propostas em andamento</p>
          </div>
          <Button className="gap-2" onClick={handleOpenCreate}>
            <Plus className="h-4 w-4" />
            Nova Apólice / Proposta
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Total de Contratos</p>
              <p className="text-2xl font-bold">{stats.total}</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Vigentes (Ativos)</p>
              <p className="text-2xl font-bold text-success">{stats.vigentes}</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Vencendo (30 dias)</p>
              <p className="text-2xl font-bold text-warning">{stats.vencendo}</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Prêmio Total Mapeado</p>
              <p className="text-2xl font-bold">
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', notation: 'compact' }).format(stats.premioTotal)}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Filters & Search */}
        <Card className="border-border/50 bg-card">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Buscar por número, cliente, produto ou seguradora..." 
                  className="pl-10"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
              <Button variant="outline" className="gap-2">
                <Filter className="h-4 w-4" />
                Filtros
              </Button>
              {showArchived !== undefined && (
                <Button 
                  variant={showArchived ? "secondary" : "outline"} 
                  size="sm"
                  onClick={() => setShowArchived(!showArchived)}
                  className="gap-2 whitespace-nowrap"
                >
                  <Archive className="h-4 w-4" />
                  {showArchived ? "Ocultando arquivados" : "Ver arquivados"}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Table */}
        <Card className="border-border/50 bg-card">
          <CardContent className="p-0">
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="border-border/50 hover:bg-transparent">
                    <TableHead>Apólice / Proposta</TableHead>
                    <TableHead>Cliente</TableHead>
                    <TableHead>Produto</TableHead>
                    <TableHead>Seguradora</TableHead>
                    <TableHead>Vigência</TableHead>
                    <TableHead className="text-right">Comissões</TableHead>
                    <TableHead className="text-right">Prêmio</TableHead>
                    <TableHead className="text-center">Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredApolices.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={9} className="text-center py-8 text-muted-foreground">
                        Nenhum registro encontrado
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredApolices.map((apolice) => {
                      const { meta } = parseApoliceObservacoes(apolice.observacoes);
                      const percent = meta.comissao_real_percent ? `${parseFloat(meta.comissao_real_percent).toFixed(1)}%` : "-";
                      const commValue = meta.valor_comissao_real ? parseFloat(meta.valor_comissao_real) : null;
                      
                      return (
                        <TableRow key={apolice.id} className="border-border/50 hover:bg-secondary/30">
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="p-2 rounded-lg bg-primary/10">
                                <FileText className="h-4 w-4 text-primary" />
                              </div>
                              <span className="font-mono text-sm font-medium">{apolice.numero_apolice || "PROP-PENDENTE"}</span>
                            </div>
                          </TableCell>
                          <TableCell className="font-medium">{apolice.clients?.nome || "-"}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Shield className="h-4 w-4 text-muted-foreground" />
                              <span className="text-sm">{apolice.produtos?.nome || "-"}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">{apolice.seguradora}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Calendar className="h-3 w-3" />
                              {format(new Date(apolice.data_inicio), "dd/MM/yyyy")} - {format(new Date(apolice.data_fim), "dd/MM/yyyy")}
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex flex-col items-end">
                              <span className="text-xs font-semibold flex items-center gap-0.5 text-muted-foreground">
                                <Percent className="h-3 w-3" /> {percent}
                              </span>
                              {commValue !== null && (
                                <span className="text-xs font-black text-emerald-600 flex items-center gap-0.5 mt-0.5">
                                  <Coins className="h-2.5 w-2.5" /> R$ {commValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                                </span>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-right font-medium">
                            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(apolice.valor_premio)}
                          </TableCell>
                          <TableCell className="text-center">
                            {getStatusBadge(getStatus(apolice.data_fim, apolice.status))}
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem className="gap-2" onClick={() => handleOpenEdit(apolice)}>
                                  <Edit className="h-4 w-4" /> Editar / Detalhes
                                </DropdownMenuItem>
                                <ApoliceDocumentsModal
                                  apoliceId={apolice.id}
                                  apoliceNumero={apolice.numero_apolice}
                                  trigger={
                                    <DropdownMenuItem className="gap-2" onSelect={(e) => e.preventDefault()}>
                                      <Paperclip className="h-4 w-4" /> Documentos
                                    </DropdownMenuItem>
                                  }
                                />
                                {isApoliceArchived(apolice) ? (
                                  <DropdownMenuItem 
                                    className="gap-2 text-success" 
                                    onClick={() => handleRestore(apolice)}
                                  >
                                    <RotateCcw className="h-4 w-4" /> Restaurar
                                  </DropdownMenuItem>
                                ) : canArchive && (
                                  <DropdownMenuItem 
                                    className="gap-2 text-destructive" 
                                    onClick={() => handleArchive(apolice)}
                                  >
                                    <Archive className="h-4 w-4" /> Arquivar
                                  </DropdownMenuItem>
                                )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Form Modal */}
      <ApoliceFormModal
        isOpen={showFormModal}
        onOpenChange={setShowFormModal}
        editingApolice={editingApolice}
      />
    </AppLayout>
  );
};

export default Apolices;
