import { useEffect } from "react";
import { AppLayout } from "@/components/layout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { logSensitiveAccess } from "@/lib/audit";
import { useTestDataStatus, usePopulateEverything } from "@/hooks/useTestData";
import { FlaskConical, Loader2, RefreshCw } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  FinanceiroKPIs, 
  FinanceiroAlertas, 
  FinanceiroTendencia,
  ComissoesTab,
  CustosFixosTab,
  ContasTab,
} from "@/components/financeiro";
import { ProjecoesTabReal } from "@/components/financeiro/ProjecoesTabReal";
import { CommissionsDashboard } from "@/components/financeiro/CommissionsDashboard";
import { useCustosFixos } from "@/hooks/useCustosFixos";
import { useContas } from "@/hooks/useContas";
import { 
  exportToPDF, 
  exportToExcel, 
  prepareCustosFixosExport, 
  prepareContasExport,
  prepareResumoFinanceiroExport 
} from "@/lib/exportUtils";
import { 
  LayoutDashboard, 
  Receipt, 
  Wallet, 
  CreditCard, 
  TrendingUp,
  Download,
  FileSpreadsheet,
  FileText
} from "lucide-react";
import { toast } from "sonner";

const Financeiro = () => {
  const { custosFixos } = useCustosFixos();
  const { contas } = useContas();
  const { data: testDataStatus } = useTestDataStatus();
  const populateEverything = usePopulateEverything();

  // Registrar acesso ao módulo financeiro (dados sensíveis)
  useEffect(() => {
    logSensitiveAccess('contas', undefined, 'SELECT');
    logSensitiveAccess('custos_fixos', undefined, 'SELECT');
    logSensitiveAccess('client_commission_terms', undefined, 'SELECT');
  }, []);

  const handleExportCustosFixos = (format: 'pdf' | 'excel') => {
    const data = prepareCustosFixosExport(custosFixos);
    if (format === 'pdf') {
      exportToPDF(data, 'custos-fixos');
    } else {
      exportToExcel(data, 'custos-fixos');
    }
    toast.success(`Relatório exportado em ${format.toUpperCase()}`);
  };

  const handleExportContas = (tipo: 'pagar' | 'receber', format: 'pdf' | 'excel') => {
    const data = prepareContasExport(contas, tipo);
    const fileName = tipo === 'pagar' ? 'contas-pagar' : 'contas-receber';
    if (format === 'pdf') {
      exportToPDF(data, fileName);
    } else {
      exportToExcel(data, fileName);
    }
    toast.success(`Relatório exportado em ${format.toUpperCase()}`);
  };

  const handleExportResumo = (format: 'pdf' | 'excel') => {
    // Calculate summary from real data
    const custosAtivos = custosFixos.filter(c => c.status === 'ativo');
    const totalCustosMensal = custosAtivos.reduce((sum, c) => {
      if (c.recorrencia === 'mensal') return sum + c.valor;
      if (c.recorrencia === 'anual') return sum + (c.valor / 12);
      if (c.recorrencia === 'trimestral') return sum + (c.valor / 3);
      return sum;
    }, 0);

    const contasReceber = contas.filter(c => c.tipo === 'receber' && c.status === 'pendente');
    const receitaPrevista = contasReceber.reduce((sum, c) => sum + c.valor, 0);

    const data = prepareResumoFinanceiroExport({
      receitaMensal: receitaPrevista,
      receitaAnual: receitaPrevista * 12,
      comissoesPrevistas: receitaPrevista * 0.15, // Example commission rate
      custosFixos: totalCustosMensal,
      resultadoOperacional: receitaPrevista - totalCustosMensal,
    });

    if (format === 'pdf') {
      exportToPDF(data, 'resumo-financeiro');
    } else {
      exportToExcel(data, 'resumo-financeiro');
    }
    toast.success(`Relatório exportado em ${format.toUpperCase()}`);
  };

  return (
    <AppLayout>
      <div className="content-wrapper space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="section-title">Financeiro</h1>
            <p className="section-subtitle">
              Receita recorrente, comissões, custos e projeções
            </p>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="gap-2">
                <Download className="h-4 w-4" />
                Exportar
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuItem onClick={() => handleExportResumo('pdf')}>
                <FileText className="h-4 w-4 mr-2" />
                Resumo Financeiro (PDF)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExportResumo('excel')}>
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                Resumo Financeiro (Excel)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExportCustosFixos('pdf')}>
                <FileText className="h-4 w-4 mr-2" />
                Custos Fixos (PDF)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExportCustosFixos('excel')}>
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                Custos Fixos (Excel)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExportContas('pagar', 'pdf')}>
                <FileText className="h-4 w-4 mr-2" />
                Contas a Pagar (PDF)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExportContas('pagar', 'excel')}>
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                Contas a Pagar (Excel)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExportContas('receber', 'pdf')}>
                <FileText className="h-4 w-4 mr-2" />
                Contas a Receber (PDF)
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExportContas('receber', 'excel')}>
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                Contas a Receber (Excel)
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {testDataStatus && !testDataStatus.hasTestData && (
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-2xl border border-primary/20 bg-primary/5 dark:bg-primary/10">
            <div className="space-y-1">
              <h4 className="text-sm font-semibold text-primary flex items-center gap-2">
                <FlaskConical className="h-4 w-4" />
                Deseja visualizar gráficos e análises financeiras com dados de demonstração?
              </h4>
              <p className="text-xs text-muted-foreground max-w-3xl">
                Seu banco de dados está vazio. Preencha com registros simulados (clientes, apólices, sinistros, contas e histórico consolidado) para experimentar a inteligência de negócios da aplicação.
              </p>
            </div>
            <Button
              size="sm"
              disabled={populateEverything.isPending}
              onClick={() => {
                populateEverything.mutate(undefined, {
                  onSuccess: () => {
                    toast.success("Dados demonstrativos gerados! Aproveite a visão completa de BI.");
                  }
                });
              }}
              className="gap-2 shrink-0 self-end sm:self-center font-medium"
            >
              {populateEverything.isPending ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <RefreshCw className="h-3.5 w-3.5" />
              )}
              {populateEverything.isPending ? "Processando..." : "Popular Banco de Dados"}
            </Button>
          </div>
        )}

        {/* Tabs */}
        <Tabs defaultValue="visao-geral" className="space-y-6">
          <TabsList className="bg-muted/50 p-1 h-auto flex-wrap">
            <TabsTrigger value="visao-geral" className="gap-2 data-[state=active]:bg-background">
              <LayoutDashboard className="h-4 w-4" />
              <span className="hidden sm:inline">Visão Geral</span>
            </TabsTrigger>
            <TabsTrigger value="comissoes" className="gap-2 data-[state=active]:bg-background">
              <Receipt className="h-4 w-4" />
              <span className="hidden sm:inline">Comissões</span>
            </TabsTrigger>
            <TabsTrigger value="custos" className="gap-2 data-[state=active]:bg-background">
              <Wallet className="h-4 w-4" />
              <span className="hidden sm:inline">Custos Fixos</span>
            </TabsTrigger>
            <TabsTrigger value="contas" className="gap-2 data-[state=active]:bg-background">
              <CreditCard className="h-4 w-4" />
              <span className="hidden sm:inline">Contas</span>
            </TabsTrigger>
            <TabsTrigger value="projecoes" className="gap-2 data-[state=active]:bg-background">
              <TrendingUp className="h-4 w-4" />
              <span className="hidden sm:inline">Projeções</span>
            </TabsTrigger>
          </TabsList>

          {/* Visão Geral */}
          <TabsContent value="visao-geral" className="space-y-6 mt-0">
            <FinanceiroKPIs />
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <FinanceiroTendencia />
              </div>
              <div>
                <FinanceiroAlertas />
              </div>
            </div>
          </TabsContent>

          {/* Comissões */}
          <TabsContent value="comissoes" className="mt-0 space-y-6">
            <Tabs defaultValue="dashboard" className="w-full">
              <TabsList className="bg-muted/30 mb-4">
                <TabsTrigger value="dashboard" className="text-xs">Dashboard</TabsTrigger>
                <TabsTrigger value="lista" className="text-xs">Lista</TabsTrigger>
              </TabsList>
              <TabsContent value="dashboard" className="mt-0">
                <CommissionsDashboard />
              </TabsContent>
              <TabsContent value="lista" className="mt-0">
                <ComissoesTab />
              </TabsContent>
            </Tabs>
          </TabsContent>

          {/* Custos Fixos */}
          <TabsContent value="custos" className="mt-0">
            <CustosFixosTab />
          </TabsContent>

          {/* Contas a Pagar/Receber */}
          <TabsContent value="contas" className="mt-0">
            <ContasTab />
          </TabsContent>

          {/* Projeções */}
          <TabsContent value="projecoes" className="mt-0">
            <ProjecoesTabReal />
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default Financeiro;
