import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, CheckCircle, XCircle, AlertCircle } from "lucide-react";

function maskValue(value: string | undefined): string {
  if (!value) return "NÃO DEFINIDO";
  if (value.length <= 10) return "***";
  return `${value.slice(0, 6)}...${value.slice(-4)}`;
}

export default function DebugSupabase() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  
  const [sessionResult, setSessionResult] = useState<{
    status: "idle" | "loading" | "success" | "error";
    data?: unknown;
    error?: string;
  }>({ status: "idle" });
  
  const [queryResult, setQueryResult] = useState<{
    status: "idle" | "loading" | "success" | "error";
    data?: unknown;
    error?: { message: string; code?: string };
  }>({ status: "idle" });

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const supabaseKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

  const checkSession = async () => {
    setSessionResult({ status: "loading" });
    try {
      const { data, error } = await supabase.auth.getSession();
      if (error) {
        setSessionResult({ status: "error", error: error.message });
      } else {
        setSessionResult({
          status: "success",
          data: {
            hasSession: !!data.session,
            userId: data.session?.user?.id,
            email: data.session?.user?.email,
            expiresAt: data.session?.expires_at
              ? new Date(data.session.expires_at * 1000).toLocaleString("pt-BR")
              : null,
          },
        });
      }
    } catch (err) {
      setSessionResult({
        status: "error",
        error: err instanceof Error ? err.message : "Erro desconhecido",
      });
    }
  };

  const runQuery = async () => {
    setQueryResult({ status: "loading" });
    try {
      // Using type assertion since 'clients' table may not exist yet
      const { data, error } = await supabase
        .from("clients" as never)
        .select("id")
        .limit(1);

      if (error) {
        setQueryResult({
          status: "error",
          error: { message: error.message, code: error.code },
        });
      } else {
        setQueryResult({ status: "success", data });
      }
    } catch (err) {
      setQueryResult({
        status: "error",
        error: {
          message: err instanceof Error ? err.message : "Erro desconhecido",
        },
      });
    }
  };

  const runAllTests = () => {
    checkSession();
    runQuery();
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Debug Supabase</h1>
            <p className="text-muted-foreground">
              Diagnóstico de conexão com Supabase
            </p>
          </div>
          <Button onClick={runAllTests} className="gap-2">
            <RefreshCw className="h-4 w-4" />
            Executar Todos
          </Button>
        </div>

        {/* Environment Variables */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Variáveis de Ambiente</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-mono text-sm">VITE_SUPABASE_URL</span>
              <div className="flex items-center gap-2">
                <code className="bg-muted px-2 py-1 rounded text-sm">
                  {maskValue(supabaseUrl)}
                </code>
                {supabaseUrl ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <XCircle className="h-4 w-4 text-destructive" />
                )}
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-mono text-sm">
                VITE_SUPABASE_PUBLISHABLE_KEY
              </span>
              <div className="flex items-center gap-2">
                <code className="bg-muted px-2 py-1 rounded text-sm">
                  {maskValue(supabaseKey)}
                </code>
                {supabaseKey ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <XCircle className="h-4 w-4 text-destructive" />
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Session Check */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Sessão (getSession)</CardTitle>
            <Button variant="outline" size="sm" onClick={checkSession}>
              Testar
            </Button>
          </CardHeader>
          <CardContent>
            {sessionResult.status === "idle" && (
              <p className="text-muted-foreground text-sm">
                Clique em "Testar" para verificar a sessão
              </p>
            )}
            {sessionResult.status === "loading" && (
              <div className="flex items-center gap-2">
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span>Verificando...</span>
              </div>
            )}
            {sessionResult.status === "success" && (
              <div className="space-y-2">
                <Badge variant="default" className="bg-green-500">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Sucesso
                </Badge>
                <pre className="bg-muted p-3 rounded text-sm overflow-auto">
                  {JSON.stringify(sessionResult.data, null, 2)}
                </pre>
              </div>
            )}
            {sessionResult.status === "error" && (
              <div className="space-y-2">
                <Badge variant="destructive">
                  <XCircle className="h-3 w-3 mr-1" />
                  Erro
                </Badge>
                <p className="text-destructive text-sm">{sessionResult.error}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Query Test */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">
              Query (clients.select)
            </CardTitle>
            <Button variant="outline" size="sm" onClick={runQuery}>
              Testar
            </Button>
          </CardHeader>
          <CardContent>
            {queryResult.status === "idle" && (
              <p className="text-muted-foreground text-sm">
                Clique em "Testar" para executar a query
              </p>
            )}
            {queryResult.status === "loading" && (
              <div className="flex items-center gap-2">
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span>Executando...</span>
              </div>
            )}
            {queryResult.status === "success" && (
              <div className="space-y-2">
                <Badge variant="default" className="bg-green-500">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Sucesso
                </Badge>
                <pre className="bg-muted p-3 rounded text-sm overflow-auto">
                  {JSON.stringify(queryResult.data, null, 2)}
                </pre>
              </div>
            )}
            {queryResult.status === "error" && (
              <div className="space-y-2">
                <Badge variant="destructive">
                  <AlertCircle className="h-3 w-3 mr-1" />
                  Erro
                </Badge>
                <div className="bg-destructive/10 p-3 rounded space-y-1">
                  <p className="text-sm">
                    <strong>Mensagem:</strong> {queryResult.error?.message}
                  </p>
                  {queryResult.error?.code && (
                    <p className="text-sm">
                      <strong>Código:</strong> {queryResult.error.code}
                    </p>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <p className="text-xs text-muted-foreground text-center">
          ⚠️ Esta página é apenas para diagnóstico. Proteja-a adequadamente em
          produção.
        </p>
      </div>
    </div>
  );
}
