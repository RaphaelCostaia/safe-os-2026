import { useMemo, useState } from "react";
import { AppLayout } from "@/components/layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  AlertTriangle, 
  Clock, 
  CheckCircle, 
  Calendar, 
  Phone, 
  Mail, 
  ArrowRight,
  RefreshCw,
  XCircle,
  Loader2,
  FilterX
} from "lucide-react";
import { useRenovacoes, useUpdateRenovacao, type RenovacaoWithRelations } from "@/hooks/useRenovacoes";
import { differenceInDays, format, isAfter, isBefore, parseISO, startOfDay, endOfDay } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";

const Renovacoes = () => {
  const { data: renovacoesData = [], isLoading } = useRenovacoes();
  const updateRenovacao = useUpdateRenovacao();

  const [dateStart, setDateStart] = useState("");
  const [dateEnd, setDateEnd] = useState("");

  // Transform and filter data
  const renewals = useMemo(() => {
    let filtered = renovacoesData;

    if (dateStart) {
      const start = startOfDay(parseISO(dateStart));
      filtered = filtered.filter(r => {
        if (!r.apolices?.data_inicio) return false;
        return isAfter(parseISO(r.apolices.data_inicio), start) || parseISO(r.apolices.data_inicio).getTime() === start.getTime();
      });
    }

    if (dateEnd) {
      const end = endOfDay(parseISO(dateEnd));
      filtered = filtered.filter(r => {
        if (!r.apolices?.data_fim) return false;
        return isBefore(parseISO(r.apolices.data_fim), end) || parseISO(r.apolices.data_fim).getTime() === end.getTime();
      });
    }

    return filtered.map((r: RenovacaoWithRelations) => {
      const daysRemaining = differenceInDays(new Date(r.data_vencimento), new Date());
      return {
        id: r.id,
        policyNumber: r.apolices?.numero_apolice || "",
        clientName: r.apolices?.clients?.nome || "",
        clientEmail: r.apolices?.clients?.email || "",
        clientPhone: r.apolices?.clients?.telefone || "",
        product: r.apolices?.produtos?.nome || "",
        currentPremium: r.valor_anterior || r.apolices?.valor_premio || 0,
        proposedPremium: r.valor_novo || (r.apolices?.valor_premio || 0) * 1.05,
        expiryDate: r.data_vencimento,
        daysRemaining: Math.max(0, daysRemaining),
        probability: 85,
        lastContact: r.data_contato || r.created_at,
        status: r.status as "pendente" | "contatado" | "negociando" | "renovado" | "cancelado",
        observacoes: r.observacoes,
        policyStart: r.apolices?.data_inicio,
        policyEnd: r.apolices?.data_fim,
      };
    });
  }, [renovacoesData, dateStart, dateEnd]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pendente":
        return <Badge className="bg-secondary text-secondary-foreground">Pendente</Badge>;
      case "contatado":
        return <Badge className="bg-info/10 text-info border-info/20">Contatado</Badge>;
      case "negociando":
        return <Badge className="bg-warning/10 text-warning border-warning/20">Em Negociação</Badge>;
      case "renovado":
        return <Badge className="bg-success/10 text-success border-success/20">Renovado</Badge>;
      case "cancelado":
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20">Cancelado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getUrgencyColor = (days: number) => {
    if (days <= 7) return "border-l-destructive bg-destructive/5";
    if (days <= 14) return "border-l-warning bg-warning/5";
    return "border-l-info bg-info/5";
  };

  const handleUpdateStatus = (id: string, status: string) => {
    updateRenovacao.mutate({ id, status }, {
      onSuccess: () => toast.success(`Status atualizado para ${status}`)
    });
  };

  const handleContact = (id: string) => {
    updateRenovacao.mutate({ 
      id, 
      status: "contatado",
      data_contato: new Date().toISOString().split('T')[0]
    }, {
      onSuccess: () => toast.success("Contato registrado")
    });
  };

  const criticalCount = renewals.filter(r => r.daysRemaining <= 7 && !["renovado", "cancelado"].includes(r.status)).length;
  const warningCount = renewals.filter(r => r.daysRemaining > 7 && r.daysRemaining <= 14 && !["renovado", "cancelado"].includes(r.status)).length;
  const upcomingCount = renewals.filter(r => r.daysRemaining > 14 && !["renovado", "cancelado"].includes(r.status)).length;
  const pendingRenewals = renewals.filter(r => r.status === "pendente");
  const criticalRenewals = renewals.filter(r => r.daysRemaining <= 7 && !["renovado", "cancelado"].includes(r.status));
  const confirmedRenewals = renewals.filter(r => r.status === "renovado");
  
  const successRate = useMemo(() => {
    const completed = renewals.filter(r => r.status === "renovado").length;
    const lost = renewals.filter(r => r.status === "cancelado").length;
    return completed + lost > 0 ? ((completed / (completed + lost)) * 100).toFixed(1) : "100.0";
  }, [renewals]);

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-96">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </AppLayout>
    );
  }

  const RenewalCard = ({ renewal }: { renewal: typeof renewals[0] }) => (
    <Card className={`border-border/50 bg-card border-l-4 ${getUrgencyColor(renewal.daysRemaining)}`}>
      <CardContent className="p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex-1 space-y-3">
            <div className="flex items-center gap-3">
              <span className="font-mono text-sm font-medium text-primary">{renewal.policyNumber}</span>
              {getStatusBadge(renewal.status)}
              <Badge variant="outline" className={
                renewal.daysRemaining <= 7 ? "border-destructive text-destructive" :
                renewal.daysRemaining <= 14 ? "border-warning text-warning" :
                "border-info text-info"
              }>
                {renewal.daysRemaining} dias
              </Badge>
            </div>
            
            <div>
              <h3 className="font-semibold text-lg">{renewal.clientName || "Cliente não identificado"}</h3>
              <p className="text-sm text-muted-foreground">{renewal.product || "Produto não especificado"}</p>
            </div>

            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              {renewal.clientEmail && (
                <span className="flex items-center gap-1">
                  <Mail className="h-3 w-3" />
                  {renewal.clientEmail}
                </span>
              )}
              {renewal.clientPhone && (
                <span className="flex items-center gap-1">
                  <Phone className="h-3 w-3" />
                  {renewal.clientPhone}
                </span>
              )}
            </div>

            <div className="flex items-center gap-6">
              <div>
                <p className="text-xs text-muted-foreground">Prêmio Atual</p>
                <p className="font-semibold">R$ {renewal.currentPremium.toLocaleString('pt-BR')}</p>
              </div>
              <ArrowRight className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Proposta</p>
                <p className="font-semibold text-primary">R$ {renewal.proposedPremium.toLocaleString('pt-BR')}</p>
              </div>
              <div className="ml-4">
                <p className="text-xs text-muted-foreground">Vencimento</p>
                <p className="font-medium">{format(new Date(renewal.expiryDate), "dd/MM/yyyy", { locale: ptBR })}</p>
              </div>
            </div>

            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              {renewal.policyStart && (
                <span>Vigência: {format(parseISO(renewal.policyStart), "dd/MM/yyyy")} a {format(parseISO(renewal.policyEnd || renewal.expiryDate), "dd/MM/yyyy")}</span>
              )}
            </div>

            <div className="max-w-md">
              <div className="flex justify-between text-xs mb-1">
                <span className="text-muted-foreground">Probabilidade de renovação</span>
                <span className="font-medium text-success">{renewal.probability}%</span>
              </div>
              <Progress value={renewal.probability} className="h-1.5" />
            </div>
          </div>

          <div className="flex flex-col gap-2 lg:w-40">
            <Button 
              size="sm" 
              className="w-full gap-2"
              onClick={() => handleContact(renewal.id)}
              disabled={renewal.status === "renovado" || renewal.status === "cancelado"}
            >
              <Phone className="h-4 w-4" />
              Contatar
            </Button>
            <Button 
              size="sm" 
              variant="outline" 
              className="w-full gap-2"
              onClick={() => handleUpdateStatus(renewal.id, "renovado")}
              disabled={renewal.status === "renovado" || renewal.status === "cancelado"}
            >
              <CheckCircle className="h-4 w-4" />
              Confirmar
            </Button>
            <Button 
              size="sm" 
              variant="ghost" 
              className="w-full gap-2 text-destructive hover:text-destructive"
              onClick={() => handleUpdateStatus(renewal.id, "cancelado")}
              disabled={renewal.status === "renovado" || renewal.status === "cancelado"}
            >
              <XCircle className="h-4 w-4" />
              Marcar Perdido
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <AppLayout>
      <div className="content-wrapper space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="section-title">Renovações</h1>
            <p className="section-subtitle">Acompanhamento e gestão de renovações</p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" className="gap-2">
              <Calendar className="h-4 w-4" />
              Calendário
            </Button>
            <Button className="gap-2">
              <RefreshCw className="h-4 w-4" />
              Sincronizar
            </Button>
          </div>
        </div>
        
        {/* Filters */}
        <Card className="border-border/50 bg-card">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row items-end gap-4">
              <div className="grid w-full max-w-sm items-center gap-1.5">
                <Label htmlFor="date-start">Início da Vigência</Label>
                <div className="relative">
                  <Input 
                    type="date" 
                    id="date-start" 
                    value={dateStart}
                    onChange={(e) => setDateStart(e.target.value)}
                    className="pl-10"
                  />
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                </div>
              </div>
              <div className="grid w-full max-w-sm items-center gap-1.5">
                <Label htmlFor="date-end">Fim da Vigência</Label>
                <div className="relative">
                  <Input 
                    type="date" 
                    id="date-end" 
                    value={dateEnd}
                    onChange={(e) => setDateEnd(e.target.value)}
                    className="pl-10"
                  />
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-10 w-10 text-muted-foreground hover:text-foreground"
                onClick={() => { setDateStart(""); setDateEnd(""); }}
                title="Limpar filtros"
              >
                <FilterX className="h-5 w-5" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="border-border/50 bg-card border-l-4 border-l-destructive">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="h-4 w-4 text-destructive" />
                <p className="text-sm text-muted-foreground">Crítico (≤7 dias)</p>
              </div>
              <p className="text-2xl font-bold text-destructive">{criticalCount}</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 bg-card border-l-4 border-l-warning">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="h-4 w-4 text-warning" />
                <p className="text-sm text-muted-foreground">Atenção (8-14 dias)</p>
              </div>
              <p className="text-2xl font-bold text-warning">{warningCount}</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 bg-card border-l-4 border-l-info">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Calendar className="h-4 w-4 text-info" />
                <p className="text-sm text-muted-foreground">Próximas (15+ dias)</p>
              </div>
              <p className="text-2xl font-bold text-info">{upcomingCount}</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 bg-card border-l-4 border-l-success">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle className="h-4 w-4 text-success" />
                <p className="text-sm text-muted-foreground">Taxa de Sucesso</p>
              </div>
              <p className="text-2xl font-bold text-success">{successRate}%</p>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="all" className="space-y-4">
          <TabsList className="bg-secondary">
            <TabsTrigger value="all">Todas ({renewals.length})</TabsTrigger>
            <TabsTrigger value="critical">Críticas ({criticalRenewals.length})</TabsTrigger>
            <TabsTrigger value="pending">Pendentes ({pendingRenewals.length})</TabsTrigger>
            <TabsTrigger value="confirmed">Confirmadas ({confirmedRenewals.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            {renewals.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                Nenhuma renovação encontrada
              </div>
            ) : (
              renewals.map((renewal) => (
                <RenewalCard key={renewal.id} renewal={renewal} />
              ))
            )}
          </TabsContent>
          
          <TabsContent value="critical" className="space-y-4">
            {criticalRenewals.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">Nenhuma renovação crítica</p>
            ) : (
              criticalRenewals.map((renewal) => (
                <RenewalCard key={renewal.id} renewal={renewal} />
              ))
            )}
          </TabsContent>
          
          <TabsContent value="pending" className="space-y-4">
            {pendingRenewals.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">Nenhuma renovação pendente</p>
            ) : (
              pendingRenewals.map((renewal) => (
                <RenewalCard key={renewal.id} renewal={renewal} />
              ))
            )}
          </TabsContent>
          
          <TabsContent value="confirmed" className="space-y-4">
            {confirmedRenewals.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">Nenhuma renovação confirmada</p>
            ) : (
              confirmedRenewals.map((renewal) => (
                <RenewalCard key={renewal.id} renewal={renewal} />
              ))
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default Renovacoes;
