import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { AppLayout } from "@/components/layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Sparkles } from "lucide-react";
import { OpportunityFormModal } from "@/components/clients/OpportunityFormModal";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { 
  Search, 
  Plus, 
  Filter, 
  MoreHorizontal, 
  Eye, 
  Edit, 
  Trash2,
  Phone, 
  Mail, 
  Briefcase,
  MessageSquare,
  Paperclip,
  Loader2,
  Download,
  FileSpreadsheet,
  FileText,
  Percent,
  RefreshCw
} from "lucide-react";
import { useClientCommission, formatCommissionShort, useCreateClientCommission } from "@/hooks/useClientCommission";
import { usePermissions } from "@/hooks/useUserRole";
import { Archive, RotateCcw } from "lucide-react";
import { ClientTimeline, ClientNotesModal, ClientDocumentsModal, ClientFormModal, ClientFilters, ClientCommissionSection, type ClientFiltersState } from "@/components/clients";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { 
  useClients, 
  useCreateClient, 
  useUpdateClient, 
  useArchiveClient,
  useRestoreClient,
  useDeleteClient,
  type Client,
  type ClientInsert,
  type ClientUpdate
} from "@/hooks/useClients";
import { Client360Sheet } from "@/components/clients/Client360Sheet";
import { useApolices } from "@/hooks/useApolices";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { exportToPDF, exportToExcel, prepareClientesExport } from "@/lib/exportUtils";
import { calculatePolicyCommission } from "@/lib/commissionUtils";
import { toast } from "sonner";

// Client detail header component with commission badge
function ClientDetailHeader({ client, getStatusBadge }: { client: Client; getStatusBadge: (status: string) => React.ReactNode }) {
  const { data: commission } = useClientCommission(client.id);
  
  return (
    <div className="flex items-center gap-4">
      <Avatar className="h-16 w-16">
        <AvatarFallback className="bg-primary/10 text-primary text-xl">
          {client.nome.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1">
        <div className="flex items-center gap-2">
          <h3 className="text-lg font-semibold">{client.nome}</h3>
          {commission && (
            <Badge variant="outline" className="bg-success/10 text-success border-success/20 gap-1 text-xs">
              <Percent className="h-3 w-3" />
              {formatCommissionShort(commission)}
            </Badge>
          )}
        </div>
        <p className="text-sm text-muted-foreground">{client.profissao || "Profissão não informada"}</p>
        {getStatusBadge(client.status)}
      </div>
    </div>
  );
}

const Clientes = () => {
  const navigate = useNavigate();
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [showArchived, setShowArchived] = useState(false);
  const [archiveClient, setArchiveClient] = useState<Client | null>(null);
  const [deleteClient, setDeleteClient] = useState<Client | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [showOpportunityOfferForClient, setShowOpportunityOfferForClient] = useState<{ id: string; nome: string } | null>(null);
  const [showOpportunityModal, setShowOpportunityModal] = useState(false);
  const [filters, setFilters] = useState<ClientFiltersState>({
    status: null,
    profissao: null,
    dateFrom: null,
    dateTo: null,
  });

  // Hooks
  const { data: clients = [], isLoading } = useClients({ includeArchived: showArchived });
  const { data: apolices = [] } = useApolices();
  const createClient = useCreateClient();
  const updateClient = useUpdateClient();
  const archiveClientMutation = useArchiveClient();
  const restoreClientMutation = useRestoreClient();
  const deleteClientMutation = useDeleteClient();
  const createCommission = useCreateClientCommission();
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { isManager, hasPermission } = usePermissions();
  const canArchive = hasPermission('clients', 'delete');
  const canDelete = hasPermission('clients', 'delete');

  const [isRunningCorrection, setIsRunningCorrection] = useState(false);

  const handleRunCorrectionRoutine = async () => {
    if (!clients || clients.length === 0) {
      toast.info("Nenhum cliente cadastrado para correção.");
      return;
    }
    
    setIsRunningCorrection(true);
    try {
      let correctedCount = 0;
      const updatesPromises = [];

      for (const client of clients) {
        // Filter policies for this client
        const clientPolicies = apolices?.filter(p => p.client_id === client.id) || [];
        const hasActivePolicy = clientPolicies.some(p => p.status === "ativa");
        const hasAnyPolicy = clientPolicies?.length > 0;
        const allPoliciesInactive = hasAnyPolicy && clientPolicies.every(p => p.status === "cancelada" || p.status === "expirada");

        let targetStatus = client.status;
        if (hasActivePolicy && client.status === "prospecto") {
          targetStatus = "ativo";
        } else if (allPoliciesInactive && client.status === "ativo") {
          targetStatus = "inativo";
        }

        if (targetStatus !== client.status) {
          correctedCount++;
          updatesPromises.push(
            updateClient.mutateAsync({
              id: client.id,
              status: targetStatus,
            })
          );
        }
      }

      if (updatesPromises.length > 0) {
        await Promise.all(updatesPromises);
        toast.success(`Rotina de correção concluída! Sincronizados ${correctedCount} clientes que apresentavam divergências.`);
      } else {
        toast.success("Todos os cadastros de clientes já estão em perfeita sincronia com suas apólices.");
      }
    } catch (err: any) {
      console.error(err);
      toast.error("Erro ao executar rotina de correção nos cadastros.");
    } finally {
      setIsRunningCorrection(false);
    }
  };

  // Get unique professions for filter dropdown
  const profissoes = useMemo(() => {
    const profs = clients
      .map(c => c.profissao)
      .filter((p): p is string => !!p);
    return [...new Set(profs)].sort();
  }, [clients]);

  // Filter clients
  const filteredClients = useMemo(() => {
    let result = clients;
    
    // Search filter
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      result = result.filter(c => 
        c.nome.toLowerCase().includes(search) ||
        c.email?.toLowerCase().includes(search) ||
        c.cpf_cnpj?.includes(search) ||
        c.profissao?.toLowerCase().includes(search)
      );
    }
    
    // Status filter
    if (filters.status) {
      result = result.filter(c => c.status === filters.status);
    }
    
    // Profissão filter
    if (filters.profissao) {
      result = result.filter(c => c.profissao === filters.profissao);
    }
    
    // Date range filter
    if (filters.dateFrom) {
      result = result.filter(c => new Date(c.created_at) >= filters.dateFrom!);
    }
    if (filters.dateTo) {
      result = result.filter(c => new Date(c.created_at) <= filters.dateTo!);
    }
    
    return result;
  }, [clients, searchTerm, filters]);

  // Calculate stats
  const stats = useMemo(() => {
    const total = clients.length;
    const active = clients.filter(c => c.status === "ativo").length;
    const thisMonth = clients.filter(c => {
      const created = new Date(c.created_at);
      const now = new Date();
      return created.getMonth() === now.getMonth() && 
             created.getFullYear() === now.getFullYear();
    }).length;
    
    // Helper to parse policy metadata for commissions
    const parseApoliceObservacoes = (observacoesText: string | null) => {
      const defaultMeta = {
        comissao_real_percent: "",
        valor_comissao_real: "",
        data_renovacao: "",
      };
      if (!observacoesText) return { notes: "", meta: defaultMeta };
      const divider = "-- METADATA_APOLICE_V1 --";
      const parts = observacoesText.split(divider);
      if (parts.length < 2) return { notes: observacoesText, meta: defaultMeta };
      try {
        const meta = JSON.parse(parts[1].trim());
        return { notes: parts[0].trim(), meta: { ...defaultMeta, ...meta } };
      } catch {
        return { notes: observacoesText, meta: defaultMeta };
      }
    };

    // Calculate average annual commission per client (Ticket Médio de Comissão)
    const clientCommissions = clients.map(client => {
      const clientApolices = apolices.filter(a => a.client_id === client.id && ["ativa", "em_renovacao", "renovada"].includes(a.status));
      if (clientApolices.length === 0) return 0;
      
      return clientApolices.reduce((sum, a) => {
        const prod = a.produtos as any;
        const comm = calculatePolicyCommission(
          {
            valor_premio: a.valor_premio,
            observacoes: a.observacoes,
            produto_id: a.produto_id,
            produto: prod ? { comissao_percentual: prod.comissao_percentual } : null,
          },
          null,
          20
        );

        return sum + comm.valor;
      }, 0);
    });

    const activeClientsWithCommissionsList = clientCommissions.filter(c => c > 0);
    const avgTicket = activeClientsWithCommissionsList.length > 0 
      ? clientCommissions.reduce((a, b) => a + b, 0) / activeClientsWithCommissionsList.length || 0
      : 0;

    return { total, active, thisMonth, avgTicket };
  }, [clients, apolices]);

  const getStatusBadge = (status: string) => {
    const rawStatus = status?.toLowerCase();
    
    switch (rawStatus) {
      case "ativo":
      case "convertido":
        return <Badge className="bg-success/10 text-success border-success/20">Ativo</Badge>;
      case "prospecto":
      case "contato":
      case "lead_quente":
      case "qualificado":
      case "cotacao":
      case "negociacao":
        return <Badge className="bg-warning/10 text-warning border-warning/20">Prospecto</Badge>;
      case "inativo":
      case "perdido":
      case "pos_venda":
        return <Badge className="bg-muted text-muted-foreground border-border">Inativo</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const handleViewClient = (client: Client) => {
    navigate(`/clientes/${client.id}`);
  };

  const handleEditClient = (client: Client) => {
    setEditingClient(client);
    setShowFormModal(true);
  };

  const handleFormSubmit = (data: ClientInsert | ClientUpdate, commissionPercent?: number) => {
    if (editingClient) {
      updateClient.mutate({ id: editingClient.id, ...data }, {
        onSuccess: () => {
          if (commissionPercent !== undefined && commissionPercent !== null && !isNaN(commissionPercent) && commissionPercent > 0) {
            createCommission.mutate({
              client_id: editingClient.id,
              model: "percentual",
              percent: commissionPercent,
              starts_at: new Date().toISOString().split('T')[0],
              is_active: true,
              created_by: user?.id || null,
            }, {
              onSuccess: () => {
                queryClient.invalidateQueries({ queryKey: ["client_commission_terms"] });
                queryClient.invalidateQueries({ queryKey: ["financeiro_realtime"] });
                queryClient.invalidateQueries({ queryKey: ["client_map_data"] });
              }
            });
          }
          setShowFormModal(false);
          setEditingClient(null);
        }
      });
    } else {
      // Create client, then create commission term
      createClient.mutate(data, {
        onSuccess: (newClient) => {
          // Create commission term for the new client (only if greater than 0)
          if (commissionPercent !== undefined && commissionPercent !== null && !isNaN(commissionPercent) && commissionPercent > 0) {
            createCommission.mutate({
              client_id: newClient.id,
              model: "percentual",
              percent: commissionPercent,
              starts_at: new Date().toISOString().split('T')[0],
              is_active: true,
              created_by: user?.id || null,
            }, {
              onSuccess: () => {
                // Invalidate map data for auto-update
                queryClient.invalidateQueries({ queryKey: ["client_map_data"] });
              }
            });
          } else {
            // Still invalidate map data even without commission
            queryClient.invalidateQueries({ queryKey: ["client_map_data"] });
          }
          setShowFormModal(false);
          setShowOpportunityOfferForClient({ id: newClient.id, nome: newClient.nome });
        }
      });
    }
  };

  const handleArchiveConfirm = () => {
    if (archiveClient && user?.id) {
      archiveClientMutation.mutate(
        { id: archiveClient.id, userId: user.id },
        { onSettled: () => setArchiveClient(null) }
      );
    }
  };

  const handleDeleteConfirm = () => {
    if (deleteClient) {
      deleteClientMutation.mutate(deleteClient.id, {
        onSettled: () => setDeleteClient(null)
      });
    }
  };

  const handleRestoreClient = (client: Client) => {
    restoreClientMutation.mutate(client.id);
  };

  const isClientArchived = (client: Client) => {
    return !!(client as unknown as { deleted_at?: string | null }).deleted_at;
  };

  const getClientPolicyCount = (clientId: string) => {
    return apolices.filter(a => a.client_id === clientId).length;
  };

  const getClientTotalPremium = (clientId: string) => {
    return apolices
      .filter(a => a.client_id === clientId && a.status === "ativa")
      .reduce((sum, a) => sum + (a.valor_premio || 0), 0);
  };

  return (
    <AppLayout>
      <div className="content-wrapper space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="section-title">Clientes</h1>
            <p className="section-subtitle">Gestão completa da carteira de clientes</p>
          </div>
          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <Download className="h-4 w-4" />
                  Exportar
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem 
                  className="gap-2" 
                  onClick={() => {
                    const exportData = prepareClientesExport(filteredClients);
                    exportToPDF(exportData, 'clientes');
                    toast.success('Exportação PDF concluída!');
                  }}
                >
                  <FileText className="h-4 w-4" />
                  Exportar PDF
                </DropdownMenuItem>
                <DropdownMenuItem 
                  className="gap-2" 
                  onClick={() => {
                    const exportData = prepareClientesExport(filteredClients);
                    exportToExcel(exportData, 'clientes');
                    toast.success('Exportação Excel concluída!');
                  }}
                >
                  <FileSpreadsheet className="h-4 w-4" />
                  Exportar Excel
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button 
              variant="outline" 
              className="gap-2 border-indigo-200 hover:border-indigo-300 hover:bg-indigo-50 text-indigo-700 font-semibold"
              onClick={handleRunCorrectionRoutine}
              disabled={isRunningCorrection}
              title="Executa uma rotina para analisar e corrigir o status de todos os clientes com base em suas apólices."
            >
              {isRunningCorrection ? (
                <Loader2 className="h-4 w-4 animate-spin text-indigo-600" />
              ) : (
                <RefreshCw className="h-4 w-4 text-indigo-600" />
              )}
              Corrigir Cadastros
            </Button>
            <Button className="gap-2" onClick={() => { setEditingClient(null); setShowFormModal(true); }}>
              <Plus className="h-4 w-4" />
              Novo Cliente
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Total de Clientes</p>
              <p className="text-2xl font-bold">{stats.total}</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Clientes Ativos</p>
              <p className="text-2xl font-bold text-success">{stats.active}</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Novos (este mês)</p>
              <p className="text-2xl font-bold text-primary">+{stats.thisMonth}</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Ticket Médio</p>
              <p className="text-2xl font-bold">
                {stats.avgTicket > 0 
                  ? `R$ ${stats.avgTicket.toLocaleString('pt-BR', { maximumFractionDigits: 0 })}`
                  : "—"
                }
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Filters & Search */}
        <Card className="border-border/50 bg-card">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Buscar por nome, email, CPF, profissão..." 
                  className="pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <ClientFilters 
                filters={filters}
                onFiltersChange={setFilters}
                profissoes={profissoes}
              />
              {isManager && (
                <Button 
                  variant={showArchived ? "secondary" : "outline"} 
                  size="sm"
                  onClick={() => setShowArchived(!showArchived)}
                  className="gap-2 whitespace-nowrap"
                >
                  <Archive className="h-4 w-4" />
                  {showArchived ? "Ocultando arquivados" : "Ver arquivados"}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Table */}
        <Card className="border-border/50 bg-card">
          <CardContent className="p-0">
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : filteredClients.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                {searchTerm ? "Nenhum cliente encontrado" : "Nenhum cliente cadastrado"}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="border-border/50 hover:bg-transparent">
                    <TableHead>Cliente</TableHead>
                    <TableHead>Profissão</TableHead>
                    <TableHead>Contato</TableHead>
                    <TableHead className="text-center">Apólices</TableHead>
                    <TableHead className="text-right">Prêmio Total</TableHead>
                    <TableHead className="text-center">Status</TableHead>
                    <TableHead className="text-center">Ações</TableHead>
                    <TableHead className="text-right">Menu</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredClients.map((client) => (
                    <TableRow 
                      key={client.id} 
                      className="border-border/50 hover:bg-secondary/30 cursor-pointer"
                      onClick={() => handleViewClient(client)}
                    >
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10">
                            <AvatarFallback className="bg-primary/10 text-primary">
                              {client.nome.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{client.nome}</p>
                            <p className="text-xs text-muted-foreground">
                              Cliente desde {format(new Date(client.created_at), "MMM yyyy", { locale: ptBR })}
                            </p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Briefcase className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{client.profissao || "—"}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          {client.email && (
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Mail className="h-3 w-3" />
                              {client.email}
                            </div>
                          )}
                          {client.telefone && (
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Phone className="h-3 w-3" />
                              {client.telefone}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="secondary">{getClientPolicyCount(client.id)}</Badge>
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        {getClientTotalPremium(client.id) > 0 
                          ? `R$ ${getClientTotalPremium(client.id).toLocaleString('pt-BR')}`
                          : "—"
                        }
                      </TableCell>
                      <TableCell className="text-center">
                        {getStatusBadge(client.status)}
                      </TableCell>
                      <TableCell onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-center gap-1">
                          <ClientNotesModal 
                            clientId={client.id} 
                            clientName={client.nome}
                            trigger={
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary" onClick={(e) => e.stopPropagation()}>
                                <MessageSquare className="h-4 w-4" />
                              </Button>
                            }
                          />
                          <ClientDocumentsModal 
                            clientId={client.id} 
                            clientName={client.nome}
                            trigger={
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary" onClick={(e) => e.stopPropagation()}>
                                <Paperclip className="h-4 w-4" />
                              </Button>
                            }
                          />
                        </div>
                      </TableCell>
                      <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem className="gap-2" onClick={(e) => { e.stopPropagation(); handleViewClient(client); }}>
                              <Eye className="h-4 w-4" /> Ver Detalhes
                            </DropdownMenuItem>
                            <DropdownMenuItem className="gap-2" onClick={(e) => { e.stopPropagation(); handleEditClient(client); }}>
                              <Edit className="h-4 w-4" /> Editar
                            </DropdownMenuItem>
                            {isClientArchived(client) ? (
                              <>
                                <DropdownMenuItem 
                                  className="gap-2 text-success focus:text-success" 
                                  onClick={(e) => { e.stopPropagation(); handleRestoreClient(client); }}
                                >
                                  <RotateCcw className="h-4 w-4" /> Restaurar
                                </DropdownMenuItem>
                                {canDelete && (
                                  <DropdownMenuItem 
                                    className="gap-2 text-destructive focus:text-destructive" 
                                    onClick={(e) => { e.stopPropagation(); setDeleteClient(client); }}
                                  >
                                    <Trash2 className="h-4 w-4" /> Excluir Permanentemente
                                  </DropdownMenuItem>
                                )}
                              </>
                            ) : (
                              <>
                                {canArchive && (
                                  <DropdownMenuItem 
                                    className="gap-2 text-destructive/80 focus:text-destructive" 
                                    onClick={(e) => { e.stopPropagation(); setArchiveClient(client); }}
                                  >
                                    <Archive className="h-4 w-4" /> Arquivar
                                  </DropdownMenuItem>
                                )}
                                {canDelete && (
                                  <DropdownMenuItem 
                                    className="gap-2 text-destructive focus:text-destructive" 
                                    onClick={(e) => { e.stopPropagation(); setDeleteClient(client); }}
                                  >
                                    <Trash2 className="h-4 w-4" /> Excluir
                                  </DropdownMenuItem>
                                )}
                              </>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Form Modal */}
      <ClientFormModal
        open={showFormModal}
        onOpenChange={(open) => {
          setShowFormModal(open);
          if (!open) setEditingClient(null);
        }}
        onSubmit={handleFormSubmit}
        editData={editingClient}
        isLoading={createClient.isPending || updateClient.isPending}
      />

      {/* Offer opportunity Dialog */}
      <Dialog open={!!showOpportunityOfferForClient} onOpenChange={(open) => {
        if (!open) setShowOpportunityOfferForClient(null);
      }}>
        <DialogContent className="max-w-md bg-card border-border/70 shadow-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 font-bold text-lg text-indigo-950">
              <Sparkles className="h-5 w-5 text-indigo-600" />
              Gostaria de Criar uma Oportunidade?
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground mt-2">
              O perfil de <strong>"{showOpportunityOfferForClient?.nome}"</strong> foi salvo com sucesso. 
              Deseja aproveitar o momento e registrar uma **nova oportunidade comercial ou cotar uma proposta** em andamento vinculada a este cliente?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex gap-2 pt-4 border-t border-border/10">
            <Button variant="outline" size="sm" onClick={() => setShowOpportunityOfferForClient(null)}>
              Não, apenas concluir
            </Button>
            <Button 
              size="sm"
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold"
              onClick={() => {
                setShowOpportunityModal(true);
              }}
            >
              Sim, Criar Oportunidade
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <OpportunityFormModal
        open={showOpportunityModal}
        onOpenChange={(open) => {
          setShowOpportunityModal(open);
          if (!open) setShowOpportunityOfferForClient(null);
        }}
        preSelectedClientId={showOpportunityOfferForClient?.id}
        onSuccess={() => {
          queryClient.invalidateQueries({ queryKey: ["clients"] });
          queryClient.invalidateQueries({ queryKey: ["apolices"] });
        }}
      />

      {/* Archive Confirmation */}
      <AlertDialog open={!!archiveClient} onOpenChange={() => setArchiveClient(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar arquivamento</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja arquivar o cliente "{archiveClient?.nome}"? 
              O cliente será removido da lista ativa, mas o histórico será mantido.
              {archiveClientMutation.isPending && " Processando..."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={archiveClientMutation.isPending}>Cancelar</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleArchiveConfirm}
              disabled={archiveClientMutation.isPending}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {archiveClientMutation.isPending ? "Arquivando..." : "Arquivar"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteClient} onOpenChange={() => setDeleteClient(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão permanente</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir permanentemente o cliente "{deleteClient?.nome}"? 
              Esta ação é irreversível e removerá todos os dados deste cliente do sistema.
              {deleteClientMutation.isPending && " Processando..."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteClientMutation.isPending}>Cancelar</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteConfirm}
              disabled={deleteClientMutation.isPending}
              className="bg-rose-600 hover:bg-rose-700 text-white font-semibold"
            >
              {deleteClientMutation.isPending ? "Excluindo..." : "Excluir permanentemente"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
};

export default Clientes;
