import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AppLayout } from "@/components/layout/AppLayout";
import { ShieldAlert, User, Calendar, Database, Eye } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription 
} from "@/components/ui/dialog";

export default function Auditoria() {
  const [selectedLog, setSelectedLog] = useState<any>(null);

  const { data: logs, isLoading } = useQuery({
    queryKey: ["audit_logs"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("audit_logs")
        .select(`
          *,
          profiles:user_id (full_name, email)
        `)
        .order("created_at", { ascending: false })
        .limit(100);

      if (error) throw error;
      return data;
    },
  });

  const getActionBadge = (action: string) => {
    switch (action) {
      case "INSERT": return <Badge className="bg-green-500/10 text-green-500 border-green-500/20">CRIAÇÃO</Badge>;
      case "UPDATE": return <Badge className="bg-blue-500/10 text-blue-500 border-blue-500/20">EDIÇÃO</Badge>;
      case "DELETE": return <Badge className="bg-red-500/10 text-red-500 border-red-500/20">EXCLUSÃO</Badge>;
      case "SELECT": return <Badge className="bg-slate-500/10 text-slate-500 border-slate-500/20">ACESSO</Badge>;
      default: return <Badge variant="outline">{action}</Badge>;
    }
  };

  return (
    <AppLayout>
      <div className="p-8 space-y-8">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
              <ShieldAlert className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-black uppercase tracking-tighter">Trilha de Auditoria</h1>
              <p className="text-muted-foreground text-sm font-medium">Registro de todas as ações e acessos a dados sensíveis</p>
            </div>
          </div>
        </div>

        <div className="bg-card rounded-[2.5rem] border border-border/50 shadow-sm overflow-hidden">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead className="w-[180px] font-bold uppercase tracking-widest text-[10px]">Data/Hora</TableHead>
                <TableHead className="w-[120px] font-bold uppercase tracking-widest text-[10px]">Ação</TableHead>
                <TableHead className="w-[150px] font-bold uppercase tracking-widest text-[10px]">Usuário</TableHead>
                <TableHead className="w-[150px] font-bold uppercase tracking-widest text-[10px]">Tabela</TableHead>
                <TableHead className="font-bold uppercase tracking-widest text-[10px]">Descrição do Log</TableHead>
                <TableHead className="w-[80px] text-right"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell><Skeleton className="h-4 w-full" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-full" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-full" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-full" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-full" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-8 ml-auto" /></TableCell>
                  </TableRow>
                ))
              ) : (
                logs?.map((log) => (
                  <TableRow key={log.id} className="group hover:bg-muted/30 transition-colors">
                    <TableCell className="font-mono text-[11px] text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-3 w-3" />
                        {format(new Date(log.created_at), "dd/MM/yyyy HH:mm:ss", { locale: ptBR })}
                      </div>
                    </TableCell>
                    <TableCell>{getActionBadge(log.action)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-primary/5 flex items-center justify-center">
                          <User className="h-3 w-3 text-primary" />
                        </div>
                        <span className="text-xs font-bold truncate max-w-[120px]">
                          {log.profiles?.full_name || "Sistema"}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-[10px] uppercase text-muted-foreground/70 tracking-widest">
                      <div className="flex items-center gap-2">
                        <Database className="h-3 w-3" />
                        {log.table_name}
                      </div>
                    </TableCell>
                    <TableCell className="text-xs font-medium text-muted-foreground/80">
                      ID: <span className="font-mono text-[10px]">{log.record_id?.slice(0, 8)}...</span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => setSelectedLog(log)}
                        className="rounded-xl h-8 w-8 p-0"
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      <Dialog open={!!selectedLog} onOpenChange={() => setSelectedLog(null)}>
        <DialogContent className="max-w-2xl rounded-[2rem]">
          <DialogHeader>
            <DialogTitle className="text-xl font-black uppercase tracking-tight">Detalhes do Log</DialogTitle>
            <DialogDescription>Dados técnicos da alteração no banco de dados</DialogDescription>
          </DialogHeader>
          
          {selectedLog && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-muted/30 rounded-2xl flex flex-col gap-1">
                  <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Usuário</span>
                  <span className="text-sm font-bold">{selectedLog.profiles?.full_name}</span>
                  <span className="text-[10px] text-muted-foreground font-mono">{selectedLog.user_id}</span>
                </div>
                <div className="p-4 bg-muted/30 rounded-2xl flex flex-col gap-1">
                  <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Tabela</span>
                  <span className="text-sm font-bold uppercase tracking-wider">{selectedLog.table_name}</span>
                  <span className="text-[10px] text-muted-foreground font-mono">ID: {selectedLog.record_id}</span>
                </div>
              </div>

              <div className="flex gap-4">
                {selectedLog.old_data && (
                  <div className="flex-1 space-y-2">
                    <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground px-1">Dados Anteriores</span>
                    <pre className="p-4 bg-red-500/5 text-[10px] rounded-2xl border border-red-500/10 overflow-auto max-h-[300px] font-mono">
                      {JSON.stringify(selectedLog.old_data, null, 2)}
                    </pre>
                  </div>
                )}
                <div className="flex-1 space-y-2">
                  <span className="text-[10px] font-black uppercase tracking-widest text-muted-foreground px-1">Novos Dados</span>
                  <pre className="p-4 bg-green-500/5 text-[10px] rounded-2xl border border-green-500/10 overflow-auto max-h-[300px] font-mono">
                    {JSON.stringify(selectedLog.new_data, null, 2)}
                  </pre>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}
