import { AppLayout } from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Construction } from "lucide-react";

interface PlaceholderPageProps {
  title: string;
  description: string;
}

const PlaceholderPage = ({ title, description }: PlaceholderPageProps) => {
  return (
    <AppLayout>
      <div className="content-wrapper">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="section-title">{title}</h1>
            <p className="section-subtitle">{description}</p>
          </div>
        </div>

        <Card className="border-border/50 bg-card">
          <CardContent className="flex flex-col items-center justify-center py-16">
            <div className="p-4 rounded-full bg-primary/10 mb-4">
              <Construction className="h-8 w-8 text-primary" />
            </div>
            <h2 className="text-xl font-semibold mb-2">Em Desenvolvimento</h2>
            <p className="text-muted-foreground text-center max-w-md">
              Esta página está sendo construída. Em breve você terá acesso a todas as funcionalidades de {title.toLowerCase()}.
            </p>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export const Financeiro = () => (
  <PlaceholderPage 
    title="Financeiro" 
    description="Gestão financeira completa da corretora" 
  />
);


export const Configuracoes = () => (
  <PlaceholderPage 
    title="Configurações" 
    description="Configurações do sistema" 
  />
);
