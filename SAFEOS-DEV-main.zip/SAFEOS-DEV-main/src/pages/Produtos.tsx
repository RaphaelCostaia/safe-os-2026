import { useState } from "react";
import { AppLayout } from "@/components/layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { 
  Shield, 
  Heart, 
  Umbrella, 
  Car, 
  Home, 
  Briefcase,
  Plus,
  Settings,
  TrendingUp,
  Users,
  Loader2,
  Edit,
  Trash2,
  Lock
} from "lucide-react";
import { useProdutos, useCreateProduto, useUpdateProduto, useDeleteProduto, type Produto } from "@/hooks/useProdutos";
import { usePermissions } from "@/hooks/useUserRole";
import { getRoleName } from "@/lib/permissions";

const categoryIcons: Record<string, React.ElementType> = {
  "rcp": Shield,
  "vida": Heart,
  "dit": Umbrella,
  "auto": Car,
  "residencial": Home,
  "consorcio": Briefcase,
  "outros": Shield,
};

const Produtos = () => {
  const { data: produtos, isLoading } = useProdutos();
  const createProduto = useCreateProduto();
  const updateProduto = useUpdateProduto();
  const deleteProduto = useDeleteProduto();
  const { can, role, isLoading: isLoadingPermissions } = usePermissions();

  // Permission checks
  const canCreate = can('produtos', 'create');
  const canEdit = can('produtos', 'edit');
  const canDelete = can('produtos', 'delete');

  const [showFormModal, setShowFormModal] = useState(false);
  const [editingProduto, setEditingProduto] = useState<Produto | null>(null);
  const [formData, setFormData] = useState({
    codigo: "",
    nome: "",
    categoria: "",
    seguradora: "",
    descricao: "",
    comissao_percentual: "",
    ativo: true,
  });

  const getCategoryBadge = (categoria: string) => {
    const categoriesMap: Record<string, { label: string; variant: "primary" | "accent" | "secondary" }> = {
      rcp: { label: "Core", variant: "primary" },
      vida: { label: "Core", variant: "primary" },
      dit: { label: "Core", variant: "primary" },
      consorcio: { label: "Estratégico", variant: "accent" },
      auto: { label: "Adicional", variant: "secondary" },
      residencial: { label: "Adicional", variant: "secondary" },
    };
    
    const config = categoriesMap[categoria.toLowerCase()] || { label: categoria, variant: "secondary" as const };
    
    if (config.variant === "primary") {
      return <Badge className="bg-primary/10 text-primary border-primary/20">{config.label}</Badge>;
    } else if (config.variant === "accent") {
      return <Badge className="bg-accent/10 text-accent border-accent/20">{config.label}</Badge>;
    }
    return <Badge className="bg-secondary text-secondary-foreground">{config.label}</Badge>;
  };

  const handleOpenCreate = () => {
    setEditingProduto(null);
    setFormData({
      codigo: "",
      nome: "",
      categoria: "",
      seguradora: "",
      descricao: "",
      comissao_percentual: "",
      ativo: true,
    });
    setShowFormModal(true);
  };

  const handleOpenEdit = (produto: Produto) => {
    setEditingProduto(produto);
    setFormData({
      codigo: produto.codigo,
      nome: produto.nome,
      categoria: produto.categoria,
      seguradora: produto.seguradora,
      descricao: produto.descricao || "",
      comissao_percentual: produto.comissao_percentual?.toString() || "",
      ativo: produto.ativo,
    });
    setShowFormModal(true);
  };

  const handleSubmit = () => {
    const data = {
      codigo: formData.codigo,
      nome: formData.nome,
      categoria: formData.categoria,
      seguradora: formData.seguradora,
      descricao: formData.descricao || null,
      comissao_percentual: formData.comissao_percentual ? parseFloat(formData.comissao_percentual) : null,
      ativo: formData.ativo,
    };

    if (editingProduto) {
      updateProduto.mutate({ id: editingProduto.id, ...data }, {
        onSuccess: () => setShowFormModal(false),
      });
    } else {
      createProduto.mutate(data, {
        onSuccess: () => setShowFormModal(false),
      });
    }
  };

  const handleDelete = (id: string) => {
    if (confirm("Tem certeza que deseja excluir este produto?")) {
      deleteProduto.mutate(id);
    }
  };

  const handleToggleAtivo = (produto: Produto) => {
    updateProduto.mutate({ id: produto.id, ativo: !produto.ativo });
  };

  const activeProducts = produtos?.filter(p => p.ativo) || [];
  const inactiveProducts = produtos?.filter(p => !p.ativo) || [];

  const stats = {
    ativos: activeProducts.length,
    inativos: inactiveProducts.length,
  };

  if (isLoading || isLoadingPermissions) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="content-wrapper space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="section-title">Produtos</h1>
            <p className="section-subtitle">Catálogo de produtos e seguros</p>
          </div>
          
          {canCreate ? (
            <Button className="gap-2" onClick={handleOpenCreate}>
              <Plus className="h-4 w-4" />
              Novo Produto
            </Button>
          ) : (
            <Tooltip>
              <TooltipTrigger asChild>
                <span tabIndex={0}>
                  <Button className="gap-2" disabled>
                    <Lock className="h-4 w-4" />
                    Novo Produto
                  </Button>
                </span>
              </TooltipTrigger>
              <TooltipContent>
                <p>Apenas Admin ou Gestor podem criar produtos</p>
                <p className="text-xs text-muted-foreground">Seu cargo atual: {getRoleName(role || 'vendedor')}</p>
              </TooltipContent>
            </Tooltip>
          )}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Produtos Ativos</p>
              <p className="text-2xl font-bold">{stats.ativos}</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Produtos Inativos</p>
              <p className="text-2xl font-bold text-muted-foreground">{stats.inativos}</p>
            </CardContent>
          </Card>
          <Card className="border-border/50 bg-card">
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">Total de Produtos</p>
              <p className="text-2xl font-bold">{produtos?.length || 0}</p>
            </CardContent>
          </Card>
        </div>

        {/* Active Products */}
        {activeProducts.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              Produtos Ativos
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {activeProducts.map((produto) => {
                const IconComponent = categoryIcons[produto.categoria.toLowerCase()] || Shield;
                return (
                  <Card key={produto.id} className="border-border/50 bg-card hover:border-primary/30 transition-colors">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="p-3 rounded-xl bg-primary/10">
                            <IconComponent className="h-6 w-6 text-primary" />
                          </div>
                          <div>
                            <h3 className="font-semibold">{produto.nome}</h3>
                            <p className="text-sm text-muted-foreground">{produto.descricao || produto.seguradora}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {getCategoryBadge(produto.categoria)}
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span>
                                <Switch 
                                  checked={produto.ativo} 
                                  onCheckedChange={() => handleToggleAtivo(produto)}
                                  disabled={!canEdit}
                                />
                              </span>
                            </TooltipTrigger>
                            {!canEdit && (
                              <TooltipContent>Apenas Admin ou Gestor podem alterar status</TooltipContent>
                            )}
                          </Tooltip>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border/50">
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Código</p>
                          <span className="font-mono text-sm font-semibold">{produto.codigo}</span>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Seguradora</p>
                          <span className="text-sm">{produto.seguradora}</span>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Comissão</p>
                          <span className="font-semibold text-success">{produto.comissao_percentual || 0}%</span>
                        </div>
                      </div>

                      <div className="flex justify-end mt-4 gap-2">
                        {canEdit ? (
                          <Button variant="ghost" size="sm" className="gap-2" onClick={() => handleOpenEdit(produto)}>
                            <Edit className="h-4 w-4" />
                            Editar
                          </Button>
                        ) : (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span tabIndex={0}>
                                <Button variant="ghost" size="sm" className="gap-2" disabled>
                                  <Lock className="h-4 w-4" />
                                  Editar
                                </Button>
                              </span>
                            </TooltipTrigger>
                            <TooltipContent>Apenas Admin ou Gestor podem editar</TooltipContent>
                          </Tooltip>
                        )}
                        
                        {canDelete ? (
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="gap-2 text-destructive hover:text-destructive"
                            onClick={() => handleDelete(produto.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                            Excluir
                          </Button>
                        ) : (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span tabIndex={0}>
                                <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground" disabled>
                                  <Lock className="h-4 w-4" />
                                  Excluir
                                </Button>
                              </span>
                            </TooltipTrigger>
                            <TooltipContent>Apenas Admin pode excluir produtos</TooltipContent>
                          </Tooltip>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {/* Inactive Products */}
        {inactiveProducts.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold flex items-center gap-2 text-muted-foreground">
              <Plus className="h-5 w-5" />
              Produtos Inativos
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {inactiveProducts.map((produto) => {
                const IconComponent = categoryIcons[produto.categoria.toLowerCase()] || Shield;
                return (
                  <Card key={produto.id} className="border-border/50 bg-card/50 opacity-60 hover:opacity-100 transition-opacity">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="p-3 rounded-xl bg-secondary">
                            <IconComponent className="h-6 w-6 text-muted-foreground" />
                          </div>
                          <div>
                            <h3 className="font-semibold">{produto.nome}</h3>
                            <p className="text-sm text-muted-foreground">{produto.descricao || produto.seguradora}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {getCategoryBadge(produto.categoria)}
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span>
                                <Switch 
                                  checked={produto.ativo} 
                                  onCheckedChange={() => handleToggleAtivo(produto)}
                                  disabled={!canEdit}
                                />
                              </span>
                            </TooltipTrigger>
                            {!canEdit && (
                              <TooltipContent>Apenas Admin ou Gestor podem alterar status</TooltipContent>
                            )}
                          </Tooltip>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border/50">
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Código</p>
                          <span className="font-mono text-sm font-semibold">{produto.codigo}</span>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Seguradora</p>
                          <span className="text-sm">{produto.seguradora}</span>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Comissão</p>
                          <span className="font-semibold text-success">{produto.comissao_percentual || 0}%</span>
                        </div>
                      </div>

                      <div className="flex justify-end mt-4 gap-2">
                        {canEdit ? (
                          <Button variant="ghost" size="sm" className="gap-2" onClick={() => handleOpenEdit(produto)}>
                            <Edit className="h-4 w-4" />
                            Editar
                          </Button>
                        ) : (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span tabIndex={0}>
                                <Button variant="ghost" size="sm" className="gap-2" disabled>
                                  <Lock className="h-4 w-4" />
                                  Editar
                                </Button>
                              </span>
                            </TooltipTrigger>
                            <TooltipContent>Apenas Admin ou Gestor podem editar</TooltipContent>
                          </Tooltip>
                        )}
                        
                        {canDelete ? (
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="gap-2 text-destructive hover:text-destructive"
                            onClick={() => handleDelete(produto.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                            Excluir
                          </Button>
                        ) : (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span tabIndex={0}>
                                <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground" disabled>
                                  <Lock className="h-4 w-4" />
                                  Excluir
                                </Button>
                              </span>
                            </TooltipTrigger>
                            <TooltipContent>Apenas Admin pode excluir produtos</TooltipContent>
                          </Tooltip>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {/* Empty State */}
        {produtos?.length === 0 && (
          <Card className="border-border/50 bg-card">
            <CardContent className="p-12 text-center">
              <Shield className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="font-semibold text-lg mb-2">Nenhum produto cadastrado</h3>
              <p className="text-muted-foreground mb-4">Comece adicionando seu primeiro produto</p>
              {canCreate ? (
                <Button onClick={handleOpenCreate}>
                  <Plus className="h-4 w-4 mr-2" />
                  Novo Produto
                </Button>
              ) : (
                <div className="space-y-2">
                  <Button disabled>
                    <Lock className="h-4 w-4 mr-2" />
                    Novo Produto
                  </Button>
                  <p className="text-xs text-muted-foreground">
                    Apenas Admin ou Gestor podem criar produtos
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Form Modal */}
      <Dialog open={showFormModal} onOpenChange={setShowFormModal}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingProduto ? "Editar Produto" : "Novo Produto"}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="codigo">Código</Label>
                <Input
                  id="codigo"
                  value={formData.codigo}
                  onChange={(e) => setFormData({ ...formData, codigo: e.target.value })}
                  placeholder="RCP-001"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="categoria">Categoria</Label>
                <Select value={formData.categoria} onValueChange={(v) => setFormData({ ...formData, categoria: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rcp">RCP</SelectItem>
                    <SelectItem value="vida">Vida</SelectItem>
                    <SelectItem value="dit">DIT</SelectItem>
                    <SelectItem value="auto">Auto</SelectItem>
                    <SelectItem value="residencial">Residencial</SelectItem>
                    <SelectItem value="consorcio">Consórcio</SelectItem>
                    <SelectItem value="outros">Outros</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="nome">Nome</Label>
              <Input
                id="nome"
                value={formData.nome}
                onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                placeholder="RCP Médico"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="seguradora">Seguradora</Label>
              <Input
                id="seguradora"
                value={formData.seguradora}
                onChange={(e) => setFormData({ ...formData, seguradora: e.target.value })}
                placeholder="Tokio Marine"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="descricao">Descrição</Label>
              <Textarea
                id="descricao"
                value={formData.descricao}
                onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                placeholder="Descrição do produto..."
                rows={2}
              />
            </div>

            <div className="flex items-center gap-2">
              <Switch
                id="ativo"
                checked={formData.ativo}
                onCheckedChange={(v) => setFormData({ ...formData, ativo: v })}
              />
              <Label htmlFor="ativo">Produto ativo</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowFormModal(false)}>Cancelar</Button>
            <Button 
              onClick={handleSubmit}
              disabled={createProduto.isPending || updateProduto.isPending}
            >
              {(createProduto.isPending || updateProduto.isPending) && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {editingProduto ? "Salvar" : "Criar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
};

export default Produtos;