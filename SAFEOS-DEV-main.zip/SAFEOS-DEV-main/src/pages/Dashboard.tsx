import { useState, useMemo } from "react";
import { AppLayout } from "@/components/layout";
import { 
  StatCard, 
  RevenueChart, 
  PortfolioDistribution,
  RenewalsPipeline,
  ActionPanel,
} from "@/components/dashboard";
import { CrossSellingAdvisor } from "@/components/dashboard/CrossSellingAdvisor";
import { MarketingROIPanel } from "@/components/dashboard/MarketingROIPanel";
import { PriorityQueueList } from "@/components/dashboard/PriorityQueueList";
import { TopPartnersPanel } from "@/components/dashboard/TopPartnersPanel";
import { ExecutiveMetricsPanel } from "@/components/dashboard/ExecutiveMetricsPanel";
import { OperationalSummary } from "@/components/dashboard/OperationalSummary";
import { ClientGeographicMap } from "@/components/dashboard/ClientGeographicMap";
import { TopClientsRanking } from "@/components/dashboard/TopClientsRanking";
import { CRMKanban } from "@/components/dashboard/CRMKanban";
import { OperationalCentralHub } from "@/components/dashboard/OperationalCentralHub";
import { ThemeToggle } from "@/components/layout/ThemeToggle";
import { useNavigate } from "react-router-dom";
import { Separator } from "@/components/ui/separator";
import { 
  DollarSign, 
  Users, 
  RefreshCw, 
  TrendingUp, 
  Loader2, 
  Zap, 
  Filter, 
  ShieldCheck,
  Building2,
  Lock,
  Search,
  Plus,
  LayoutDashboard,
  BarChart3,
  Calendar,
  AlertTriangle,
  ChevronRight,
  Target,
  Activity,
  Globe,
  FlaskConical
} from "lucide-react";
import { useDashboardStats } from "@/hooks/useDashboardStats";
import { useDashboardCommissionMetrics } from "@/hooks/useDashboardCommissionMetrics";
import { useAuth } from "@/hooks/useAuth";
import { useTestDataStatus, usePopulateEverything } from "@/hooks/useTestData";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DashboardFilterProvider } from "@/hooks/useDashboardFilter";
import { DashboardPeriod } from "@/hooks/useExecutiveDashboard";
import { ClientFormModal } from "@/components/clients/ClientFormModal";
import { useCreateClient } from "@/hooks/useClients";

type DashboardRole = "super_admin" | "gestor" | "regional";

const DashboardContent = () => {
  const { data: stats, isLoading: statsLoading } = useDashboardStats();
  const { data: commissionMetrics, isLoading: commsLoading } = useDashboardCommissionMetrics();
  const { user } = useAuth();
  const navigate = useNavigate();
  const createClient = useCreateClient();
  const { data: testDataStatus } = useTestDataStatus();
  const populateEverything = usePopulateEverything();
  
  const [role, setRole] = useState<DashboardRole>("super_admin");
  const [period, setPeriod] = useState<DashboardPeriod>("last_30_days");
  const [activeTab, setActiveTab] = useState("executivo");
  const [showFormModal, setShowFormModal] = useState(false);

  const isLoading = statsLoading || commsLoading;

  const handleQuickAddSubmit = (data: any) => {
    createClient.mutate(data, {
      onSuccess: () => {
        setShowFormModal(false);
      }
    });
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      maximumFractionDigits: 0
    }).format(value);
  };

  const dashboardMood = useMemo(() => {
    switch(role) {
      case "super_admin": return { label: "Visão Geral Corporativa", color: "text-primary", icon: ShieldCheck };
      case "gestor": return { label: "Gestão Operacional", color: "text-emerald-600", icon: LayoutDashboard };
      case "regional": return { label: "Performance Regional", color: "text-amber-600", icon: Building2 };
    }
  }, [role]);

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex flex-col items-center justify-center h-[70vh] gap-4">
          <Loader2 className="h-10 w-10 animate-spin text-primary/40" />
          <p className="text-sm font-medium text-muted-foreground animate-pulse">Sincronizando dados corporativos...</p>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="content-wrapper min-h-screen pb-12">
        {/* UPPER NAVIGATION & UTILS */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-3">
            <div className={`p-3 rounded-2xl bg-primary/10 ${dashboardMood.color}`}>
              <dashboardMood.icon className="h-7 w-7" />
            </div>
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-4xl font-black tracking-tight flex items-center gap-2">
                  Analytics <span className="font-serif italic font-light text-primary/80 lowercase tracking-tight">Executivo</span>
                </h1>
                <Badge variant="outline" className="font-mono text-[9px] h-4 border-primary/20 text-primary bg-primary/5 px-1.5 font-black uppercase tracking-widest">
                  BI Engine v4.0
                </Badge>
              </div>
              <div className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/60 flex items-center gap-2 mt-1">
                {dashboardMood.label}
                <Separator orientation="vertical" className="h-2.5 opacity-30" />
                <span className="font-bold opacity-40">Sync: {format(new Date(), "HH:mm")}</span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 bg-muted/40 p-1.5 rounded-2xl border border-border/50 backdrop-blur-sm">
             <div className="hidden md:flex items-center relative group px-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground group-hover:text-primary transition-colors" />
                <Input 
                  placeholder="Pesquisar..." 
                  className="h-9 w-[140px] pl-9 bg-transparent border-none shadow-none focus-visible:ring-0 text-xs" 
                />
             </div>
             <Separator orientation="vertical" className="hidden md:block h-5 mx-1" />
             <Select value={period} onValueChange={(v) => setPeriod(v as DashboardPeriod)}>
                <SelectTrigger className="h-9 border-none shadow-none bg-background/50 hover:bg-background transition-colors gap-2 text-xs font-bold w-[160px] rounded-xl">
                  <Calendar className="h-3.5 w-3.5 text-primary" />
                  <SelectValue placeholder="Período" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="last_30_days">Últimos 30 dias</SelectItem>
                  <SelectItem value="last_90_days">Último Trimestre</SelectItem>
                  <SelectItem value="last_12_months">Últimos 12 meses</SelectItem>
                  <SelectItem value="year_to_date">Ano Atual (YTD)</SelectItem>
                </SelectContent>
             </Select>
             <Separator orientation="vertical" className="h-5 mx-1" />
             <ThemeToggle />
             <Button 
                variant="default" 
                size="sm" 
                className="h-9 px-4 rounded-xl gap-2 shadow-sm font-bold bg-primary hover:bg-primary/90 transition-all"
                onClick={() => setShowFormModal(true)}
             >
                <Plus className="h-4 w-4" />
                Ação Rápida
             </Button>
          </div>
        </div>

        {testDataStatus && !testDataStatus.hasTestData && (
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-2xl border border-primary/20 bg-primary/5 dark:bg-primary/10 mb-8">
            <div className="space-y-1">
              <h4 className="text-sm font-semibold text-primary flex items-center gap-2">
                <FlaskConical className="h-4 w-4" />
                Deseja visualizar os gráficos, comissões e estatísticas com dados de demonstração?
              </h4>
              <p className="text-xs text-muted-foreground max-w-3xl">
                Seu banco de dados está vazio. Preencha com registros simulados (clientes, apólices, sinistros, contas e histórico consolidado) para experimentar a inteligência de negócios do aplicativo.
              </p>
            </div>
            <Button
              size="sm"
              disabled={populateEverything.isPending}
              onClick={() => {
                populateEverything.mutate(undefined, {
                  onSuccess: () => {
                    toast.success("Dados de demonstração populados com sucesso! Seus painéis e gráficos do BI já estão com dados completos.");
                  }
                });
              }}
              className="gap-2 shrink-0 self-end sm:self-center font-bold"
            >
              {populateEverything.isPending ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <RefreshCw className="h-3.5 w-3.5" />
              )}
              {populateEverything.isPending ? "Processando..." : "Ativar Dados de Demonstração"}
            </Button>
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-10">
          <div className="flex items-center justify-between border-b pb-1">
            <TabsList className="bg-transparent h-auto p-0 gap-10">
              <TabsTrigger 
                value="executivo" 
                className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-4 data-[state=active]:border-primary rounded-none px-0 pb-4 font-black text-xs uppercase tracking-[0.15em] transition-all opacity-40 data-[state=active]:opacity-100"
              >
                Dashboard Executivo
              </TabsTrigger>
              <TabsTrigger 
                value="operacional" 
                className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-4 data-[state=active]:border-primary rounded-none px-0 pb-4 font-black text-xs uppercase tracking-[0.15em] transition-all opacity-40 data-[state=active]:opacity-100"
              >
                Resumo Operacional
              </TabsTrigger>
              <TabsTrigger 
                value="geografico" 
                className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-4 data-[state=active]:border-primary rounded-none px-0 pb-4 font-black text-xs uppercase tracking-[0.15em] transition-all opacity-40 data-[state=active]:opacity-100"
              >
                Inteligência Territorial
              </TabsTrigger>
              <TabsTrigger 
                value="crm" 
                className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-4 data-[state=active]:border-primary rounded-none px-0 pb-4 font-black text-xs uppercase tracking-[0.15em] transition-all opacity-40 data-[state=active]:opacity-100"
              >
                Pipeline CRM
              </TabsTrigger>
            </TabsList>
            
            <div className="hidden lg:flex items-center gap-6 text-[10px] uppercase font-black tracking-[0.2em] text-muted-foreground/50">
              <span className="flex items-center gap-2"><Lock className="h-3 w-3" /> Secure Access</span>
              <span className="flex items-center gap-2"><Building2 className="h-3 w-3" /> Matriz SP</span>
            </div>
          </div>

          <TabsContent value="executivo" className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* NEW EXECUTIVE KPI GRID */}
            <ExecutiveMetricsPanel period={period} />

            <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
              {/* LEFT COLUMN - MAIN CHARTS (8 columns) */}
              <div className="xl:col-span-8 space-y-8">
                {/* MAIN CHART - REVENUE & PROJECTIONS */}
                <div className="relative overflow-hidden rounded-[2.5rem] border bg-card shadow-sm p-8 group transition-all hover:shadow-md border-border/60">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-10">
                    <div>
                      <h3 className="text-2xl font-black tracking-tight flex items-center gap-3">
                         <div className="p-2 bg-primary/10 rounded-xl">
                            <BarChart3 className="h-5 w-5 text-primary" />
                         </div>
                         Gráfico de Performance e Projeções
                      </h3>
                      <p className="text-sm text-muted-foreground mt-1 font-medium">Análise volumétrica da receita recorrente e comissionamento</p>
                    </div>
                    <div className="flex items-center gap-2">
                       <Button variant="outline" size="sm" className="h-9 px-4 rounded-xl font-bold bg-muted/30">Relatórios Detalhados</Button>
                    </div>
                  </div>
                  <div className="h-[400px]">
                    <RevenueChart />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                   <PortfolioDistribution />
                   <RenewalsPipeline />
                </div>
              </div>

              {/* RIGHT COLUMN - OPS & INSIGHTS (4 columns) */}
              <div className="xl:col-span-4 space-y-8">
                 {/* CROSS-SELLING AI - PROMINENT */}
                <div className="bg-gradient-to-br from-indigo-600 via-indigo-700 to-indigo-900 rounded-[2.5rem] p-8 shadow-xl relative overflow-hidden text-white group cursor-pointer hover:scale-[1.01] transition-all">
                    <div className="absolute top-0 right-0 p-12 bg-white/10 blur-3xl rounded-full -translate-y-1/2 translate-x-1/2" />
                    <CrossSellingAdvisor />
                </div>

                {/* MARKETING & PARTNERS */}
                <MarketingROIPanel />
                <TopPartnersPanel />

                {/* CRITICAL ALERTS */}
                <div className="bg-card rounded-[2rem] border shadow-sm p-7 border-l-4 border-l-destructive">
                  <div className="flex items-center justify-between mb-6">
                      <h3 className="text-lg font-black flex items-center gap-3 tracking-tight">
                        <AlertTriangle className="h-6 w-6 text-destructive" />
                        Sinistros Críticos
                      </h3>
                      <Badge variant="destructive" className="h-6 px-2 font-black rounded-lg">{stats?.criticalClaims}</Badge>
                  </div>
                  
                  <div className="space-y-4">
                      {stats && stats.criticalClaims > 0 ? (
                        <div className="p-5 rounded-2xl bg-destructive/5 border border-destructive/10">
                          <p className="text-sm font-black text-destructive mb-2 uppercase tracking-wide">Bloqueio Operacional</p>
                          <p className="text-xs text-muted-foreground leading-relaxed font-medium">
                              Detectamos {stats.criticalClaims} casos com SLA estourado. Ação imediata necessária para manter o NPS.
                          </p>
                          <Button 
                            variant="default" 
                            size="sm" 
                            className="w-full bg-destructive hover:bg-destructive/90 text-white font-bold rounded-xl mt-5 h-10 shadow-lg"
                            onClick={() => navigate("/sinistros")}
                          >
                              Resolver Agora <ChevronRight className="h-4 w-4 ml-1" />
                          </Button>
                        </div>
                      ) : (
                        <div className="text-center py-8 opacity-40">
                          <ShieldCheck className="h-10 w-10 mx-auto text-success mb-3" />
                          <p className="text-xs font-bold uppercase tracking-widest">Nenhuma anormalidade</p>
                        </div>
                      )}
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-8">
               <TopClientsRanking />
            </div>
          </TabsContent>

          <TabsContent value="operacional" className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* OPERATIONAL SUMMARY ROW */}
            <OperationalSummary period={period} />

            <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
              <div className="xl:col-span-8">
                 {/* CENTRAL HUB */}
                 <OperationalCentralHub />
              </div>

              <div className="xl:col-span-4">
                 <div className="bg-card rounded-[2.5rem] border shadow-sm p-8 space-y-8 sticky top-24">
                    <div>
                      <h3 className="text-xl font-black tracking-tight mb-2">Ações Rápidas</h3>
                      <p className="text-xs text-muted-foreground font-medium">Atalhos operacionais inteligentes</p>
                    </div>
                    
                    <ActionPanel />

                    <Button variant="outline" className="w-full justify-between h-14 px-6 group hover:bg-primary hover:text-white transition-all rounded-2xl border-2">
                      <span className="text-sm font-black uppercase tracking-wider">Acessar CRM Completo</span>
                      <ChevronRight className="h-5 w-5 opacity-40 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
                    </Button>
                 </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="geografico" className="animate-in fade-in slide-in-from-bottom-4 duration-500">
             <ClientGeographicMap />
          </TabsContent>

          <TabsContent value="crm" className="animate-in fade-in slide-in-from-bottom-4 duration-500">
             <CRMKanban />
          </TabsContent>
        </Tabs>
      </div>

      <ClientFormModal
        open={showFormModal}
        onOpenChange={setShowFormModal}
        onSubmit={handleQuickAddSubmit}
        isLoading={createClient.isPending}
      />
    </AppLayout>
  );
};

const Dashboard = () => {
  return (
    <DashboardFilterProvider>
      <DashboardContent />
    </DashboardFilterProvider>
  );
};

export default Dashboard;

