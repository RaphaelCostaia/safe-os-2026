import React from "react";
import { AppLayout } from "@/components/layout/AppLayout";
import { CRMKanban } from "@/components/dashboard/CRMKanban";

const CRM = () => {
  return (
    <AppLayout>
      <div className="container mx-auto px-6 py-10 space-y-10 animate-in fade-in duration-700">
        <CRMKanban />
      </div>
    </AppLayout>
  );
};

export default CRM;
