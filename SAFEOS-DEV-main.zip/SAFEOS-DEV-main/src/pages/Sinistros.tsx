import { useState, useMemo } from "react";
import { Plus, AlertTriangle, Download, Loader2, Paperclip, FileText, FileSpreadsheet } from "lucide-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  SinistroKPIs, 
  SinistroFilters, 
  SinistroFormModal, 
  SinistroTable,
  SinistroTimeline,
  SinistroNotesAndTips,
  type SinistroFiltersState 
} from "@/components/sinistros";
import type { SinistroFormData } from "@/components/sinistros/SinistroFormModal";
import { SinistroDocumentsModal } from "@/components/sinistros/SinistroDocumentsModal";
import { SinistroDocumentsSection } from "@/components/sinistros/SinistroDocumentsSection";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { 
  useSinistros, 
  useCreateSinistro, 
  useUpdateSinistro,
  type SinistroWithRelations 
} from "@/hooks/useSinistros";
import { useClients } from "@/hooks/useClients";
import { useApolices, type ApoliceWithRelations } from "@/hooks/useApolices";
import { useTeamMembers } from "@/hooks/useTeamMembers";
import { 
  prepareSinistrosExport, 
  exportToPDF, 
  exportToExcel,
  exportWithAudit 
} from "@/lib/exportUtils";

export default function Sinistros() {
  const [filters, setFilters] = useState<SinistroFiltersState>({
    search: "",
    status: "todos",
    criticidade: "todos",
    produto: "todos",
    tipoProfissional: "todos",
    responsavel: "todos",
    somentesCriticos: false,
    somentesAtrasados: false,
  });

  const [showFormModal, setShowFormModal] = useState(false);
  const [editingSinistro, setEditingSinistro] = useState<SinistroFormData | null>(null);
  const [selectedSinistro, setSelectedSinistro] = useState<SinistroWithRelations | null>(null);
  const [showResponsavelModal, setShowResponsavelModal] = useState(false);
  const [responsavelTarget, setResponsavelTarget] = useState<SinistroWithRelations | null>(null);
  const [newResponsavel, setNewResponsavel] = useState("");
  const [showDocumentsModal, setShowDocumentsModal] = useState(false);
  const [documentsTarget, setDocumentsTarget] = useState<SinistroWithRelations | null>(null);

  // Hooks
  const { data: sinistrosData = [], isLoading } = useSinistros();
  const { data: clientsData = [] } = useClients();
  const { data: apolicesData = [] } = useApolices();
  const createSinistro = useCreateSinistro();
  const updateSinistro = useUpdateSinistro();

  // Fetch team members for responsaveis dropdown
  const { data: teamMembersData = [] } = useTeamMembers(true);

  // Transform data for components
  const clientes = useMemo(() => 
    clientsData.map(c => ({
      id: c.id,
      nome: c.nome,
      cpf: c.cpf_cnpj || "",
      tipoProfissional: c.profissao || "Outro"
    })), [clientsData]
  );

  const apolices = useMemo(() => 
    apolicesData.map((a: ApoliceWithRelations) => ({
      id: a.id,
      numero: a.numero_apolice,
      produto: a.produtos?.nome || "",
      clienteId: a.client_id,
      seguradora: a.seguradora
    })), [apolicesData]
  );

  // Transform team members for responsaveis
  const responsaveis = useMemo(() => 
    teamMembersData.map(m => ({
      id: m.id,
      nome: m.full_name
    })), [teamMembersData]
  );

  // Helper to get responsavel name by id
  const getResponsavelNome = (id: string | null) => {
    if (!id) return "Não atribuído";
    const member = teamMembersData.find(m => m.id === id);
    return member?.full_name || "Não atribuído";
  };

  // Transform sinistros for table
  const sinistros = useMemo(() => 
    sinistrosData.map(s => ({
      id: s.id,
      clienteNome: s.clients?.nome || "",
      clienteCpf: s.clients?.cpf_cnpj || "",
      tipoProfissional: s.clients?.profissao || "Outro",
      produto: s.apolices?.produtos?.nome?.toLowerCase() || "outros",
      apoliceNumero: s.apolices?.numero_apolice,
      seguradora: s.apolices?.seguradora,
      status: s.status,
      criticidade: s.criticidade,
      dataOcorrencia: s.data_ocorrencia,
      dataAviso: s.data_aviso,
      responsavel: getResponsavelNome(s.responsavel_id),
      responsavelId: s.responsavel_id || "",
      ultimaAtualizacao: s.updated_at,
      protocolo: s.protocolo_seguradora,
      valorEstimado: s.valor_estimado,
      valorPago: s.valor_pago,
      descricaoResumida: s.descricao_resumida,
    })), [sinistrosData, teamMembersData]
  );

  // KPIs calculation
  const kpis = useMemo(() => {
    const now = new Date();
    return {
      abertos: sinistros.filter(s => s.status === "aberto").length,
      emAndamento: sinistros.filter(s => s.status === "em_andamento").length,
      aguardandoCliente: sinistros.filter(s => s.status === "aguardando_cliente").length,
      aguardandoSeguradora: sinistros.filter(s => s.status === "aguardando_seguradora").length,
      encerrados: sinistros.filter(s => s.status === "encerrado").length,
      criticos: sinistros.filter(s => s.criticidade === "critica" && !["encerrado", "arquivado"].includes(s.status)).length,
      atrasados: 0,
      valorEstimadoTotal: sinistros.reduce((acc, s) => acc + (s.valorEstimado || 0), 0),
      valorPagoTotal: sinistros.reduce((acc, s) => acc + (s.valorPago || 0), 0),
    };
  }, [sinistros]);

  // Filtered sinistros
  const filteredSinistros = useMemo(() => {
    return sinistros.filter(s => {
      if (filters.search) {
        const search = filters.search.toLowerCase();
        if (
          !s.clienteNome.toLowerCase().includes(search) &&
          !s.clienteCpf.includes(search) &&
          !(s.apoliceNumero?.toLowerCase().includes(search)) &&
          !(s.protocolo?.toLowerCase().includes(search))
        ) {
          return false;
        }
      }
      if (filters.status !== "todos" && s.status !== filters.status) return false;
      if (filters.criticidade !== "todos" && s.criticidade !== filters.criticidade) return false;
      if (filters.produto !== "todos" && s.produto !== filters.produto) return false;
      if (filters.tipoProfissional !== "todos" && s.tipoProfissional.toLowerCase() !== filters.tipoProfissional) return false;
      if (filters.somentesCriticos && s.criticidade !== "critica") return false;
      if (filters.dataOcorrenciaInicio && new Date(s.dataOcorrencia) < filters.dataOcorrenciaInicio) return false;
      if (filters.dataOcorrenciaFim && new Date(s.dataOcorrencia) > filters.dataOcorrenciaFim) return false;
      return true;
    });
  }, [sinistros, filters]);

  const handleCreateSinistro = (data: SinistroFormData) => {
    const sinistroData = {
      client_id: data.clienteId,
      apolice_id: data.apoliceId || apolices.find(a => a.clienteId === data.clienteId)?.id || "",
      numero_sinistro: data.protocolo || `SIN-${Date.now()}`,
      data_ocorrencia: data.dataOcorrencia,
      data_aviso: data.dataAviso,
      descricao_resumida: data.descricaoResumida,
      descricao_detalhada: data.descricaoDetalhada,
      criticidade: data.criticidade,
      status: data.status,
      protocolo_seguradora: data.protocolo,
      valor_estimado: data.valorEstimado,
      valor_pago: data.valorPago,
    };

    if (data.id) {
      updateSinistro.mutate({ id: data.id, ...sinistroData }, {
        onSuccess: () => {
          setShowFormModal(false);
          setEditingSinistro(null);
        }
      });
    } else {
      createSinistro.mutate(sinistroData, {
        onSuccess: () => {
          setShowFormModal(false);
          setEditingSinistro(null);
        }
      });
    }
  };

  const handleEditSinistro = (sinistro: any) => {
    const original = sinistrosData.find(s => s.id === sinistro.id);
    if (!original) return;
    
    setEditingSinistro({
      id: sinistro.id,
      clienteId: original.client_id,
      produto: sinistro.produto,
      apoliceId: original.apolice_id,
      seguradora: sinistro.seguradora,
      dataOcorrencia: sinistro.dataOcorrencia,
      dataAviso: sinistro.dataAviso,
      descricaoResumida: sinistro.descricaoResumida,
      descricaoDetalhada: original.descricao_detalhada || "",
      criticidade: sinistro.criticidade,
      status: sinistro.status,
      responsavel: sinistro.responsavelId,
      protocolo: sinistro.protocolo,
      valorEstimado: sinistro.valorEstimado,
      valorPago: sinistro.valorPago,
    });
    setShowFormModal(true);
  };

  const handleChangeStatus = (sinistro: any, newStatus: string) => {
    const original = sinistrosData.find(s => s.id === sinistro.id);
    if (!original) return;
    
    updateSinistro.mutate({ 
      id: sinistro.id, 
      status: newStatus,
      previousData: { status: original.status }
    }, {
      onSuccess: () => toast.success(`Status alterado para ${newStatus.replace("_", " ")}`)
    });
  };

  const handleChangeResponsavel = (sinistro: any) => {
    const original = sinistrosData.find(s => s.id === sinistro.id);
    if (!original) return;
    
    setResponsavelTarget(original);
    setNewResponsavel(sinistro.responsavelId);
    setShowResponsavelModal(true);
  };

  const confirmResponsavelChange = () => {
    if (responsavelTarget && newResponsavel) {
      updateSinistro.mutate({ 
        id: responsavelTarget.id, 
        responsavel_id: newResponsavel,
        previousData: { responsavel_id: responsavelTarget.responsavel_id }
      }, {
        onSuccess: () => {
          toast.success(`Responsável alterado`);
          setShowResponsavelModal(false);
          setResponsavelTarget(null);
        }
      });
    }
  };

  const handleViewSinistro = (sinistro: any) => {
    const original = sinistrosData.find(s => s.id === sinistro.id);
    if (original) setSelectedSinistro(original);
  };

  const handleAttachDocuments = (sinistro: any) => {
    const original = sinistrosData.find(s => s.id === sinistro.id);
    if (original) {
      setDocumentsTarget(original);
      setShowDocumentsModal(true);
    }
  };

  // Export handlers
  const handleExportPDF = async () => {
    const exportData = prepareSinistrosExport(filteredSinistros);
    await exportWithAudit(exportData, {
      format: 'pdf',
      filename: 'sinistros',
      entityType: 'sinistros',
      filters,
    });
    toast.success("Sinistros exportados em PDF");
  };

  const handleExportExcel = async () => {
    const exportData = prepareSinistrosExport(filteredSinistros);
    await exportWithAudit(exportData, {
      format: 'excel',
      filename: 'sinistros',
      entityType: 'sinistros',
      filters,
    });
    toast.success("Sinistros exportados em Excel");
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-96">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="content-wrapper">
        <div className="space-y-6">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <AlertTriangle className="h-6 w-6 text-amber-500" />
                <h1 className="text-3xl font-bold tracking-tight">Sinistros</h1>
              </div>
              <p className="text-muted-foreground font-medium">
                Gestão completa de sinistros e acompanhamento operacional
              </p>
            </div>
          <div className="flex gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2">
                  <Download className="h-4 w-4" />
                  Exportar
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handleExportPDF}>
                  <FileText className="h-4 w-4 mr-2" />
                  Exportar PDF
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleExportExcel}>
                  <FileSpreadsheet className="h-4 w-4 mr-2" />
                  Exportar Excel
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button onClick={() => setShowFormModal(true)} className="gap-2">
              <Plus className="h-4 w-4" />
              Novo Sinistro
            </Button>
          </div>
        </div>

        {/* KPIs */}
        <SinistroKPIs data={kpis} />

        {/* Filters */}
        <SinistroFilters
          filters={filters}
          onFiltersChange={setFilters}
          responsaveis={responsaveis}
        />

        {/* Results count */}
        <div className="text-sm text-muted-foreground">
          {filteredSinistros.length} sinistro(s) encontrado(s)
        </div>

        {/* Table */}
        <SinistroTable
          sinistros={filteredSinistros}
          onView={handleViewSinistro}
          onEdit={handleEditSinistro}
          onChangeResponsavel={handleChangeResponsavel}
          onChangeStatus={handleChangeStatus}
          onAttachDocuments={handleAttachDocuments}
        />

        {/* Form Modal */}
        <SinistroFormModal
          open={showFormModal}
          onOpenChange={(open) => {
            setShowFormModal(open);
            if (!open) setEditingSinistro(null);
          }}
          onSubmit={handleCreateSinistro}
          clientes={clientes}
          apolices={apolices}
          responsaveis={responsaveis}
          editData={editingSinistro}
        />

        {/* Detail Sheet */}
        <Sheet open={!!selectedSinistro} onOpenChange={() => setSelectedSinistro(null)}>
          <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
            {selectedSinistro && (
              <>
                <SheetHeader>
                  <SheetTitle className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-amber-500" />
                    Detalhes do Sinistro
                  </SheetTitle>
                </SheetHeader>
                <div className="space-y-6 mt-6">
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Protocolo</p>
                    <p className="font-mono text-lg">{selectedSinistro.protocolo_seguradora || selectedSinistro.numero_sinistro}</p>
                  </div>

                  <Separator />

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Cliente</p>
                      <p className="font-medium">{selectedSinistro.clients?.nome}</p>
                      <p className="text-xs text-muted-foreground">{selectedSinistro.clients?.cpf_cnpj}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Tipo</p>
                      <Badge variant="outline">{selectedSinistro.clients?.profissao || "—"}</Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Produto</p>
                      <p className="font-medium">{selectedSinistro.apolices?.produtos?.nome || "—"}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Apólice</p>
                      <p className="font-medium">{selectedSinistro.apolices?.numero_apolice || "—"}</p>
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Descrição</p>
                    <p className="text-sm">{selectedSinistro.descricao_resumida}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Data Ocorrência</p>
                      <p>{format(new Date(selectedSinistro.data_ocorrencia), "dd/MM/yyyy", { locale: ptBR })}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Data Aviso</p>
                      <p>{format(new Date(selectedSinistro.data_aviso), "dd/MM/yyyy", { locale: ptBR })}</p>
                    </div>
                  </div>

                  <div>
                    <p className="text-sm text-muted-foreground">Responsável</p>
                    <p className="font-medium">{getResponsavelNome(selectedSinistro.responsavel_id)}</p>
                  </div>

                  {(selectedSinistro.valor_estimado || selectedSinistro.valor_pago) && (
                    <>
                      <Separator />
                      <div className="grid grid-cols-2 gap-4">
                        {selectedSinistro.valor_estimado && (
                          <div>
                            <p className="text-sm text-muted-foreground">Valor Estimado</p>
                            <p className="text-lg font-bold text-amber-400">
                              {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(selectedSinistro.valor_estimado)}
                            </p>
                          </div>
                        )}
                        {selectedSinistro.valor_pago && (
                          <div>
                            <p className="text-sm text-muted-foreground">Valor Pago</p>
                            <p className="text-lg font-bold text-emerald-400">
                              {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(selectedSinistro.valor_pago)}
                            </p>
                          </div>
                        )}
                      </div>
                    </>
                  )}

                  <Separator />

                  {/* Timeline Section */}
                  <SinistroTimeline sinistroId={selectedSinistro.id} />

                  {/* Notes and Tips Section */}
                  <SinistroNotesAndTips 
                    sinistroId={selectedSinistro.id}
                    produtoCategoria={selectedSinistro.apolices?.produtos?.categoria}
                  />

                  <Separator />

                  {/* Documents Section */}
                  <SinistroDocumentsSection
                    sinistroId={selectedSinistro.id}
                    onOpenModal={() => {
                      setDocumentsTarget(selectedSinistro);
                      setShowDocumentsModal(true);
                    }}
                  />
                </div>
              </>
            )}
          </SheetContent>
        </Sheet>

        {/* Documents Modal */}
        {documentsTarget && (
          <SinistroDocumentsModal
            open={showDocumentsModal}
            onOpenChange={(open) => {
              setShowDocumentsModal(open);
              if (!open) setDocumentsTarget(null);
            }}
            sinistroId={documentsTarget.id}
            clientId={documentsTarget.client_id}
            apoliceId={documentsTarget.apolice_id}
            sinistroNumero={documentsTarget.protocolo_seguradora || documentsTarget.numero_sinistro}
          />
        )}

        {/* Responsavel Modal */}
        <Dialog open={showResponsavelModal} onOpenChange={setShowResponsavelModal}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Alterar Responsável</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <Select value={newResponsavel} onValueChange={setNewResponsavel}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o responsável" />
                </SelectTrigger>
                <SelectContent>
                  {responsaveis.map((r) => (
                    <SelectItem key={r.id} value={r.id}>{r.nome}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowResponsavelModal(false)}>
                  Cancelar
                </Button>
                <Button onClick={confirmResponsavelChange}>
                  Confirmar
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  </AppLayout>
);
}
