// Mock data estruturada para a página Financeiro
// Facilmente substituível por dados reais do Supabase

export interface ComissaoItem {
  id: string;
  cliente: string;
  produto: 'RCP' | 'Vida' | 'DIT' | 'Outros';
  apolice: string;
  seguradora: string;
  competencia: string;
  comissaoPrevista: number;
  comissaoRecebida: number;
  status: 'prevista' | 'recebida' | 'atrasada';
}

export interface CustoFixo {
  id: string;
  categoria: 'salarios' | 'aluguel' | 'ferramentas' | 'marketing' | 'impostos' | 'outros';
  descricao: string;
  valor: number;
  recorrencia: 'mensal' | 'anual' | 'trimestral';
  status: 'ativo' | 'inativo';
}

export interface ContaPagarReceber {
  id: string;
  tipo: 'pagar' | 'receber';
  descricao: string;
  categoria: string;
  valor: number;
  vencimento: string;
  status: 'pendente' | 'pago' | 'atrasado';
  responsavel: string;
}

export interface ProjecaoMensal {
  mes: string;
  receitaEstimada: number;
  custosEstimados: number;
  resultado: number;
}

export interface AlertaFinanceiro {
  id: string;
  tipo: 'vencida' | 'vencer_7' | 'vencer_15' | 'vencer_30' | 'queda_receita';
  titulo: string;
  valor?: number;
  quantidade?: number;
}

// Categorias de custos fixos
export const categoriasCustoFixo = [
  { value: 'salarios', label: 'Salários' },
  { value: 'aluguel', label: 'Aluguel' },
  { value: 'ferramentas', label: 'Ferramentas/Software' },
  { value: 'marketing', label: 'Marketing' },
  { value: 'impostos', label: 'Impostos' },
  { value: 'outros', label: 'Outros' },
];

// Mock KPIs
export const mockKPIs = {
  receitaRecorrenteMensal: 87500,
  receitaRecorrenteAnual: 1050000,
  comissoesPrevistasMes: 32800,
  custosFixosMes: 24500,
  resultadoOperacional: 63000,
};

// Mock dados de tendência (últimos 12 meses)
export const mockTendenciaMensal: ProjecaoMensal[] = [
  { mes: 'Jan', receitaEstimada: 78000, custosEstimados: 23000, resultado: 55000 },
  { mes: 'Fev', receitaEstimada: 81000, custosEstimados: 23500, resultado: 57500 },
  { mes: 'Mar', receitaEstimada: 79500, custosEstimados: 24000, resultado: 55500 },
  { mes: 'Abr', receitaEstimada: 84000, custosEstimados: 23800, resultado: 60200 },
  { mes: 'Mai', receitaEstimada: 82500, custosEstimados: 24200, resultado: 58300 },
  { mes: 'Jun', receitaEstimada: 85000, custosEstimados: 24000, resultado: 61000 },
  { mes: 'Jul', receitaEstimada: 86500, custosEstimados: 24100, resultado: 62400 },
  { mes: 'Ago', receitaEstimada: 83000, custosEstimados: 24300, resultado: 58700 },
  { mes: 'Set', receitaEstimada: 88000, custosEstimados: 24400, resultado: 63600 },
  { mes: 'Out', receitaEstimada: 85500, custosEstimados: 24200, resultado: 61300 },
  { mes: 'Nov', receitaEstimada: 89000, custosEstimados: 24600, resultado: 64400 },
  { mes: 'Dez', receitaEstimada: 87500, custosEstimados: 24500, resultado: 63000 },
];

// Mock alertas financeiros
export const mockAlertas: AlertaFinanceiro[] = [
  { id: '1', tipo: 'vencida', titulo: 'Contas vencidas', quantidade: 3, valor: 4580 },
  { id: '2', tipo: 'vencer_7', titulo: 'Vencem em 7 dias', quantidade: 5, valor: 8200 },
  { id: '3', tipo: 'vencer_15', titulo: 'Vencem em 15 dias', quantidade: 8, valor: 12400 },
  { id: '4', tipo: 'vencer_30', titulo: 'Vencem em 30 dias', quantidade: 12, valor: 18500 },
  { id: '5', tipo: 'queda_receita', titulo: 'Queda de 8% vs mês anterior', valor: 7200 },
];

// Mock comissões
export const mockComissoes: ComissaoItem[] = [
  { id: '1', cliente: 'Dr. Carlos Mendes', produto: 'RCP', apolice: 'APL-2024-001', seguradora: 'Porto Seguro', competencia: '2026-01', comissaoPrevista: 1250, comissaoRecebida: 1250, status: 'recebida' },
  { id: '2', cliente: 'Dra. Ana Paula Silva', produto: 'Vida', apolice: 'APL-2024-002', seguradora: 'SulAmérica', competencia: '2026-01', comissaoPrevista: 890, comissaoRecebida: 890, status: 'recebida' },
  { id: '3', cliente: 'Hospital São Lucas', produto: 'RCP', apolice: 'APL-2024-003', seguradora: 'Bradesco Seguros', competencia: '2026-01', comissaoPrevista: 3200, comissaoRecebida: 0, status: 'prevista' },
  { id: '4', cliente: 'Clínica Bem Estar', produto: 'DIT', apolice: 'APL-2024-004', seguradora: 'Tokio Marine', competencia: '2026-01', comissaoPrevista: 1800, comissaoRecebida: 0, status: 'atrasada' },
  { id: '5', cliente: 'Dr. Roberto Almeida', produto: 'RCP', apolice: 'APL-2024-005', seguradora: 'Porto Seguro', competencia: '2026-01', comissaoPrevista: 980, comissaoRecebida: 980, status: 'recebida' },
  { id: '6', cliente: 'Dra. Marina Costa', produto: 'Vida', apolice: 'APL-2024-006', seguradora: 'Prudential', competencia: '2026-01', comissaoPrevista: 1450, comissaoRecebida: 0, status: 'prevista' },
  { id: '7', cliente: 'Centro Médico Paulista', produto: 'Outros', apolice: 'APL-2024-007', seguradora: 'Liberty', competencia: '2025-12', comissaoPrevista: 2100, comissaoRecebida: 0, status: 'atrasada' },
  { id: '8', cliente: 'Dr. Fernando Santos', produto: 'DIT', apolice: 'APL-2024-008', seguradora: 'SulAmérica', competencia: '2026-01', comissaoPrevista: 720, comissaoRecebida: 720, status: 'recebida' },
  { id: '9', cliente: 'Dra. Juliana Ferreira', produto: 'RCP', apolice: 'APL-2024-009', seguradora: 'Zurich', competencia: '2026-01', comissaoPrevista: 1560, comissaoRecebida: 0, status: 'prevista' },
  { id: '10', cliente: 'Laboratório Vida', produto: 'Outros', apolice: 'APL-2024-010', seguradora: 'Mapfre', competencia: '2026-01', comissaoPrevista: 2800, comissaoRecebida: 2800, status: 'recebida' },
];

// Mock custos fixos
export const mockCustosFixos: CustoFixo[] = [
  { id: '1', categoria: 'salarios', descricao: 'Folha de pagamento', valor: 15000, recorrencia: 'mensal', status: 'ativo' },
  { id: '2', categoria: 'aluguel', descricao: 'Aluguel escritório', valor: 3500, recorrencia: 'mensal', status: 'ativo' },
  { id: '3', categoria: 'ferramentas', descricao: 'CRM + Sistema de gestão', valor: 890, recorrencia: 'mensal', status: 'ativo' },
  { id: '4', categoria: 'ferramentas', descricao: 'Office 365', valor: 450, recorrencia: 'mensal', status: 'ativo' },
  { id: '5', categoria: 'marketing', descricao: 'Google Ads', valor: 1200, recorrencia: 'mensal', status: 'ativo' },
  { id: '6', categoria: 'marketing', descricao: 'Redes sociais', valor: 800, recorrencia: 'mensal', status: 'ativo' },
  { id: '7', categoria: 'impostos', descricao: 'Simples Nacional', valor: 2100, recorrencia: 'mensal', status: 'ativo' },
  { id: '8', categoria: 'outros', descricao: 'Contador', valor: 560, recorrencia: 'mensal', status: 'ativo' },
  { id: '9', categoria: 'outros', descricao: 'Plano de saúde funcionários', valor: 0, recorrencia: 'mensal', status: 'inativo' },
];

// Mock contas a pagar/receber
export const mockContas: ContaPagarReceber[] = [
  { id: '1', tipo: 'pagar', descricao: 'Aluguel Janeiro', categoria: 'Aluguel', valor: 3500, vencimento: '2026-01-10', status: 'pago', responsavel: 'Admin' },
  { id: '2', tipo: 'pagar', descricao: 'Energia elétrica', categoria: 'Utilidades', valor: 450, vencimento: '2026-01-15', status: 'pendente', responsavel: 'Admin' },
  { id: '3', tipo: 'pagar', descricao: 'Internet', categoria: 'Utilidades', valor: 280, vencimento: '2026-01-08', status: 'atrasado', responsavel: 'Admin' },
  { id: '4', tipo: 'pagar', descricao: 'Salários', categoria: 'Pessoal', valor: 15000, vencimento: '2026-01-05', status: 'pago', responsavel: 'RH' },
  { id: '5', tipo: 'pagar', descricao: 'Impostos DAS', categoria: 'Impostos', valor: 2100, vencimento: '2026-01-20', status: 'pendente', responsavel: 'Financeiro' },
  { id: '6', tipo: 'receber', descricao: 'Comissão Porto Seguro', categoria: 'Comissões', valor: 4500, vencimento: '2026-01-12', status: 'pendente', responsavel: 'Financeiro' },
  { id: '7', tipo: 'receber', descricao: 'Comissão SulAmérica', categoria: 'Comissões', valor: 2800, vencimento: '2026-01-05', status: 'atrasado', responsavel: 'Financeiro' },
  { id: '8', tipo: 'receber', descricao: 'Comissão Bradesco', categoria: 'Comissões', valor: 3200, vencimento: '2026-01-18', status: 'pendente', responsavel: 'Financeiro' },
  { id: '9', tipo: 'receber', descricao: 'Consultoria Sr. Mendes', categoria: 'Serviços', valor: 1500, vencimento: '2026-01-25', status: 'pendente', responsavel: 'Comercial' },
  { id: '10', tipo: 'receber', descricao: 'Comissão Tokio Marine', categoria: 'Comissões', valor: 1800, vencimento: '2025-12-28', status: 'atrasado', responsavel: 'Financeiro' },
];

// Gerar projeções futuras
export const gerarProjecoes = (meses: 12 | 24 | 36): ProjecaoMensal[] => {
  const projecoes: ProjecaoMensal[] = [];
  const mesesNome = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
  
  const receitaBase = 87500;
  const custoBase = 24500;
  const taxaCrescimento = 0.02; // 2% ao mês
  const taxaInflacao = 0.005; // 0.5% ao mês
  
  for (let i = 0; i < meses; i++) {
    const ano = 2026 + Math.floor(i / 12);
    const mesIndex = i % 12;
    const receita = Math.round(receitaBase * Math.pow(1 + taxaCrescimento, i));
    const custo = Math.round(custoBase * Math.pow(1 + taxaInflacao, i));
    
    projecoes.push({
      mes: `${mesesNome[mesIndex]}/${ano}`,
      receitaEstimada: receita,
      custosEstimados: custo,
      resultado: receita - custo,
    });
  }
  
  return projecoes;
};
