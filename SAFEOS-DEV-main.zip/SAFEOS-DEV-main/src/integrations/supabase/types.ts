export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      activity_log: {
        Row: {
          action: string
          created_at: string
          description: string | null
          entity_id: string
          entity_type: string
          id: string
          metadata: Json | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          description?: string | null
          entity_id: string
          entity_type: string
          id?: string
          metadata?: Json | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          description?: string | null
          entity_id?: string
          entity_type?: string
          id?: string
          metadata?: Json | null
          user_id?: string | null
        }
        Relationships: []
      }
      apolice_documents: {
        Row: {
          apolice_id: string
          created_at: string
          id: string
          nome: string
          tamanho: number | null
          tipo: string
          uploaded_by: string | null
          url: string
        }
        Insert: {
          apolice_id: string
          created_at?: string
          id?: string
          nome: string
          tamanho?: number | null
          tipo: string
          uploaded_by?: string | null
          url: string
        }
        Update: {
          apolice_id?: string
          created_at?: string
          id?: string
          nome?: string
          tamanho?: number | null
          tipo?: string
          uploaded_by?: string | null
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "apolice_documents_apolice_id_fkey"
            columns: ["apolice_id"]
            isOneToOne: false
            referencedRelation: "apolices"
            referencedColumns: ["id"]
          },
        ]
      }
      apolices: {
        Row: {
          client_id: string
          created_at: string
          data_fim: string
          data_inicio: string
          deleted_at: string | null
          deleted_by: string | null
          forma_pagamento: string | null
          id: string
          numero_apolice: string
          observacoes: string | null
          parcelas: number | null
          produto_id: string
          responsavel_id: string | null
          seguradora: string
          status: string
          updated_at: string
          valor_cobertura: number | null
          valor_premio: number
        }
        Insert: {
          client_id: string
          created_at?: string
          data_fim: string
          data_inicio: string
          deleted_at?: string | null
          deleted_by?: string | null
          forma_pagamento?: string | null
          id?: string
          numero_apolice: string
          observacoes?: string | null
          parcelas?: number | null
          produto_id: string
          responsavel_id?: string | null
          seguradora: string
          status?: string
          updated_at?: string
          valor_cobertura?: number | null
          valor_premio: number
        }
        Update: {
          client_id?: string
          created_at?: string
          data_fim?: string
          data_inicio?: string
          deleted_at?: string | null
          deleted_by?: string | null
          forma_pagamento?: string | null
          id?: string
          numero_apolice?: string
          observacoes?: string | null
          parcelas?: number | null
          produto_id?: string
          responsavel_id?: string | null
          seguradora?: string
          status?: string
          updated_at?: string
          valor_cobertura?: number | null
          valor_premio?: number
        }
        Relationships: [
          {
            foreignKeyName: "apolices_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "apolices_produto_id_fkey"
            columns: ["produto_id"]
            isOneToOne: false
            referencedRelation: "produtos"
            referencedColumns: ["id"]
          },
        ]
      }
      client_commission_terms: {
        Row: {
          client_id: string
          created_at: string
          created_by: string | null
          ends_at: string | null
          fixed_amount: number | null
          id: string
          is_active: boolean
          model: string
          notes: string | null
          percent: number | null
          produto_id: string | null
          starts_at: string | null
          updated_at: string
        }
        Insert: {
          client_id: string
          created_at?: string
          created_by?: string | null
          ends_at?: string | null
          fixed_amount?: number | null
          id?: string
          is_active?: boolean
          model: string
          notes?: string | null
          percent?: number | null
          produto_id?: string | null
          starts_at?: string | null
          updated_at?: string
        }
        Update: {
          client_id?: string
          created_at?: string
          created_by?: string | null
          ends_at?: string | null
          fixed_amount?: number | null
          id?: string
          is_active?: boolean
          model?: string
          notes?: string | null
          percent?: number | null
          produto_id?: string | null
          starts_at?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_commission_terms_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "client_commission_terms_produto_id_fkey"
            columns: ["produto_id"]
            isOneToOne: false
            referencedRelation: "produtos"
            referencedColumns: ["id"]
          }
        ]
      }
      client_documents: {
        Row: {
          client_id: string
          created_at: string
          id: string
          nome: string
          tamanho: number | null
          tipo: string
          uploaded_by: string | null
          url: string
        }
        Insert: {
          client_id: string
          created_at?: string
          id?: string
          nome: string
          tamanho?: number | null
          tipo: string
          uploaded_by?: string | null
          url: string
        }
        Update: {
          client_id?: string
          created_at?: string
          id?: string
          nome?: string
          tamanho?: number | null
          tipo?: string
          uploaded_by?: string | null
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_documents_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      client_notes: {
        Row: {
          autor_id: string | null
          client_id: string
          conteudo: string
          created_at: string
          id: string
          updated_at: string
        }
        Insert: {
          autor_id?: string | null
          client_id: string
          conteudo: string
          created_at?: string
          id?: string
          updated_at?: string
        }
        Update: {
          autor_id?: string | null
          client_id?: string
          conteudo?: string
          created_at?: string
          id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_notes_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      clients: {
        Row: {
          cep: string | null
          cidade: string | null
          cpf_cnpj: string | null
          created_at: string
          data_nascimento: string | null
          deleted_at: string | null
          deleted_by: string | null
          email: string | null
          endereco: string | null
          estado: string | null
          id: string
          nome: string
          observacoes: string | null
          profissao: string | null
          responsavel_id: string | null
          status: string
          telefone: string | null
          tipo_pessoa: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          cep?: string | null
          cidade?: string | null
          cpf_cnpj?: string | null
          created_at?: string
          data_nascimento?: string | null
          deleted_at?: string | null
          deleted_by?: string | null
          email?: string | null
          endereco?: string | null
          estado?: string | null
          id?: string
          nome: string
          observacoes?: string | null
          profissao?: string | null
          responsavel_id?: string | null
          status?: string
          telefone?: string | null
          tipo_pessoa?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          cep?: string | null
          cidade?: string | null
          cpf_cnpj?: string | null
          created_at?: string
          data_nascimento?: string | null
          deleted_at?: string | null
          deleted_by?: string | null
          email?: string | null
          endereco?: string | null
          estado?: string | null
          id?: string
          nome?: string
          observacoes?: string | null
          profissao?: string | null
          responsavel_id?: string | null
          status?: string
          telefone?: string | null
          tipo_pessoa?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      contas: {
        Row: {
          apolice_id: string | null
          categoria: string
          cliente_id: string | null
          created_at: string
          data_pagamento: string | null
          descricao: string
          id: string
          observacoes: string | null
          responsavel_id: string | null
          status: string
          tipo: string
          updated_at: string
          valor: number
          vencimento: string
        }
        Insert: {
          apolice_id?: string | null
          categoria: string
          cliente_id?: string | null
          created_at?: string
          data_pagamento?: string | null
          descricao: string
          id?: string
          observacoes?: string | null
          responsavel_id?: string | null
          status?: string
          tipo: string
          updated_at?: string
          valor?: number
          vencimento: string
        }
        Update: {
          apolice_id?: string | null
          categoria?: string
          cliente_id?: string | null
          created_at?: string
          data_pagamento?: string | null
          descricao?: string
          id?: string
          observacoes?: string | null
          responsavel_id?: string | null
          status?: string
          tipo?: string
          updated_at?: string
          valor?: number
          vencimento?: string
        }
        Relationships: [
          {
            foreignKeyName: "contas_apolice_id_fkey"
            columns: ["apolice_id"]
            isOneToOne: false
            referencedRelation: "apolices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contas_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      custos_fixos: {
        Row: {
          categoria: string
          created_at: string
          descricao: string
          id: string
          recorrencia: string
          responsavel_id: string | null
          status: string
          updated_at: string
          valor: number
        }
        Insert: {
          categoria: string
          created_at?: string
          descricao: string
          id?: string
          recorrencia?: string
          responsavel_id?: string | null
          status?: string
          updated_at?: string
          valor?: number
        }
        Update: {
          categoria?: string
          created_at?: string
          descricao?: string
          id?: string
          recorrencia?: string
          responsavel_id?: string | null
          status?: string
          updated_at?: string
          valor?: number
        }
        Relationships: []
      }
      financeiro_historico: {
        Row: {
          ano: number
          created_at: string
          custos_fixos: number
          custos_total: number
          custos_variaveis: number
          id: string
          mes: number
          observacoes: string | null
          receita_comissoes: number
          receita_outras: number
          receita_premios: number
          receita_total: number
          resultado_operacional: number
          ticket_medio: number | null
          total_apolices_ativas: number | null
          total_clientes_ativos: number | null
          updated_at: string
        }
        Insert: {
          ano: number
          created_at?: string
          custos_fixos?: number
          custos_total?: number
          custos_variaveis?: number
          id?: string
          mes: number
          observacoes?: string | null
          receita_comissoes?: number
          receita_outras?: number
          receita_premios?: number
          receita_total?: number
          resultado_operacional?: number
          ticket_medio?: number | null
          total_apolices_ativas?: number | null
          total_clientes_ativos?: number | null
          updated_at?: string
        }
        Update: {
          ano?: number
          created_at?: string
          custos_fixos?: number
          custos_total?: number
          custos_variaveis?: number
          id?: string
          mes?: number
          observacoes?: string | null
          receita_comissoes?: number
          receita_outras?: number
          receita_premios?: number
          receita_total?: number
          resultado_operacional?: number
          ticket_medio?: number | null
          total_apolices_ativas?: number | null
          total_clientes_ativos?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      produtos: {
        Row: {
          ativo: boolean
          categoria: string
          codigo: string
          comissao_percentual: number | null
          created_at: string
          descricao: string | null
          id: string
          nome: string
          seguradora: string
          updated_at: string
        }
        Insert: {
          ativo?: boolean
          categoria: string
          codigo: string
          comissao_percentual?: number | null
          created_at?: string
          descricao?: string | null
          id?: string
          nome: string
          seguradora: string
          updated_at?: string
        }
        Update: {
          ativo?: boolean
          categoria?: string
          codigo?: string
          comissao_percentual?: number | null
          created_at?: string
          descricao?: string | null
          id?: string
          nome?: string
          seguradora?: string
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string
          full_name: string
          id: string
          phone: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email: string
          full_name: string
          id: string
          phone?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          phone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      renovacoes: {
        Row: {
          apolice_id: string
          created_at: string
          data_contato: string | null
          data_vencimento: string
          id: string
          observacoes: string | null
          responsavel_id: string | null
          status: string
          updated_at: string
          valor_anterior: number | null
          valor_novo: number | null
        }
        Insert: {
          apolice_id: string
          created_at?: string
          data_contato?: string | null
          data_vencimento: string
          id?: string
          observacoes?: string | null
          responsavel_id?: string | null
          status?: string
          updated_at?: string
          valor_anterior?: number | null
          valor_novo?: number | null
        }
        Update: {
          apolice_id?: string
          created_at?: string
          data_contato?: string | null
          data_vencimento?: string
          id?: string
          observacoes?: string | null
          responsavel_id?: string | null
          status?: string
          updated_at?: string
          valor_anterior?: number | null
          valor_novo?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "renovacoes_apolice_id_fkey"
            columns: ["apolice_id"]
            isOneToOne: false
            referencedRelation: "apolices"
            referencedColumns: ["id"]
          },
        ]
      }
      sinistro_activities: {
        Row: {
          created_at: string
          descricao: string | null
          id: string
          metadata: Json | null
          sinistro_id: string
          tipo: string
          titulo: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          descricao?: string | null
          id?: string
          metadata?: Json | null
          sinistro_id: string
          tipo: string
          titulo: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          descricao?: string | null
          id?: string
          metadata?: Json | null
          sinistro_id?: string
          tipo?: string
          titulo?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "sinistro_activities_sinistro_id_fkey"
            columns: ["sinistro_id"]
            isOneToOne: false
            referencedRelation: "sinistros"
            referencedColumns: ["id"]
          },
        ]
      }
      sinistro_documents: {
        Row: {
          apolice_id: string | null
          client_id: string
          created_at: string
          data_documento: string
          descricao: string | null
          id: string
          nome: string
          sinistro_id: string
          tamanho: number | null
          tipo: string
          updated_at: string
          uploaded_by: string | null
          url: string
        }
        Insert: {
          apolice_id?: string | null
          client_id: string
          created_at?: string
          data_documento?: string
          descricao?: string | null
          id?: string
          nome: string
          sinistro_id: string
          tamanho?: number | null
          tipo: string
          updated_at?: string
          uploaded_by?: string | null
          url: string
        }
        Update: {
          apolice_id?: string | null
          client_id?: string
          created_at?: string
          data_documento?: string
          descricao?: string | null
          id?: string
          nome?: string
          sinistro_id?: string
          tamanho?: number | null
          tipo?: string
          updated_at?: string
          uploaded_by?: string | null
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "sinistro_documents_apolice_id_fkey"
            columns: ["apolice_id"]
            isOneToOne: false
            referencedRelation: "apolices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sinistro_documents_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sinistro_documents_sinistro_id_fkey"
            columns: ["sinistro_id"]
            isOneToOne: false
            referencedRelation: "sinistros"
            referencedColumns: ["id"]
          },
        ]
      }
      sinistro_notes: {
        Row: {
          autor_id: string | null
          conteudo: string
          created_at: string
          id: string
          is_pinned: boolean | null
          is_private: boolean | null
          sinistro_id: string
          tags: string[] | null
          updated_at: string
        }
        Insert: {
          autor_id?: string | null
          conteudo: string
          created_at?: string
          id?: string
          is_pinned?: boolean | null
          is_private?: boolean | null
          sinistro_id: string
          tags?: string[] | null
          updated_at?: string
        }
        Update: {
          autor_id?: string | null
          conteudo?: string
          created_at?: string
          id?: string
          is_pinned?: boolean | null
          is_private?: boolean | null
          sinistro_id?: string
          tags?: string[] | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "sinistro_notes_sinistro_id_fkey"
            columns: ["sinistro_id"]
            isOneToOne: false
            referencedRelation: "sinistros"
            referencedColumns: ["id"]
          },
        ]
      }
      sinistro_tips: {
        Row: {
          ativo: boolean | null
          categoria: string | null
          conteudo: string
          created_at: string
          id: string
          link_interno: string | null
          ordem: number | null
          titulo: string
          updated_at: string
        }
        Insert: {
          ativo?: boolean | null
          categoria?: string | null
          conteudo: string
          created_at?: string
          id?: string
          link_interno?: string | null
          ordem?: number | null
          titulo: string
          updated_at?: string
        }
        Update: {
          ativo?: boolean | null
          categoria?: string | null
          conteudo?: string
          created_at?: string
          id?: string
          link_interno?: string | null
          ordem?: number | null
          titulo?: string
          updated_at?: string
        }
        Relationships: []
      }
      sinistros: {
        Row: {
          apolice_id: string
          client_id: string
          created_at: string
          criticidade: string
          data_aviso: string
          data_ocorrencia: string
          deleted_at: string | null
          deleted_by: string | null
          descricao_detalhada: string | null
          descricao_resumida: string
          id: string
          numero_sinistro: string
          observacoes: string | null
          protocolo_seguradora: string | null
          responsavel_id: string | null
          status: string
          updated_at: string
          valor_aprovado: number | null
          valor_estimado: number | null
          valor_pago: number | null
        }
        Insert: {
          apolice_id: string
          client_id: string
          created_at?: string
          criticidade?: string
          data_aviso?: string
          data_ocorrencia: string
          deleted_at?: string | null
          deleted_by?: string | null
          descricao_detalhada?: string | null
          descricao_resumida: string
          id?: string
          numero_sinistro: string
          observacoes?: string | null
          protocolo_seguradora?: string | null
          responsavel_id?: string | null
          status?: string
          updated_at?: string
          valor_aprovado?: number | null
          valor_estimado?: number | null
          valor_pago?: number | null
        }
        Update: {
          apolice_id?: string
          client_id?: string
          created_at?: string
          criticidade?: string
          data_aviso?: string
          data_ocorrencia?: string
          deleted_at?: string | null
          deleted_by?: string | null
          descricao_detalhada?: string | null
          descricao_resumida?: string
          id?: string
          numero_sinistro?: string
          observacoes?: string | null
          protocolo_seguradora?: string | null
          responsavel_id?: string | null
          status?: string
          updated_at?: string
          valor_aprovado?: number | null
          valor_estimado?: number | null
          valor_pago?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "sinistros_apolice_id_fkey"
            columns: ["apolice_id"]
            isOneToOne: false
            referencedRelation: "apolices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sinistros_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      tasks: {
        Row: {
          created_at: string
          descricao: string | null
          id: string
          prazo: string | null
          prioridade: string
          status: string
          titulo: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          descricao?: string | null
          id?: string
          prazo?: string | null
          prioridade?: string
          status?: string
          titulo: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          descricao?: string | null
          id?: string
          prazo?: string | null
          prioridade?: string
          status?: string
          titulo?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      team_members: {
        Row: {
          created_at: string | null
          created_by: string | null
          department: string | null
          email: string | null
          full_name: string
          id: string
          is_active: boolean | null
          phone: string | null
          role: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          department?: string | null
          email?: string | null
          full_name: string
          id?: string
          is_active?: boolean | null
          phone?: string | null
          role?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          department?: string | null
          email?: string | null
          full_name?: string
          id?: string
          is_active?: boolean | null
          phone?: string | null
          role?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      user_notes: {
        Row: {
          conteudo: string
          created_at: string
          id: string
          tags: string[] | null
          updated_at: string
          user_id: string
          visibilidade: string
        }
        Insert: {
          conteudo: string
          created_at?: string
          id?: string
          tags?: string[] | null
          updated_at?: string
          user_id: string
          visibilidade?: string
        }
        Update: {
          conteudo?: string
          created_at?: string
          id?: string
          tags?: string[] | null
          updated_at?: string
          user_id?: string
          visibilidade?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_tips: {
        Row: {
          ativo: boolean
          categoria: string | null
          created_at: string
          descricao: string | null
          id: string
          is_global: boolean
          titulo: string
          updated_at: string
          user_id: string
        }
        Insert: {
          ativo?: boolean
          categoria?: string | null
          created_at?: string
          descricao?: string | null
          id?: string
          is_global?: boolean
          titulo: string
          updated_at?: string
          user_id: string
        }
        Update: {
          ativo?: boolean
          categoria?: string | null
          created_at?: string
          descricao?: string | null
          id?: string
          is_global?: boolean
          titulo?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      can_soft_delete: { Args: { _user_id: string }; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "gestor" | "vendedor" | "administrativo"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "gestor", "vendedor", "administrativo"],
    },
  },
} as const
