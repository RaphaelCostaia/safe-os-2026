// Export utilities with filters, RBAC, and audit support
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import { supabase } from "@/integrations/supabase/client";
import { logActivity } from "@/hooks/useActivityLog";

// Types
export interface ExportData {
  headers: string[];
  rows: (string | number)[][];
  title?: string;
  subtitle?: string;
}

export interface ExportOptions {
  format: 'pdf' | 'excel' | 'csv';
  filename: string;
  entityType?: string; // For audit logging
  filters?: Record<string, any>; // Active filters applied
}

// Currency formatter
const formatCurrency = (value: number): string => {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value);
};

// Date formatter
const formatDate = (date: string | Date): string => {
  if (!date) return "";
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleDateString("pt-BR");
};

// Export to PDF with improved styling
export function exportToPDF(data: ExportData, fileName: string = "relatorio") {
  const doc = new jsPDF();
  
  // Header
  doc.setFontSize(18);
  doc.setTextColor(40, 40, 40);
  doc.text(data.title || "Relatório", 14, 22);
  
  if (data.subtitle) {
    doc.setFontSize(11);
    doc.setTextColor(100, 100, 100);
    doc.text(data.subtitle, 14, 30);
  }

  // Generation date
  doc.setFontSize(9);
  doc.setTextColor(150, 150, 150);
  const dataGeracao = new Date().toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
  doc.text(`Gerado em: ${dataGeracao}`, 14, data.subtitle ? 38 : 30);

  // Table
  autoTable(doc, {
    head: [data.headers],
    body: data.rows.map(row => 
      row.map(cell => 
        typeof cell === "number" && cell > 100 ? formatCurrency(cell) : String(cell)
      )
    ),
    startY: data.subtitle ? 45 : 37,
    styles: {
      fontSize: 9,
      cellPadding: 4,
    },
    headStyles: {
      fillColor: [59, 130, 246],
      textColor: 255,
      fontStyle: "bold",
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    margin: { left: 14, right: 14 },
  });

  // Footer
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
    doc.text(
      `Página ${i} de ${pageCount}`,
      doc.internal.pageSize.getWidth() / 2,
      doc.internal.pageSize.getHeight() - 10,
      { align: "center" }
    );
    doc.text(
      "SafeOS - Sistema de Gestão de Seguros",
      14,
      doc.internal.pageSize.getHeight() - 10
    );
  }

  doc.save(`${fileName}.pdf`);
}

// Export to Excel
export function exportToExcel(data: ExportData, fileName: string = "relatorio") {
  const wb = XLSX.utils.book_new();
  const wsData = [data.headers, ...data.rows];
  const ws = XLSX.utils.aoa_to_sheet(wsData);

  // Set column widths
  const colWidths = data.headers.map((header, i) => {
    const maxDataLength = Math.max(
      header.length,
      ...data.rows.map(row => String(row[i] || "").length)
    );
    return { wch: Math.min(maxDataLength + 2, 40) };
  });
  ws["!cols"] = colWidths;

  XLSX.utils.book_append_sheet(wb, ws, data.title || "Relatório");
  XLSX.writeFile(wb, `${fileName}.xlsx`);
}

// Export to CSV
export function exportToCSV(data: ExportData, fileName: string = "relatorio") {
  const csvContent = [
    data.headers.join(";"),
    ...data.rows.map(row => 
      row.map(cell => {
        const str = String(cell);
        // Escape quotes and wrap in quotes if contains semicolon
        if (str.includes(";") || str.includes('"')) {
          return `"${str.replace(/"/g, '""')}"`;
        }
        return str;
      }).join(";")
    )
  ].join("\n");

  const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `${fileName}.csv`;
  link.click();
}

// Generic export function with audit
export async function exportWithAudit(
  data: ExportData, 
  options: ExportOptions
): Promise<void> {
  const { format, filename, entityType, filters } = options;

  // Perform export
  switch (format) {
    case 'pdf':
      exportToPDF(data, filename);
      break;
    case 'excel':
      exportToExcel(data, filename);
      break;
    case 'csv':
      exportToCSV(data, filename);
      break;
  }

  // Log audit
  if (entityType) {
    await logActivity(
      entityType,
      'export',
      `export.${entityType}`,
      `Exportado ${data.rows.length} registros em ${format.toUpperCase()}`,
      { format, filters, recordCount: data.rows.length }
    );
  }
}

// Helper: Prepare clients data
export function prepareClientesExport(clients: any[]): ExportData {
  return {
    title: "Relatório de Clientes",
    subtitle: `Total: ${clients.length} clientes`,
    headers: ["Nome", "Email", "Telefone", "CPF/CNPJ", "Profissão", "Status", "Data Cadastro"],
    rows: clients.map(c => [
      c.nome || "",
      c.email || "",
      c.telefone || "",
      c.cpf_cnpj || "",
      c.profissao || "",
      c.status || "",
      c.created_at ? formatDate(c.created_at) : "",
    ]),
  };
}

// Helper: Prepare policies data
export function prepareApolicesExport(apolices: any[], clients: any[], produtos: any[]): ExportData {
  return {
    title: "Relatório de Apólices",
    subtitle: `Total: ${apolices.length} apólices`,
    headers: ["Número", "Cliente", "Produto", "Seguradora", "Início", "Fim", "Prêmio", "Status"],
    rows: apolices.map(a => {
      const client = clients.find(c => c.id === a.client_id);
      const produto = produtos.find(p => p.id === a.produto_id);
      return [
        a.numero_apolice || "",
        client?.nome || "",
        produto?.nome || "",
        a.seguradora || "",
        a.data_inicio ? formatDate(a.data_inicio) : "",
        a.data_fim ? formatDate(a.data_fim) : "",
        a.valor_premio || 0,
        a.status || "",
      ];
    }),
  };
}

// Helper: Prepare sinistros data
export function prepareSinistrosExport(sinistros: any[]): ExportData {
  return {
    title: "Relatório de Sinistros",
    subtitle: `Total: ${sinistros.length} sinistros`,
    headers: ["Número", "Cliente", "Data Ocorrência", "Descrição", "Valor Estimado", "Valor Pago", "Status", "Criticidade"],
    rows: sinistros.map(s => [
      s.numero_sinistro || "",
      s.clients?.nome || s.clienteNome || "",
      s.data_ocorrencia ? formatDate(s.data_ocorrencia) : "",
      s.descricao_resumida || "",
      s.valor_estimado || 0,
      s.valor_pago || 0,
      s.status || "",
      s.criticidade || "",
    ]),
  };
}

// Helper: Prepare monthly report
export function prepareMonthlyReportExport(monthlyStats: any[]): ExportData {
  return {
    title: "Relatório Mensal de Performance",
    subtitle: `Período: ${monthlyStats.length} meses`,
    headers: ["Mês", "Clientes", "Apólices", "Sinistros", "Receita", "Renovações", "Cancelamentos"],
    rows: monthlyStats.map(m => [
      m.monthLabel || "",
      m.clientes || 0,
      m.apolices || 0,
      m.sinistros || 0,
      m.receita || 0,
      m.renovacoes || 0,
      m.cancelamentos || 0,
    ]),
  };
}

// Helper: Prepare custos fixos data
export function prepareCustosFixosExport(custosFixos: any[]): ExportData {
  const getRecorrenciaLabel = (recorrencia: string) => {
    const labels: Record<string, string> = {
      mensal: 'Mensal',
      anual: 'Anual',
      trimestral: 'Trimestral',
    };
    return labels[recorrencia] || recorrencia;
  };

  return {
    title: "Relatório de Custos Fixos",
    subtitle: `Total: ${custosFixos.length} custos`,
    headers: ["Categoria", "Descrição", "Valor", "Recorrência", "Status"],
    rows: custosFixos.map(c => [
      c.categoria || "",
      c.descricao || "",
      c.valor || 0,
      getRecorrenciaLabel(c.recorrencia),
      c.status === 'ativo' ? 'Ativo' : 'Inativo',
    ]),
  };
}

// Helper: Prepare contas data
export function prepareContasExport(contas: any[], tipo: 'pagar' | 'receber'): ExportData {
  const contasFiltradas = contas.filter(c => c.tipo === tipo);
  
  return {
    title: tipo === 'pagar' ? "Relatório de Contas a Pagar" : "Relatório de Contas a Receber",
    subtitle: `Total: ${contasFiltradas.length} contas`,
    headers: ["Descrição", "Categoria", "Valor", "Vencimento", "Status", "Observações"],
    rows: contasFiltradas.map(c => [
      c.descricao || "",
      c.categoria || "",
      c.valor || 0,
      c.vencimento ? formatDate(c.vencimento) : "",
      c.status || "",
      c.observacoes || "",
    ]),
  };
}

// Helper: Prepare financial summary
export function prepareResumoFinanceiroExport(data: {
  receitaMensal: number;
  receitaAnual: number;
  comissoesPrevistas: number;
  custosFixos: number;
  resultadoOperacional: number;
}): ExportData {
  return {
    title: "Resumo Financeiro",
    subtitle: `Gerado em ${formatDate(new Date())}`,
    headers: ["Indicador", "Valor"],
    rows: [
      ["Receita Recorrente Mensal", data.receitaMensal],
      ["Receita Recorrente Anual", data.receitaAnual],
      ["Comissões Previstas (mês)", data.comissoesPrevistas],
      ["Custos Fixos (mês)", data.custosFixos],
      ["Resultado Operacional (mês)", data.resultadoOperacional],
    ],
  };
}

// Helper: Prepare comissoes export
export function prepareComissoesExport(comissoes: any[]): ExportData {
  const formatCompetencia = (competencia: string) => {
    const [year, month] = competencia.split('-');
    const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    return `${months[parseInt(month) - 1]}/${year}`;
  };

  const totais = comissoes.reduce(
    (acc, c) => ({
      prevista: acc.prevista + (c.comissaoPrevista || 0),
      recebida: acc.recebida + (c.comissaoRecebida || 0),
    }),
    { prevista: 0, recebida: 0 }
  );

  return {
    title: "Relatório de Comissões",
    subtitle: `Total: ${comissoes.length} | Previsto: ${formatCurrency(totais.prevista)} | Recebido: ${formatCurrency(totais.recebida)}`,
    headers: ["Cliente", "Produto", "Apólice", "Seguradora", "Competência", "% Comissão", "Prevista", "Recebida", "Status"],
    rows: comissoes.map(c => [
      c.clienteNome || "",
      c.produtoCategoria || "",
      c.numeroApolice || "",
      c.seguradora || "",
      c.competencia ? formatCompetencia(c.competencia) : "",
      c.percentualComissao ? `${c.percentualComissao}%` : 'N/C',
      c.comissaoPrevista || 0,
      c.comissaoRecebida || 0,
      c.status === 'recebida' ? 'Recebida' : c.status === 'atrasada' ? 'Atrasada' : 'Prevista',
    ]),
  };
}
