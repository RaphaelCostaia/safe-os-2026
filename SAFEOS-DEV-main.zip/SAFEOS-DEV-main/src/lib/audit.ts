import { supabase } from "@/integrations/supabase/client";

/**
 * Registra manualmente um acesso a dados sensíveis (SELECT/VIEW)
 * Já que triggers de banco só funcionam em INSERT/UPDATE/DELETE.
 */
export async function logSensitiveAccess(tableName: string, recordId?: string, action: string = 'SELECT') {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    // Precisamos do organization_id do perfil para o log respeitar o RLS
    const { data: profile } = await supabase
      .from('profiles')
      .select('organization_id')
      .eq('id', user.id)
      .single();

    if (!profile?.organization_id) return;

    await supabase.from('audit_logs').insert({
      organization_id: profile.organization_id,
      user_id: user.id,
      action: action,
      table_name: tableName,
      record_id: recordId || null,
      new_data: { 
        accessed_at: new Date().toISOString(),
        description: `Visualização de ${tableName}`
      }
    });
  } catch (error) {
    console.error("Erro ao registrar auditoria de acesso:", error);
  }
}
