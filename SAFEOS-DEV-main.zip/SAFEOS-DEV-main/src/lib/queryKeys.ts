// Query keys registry (REAL keys used across the app)
//
// IMPORTANT:
// - Do not “invent” keys elsewhere; import these or keep the same literals.
// - When changing a key here, update invalidation mappings in queryInvalidation.ts.
//
// Minimal set required for global consistency after DELETE (Clientes/Apólices + dashboards):
// - ["clients"]
// - ["clients", id]
// - ["apolices"]
// - ["apolices", id]
// - ["dashboard-stats"]
// - ["commissions_dashboard", filters]
// - ["commission_filters"]
// - ["client_map_data", profissao?, status?]
// - ["client_growth_data", monthsBack]
// - ["financeiro_projecoes", horizonte]
// - ["financeiro-dashboard"]
// - ["priority_queue", limit, userId]
// - ["recent-activity"]

export const QUERY_KEYS = {
  clients: {
    list: ["clients"] as const,
    detail: (id: string) => ["clients", id] as const,
  },
  apolices: {
    list: ["apolices"] as const,
    detail: (id: string) => ["apolices", id] as const,
  },
  dashboard: {
    stats: ["dashboard-stats"] as const,
    recentActivity: ["recent-activity"] as const,
  },
  commissions: {
    dashboard: (filters?: unknown) => ["commissions_dashboard", filters] as const,
    filters: ["commission_filters"] as const,
  },
  clientMapData: (filters?: { profissao?: string; status?: string }) =>
    ["client_map_data", filters?.profissao, filters?.status] as const,
  clientGrowthData: (monthsBack: number) => ["client_growth_data", monthsBack] as const,
  financeiro: {
    projecoes: (horizonte: number) => ["financeiro_projecoes", horizonte] as const,
    dashboard: ["financeiro-dashboard"] as const,
  },
  priorityQueue: (limit: number, userId?: string) => ["priority_queue", limit, userId] as const,
} as const;
