// RBAC Permissions Map
// Defines what each role can do in each module

export type AppRole = 'admin' | 'gestor' | 'vendedor' | 'administrativo' | 'owner' | 'financeiro' | 'suporte' | 'leitura' | 'corretor';

export type Resource = 
  | 'dashboard' 
  | 'clients' 
  | 'apolices' 
  | 'renovacoes'
  | 'sinistros' 
  | 'financeiro' 
  | 'relatorios' 
  | 'configuracoes' 
  | 'equipe'
  | 'auditoria'
  | 'produtos';

export type Action = 'view' | 'create' | 'edit' | 'delete' | 'assign' | 'export';

// Permission map: role -> resource -> allowed actions
export const PERMISSIONS: Record<AppRole, Partial<Record<Resource, Action[]>>> = {
  owner: {
    dashboard: ['view'],
    clients: ['view', 'create', 'edit', 'delete', 'export'],
    apolices: ['view', 'create', 'edit', 'delete', 'export'],
    renovacoes: ['view', 'create', 'edit', 'delete', 'assign'],
    sinistros: ['view', 'create', 'edit', 'delete', 'assign', 'export'],
    financeiro: ['view', 'create', 'edit', 'delete', 'export'],
    relatorios: ['view', 'export'],
    configuracoes: ['view', 'edit'],
    equipe: ['view', 'create', 'edit', 'delete'],
    auditoria: ['view', 'export'],
    produtos: ['view', 'create', 'edit', 'delete'],
  },
  admin: {
    dashboard: ['view'],
    clients: ['view', 'create', 'edit', 'delete', 'export'],
    apolices: ['view', 'create', 'edit', 'delete', 'export'],
    renovacoes: ['view', 'create', 'edit', 'assign'],
    sinistros: ['view', 'create', 'edit', 'assign', 'export'],
    financeiro: ['view', 'create', 'edit', 'export'],
    relatorios: ['view', 'export'],
    configuracoes: ['view', 'edit'],
    equipe: ['view', 'create', 'edit', 'delete'],
    auditoria: ['view'],
    produtos: ['view', 'create', 'edit', 'delete'],
  },
  gestor: {
    dashboard: ['view'],
    clients: ['view', 'create', 'edit', 'export'],
    apolices: ['view', 'create', 'edit', 'export'],
    renovacoes: ['view', 'create', 'edit', 'assign'],
    sinistros: ['view', 'create', 'edit', 'assign', 'export'],
    financeiro: ['view', 'export'],
    relatorios: ['view', 'export'],
    configuracoes: ['view'],
    equipe: ['view', 'create', 'edit'],
    auditoria: ['view'],
    produtos: ['view', 'create', 'edit'],
  },
  corretor: {
    dashboard: ['view'],
    clients: ['view', 'create', 'edit'],
    apolices: ['view', 'create', 'edit'],
    renovacoes: ['view', 'create', 'edit'],
    sinistros: ['view', 'create', 'edit'],
    financeiro: ['view'],
    relatorios: [],
    configuracoes: [],
    equipe: [],
    auditoria: [],
    produtos: ['view'],
  },
  vendedor: {
    dashboard: ['view'],
    clients: ['view', 'create', 'edit'],
    apolices: ['view', 'create'],
    renovacoes: ['view', 'create'],
    sinistros: ['view', 'create'],
    financeiro: ['view'],
    relatorios: [],
    configuracoes: [],
    equipe: [],
    auditoria: [],
    produtos: ['view'],
  },
  financeiro: {
    dashboard: ['view'],
    clients: ['view'],
    apolices: ['view'],
    renovacoes: ['view'],
    sinistros: ['view'],
    financeiro: ['view', 'create', 'edit', 'export'],
    relatorios: ['view', 'export'],
    configuracoes: ['view'],
    equipe: [],
    auditoria: [],
    produtos: ['view'],
  },
  suporte: {
    dashboard: ['view'],
    clients: ['view', 'create', 'edit'],
    apolices: ['view'],
    renovacoes: ['view'],
    sinistros: ['view', 'edit'],
    financeiro: ['view'],
    relatorios: [],
    configuracoes: [],
    equipe: [],
    auditoria: [],
    produtos: ['view'],
  },
  administrativo: {
    dashboard: ['view'],
    clients: ['view', 'create', 'edit', 'export'],
    apolices: ['view', 'create', 'edit', 'export'],
    renovacoes: ['view', 'create', 'edit', 'assign'],
    sinistros: ['view', 'create', 'edit', 'assign'],
    financeiro: ['view', 'create', 'edit'],
    relatorios: ['view'],
    configuracoes: ['view'],
    equipe: ['view', 'create', 'edit'],
    auditoria: ['view'],
    produtos: ['view', 'create', 'edit'],
  },
  leitura: {
    dashboard: ['view'],
    clients: ['view'],
    apolices: ['view'],
    renovacoes: ['view'],
    sinistros: ['view'],
    financeiro: ['view'],
    relatorios: ['view'],
    configuracoes: [],
    equipe: [],
    auditoria: [],
    produtos: ['view'],
  },
};

/**
 * Check if a role has permission for a specific action on a resource
 */
export function hasPermission(
  role: AppRole | null | undefined, 
  resource: Resource, 
  action: Action
): boolean {
  if (role === 'owner') return true;
  if (!role) return false;
  
  const rolePermissions = PERMISSIONS[role];
  if (!rolePermissions) return false;
  
  const resourceActions = rolePermissions[resource];
  if (!resourceActions) return false;
  
  return resourceActions.includes(action);
}

/**
 * Check if a role can access a resource (has any action permission)
 */
export function canAccessResource(
  role: AppRole | null | undefined, 
  resource: Resource
): boolean {
  if (role === 'owner') return true;
  if (!role) return false;
  
  const rolePermissions = PERMISSIONS[role];
  if (!rolePermissions) return false;
  
  const resourceActions = rolePermissions[resource];
  return resourceActions !== undefined && resourceActions.length > 0;
}

/**
 * Get all allowed actions for a role on a resource
 */
export function getAllowedActions(
  role: AppRole | null | undefined, 
  resource: Resource
): Action[] {
  if (!role) return [];
  
  const rolePermissions = PERMISSIONS[role];
  if (!rolePermissions) return [];
  
  return rolePermissions[resource] || [];
}

/**
 * Get human-readable role name in Portuguese
 */
export function getRoleName(role: AppRole): string {
  const names: Record<AppRole, string> = {
    owner: 'Proprietário',
    admin: 'Administrador',
    gestor: 'Gestor',
    vendedor: 'Vendedor',
    corretor: 'Corretor',
    financeiro: 'Financeiro',
    suporte: 'Suporte',
    administrativo: 'Administrativo',
    leitura: 'Apenas Leitura',
  };
  return names[role] || role;
}

/**
 * Get role badge variant for UI
 */
export function getRoleBadgeVariant(role: string): 'default' | 'secondary' | 'outline' | 'destructive' {
  const variants: Record<string, 'default' | 'secondary' | 'outline' | 'destructive'> = {
    owner: 'default',
    admin: 'default',
    gestor: 'secondary',
    financeiro: 'secondary',
    vendedor: 'outline',
    corretor: 'outline',
    administrativo: 'secondary',
    suporte: 'outline',
    leitura: 'outline',
  };
  return variants[role] || 'outline';
}
