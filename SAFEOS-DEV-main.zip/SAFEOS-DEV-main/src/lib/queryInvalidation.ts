// Central query invalidation utility for consistent data refresh after mutations
import { QueryClient } from "@tanstack/react-query";

// Entity types and their related query keys
const ENTITY_QUERY_MAP: Record<string, string[]> = {
  clients: [
    "clients",
    "crm_leads",
    "client_policies",
    "dashboard-stats",
    "client_map_data",
    "client_growth_data",
    "commissions_dashboard",
    "commission_filters",
    "financeiro_projecoes",
    "financeiro-dashboard",
    "priority_queue",
    "recent-activity",
    "top-partners",
  ],
  apolices: [
    "apolices",
    "clients", // Client details may include policy counts
    "client_policies",
    "dashboard-stats",
    "commissions_dashboard",
    "financeiro_projecoes",
    "financeiro-dashboard",
    "renovacoes",
    "priority_queue",
    "recent-activity",
    "top-partners",
  ],
  sinistros: [
    "sinistros",
    "dashboard-stats",
    "sinistro-activities",
    "priority_queue",
    "recent-activity",
  ],
  renovacoes: [
    "renovacoes",
    "apolices",
    "dashboard-stats",
    "priority_queue",
    "recent-activity",
  ],
  produtos: [
    "produtos",
    "apolices",
    "commissions_dashboard",
    "commission_filters",
  ],
  contas: [
    "contas",
    "financeiro-dashboard",
    "priority_queue",
    "recent-activity",
  ],
  custos_fixos: [
    // NOTE: this app currently uses queryKey: ['custos-fixos'] (hyphen)
    "custos-fixos",
    "financeiro-dashboard",
    "recent-activity",
  ],
  client_commission_terms: [
    "client_commission_terms",
    "commissions_dashboard",
    "clients",
    "financeiro_projecoes",
  ],
  team_members: [
    "team_members",
  ],
  tasks: [
    "tasks",
  ],
  user_notes: [
    "user_notes",
  ],
  user_tips: [
    "user_tips",
  ],
};

/**
 * Invalidate all queries related to an entity type.
 * This ensures UI consistency after CRUD operations.
 */
export function invalidateEntityQueries(
  queryClient: QueryClient,
  entityType: keyof typeof ENTITY_QUERY_MAP | string
): void {
  const queryKeys = ENTITY_QUERY_MAP[entityType] || [entityType];
  
  queryKeys.forEach(key => {
    queryClient.invalidateQueries({ queryKey: [key] });
  });
}

/**
 * Invalidate multiple entity types at once
 */
export function invalidateMultipleEntities(
  queryClient: QueryClient,
  entityTypes: (keyof typeof ENTITY_QUERY_MAP | string)[]
): void {
  const allKeys = new Set<string>();
  
  entityTypes.forEach(entityType => {
    const queryKeys = ENTITY_QUERY_MAP[entityType] || [entityType];
    queryKeys.forEach(key => allKeys.add(key));
  });
  
  allKeys.forEach(key => {
    queryClient.invalidateQueries({ queryKey: [key] });
  });
}

/**
 * Optimistically remove an item from a list cache
 * Use this for immediate UI feedback before server confirmation
 */
export function optimisticRemove<T extends { id: string }>(
  queryClient: QueryClient,
  queryKey: string[],
  itemId: string
): T[] | undefined {
  const previousData = queryClient.getQueryData<T[]>(queryKey);
  
  if (previousData) {
    queryClient.setQueryData<T[]>(
      queryKey,
      previousData.filter(item => item.id !== itemId)
    );
  }
  
  return previousData;
}

/**
 * Restore cached data if optimistic update fails
 */
export function restoreCache<T>(
  queryClient: QueryClient,
  queryKey: string[],
  previousData: T | undefined
): void {
  if (previousData !== undefined) {
    queryClient.setQueryData(queryKey, previousData);
  }
}

/**
 * Create mutation callbacks with automatic invalidation and optimistic updates
 */
export function createDeleteMutationCallbacks<T extends { id: string }>(
  queryClient: QueryClient,
  entityType: keyof typeof ENTITY_QUERY_MAP,
  listQueryKey: string[]
) {
  return {
    onMutate: async (id: string) => {
      // Cancel any outgoing refetches
      await queryClient.cancelQueries({ queryKey: listQueryKey });
      
      // Snapshot previous value
      const previousData = optimisticRemove<T>(queryClient, listQueryKey, id);
      
      return { previousData };
    },
    onError: (_error: Error, _id: string, context: { previousData?: T[] } | undefined) => {
      // Restore on error
      if (context?.previousData) {
        restoreCache(queryClient, listQueryKey, context.previousData);
      }
    },
    onSuccess: () => {
      invalidateEntityQueries(queryClient, entityType);
    },
  };
}

