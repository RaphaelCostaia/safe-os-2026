import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Sanitizes a payload object by converting all empty strings ("") to null.
 * This prevents PostgreSQL from throwing "invalid input syntax" errors for 
 * typed columns like date, uuid, or numeric when passed an empty string.
 */
export function sanitizePayload<T extends Record<string, any>>(data: T): T {
  const sanitized = { ...data };
  Object.keys(sanitized).forEach((key) => {
    if (sanitized[key] === "") {
      sanitized[key] = null as any;
    }
  });
  return sanitized;
}
