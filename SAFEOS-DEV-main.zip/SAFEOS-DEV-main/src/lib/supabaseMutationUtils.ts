/**
 * Helpers to prevent “false success” writes with PostgREST + RLS.
 *
 * In Supabase/PostgREST, DELETE/UPDATE can return 204 even when 0 rows were affected
 * (e.g. blocked by RLS or record not found). To avoid lying to the user, we:
 * - request `count: 'exact'` and/or `select('id')`
 * - treat 0 affected rows as an error
 */

export function affectedRowsCount<T>(result: {
  count?: number | null;
  data?: T[] | null;
}): number {
  if (typeof result.count === "number") return result.count;
  return result.data?.length ?? 0;
}

export function assertAffectedRows<T>(
  result: { count?: number | null; data?: T[] | null },
  message: string
): number {
  const affected = affectedRowsCount(result);
  if (affected <= 0) {
    throw new Error(message);
  }
  return affected;
}
