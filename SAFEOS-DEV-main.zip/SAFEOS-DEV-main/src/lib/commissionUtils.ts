import { calculateLtvValue, type LtvSettings } from "@/hooks/useLtvSettings";

export interface ApoliceMetadata {
  comissao_real_percent: string;
  valor_comissao_real: string;
  data_renovacao: string;
  [key: string]: any;
}

export function parseApoliceObservacoes(observacoesText: string | null | undefined): {
  notes: string;
  meta: ApoliceMetadata;
} {
  const defaultMeta: ApoliceMetadata = {
    comissao_real_percent: "",
    valor_comissao_real: "",
    data_renovacao: "",
  };

  if (!observacoesText) return { notes: "", meta: defaultMeta };

  const divider = "-- METADATA_APOLICE_V1 --";
  const parts = observacoesText.split(divider);

  if (parts.length < 2) return { notes: observacoesText, meta: defaultMeta };

  try {
    const meta = JSON.parse(parts[1].trim());
    return { notes: parts[0].trim(), meta: { ...defaultMeta, ...meta } };
  } catch {
    return { notes: parts[0].trim() || observacoesText, meta: defaultMeta };
  }
}

export interface PolicyCommissionResult {
  valor: number;
  percent: number;
  source: "metadata_valor" | "metadata_percent" | "client_agreement" | "product_catalog" | "default_broker";
}

export function calculatePolicyCommission(
  policy: {
    client_id?: string | null;
    valor_premio?: number | null;
    observacoes?: string | null;
    produto_id?: string | null;
    produto?: { comissao_percentual?: number | null } | null;
  },
  activeCommissions?: Array<{
    client_id?: string | null;
    produto_id?: string | null;
    model?: string;
    percent?: number | null;
    fixed_amount?: number | null;
    is_active?: boolean;
  }> | null,
  clientMeta?: {
    parceria_comissao?: string | number | null;
    comissao_percentual?: string | number | null;
    [key: string]: any;
  } | null,
  defaultFallbackPercent: number = 20
): PolicyCommissionResult {
  const premio = Number(policy.valor_premio) || 0;
  const { meta } = parseApoliceObservacoes(policy.observacoes || null);

  // 1. Direct real commission value in policy metadata
  const metaVal = meta.valor_comissao_real ? parseFloat(meta.valor_comissao_real) : NaN;
  if (!isNaN(metaVal) && metaVal > 0) {
    const derivedPct = premio > 0 
      ? (metaVal / premio) * 100 
      : (meta.comissao_real_percent ? parseFloat(meta.comissao_real_percent) : defaultFallbackPercent);
    return {
      valor: metaVal,
      percent: !isNaN(derivedPct) && derivedPct > 0 ? derivedPct : defaultFallbackPercent,
      source: "metadata_valor",
    };
  }

  // 2. Real commission percentage in policy metadata
  const metaPct = meta.comissao_real_percent ? parseFloat(meta.comissao_real_percent) : NaN;
  if (!isNaN(metaPct) && metaPct > 0) {
    return {
      valor: (premio * metaPct) / 100,
      percent: metaPct,
      source: "metadata_percent",
    };
  }

  // 3. Client agreement from client_commission_terms (prioritizing terms for this specific client)
  if (activeCommissions && activeCommissions.length > 0) {
    const clientTerms = policy.client_id
      ? activeCommissions.filter(t => t.client_id === policy.client_id)
      : activeCommissions;

    const pool = clientTerms.length > 0 ? clientTerms : activeCommissions;

    const matched = pool.find(t => (t.is_active !== false) && t.produto_id === policy.produto_id)
      || pool.find(t => (t.is_active !== false) && (!t.produto_id || t.produto_id === null));

    if (matched) {
      if (matched.model === "fixo" && matched.fixed_amount) {
        const fixVal = Number(matched.fixed_amount);
        const derivedPct = premio > 0 ? (fixVal / premio) * 100 : 0;
        return {
          valor: fixVal,
          percent: derivedPct,
          source: "client_agreement",
        };
      } else if (matched.percent !== null && matched.percent !== undefined && !isNaN(Number(matched.percent)) && Number(matched.percent) > 0) {
        const pct = Number(matched.percent);
        return {
          valor: (premio * pct) / 100,
          percent: pct,
          source: "client_agreement",
        };
      } else if (matched.model === "misto") {
        const pct = Number(matched.percent || 0);
        const fixVal = Number(matched.fixed_amount || 0);
        const val = ((premio * pct) / 100) + fixVal;
        const derivedPct = premio > 0 ? (val / premio) * 100 : pct;
        return {
          valor: val,
          percent: derivedPct,
          source: "client_agreement",
        };
      }
    }
  }

  // 4. Commission defined in the Client Registration (Cadastro de Clientes - parceria_comissao)
  const clientRawComm = clientMeta?.parceria_comissao ?? clientMeta?.comissao_percentual;
  if (clientRawComm !== undefined && clientRawComm !== null && clientRawComm !== "") {
    const parsedPct = parseFloat(String(clientRawComm).replace(',', '.'));
    if (!isNaN(parsedPct) && parsedPct > 0) {
      return {
        valor: (premio * parsedPct) / 100,
        percent: parsedPct,
        source: "client_agreement",
      };
    }
  }

  // 5. Product catalog default commission
  const prodPct = policy.produto?.comissao_percentual;
  if (prodPct !== null && prodPct !== undefined && !isNaN(Number(prodPct)) && Number(prodPct) > 0) {
    const pct = Number(prodPct);
    return {
      valor: (premio * pct) / 100,
      percent: pct,
      source: "product_catalog",
    };
  }

  // 6. Standard fallback for active insurance policies
  if (premio > 0) {
    return {
      valor: (premio * defaultFallbackPercent) / 100,
      percent: defaultFallbackPercent,
      source: "default_broker",
    };
  }

  return {
    valor: 0,
    percent: 0,
    source: "default_broker",
  };
}

export interface ClientFinancialsResult {
  activePolicies: any[];
  totalPremium: number;
  totalCommissionAnual: number;
  mrrEquivalente: number;
  ltvContratado: number;
  ltvProjetado: number;
  averagePremiumPerPolicy: number;
  averageCommission: number;
}

export function calculateClientFinancials(
  policies: any[] | null | undefined,
  activeCommissions?: any[] | null,
  ltvSettings?: LtvSettings
): ClientFinancialsResult {
  const activePolicies = (policies || []).filter(p => ["ativa", "em_renovacao", "renovada"].includes(p.status));

  const totalPremium = activePolicies.reduce((acc, p) => acc + (Number(p.valor_premio) || 0), 0);

  const totalCommissionAnual = activePolicies.reduce((acc, p) => {
    const comm = calculatePolicyCommission(p, activeCommissions);
    return acc + comm.valor;
  }, 0);

  const mrrEquivalente = totalCommissionAnual / 12;

  const defaultLtvSettings: LtvSettings = {
    tempoPermanencia: 3,
    taxaRenovacao: 85,
    churnAnual: 15,
    regraCalculo: "anos_retencao",
    modoCalculo: "automatico",
  };

  const { contracted: ltvContratado, projected: ltvProjetado } = calculateLtvValue(
    totalCommissionAnual,
    ltvSettings || defaultLtvSettings
  );

  const averagePremiumPerPolicy = activePolicies.length > 0 ? (totalPremium / activePolicies.length) : 0;
  const averageCommission = activePolicies.length > 0 ? (totalCommissionAnual / activePolicies.length) : 0;

  return {
    activePolicies,
    totalPremium,
    totalCommissionAnual,
    mrrEquivalente,
    ltvContratado,
    ltvProjetado,
    averagePremiumPerPolicy,
    averageCommission,
  };
}

export interface PolicyPaymentInfo {
  forma_pagamento: "a_vista" | "parcelado";
  parcelas: number;
  meio_pagamento?: string;
  valor_premio_total: number;
  valor_premio_parcela: number;
  valor_comissao_total: number;
  valor_comissao_parcela: number;
}

/**
 * Resolves the payment method and installments for a policy, checking the policy record,
 * its metadata, and falling back to the client's preference or standard insurance defaults.
 */
export function resolvePolicyPaymentInfo(
  policy: {
    client_id?: string | null;
    valor_premio?: number | null;
    forma_pagamento?: string | null;
    parcelas?: number | null;
    observacoes?: string | null;
    produto_id?: string | null;
    produto?: { comissao_percentual?: number | null } | null;
  },
  activeCommissions?: Array<{
    client_id?: string | null;
    produto_id?: string | null;
    model?: string;
    percent?: number | null;
    fixed_amount?: number | null;
    is_active?: boolean;
  }> | null,
  clientMeta?: {
    forma_pagamento_preferencial?: string | null;
    parcelas_preferenciais?: number | string | null;
    meio_pagamento?: string | null;
    parceria_comissao?: string | number | null;
    comissao_percentual?: string | number | null;
    [key: string]: any;
  } | null
): PolicyPaymentInfo {
  const { meta } = parseApoliceObservacoes(policy.observacoes || null);
  const premioTotal = Number(policy.valor_premio) || 0;
  const commission = calculatePolicyCommission(policy, activeCommissions, clientMeta);
  const comissaoTotal = commission.valor;

  // 1. Resolve installments (parcelas)
  let parcelas = 1;
  const rawPolicyParcelas = policy.parcelas !== null && policy.parcelas !== undefined ? Number(policy.parcelas) : NaN;
  const rawMetaParcelas = meta.parcelas ? Number(meta.parcelas) : NaN;
  const rawClientParcelas = clientMeta?.parcelas_preferenciais ? Number(clientMeta.parcelas_preferenciais) : NaN;

  if (!isNaN(rawPolicyParcelas) && rawPolicyParcelas >= 1) {
    parcelas = Math.min(Math.max(Math.round(rawPolicyParcelas), 1), 12);
  } else if (!isNaN(rawMetaParcelas) && rawMetaParcelas >= 1) {
    parcelas = Math.min(Math.max(Math.round(rawMetaParcelas), 1), 12);
  } else if (!isNaN(rawClientParcelas) && rawClientParcelas >= 1) {
    parcelas = Math.min(Math.max(Math.round(rawClientParcelas), 1), 12);
  } else {
    // Check if explicitly marked as 'a_vista'
    const isAVista = policy.forma_pagamento === "a_vista" || 
                     meta.forma_pagamento === "a_vista" || 
                     clientMeta?.forma_pagamento_preferencial === "a_vista";
    if (isAVista) {
      parcelas = 1;
    } else {
      // Default standard annual insurance policy is divided into 11 or 12 monthly installments
      parcelas = 11;
    }
  }

  const formaPagamento: "a_vista" | "parcelado" = parcelas === 1 ? "a_vista" : "parcelado";
  const meioPagamento = meta.meio_pagamento || clientMeta?.meio_pagamento || "boleto";

  const valor_premio_parcela = parcelas > 0 ? premioTotal / parcelas : premioTotal;
  const valor_comissao_parcela = parcelas > 0 ? comissaoTotal / parcelas : comissaoTotal;

  return {
    forma_pagamento: formaPagamento,
    parcelas,
    meio_pagamento: meioPagamento,
    valor_premio_total: premioTotal,
    valor_premio_parcela,
    valor_comissao_total: comissaoTotal,
    valor_comissao_parcela,
  };
}

/**
 * Calculates the exact commission installment falling in a specific target month for a given policy.
 */
export function calculatePolicyCommissionForMonth(
  policy: {
    data_inicio?: string | null;
    data_fim?: string | null;
    status?: string | null;
    valor_premio?: number | null;
    forma_pagamento?: string | null;
    parcelas?: number | null;
    observacoes?: string | null;
    produto_id?: string | null;
    produto?: { comissao_percentual?: number | null } | null;
  },
  targetDate: Date,
  activeCommissions?: any[] | null,
  clientMeta?: any | null
): { comissao: number; premio: number; isScheduled: boolean } {
  const payInfo = resolvePolicyPaymentInfo(policy, activeCommissions, clientMeta);

  if (!policy.data_inicio) {
    // If no start date, return default recurring monthly share if policy is active
    return {
      comissao: payInfo.valor_comissao_parcela,
      premio: payInfo.valor_premio_parcela,
      isScheduled: true,
    };
  }

  try {
    const dataInicio = new Date(policy.data_inicio);
    if (isNaN(dataInicio.getTime())) {
      return {
        comissao: payInfo.valor_comissao_parcela,
        premio: payInfo.valor_premio_parcela,
        isScheduled: true,
      };
    }

    // Difference in calendar months between targetDate and dataInicio
    const startYear = dataInicio.getFullYear();
    const startMonth = dataInicio.getMonth();
    const targetYear = targetDate.getFullYear();
    const targetMonthIndex = targetDate.getMonth();

    const diffMonths = (targetYear - startYear) * 12 + (targetMonthIndex - startMonth);

    if (payInfo.forma_pagamento === "a_vista" || payInfo.parcelas === 1) {
      if (diffMonths === 0) {
        return {
          comissao: payInfo.valor_comissao_total,
          premio: payInfo.valor_premio_total,
          isScheduled: true,
        };
      }
      return { comissao: 0, premio: 0, isScheduled: false };
    }

    // For installment payment (e.g. 2x to 11x/12x)
    if (diffMonths >= 0 && diffMonths < payInfo.parcelas) {
      return {
        comissao: payInfo.valor_comissao_parcela,
        premio: payInfo.valor_premio_parcela,
        isScheduled: true,
      };
    }

    return { comissao: 0, premio: 0, isScheduled: false };
  } catch {
    return {
      comissao: payInfo.valor_comissao_parcela,
      premio: payInfo.valor_premio_parcela,
      isScheduled: true,
    };
  }
}
