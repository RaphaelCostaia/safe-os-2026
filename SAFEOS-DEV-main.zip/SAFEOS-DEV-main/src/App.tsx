import { useEffect } from "react";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/useAuth";
import { ThemeProvider } from "@/hooks/useTheme";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { DashboardFilterProvider } from "@/hooks/useDashboardFilter";

import Dashboard from "./pages/Dashboard";
import CRM from "./pages/CRM";
import Auth from "./pages/Auth";
import Clientes from "./pages/Clientes";
import ClientDetail from "./pages/ClientDetail";
import Apolices from "./pages/Apolices";
import Sinistros from "./pages/Sinistros";
import Renovacoes from "./pages/Renovacoes";
import Produtos from "./pages/Produtos";
import Financeiro from "./pages/Financeiro";
import Relatorios from "./pages/Relatorios";
import Configuracoes from "./pages/Configuracoes";
import Auditoria from "./pages/Auditoria";
import Perfil from "./pages/Perfil";
import DebugSupabase from "./pages/DebugSupabase";
import RedefinirSenha from "./pages/RedefinirSenha";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000,
      retry: 1,
      refetchInterval: 15000, // Atualiza automaticamente os dados em segundo plano a cada 15 segundos sem nenhuma ação do usuário
      refetchOnWindowFocus: true, // Atualiza instantaneamente quando o usuário retorna à aba do app
    },
  },
});

const NavigationWatcher = () => {
  const location = useLocation();
  const queryClient = useQueryClient();

  useEffect(() => {
    // Invalidate and refetch all active page queries automatically whenever navigation occurs
    console.log("Sistema navegou para:", location.pathname, "- Forçando atualização de dados reais em produção.");
    queryClient.invalidateQueries({ refetchType: "active" });
  }, [location.pathname, queryClient]);

  return null;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider defaultTheme="light" storageKey="safeos-theme">
      <TooltipProvider>
        <Toaster position="top-right" closeButton richColors />
        <BrowserRouter>
          <AuthProvider>
            <NavigationWatcher />
            <Routes>
              <Route path="/auth" element={<Auth />} />
              <Route path="/redefinir-senha" element={<RedefinirSenha />} />
              
              {/* Protected Routes */}
              <Route
                path="/"
                element={
                  <ProtectedRoute resource="dashboard">
                    <DashboardFilterProvider>
                      <Dashboard />
                    </DashboardFilterProvider>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/clientes"
                element={
                  <ProtectedRoute resource="clients">
                    <Clientes />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/crm"
                element={
                  <ProtectedRoute resource="dashboard">
                    <CRM />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/clientes/:id"
                element={
                  <ProtectedRoute resource="clients">
                    <ClientDetail />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/apolices"
                element={
                  <ProtectedRoute resource="apolices">
                    <Apolices />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/sinistros"
                element={
                  <ProtectedRoute resource="sinistros">
                    <Sinistros />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/renovacoes"
                element={
                  <ProtectedRoute resource="renovacoes">
                    <Renovacoes />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/produtos"
                element={
                  <ProtectedRoute resource="produtos">
                    <Produtos />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/financeiro"
                element={
                  <ProtectedRoute resource="financeiro">
                    <Financeiro />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/relatorios"
                element={
                  <ProtectedRoute resource="relatorios">
                    <Relatorios />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/configuracoes"
                element={
                  <ProtectedRoute resource="configuracoes">
                    <Configuracoes />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/auditoria"
                element={
                  <ProtectedRoute resource="auditoria">
                    <Auditoria />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/perfil"
                element={
                  <ProtectedRoute>
                    <Perfil />
                  </ProtectedRoute>
                }
              />
              {/* Fallback */}
              <Route path="/404" element={<NotFound />} />
              <Route path="*" element={<Navigate to="/404" replace />} />
            </Routes>
          </AuthProvider>
        </BrowserRouter>
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
