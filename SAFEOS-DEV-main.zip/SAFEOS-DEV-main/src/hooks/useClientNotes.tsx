import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/types";

export type ClientNote = Tables<"client_notes">;
export type ClientNoteInsert = TablesInsert<"client_notes">;
export type ClientNoteUpdate = TablesUpdate<"client_notes">;

export function useClientNotes(clientId: string) {
  return useQuery({
    queryKey: ["client_notes", clientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("client_notes")
        .select("*")
        .eq("client_id", clientId)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as ClientNote[];
    },
    enabled: !!clientId,
  });
}

export function useCreateClientNote() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (note: ClientNoteInsert) => {
      const { data: user } = await supabase.auth.getUser();
      const { data, error } = await supabase
        .from("client_notes")
        .insert({ ...note, autor_id: user.user?.id })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["client_notes", variables.client_id] });
      toast.success("Anotação adicionada com sucesso");
    },
    onError: (error) => {
      console.error("Error creating note:", error);
      toast.error("Erro ao adicionar anotação");
    },
  });
}

export function useUpdateClientNote() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, clientId, ...note }: ClientNoteUpdate & { id: string; clientId: string }) => {
      const { data, error } = await supabase
        .from("client_notes")
        .update(note)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["client_notes", variables.clientId] });
      toast.success("Anotação atualizada");
    },
    onError: (error) => {
      console.error("Error updating note:", error);
      toast.error("Erro ao atualizar anotação");
    },
  });
}

export function useDeleteClientNote() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, clientId }: { id: string; clientId: string }) => {
      const { error } = await supabase
        .from("client_notes")
        .delete()
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["client_notes", variables.clientId] });
      toast.success("Anotação excluída");
    },
    onError: (error) => {
      console.error("Error deleting note:", error);
      toast.error("Erro ao excluir anotação");
    },
  });
}
