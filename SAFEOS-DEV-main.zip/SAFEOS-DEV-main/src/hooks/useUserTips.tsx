import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { assertAffectedRows } from "@/lib/supabaseMutationUtils";

export type TipCategory = "Processo" | "Venda" | "Renovação" | "Sinistro" | "Geral";

export interface UserTip {
  id: string;
  user_id: string;
  titulo: string;
  descricao: string | null;
  categoria: string | null;
  is_global: boolean;
  ativo: boolean;
  created_at: string;
  updated_at: string;
}

export interface UserTipInsert {
  titulo: string;
  descricao?: string;
  categoria?: string;
  is_global?: boolean;
}

export interface UserTipUpdate {
  id: string;
  titulo?: string;
  descricao?: string;
  categoria?: string;
  is_global?: boolean;
  ativo?: boolean;
}

export function useUserTips() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["user_tips", user?.id],
    queryFn: async () => {
      if (!user?.id) return [];

      // Get own tips + global active tips
      const { data, error } = await supabase
        .from("user_tips")
        .select("*")
        .or(`user_id.eq.${user.id},and(is_global.eq.true,ativo.eq.true)`)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as UserTip[];
    },
    enabled: !!user?.id,
  });
}

export function useCreateUserTip() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (tip: UserTipInsert) => {
      if (!user?.id) throw new Error("Usuário não autenticado");

      const { data, error } = await supabase
        .from("user_tips")
        .insert({
          user_id: user.id,
          titulo: tip.titulo,
          descricao: tip.descricao || null,
          categoria: tip.categoria || null,
          is_global: tip.is_global || false,
        })
        .select()
        .single();

      if (error) throw error;
      return data as UserTip;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user_tips"] });
      toast.success("Tip criado!");
    },
    onError: (error) => {
      console.error("Erro ao criar tip:", error);
      toast.error("Erro ao criar tip");
    },
  });
}

export function useUpdateUserTip() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (tip: UserTipUpdate) => {
      const { id, ...updateData } = tip;

      const { data, error } = await supabase
        .from("user_tips")
        .update(updateData)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return data as UserTip;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user_tips"] });
      toast.success("Tip atualizado!");
    },
    onError: (error) => {
      console.error("Erro ao atualizar tip:", error);
      toast.error("Erro ao atualizar tip");
    },
  });
}

export function useDeleteUserTip() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (tipId: string) => {
      const { data, error, count } = await supabase
        .from("user_tips")
        .delete({ count: "exact" })
        .eq("id", tipId)
        .select("id");

      if (error) throw error;

      assertAffectedRows(
        { count, data },
        "Falha ao excluir tip (permissão insuficiente ou registro não encontrado)"
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user_tips"] });
      toast.success("Tip excluído!");
    },
    onError: (error) => {
      console.error("Erro ao excluir tip:", error);
      toast.error("Erro ao excluir tip");
    },
  });
}


export const TIP_CATEGORIES: TipCategory[] = [
  "Processo",
  "Venda",
  "Renovação",
  "Sinistro",
  "Geral",
];
