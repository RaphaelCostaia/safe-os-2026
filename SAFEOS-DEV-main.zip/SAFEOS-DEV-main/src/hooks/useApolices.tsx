import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/types";
import { toast } from "sonner";
import { invalidateEntityQueries } from "@/lib/queryInvalidation";
import { assertAffectedRows } from "@/lib/supabaseMutationUtils";
import { sanitizePayload } from "@/lib/utils";
import { differenceInDays } from "date-fns";
import { updateObservationsCrmStage } from "@/hooks/useClients";

export type Apolice = Tables<"apolices">;
export type ApoliceInsert = TablesInsert<"apolices">;
export type ApoliceUpdate = TablesUpdate<"apolices">;

export type ApoliceWithRelations = Apolice & {
  clients?: { nome: string; email: string | null } | null;
  produtos?: { nome: string; categoria: string; comissao_percentual?: number | null } | null;
};

interface UseApolicesOptions {
  includeArchived?: boolean;
}

/**
 * Automatical synchronization of client status based on their policies.
 */
async function triggerClientStatusSync(clientId: string | null | undefined) {
  if (!clientId) return;
  try {
    const { data: client, error: fetchError } = await supabase
      .from("clients")
      .select(`
        id,
        status,
        observacoes,
        apolices (id, status, data_fim, deleted_at)
      `)
      .eq("id", clientId)
      .is("deleted_at", null)
      .maybeSingle();

    if (fetchError || !client) return;

    const policies = (client.apolices || []).filter((p: any) => p && p.deleted_at === null);
    const today = new Date();

    const isPolicyActive = (p: any) => {
      if (p.status !== "ativa" && p.status !== "vencendo") return false;
      if (!p.data_fim) return true;
      try {
        const dbDate = new Date(p.data_fim);
        const days = differenceInDays(dbDate, today);
        return days >= 0;
      } catch {
        return true;
      }
    };

    const activePolicies = policies.filter(isPolicyActive);
    const hasActivePolicy = activePolicies.length > 0;
    
    const hasAnyPolicy = policies.length > 0;
    const allPoliciesInactive = hasAnyPolicy && policies.every((p: any) => {
      if (p.status === "cancelada" || p.status === "expirada") return true;
      if (!p.data_fim) return false;
      try {
        const dbDate = new Date(p.data_fim);
        const days = differenceInDays(dbDate, today);
        return days < 0;
      } catch {
        return false;
      }
    });

    let targetStatus = client.status;

    if (hasActivePolicy) {
      if (client.status !== "ativo") {
        targetStatus = "ativo";
      }
    } else if (allPoliciesInactive) {
      if (client.status === "ativo") {
        targetStatus = "inativo";
      }
    }

    if (targetStatus !== client.status) {
      let finalObs = client.observacoes || "";
      const crmStage = targetStatus === "ativo" ? "convertido" : targetStatus === "inativo" ? "perdido" : "contato";
      finalObs = updateObservationsCrmStage(finalObs, crmStage);

      await supabase
        .from("clients")
        .update({ 
          status: targetStatus,
          observacoes: finalObs,
          updated_at: new Date().toISOString()
        })
        .eq("id", clientId);
      
      console.log(`Auto-synchronized client ${clientId} to status ${targetStatus} based on policy changes.`);
    }
  } catch (err) {
    console.error("Error in triggerClientStatusSync:", err);
  }
}

export function useApolices(options: UseApolicesOptions = {}) {
  const { includeArchived = false } = options;

  return useQuery({
    queryKey: ["apolices", { includeArchived }],
    queryFn: async () => {
      let query = supabase
        .from("apolices")
        .select(`
          *,
          clients (nome, email),
          produtos (nome, categoria, comissao_percentual)
        `)
        .order("created_at", { ascending: false });

      if (!includeArchived) {
        query = query.is("deleted_at", null);
      }

      const { data, error } = await query;

      if (error) throw error;
      return data as ApoliceWithRelations[];
    },
  });
}

export function useApolice(id: string) {
  return useQuery({
    queryKey: ["apolices", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("apolices")
        .select(`
          *,
          clients (nome, email),
          produtos (nome, categoria, comissao_percentual)
        `)
        .eq("id", id)
        .single();

      if (error) throw error;
      return data as ApoliceWithRelations;
    },
    enabled: !!id,
  });
}

export function useCreateApolice() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (apolice: ApoliceInsert) => {
      // Ensure organization_id is set to avoid RLS mismatch
      const { data: { session } } = await supabase.auth.getSession();
      const currentUserId = session?.user?.id;
      let finalOrgId = apolice.organization_id;

      if (!finalOrgId && currentUserId) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("organization_id")
          .eq("id", currentUserId)
          .maybeSingle();
        
        if (profile?.organization_id) {
          finalOrgId = profile.organization_id;
        } else {
          // Fallback to first available organization if no info
          const { data: orgs } = await supabase
            .from("organizations")
            .select("id")
            .order("created_at", { ascending: true })
            .limit(1);
          if (orgs && orgs.length > 0) {
            finalOrgId = orgs[0].id;
          }
        }
      }

      // Ensure a valid produto_id is always present (database has NOT NULL constraint)
      let finalProdutoId = (apolice.produto_id && typeof apolice.produto_id === "string") ? apolice.produto_id.trim() : null;

      if (!finalProdutoId) {
        // 1. Try to find any existing active product
        const { data: existingProds } = await supabase
          .from("produtos")
          .select("id")
          .order("created_at", { ascending: true })
          .limit(1);

        if (existingProds && existingProds.length > 0) {
          finalProdutoId = existingProds[0].id;
        } else {
          // 2. Auto-generate default general insurance product if catalog is empty
          const { data: createdProd } = await supabase
            .from("produtos")
            .insert({
              nome: "Seguro Geral / RCP",
              categoria: "rcp",
              seguradora: apolice.seguradora || "Porto Seguro",
              codigo: `GERAL-${Math.floor(1000 + Math.random() * 9000)}`,
              comissao_percentual: 20,
              ativo: true,
              ...(finalOrgId ? { organization_id: finalOrgId } : {})
            })
            .select("id")
            .single();

          if (createdProd?.id) {
            finalProdutoId = createdProd.id;
          }
        }
      }

      const apoliceWithOrg = {
        ...apolice,
        produto_id: finalProdutoId,
        organization_id: finalOrgId
      };

      const sanitizedApolice = sanitizePayload(apoliceWithOrg);
      const { data, error } = await supabase
        .from("apolices")
        .insert(sanitizedApolice)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      invalidateEntityQueries(queryClient, "apolices");
      invalidateEntityQueries(queryClient, "clients");
      invalidateEntityQueries(queryClient, "crm_leads");
      
      if (data && data.client_id) {
        triggerClientStatusSync(data.client_id).then(() => {
          invalidateEntityQueries(queryClient, "clients");
          invalidateEntityQueries(queryClient, "crm_leads");
        });
      }
      
      toast.success("Apólice criada com sucesso!");
    },
    onError: (error: any) => {
      let message = error.message;
      if (error.code === "23505" || message?.includes("apolices_numero_apolice_key")) {
        message = "Já existe uma apólice ou proposta cadastrada com este número de contrato. Por favor, insira um número diferente para prosseguir.";
      }
      toast.error("Erro ao criar apólice: " + message);
    },
  });
}

export function useUpdateApolice() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...apolice }: ApoliceUpdate & { id: string }) => {
      const sanitizedApolice: any = sanitizePayload(apolice);
      if (typeof sanitizedApolice.produto_id === "string" && !sanitizedApolice.produto_id.trim()) {
        delete sanitizedApolice.produto_id;
      }
      const { data, error } = await supabase
        .from("apolices")
        .update(sanitizedApolice)
        .eq("id", id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      invalidateEntityQueries(queryClient, "apolices");
      invalidateEntityQueries(queryClient, "clients");
      invalidateEntityQueries(queryClient, "crm_leads");
      
      if (data && data.client_id) {
        triggerClientStatusSync(data.client_id).then(() => {
          invalidateEntityQueries(queryClient, "clients");
          invalidateEntityQueries(queryClient, "crm_leads");
        });
      }
      
      toast.success("Apólice atualizada com sucesso!");
    },
    onError: (error: any) => {
      let message = error.message;
      if (error.code === "23505" || message?.includes("apolices_numero_apolice_key")) {
        message = "Já existe uma apólice ou proposta cadastrada com este número de contrato. Por favor, insira um número diferente para prosseguir.";
      }
      toast.error("Erro ao atualizar apólice: " + message);
    },
  });
}

/**
 * Archive (soft-delete) an apolice.
 */
export function useArchiveApolice() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, userId }: { id: string; userId: string }) => {
      // Check for active linked sinistros
      const { count: activeSinistros } = await supabase
        .from("sinistros")
        .select("id", { count: "exact", head: true })
        .eq("apolice_id", id)
        .is("deleted_at", null);

      if (activeSinistros && activeSinistros > 0) {
        throw new Error(
          `Não é possível arquivar: existem ${activeSinistros} sinistro(s) vinculados. Arquive-os primeiro.`
        );
      }

      // Fetch the client_id first before update to sync their status on success
      const { data: currentAp } = await supabase
        .from("apolices")
        .select("client_id")
        .eq("id", id)
        .single();
      const clientId = currentAp?.client_id;

      // Perform soft delete
      const { data, error, count } = await supabase
        .from("apolices")
        .update({
          deleted_at: new Date().toISOString(),
          deleted_by: userId,
        })
        .eq("id", id)
        .is("deleted_at", null)
        .select("id");

      if (error) throw error;

      assertAffectedRows(
        { count, data },
        "Falha ao arquivar apólice (permissão insuficiente ou registro não encontrado)"
      );

      return { id, clientId };
    },
    onMutate: async ({ id }) => {
      await queryClient.cancelQueries({ queryKey: ["apolices"] });
      const previousApolices = queryClient.getQueryData<ApoliceWithRelations[]>(["apolices", { includeArchived: false }]);
      
      if (previousApolices) {
        queryClient.setQueryData<ApoliceWithRelations[]>(
          ["apolices", { includeArchived: false }],
          previousApolices.filter(a => a.id !== id)
        );
      }
      
      return { previousApolices };
    },
    onError: (error, _vars, context) => {
      if (context?.previousApolices) {
        queryClient.setQueryData(["apolices", { includeArchived: false }], context.previousApolices);
      }
      toast.error(error.message);
    },
    onSuccess: (result) => {
      toast.success("Apólice arquivada com sucesso!");
      invalidateEntityQueries(queryClient, "apolices");
      invalidateEntityQueries(queryClient, "clients");
      invalidateEntityQueries(queryClient, "crm_leads");
      
      if (result && result.clientId) {
        triggerClientStatusSync(result.clientId).then(() => {
          invalidateEntityQueries(queryClient, "clients");
          invalidateEntityQueries(queryClient, "crm_leads");
        });
      }
    },
  });
}

/**
 * Restore an archived apolice.
 */
export function useRestoreApolice() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { data: apol } = await supabase
        .from("apolices")
        .select("client_id")
        .eq("id", id)
        .single();
      const clientId = apol?.client_id;

      const { data, error, count } = await supabase
        .from("apolices")
        .update({
          deleted_at: null,
          deleted_by: null,
        })
        .eq("id", id)
        .not("deleted_at", "is", null)
        .select("id");

      if (error) throw error;

      assertAffectedRows(
        { count, data },
        "Falha ao restaurar apólice (permissão insuficiente ou registro não encontrado)"
      );

      return { id, clientId };
    },
    onSuccess: (result) => {
      toast.success("Apólice restaurada com sucesso!");
      invalidateEntityQueries(queryClient, "apolices");
      invalidateEntityQueries(queryClient, "clients");
      invalidateEntityQueries(queryClient, "crm_leads");

      if (result && result.clientId) {
        triggerClientStatusSync(result.clientId).then(() => {
          invalidateEntityQueries(queryClient, "clients");
          invalidateEntityQueries(queryClient, "crm_leads");
        });
      }
    },
    onError: (error) => {
      toast.error("Erro ao restaurar apólice: " + error.message);
    },
  });
}

/**
 * @deprecated Use useArchiveApolice instead for soft delete.
 */
export function useDeleteApolice() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { data: apol } = await supabase
        .from("apolices")
        .select("client_id")
        .eq("id", id)
        .single();
      const clientId = apol?.client_id;

      const { data, error, count } = await supabase
        .from("apolices")
        .delete({ count: "exact" })
        .eq("id", id)
        .select("id");
      
      if (error) throw error;

      assertAffectedRows(
        { count, data },
        "Falha ao excluir apólice (permissão insuficiente ou registro não encontrado)"
      );

      return { id, clientId };
    },
    onMutate: async (id: string) => {
      await queryClient.cancelQueries({ queryKey: ["apolices"] });
      const previousApolices = queryClient.getQueryData<ApoliceWithRelations[]>(["apolices", { includeArchived: false }]);
      
      if (previousApolices) {
        queryClient.setQueryData<ApoliceWithRelations[]>(
          ["apolices", { includeArchived: false }],
          previousApolices.filter(a => a.id !== id)
        );
      }
      
      return { previousApolices };
    },
    onError: (error, _id, context) => {
      if (context?.previousApolices) {
        queryClient.setQueryData(["apolices", { includeArchived: false }], context.previousApolices);
      }
      toast.error("Erro ao excluir apólice: " + error.message);
    },
    onSuccess: (result) => {
      toast.success("Apólice excluída com sucesso!");
      invalidateEntityQueries(queryClient, "apolices");
      invalidateEntityQueries(queryClient, "clients");
      invalidateEntityQueries(queryClient, "crm_leads");

      if (result && result.clientId) {
        triggerClientStatusSync(result.clientId).then(() => {
          invalidateEntityQueries(queryClient, "clients");
          invalidateEntityQueries(queryClient, "crm_leads");
        });
      }
    },
  });
}
