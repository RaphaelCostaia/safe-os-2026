import { createContext, useContext, useState, useCallback, useMemo, ReactNode, useEffect } from "react";
import { useSearchParams } from "react-router-dom";

export interface DashboardFilters {
  selectedUF: string | null;
}

interface DashboardFilterContextType {
  filters: DashboardFilters;
  setSelectedUF: (uf: string | null) => void;
  toggleUF: (uf: string) => void;
  clearFilters: () => void;
  hasActiveFilters: boolean;
}

const DashboardFilterContext = createContext<DashboardFilterContextType | undefined>(undefined);

export function DashboardFilterProvider({ children }: { children: ReactNode }) {
  const [searchParams, setSearchParams] = useSearchParams();
  
  // Initialize from URL
  const initialUF = searchParams.get("uf");
  const [selectedUF, setSelectedUFState] = useState<string | null>(initialUF);

  // Sync state to URL
  useEffect(() => {
    const newParams = new URLSearchParams(searchParams);
    if (selectedUF) {
      newParams.set("uf", selectedUF);
    } else {
      newParams.delete("uf");
    }
    // Only update if changed
    if (newParams.toString() !== searchParams.toString()) {
      setSearchParams(newParams, { replace: true });
    }
  }, [selectedUF, searchParams, setSearchParams]);

  const setSelectedUF = useCallback((uf: string | null) => {
    setSelectedUFState(uf);
  }, []);

  const toggleUF = useCallback((uf: string) => {
    setSelectedUFState(prev => prev === uf ? null : uf);
  }, []);

  const clearFilters = useCallback(() => {
    setSelectedUFState(null);
  }, []);

  const hasActiveFilters = useMemo(() => selectedUF !== null, [selectedUF]);

  const filters = useMemo(() => ({
    selectedUF,
  }), [selectedUF]);

  const value = useMemo(() => ({
    filters,
    setSelectedUF,
    toggleUF,
    clearFilters,
    hasActiveFilters,
  }), [filters, setSelectedUF, toggleUF, clearFilters, hasActiveFilters]);

  return (
    <DashboardFilterContext.Provider value={value}>
      {children}
    </DashboardFilterContext.Provider>
  );
}

export function useDashboardFilter() {
  const context = useContext(DashboardFilterContext);
  if (context === undefined) {
    throw new Error("useDashboardFilter must be used within a DashboardFilterProvider");
  }
  return context;
}

// Safe hook version that returns null if not in provider (for standalone use)
export function useDashboardFilterOptional(): DashboardFilterContextType | null {
  return useContext(DashboardFilterContext) ?? null;
}
