import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/types";
import { toast } from "sonner";
import { invalidateEntityQueries } from "@/lib/queryInvalidation";
import { assertAffectedRows } from "@/lib/supabaseMutationUtils";
import { sanitizePayload } from "@/lib/utils";

export type Client = Tables<"clients">;
export type ClientInsert = TablesInsert<"clients">;
export type ClientUpdate = TablesUpdate<"clients">;

interface UseClientsOptions {
  includeArchived?: boolean;
}

// Centralized status mapping logic
export const mapUiStatusToDbStatus = (uiStatus?: string | null): 'ativo' | 'inativo' | 'prospecto' => {
  const normalized = (uiStatus || "").toLowerCase().trim();
  if (normalized === 'ativo' || normalized === 'convertido') return 'ativo';
  if (normalized === 'inativo' || normalized === 'perdido') return 'inativo';
  return 'prospecto';
};

export const safeParseMetadata = (observacoes: string | null): any => {
  if (!observacoes) return null;
  const divider = "-- METADATA_JSON_V1 --";
  const parts = observacoes.split(divider);
  if (parts.length >= 2) {
    try {
      const sanitizedJsonStr = parts[1].replace(/\[ESTAGIO:[^\]]+\]/gi, "").trim();
      return JSON.parse(sanitizedJsonStr);
    } catch (e) {
      console.error("Failed to parse client metadata json:", e, "Raw:", parts[1]);
      return null;
    }
  }
  return null;
};

export const updateObservationsCrmStage = (observacoes: string | null, newStage: string): string => {
  const rawObs = observacoes || "";
  const divider = "-- METADATA_JSON_V1 --";
  const parts = rawObs.split(divider);
  
  let notesPart = parts[0] || "";
  const jsonPart = parts.length >= 2 ? parts[1] : "";
  
  // Clean all existing [ESTAGIO:...] tags inside the notesPart (case-insensitive)
  notesPart = notesPart.replace(/\[ESTAGIO:[^\]]+\]/gi, '').trim();
  
  // Append the new [ESTAGIO:...] tag to notesPart
  notesPart = `${notesPart} [ESTAGIO:${newStage}]`.trim();
  
  // If we had a JSON part, strip any out-of-bounds [ESTAGIO:...] appending tags from it too
  const cleanJsonPart = jsonPart.replace(/\[ESTAGIO:[^\]]+\]/gi, "").trim();
  
  if (cleanJsonPart) {
    return `${notesPart}\n\n${divider}\n${cleanJsonPart}`;
  }
  
  return notesPart;
};

export const getCrmStageFromClient = (status: string | null, observacoes: string | null): string => {
  const obs = observacoes || "";
  const match = obs.match(/\[ESTAGIO:([^\]]+)\]/);
  const matchedStage = match ? match[1].toLowerCase().trim() : null;
  const rawStatus = (status || "").toLowerCase().trim();

  if (rawStatus === 'ativo') {
    // For active clients, they can only be in active stages: 'convertido' or 'pos_venda'
    if (matchedStage === 'convertido' || matchedStage === 'pos_venda') {
      return matchedStage;
    }
    return 'convertido'; // Force to Convertido
  }

  if (rawStatus === 'inativo') {
    // For inactive clients, they can only be in 'perdido' stage
    return 'perdido';
  }

  // It is 'prospecto' (prospects cannot be 'convertido' or 'pos_venda' or 'perdido')
  if (matchedStage && matchedStage !== 'convertido' && matchedStage !== 'pos_venda' && matchedStage !== 'perdido') {
    return matchedStage;
  }
  return 'contato'; // prospecto maps to contato by default
};

export function useClients(options: UseClientsOptions = {}) {
  const { includeArchived = false } = options;
  
  return useQuery({
    queryKey: ["clients", { includeArchived }],
    queryFn: async () => {
      let query = supabase
        .from("clients")
        .select("*")
        .order("created_at", { ascending: false });
      
      // By default, filter out archived (soft-deleted) clients
      if (!includeArchived) {
        query = query.is("deleted_at", null);
      }
      
      const { data, error } = await query;
      
      if (error) throw error;
      return data as Client[];
    },
  });
}

export function useClient(id: string) {
  return useQuery({
    queryKey: ["clients", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("clients")
        .select("*")
        .eq("id", id)
        .single();
      
      if (error) throw error;
      return data as Client;
    },
    enabled: !!id,
  });
}

export function useCreateClient() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (client: ClientInsert) => {
      // Get current user for default responsavel_id if not provided
      const { data: { session } } = await supabase.auth.getSession();
      const currentUserId = session?.user?.id;

      let finalOrgId = client.organization_id;
      if (!finalOrgId && currentUserId) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("organization_id")
          .eq("id", currentUserId)
          .maybeSingle();
        
        if (profile?.organization_id) {
          finalOrgId = profile.organization_id;
        } else {
          // Fallback to first available organization if no info
          const { data: orgs } = await supabase
            .from("organizations")
            .select("id")
            .order("created_at", { ascending: true })
            .limit(1);
          if (orgs && orgs.length > 0) {
            finalOrgId = orgs[0].id;
          }
        }
      }

      // Robust status mapping to prevent DB check constraint errors
      // and preserve CRM stage via observacoes tag
      const uiStatus = client.status;
      const dbStatus = mapUiStatusToDbStatus(uiStatus);

      // Add tag to observacoes if uiStatus is more specific than dbStatus
      let finalObs = client.observacoes || "";
      if (uiStatus && uiStatus !== dbStatus) {
        finalObs = updateObservationsCrmStage(finalObs, uiStatus);
      }

      const clientWithMappedData = {
        ...client,
        status: dbStatus,
        observacoes: finalObs,
        responsavel_id: client.responsavel_id || currentUserId,
        user_id: client.user_id || currentUserId,
        organization_id: finalOrgId
      };

      const sanitizedClient = sanitizePayload(clientWithMappedData);

      const { data, error } = await supabase
        .from("clients")
        .insert(sanitizedClient)
        .select()
        .single();
      
      if (error) {
        console.error("Supabase Client Create Error Detail:", error);
        throw error;
      }
      return data as Client;
    },
    onSuccess: () => {
      invalidateEntityQueries(queryClient, "clients");
      toast.success("Cliente criado com sucesso!");
    },
    onError: (error: Error & { code?: string }) => {
      let message = error.message;
      if (error.code === "23505" || message?.includes("unique constraint") || message?.includes("já existe")) {
        message = "CPF ou CNPJ já cadastrado para outro cliente.";
      }
      if (error.code === "23514" || message?.includes("check constraint")) {
        message = "Valor de status inválido para o banco de dados. O sistema tentou corrigir automaticamente, mas houve uma falha de validação.";
      }
      toast.error("Erro ao criar cliente: " + message);
    },
  });
}

export function useUpdateClient() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...client }: ClientUpdate & { id: string }) => {
      // Similar mapping for updates
      const updatedData: ClientUpdate = { ...client };
      
      const uiStatus = client.status;
      if (uiStatus !== undefined) {
        const dbStatus = mapUiStatusToDbStatus(uiStatus);
        updatedData.status = dbStatus;

        // Sync CRM tag if status was updated
        if (uiStatus && uiStatus !== dbStatus) {
          let baseObs = client.observacoes;
          
          if (baseObs === undefined) {
             const { data: current } = await supabase.from("clients").select("observacoes").eq("id", id).single();
             baseObs = current?.observacoes || "";
          }
          
          updatedData.observacoes = updateObservationsCrmStage(baseObs, uiStatus);
        }
      }

      const sanitizedClient = sanitizePayload(updatedData);

      const { data, error } = await supabase
        .from("clients")
        .update(sanitizedClient)
        .eq("id", id)
        .select()
        .single();
      
      if (error) {
        console.error("Supabase Client Update Error Detail:", error);
        throw error;
      }
      return data;
    },
    onSuccess: () => {
      invalidateEntityQueries(queryClient, "clients");
      toast.success("Cliente atualizado com sucesso!");
    },
    onError: (error: Error & { code?: string }) => {
      let message = error.message;
      if (error.code === "23505" || message?.includes("unique constraint") || message?.includes("já existe")) {
        message = "CPF ou CNPJ já cadastrado para outro cliente.";
      }
      toast.error("Erro ao atualizar cliente: " + message);
    },
  });
}

/**
 * Archive (soft-delete) a client.
 * Sets deleted_at and deleted_by instead of hard deleting.
 * Only admin/gestor can archive (enforced by can_soft_delete check).
 */
export function useArchiveClient() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, userId }: { id: string; userId: string }) => {
      // Check for active linked records first
      const [apolicesResult, sinistrosResult, commissionsResult] = await Promise.all([
        supabase
          .from("apolices")
          .select("id", { count: "exact", head: true })
          .eq("client_id", id)
          .is("deleted_at", null),
        supabase
          .from("sinistros")
          .select("id", { count: "exact", head: true })
          .eq("client_id", id)
          .is("deleted_at", null),
        supabase
          .from("client_commission_terms")
          .select("id", { count: "exact", head: true })
          .eq("client_id", id)
          .eq("is_active", true),
      ]);

      const activeApolices = apolicesResult.count || 0;
      const activeSinistros = sinistrosResult.count || 0;
      const activeCommissions = commissionsResult.count || 0;

      if (activeApolices > 0 || activeSinistros > 0) {
        const messages: string[] = [];
        if (activeApolices > 0) messages.push(`${activeApolices} apólice(s)`);
        if (activeSinistros > 0) messages.push(`${activeSinistros} sinistro(s)`);
        throw new Error(
          `Não é possível arquivar: existem ${messages.join(" e ")} vinculados. Arquive-os primeiro.`
        );
      }

      // Deactivate any active commission terms
      if (activeCommissions > 0) {
        await supabase
          .from("client_commission_terms")
          .update({ is_active: false, ends_at: new Date().toISOString().split("T")[0] })
          .eq("client_id", id)
          .eq("is_active", true);
      }

      // Perform soft delete
      const { data, error, count } = await supabase
        .from("clients")
        .update({
          deleted_at: new Date().toISOString(),
          deleted_by: userId,
        })
        .eq("id", id)
        .is("deleted_at", null) // Only archive if not already archived
        .select("id");

      if (error) throw error;

      assertAffectedRows(
        { count, data },
        "Falha ao arquivar cliente (permissão insuficiente ou registro não encontrado)"
      );

      return { id };
    },
    onMutate: async ({ id }) => {
      // Cancel any outgoing refetches
      await queryClient.cancelQueries({ queryKey: ["clients"] });
      
      // Snapshot previous value for rollback
      const previousClients = queryClient.getQueryData<Client[]>(["clients", { includeArchived: false }]);
      
      // Optimistically remove from active list
      if (previousClients) {
        queryClient.setQueryData<Client[]>(
          ["clients", { includeArchived: false }],
          previousClients.filter(c => c.id !== id)
        );
      }
      
      return { previousClients };
    },
    onError: (error, _vars, context) => {
      // Restore on error
      if (context?.previousClients) {
        queryClient.setQueryData(["clients", { includeArchived: false }], context.previousClients);
      }
      toast.error(error.message);
    },
    onSuccess: () => {
      toast.success("Cliente arquivado com sucesso!");
      invalidateEntityQueries(queryClient, "clients");
    },
  });
}

/**
 * Restore an archived client.
 */
export function useRestoreClient() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { data, error, count } = await supabase
        .from("clients")
        .update({
          deleted_at: null,
          deleted_by: null,
        })
        .eq("id", id)
        .not("deleted_at", "is", null) // Only restore if archived
        .select("id");

      if (error) throw error;

      assertAffectedRows(
        { count, data },
        "Falha ao restaurar cliente (permissão insuficiente ou registro não encontrado)"
      );

      return { id };
    },
    onSuccess: () => {
      toast.success("Cliente restaurado com sucesso!");
      invalidateEntityQueries(queryClient, "clients");
    },
    onError: (error) => {
      toast.error("Erro ao restaurar cliente: " + error.message);
    },
  });
}

/**
 * Hard delete performs a client-directed cascading deletion of all associated 
 * records (including policies, notes, documents, commission terms, and sinistros) to ensure 
 * foreign key constraints do not fail, and then removes the client itself.
 */
export function useDeleteClient() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      // 1. Get all apolices of this client
      const { data: clientApolices, error: apolicesFetchError } = await supabase
        .from("apolices")
        .select("id")
        .eq("client_id", id);
      if (apolicesFetchError) {
        console.error("Error fetching apolices for cascading delete:", apolicesFetchError);
        throw new Error(`Erro ao buscar apólices do cliente: ${apolicesFetchError.message}`);
      }
      const apoliceIds = clientApolices?.map(a => a.id) || [];

      // 2. Get all sinistros of this client
      const { data: clientSinistros, error: sinsFetchError } = await supabase
        .from("sinistros")
        .select("id")
        .eq("client_id", id);
      if (sinsFetchError) {
        console.error("Error fetching sinistros for cascading delete:", sinsFetchError);
        throw new Error(`Erro ao buscar sinistros do cliente: ${sinsFetchError.message}`);
      }
      const directSinistroIds = clientSinistros?.map(s => s.id) || [];

      let allSinistroIds = [...directSinistroIds];
      if (apoliceIds.length > 0) {
        const { data: apoliceSinistros, error: apSinsFetchError } = await supabase
          .from("sinistros")
          .select("id")
          .in("apolice_id", apoliceIds);
        if (apSinsFetchError) {
          console.warn("Warning fetching apolice-linked sinistros:", apSinsFetchError);
        } else if (apoliceSinistros) {
          allSinistroIds = Array.from(new Set([...allSinistroIds, ...apoliceSinistros.map(s => s.id)]));
        }
      }

      // 3. Delete sinistro sub-records (sinistro_activities, sinistro_notes, sinistro_documents)
      if (allSinistroIds.length > 0) {
        try {
          await supabase.from("sinistro_activities").delete().in("sinistro_id", allSinistroIds);
        } catch (e) {
          console.warn("Non-fatal: could not clear sinistro_activities:", e);
        }

        try {
          await supabase.from("sinistro_notes").delete().in("sinistro_id", allSinistroIds);
        } catch (e) {
          console.warn("Non-fatal: could not clear sinistro_notes:", e);
        }

        try {
          await supabase.from("sinistro_documents").delete().in("sinistro_id", allSinistroIds);
        } catch (e) {
          console.warn("Non-fatal: could not clear sinistro_documents:", e);
        }

        // Delete sinistros themselves
        const { error: sinDeleteErr } = await supabase.from("sinistros").delete().in("id", allSinistroIds);
        if (sinDeleteErr) {
          console.warn("Warning deleting sinistros by ID:", sinDeleteErr);
        }
      }

      // Loose-end cleanups: sinistros/documents directly pointing to client or apolices
      try {
        await supabase.from("sinistro_documents").delete().eq("client_id", id);
      } catch (e) {
        console.warn("Non-fatal error clearing direct sinistro_documents:", e);
      }

      if (apoliceIds.length > 0) {
        try {
          await supabase.from("sinistro_documents").delete().in("apolice_id", apoliceIds);
        } catch (e) {
          console.warn("Non-fatal error clearing apolice sinistro_documents:", e);
        }
      }

      try {
        await supabase.from("sinistros").delete().eq("client_id", id);
      } catch (e) {
        console.warn("Non-fatal error clearing direct sinistros:", e);
      }

      if (apoliceIds.length > 0) {
        try {
          await supabase.from("sinistros").delete().in("apolice_id", apoliceIds);
        } catch (e) {
          console.warn("Non-fatal error clearing apolice sinistros:", e);
        }
      }

      // 4. Delete comissoes entries FIRST (to satisfy FK comissoes -> client_commission_terms and comissoes -> apolices)
      try {
        await (supabase.from("comissoes" as any) as any).delete().eq("client_id", id);
      } catch (comError) {
        console.debug("Ignored expected error deleting from optional/legacy comissoes table by client_id:", comError);
      }

      if (apoliceIds.length > 0) {
        try {
          await (supabase.from("comissoes" as any) as any).delete().in("apolice_id", apoliceIds);
        } catch (comError) {
          console.debug("Ignored expected error deleting from optional/legacy comissoes table by apolice_id:", comError);
        }
      }

      // 5. Delete client_commission_terms
      const { error: commsErr } = await supabase.from("client_commission_terms").delete().eq("client_id", id);
      if (commsErr) {
        console.warn("Warning deleting client_commission_terms:", commsErr.message);
      }

      // 6. Delete apolice sub-records (apolice_documents, contas, renovacoes)
      if (apoliceIds.length > 0) {
        try {
          await supabase.from("apolice_documents").delete().in("apolice_id", apoliceIds);
        } catch (e) {
          console.warn("Warning deleting apolice_documents:", e);
        }

        try {
          await supabase.from("contas").delete().in("apolice_id", apoliceIds);
        } catch (e) {
          console.warn("Warning deleting contas by apolice_id:", e);
        }

        try {
          await supabase.from("renovacoes").delete().in("apolice_id", apoliceIds);
        } catch (e) {
          console.warn("Warning deleting renovacoes:", e);
        }
      }
      
      // Delete contas linked to client directly via cliente_id
      try {
        await supabase.from("contas").delete().eq("cliente_id", id);
      } catch (e) {
        console.warn("Warning deleting contas by cliente_id:", e);
      }

      // 7. Delete client specific metadata and files (client_notes, client_documents)
      try {
        await supabase.from("client_notes").delete().eq("client_id", id);
      } catch (e) {
        console.warn("Warning deleting client_notes:", e);
      }

      try {
        await supabase.from("client_documents").delete().eq("client_id", id);
      } catch (e) {
        console.warn("Warning deleting client_documents:", e);
      }

      // 8. Delete apolices
      const { error: apolicesDeleteErr } = await supabase.from("apolices").delete().eq("client_id", id);
      if (apolicesDeleteErr) {
        console.error("Error deleting apolices for client:", apolicesDeleteErr);
        throw new Error(`Erro ao excluir apólices do cliente: ${apolicesDeleteErr.message}`);
      }

      if (apoliceIds.length > 0) {
        const { error: apolicesRemainingErr } = await supabase.from("apolices").delete().in("id", apoliceIds);
        if (apolicesRemainingErr) {
          console.warn("Warning deleting remaining apolices by id:", apolicesRemainingErr);
        }
      }

      // 9. Finally, delete the client record
      const { data, error, count } = await supabase
        .from("clients")
        .delete({ count: "exact" })
        .eq("id", id)
        .select("id");
      
      if (error) {
        console.error("Error deleting client record:", error);
        throw new Error(`Erro ao excluir cliente: ${error.message}`);
      }

      assertAffectedRows(
        { count, data },
        "Falha ao excluir cliente (permissão insuficiente ou registro não encontrado)"
      );

      return { affected: count };
    },
    onMutate: async (id: string) => {
      await queryClient.cancelQueries({ queryKey: ["clients"] });
      const previousClients = queryClient.getQueryData<Client[]>(["clients", { includeArchived: false }]);
      
      if (previousClients) {
        queryClient.setQueryData<Client[]>(
          ["clients", { includeArchived: false }],
          previousClients.filter(c => c.id !== id)
        );
      }
      
      return { previousClients };
    },
    onError: (error, _id, context) => {
      if (context?.previousClients) {
        queryClient.setQueryData(["clients", { includeArchived: false }], context.previousClients);
      }
      toast.error("Erro ao excluir cliente: " + error.message);
    },
    onSuccess: () => {
      toast.success("Cliente excluído com sucesso!");
      invalidateEntityQueries(queryClient, "clients");
    },
  });
}
