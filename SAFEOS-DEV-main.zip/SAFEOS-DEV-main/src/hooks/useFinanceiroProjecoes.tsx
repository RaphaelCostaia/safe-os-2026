import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format, addMonths, parseISO, isBefore, isAfter, startOfMonth, differenceInMonths } from "date-fns";
import { ptBR } from "date-fns/locale";

export interface ProjecaoMensal {
  mes: string;
  mesLabel: string;
  receitaEstimada: number;
  custosEstimados: number;
  resultado: number;
  apolicesVigentes: number;
  apolicesVencendo: number;
}

export type HorizonteProjecao = 12 | 24 | 36;

/**
 * Hook to calculate financial projections based on real data
 * Uses active policies, fixed costs, and historical patterns
 */
export function useFinanceiroProjecoes(horizonte: HorizonteProjecao = 12) {
  return useQuery({
    queryKey: ["financeiro_projecoes", horizonte],
    queryFn: async (): Promise<ProjecaoMensal[]> => {
      const hoje = new Date();
      const inicioProjecao = startOfMonth(hoje);

      // Fetch all data in parallel
      const [apolicesResult, custosResult] = await Promise.all([
        supabase
          .from("apolices")
          .select("id, valor_premio, data_inicio, data_fim, status, produtos(comissao_percentual)")
          .in("status", ["ativa", "em_renovacao", "renovada"])
          .is("deleted_at", null),
        supabase
          .from("custos_fixos")
          .select("*")
          .eq("status", "ativo"),
      ]);

      if (apolicesResult.error) throw apolicesResult.error;
      if (custosResult.error) throw custosResult.error;

      const apolices = apolicesResult.data || [];
      const custosFixos = custosResult.data || [];

      // Calculate monthly fixed costs
      const custosMensais = custosFixos.reduce((sum, c) => {
        if (c.recorrencia === "mensal") return sum + c.valor;
        if (c.recorrencia === "anual") return sum + c.valor / 12;
        if (c.recorrencia === "trimestral") return sum + c.valor / 3;
        return sum;
      }, 0);

      // Generate projections for each month
      const projecoes: ProjecaoMensal[] = [];

      for (let i = 0; i < horizonte; i++) {
        const mesProjecao = addMonths(inicioProjecao, i);
        const mesKey = format(mesProjecao, "yyyy-MM");
        const mesLabel = format(mesProjecao, "MMM/yy", { locale: ptBR });

        // Count active policies in this month
        let receitaMes = 0;
        let apolicesVigentes = 0;
        let apolicesVencendo = 0;

        apolices.forEach((ap) => {
          if (!ap.data_inicio || !ap.data_fim) return;
          try {
            const dataInicio = parseISO(ap.data_inicio);
            const dataFim = parseISO(ap.data_fim);

            if (isNaN(dataInicio.getTime()) || isNaN(dataFim.getTime())) return;

            // Check if policy is active in this month
            if (isBefore(dataInicio, addMonths(mesProjecao, 1)) && isAfter(dataFim, mesProjecao)) {
              apolicesVigentes++;
              // Estimated monthly revenue (annual premium / 12)
              receitaMes += (ap.valor_premio || 0) / 12;

              // Check if policy expires in this month
              const mesesAteVencimento = differenceInMonths(dataFim, mesProjecao);
              if (mesesAteVencimento >= 0 && mesesAteVencimento < 1) {
                apolicesVencendo++;
              }
            }
          } catch (e) {
            console.warn("useFinanceiroProjecoes: error parsing dates in loop", e);
          }
        });

        // Apply growth factor for future months (conservative 1% per month)
        const fatorCrescimento = Math.pow(1.01, i);
        const fatorInflacao = Math.pow(1.005, i);

        // Calculate final values
        const receitaFinal = Math.round(receitaMes * fatorCrescimento);
        const custosFinal = Math.round(custosMensais * fatorInflacao);

        projecoes.push({
          mes: mesKey,
          mesLabel,
          receitaEstimada: receitaFinal,
          custosEstimados: custosFinal,
          resultado: receitaFinal - custosFinal,
          apolicesVigentes,
          apolicesVencendo,
        });
      }

      return projecoes;
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
}

/**
 * Check if there's enough data for projections
 */
export function useHasProjectionData() {
  return useQuery({
    queryKey: ["has_projection_data"],
    queryFn: async () => {
      const { count } = await supabase
        .from("apolices")
        .select("*", { count: "exact", head: true })
        .in("status", ["ativa", "em_renovacao", "renovada"])
        .is("deleted_at", null);

      return (count || 0) > 0;
    },
  });
}
