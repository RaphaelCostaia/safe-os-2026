import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert, Json } from "@/integrations/supabase/types";

export type SinistroActivity = Tables<"sinistro_activities">;
export type SinistroActivityInsert = TablesInsert<"sinistro_activities">;

export type ActivityType = 
  | 'criacao' 
  | 'status' 
  | 'criticidade' 
  | 'responsavel' 
  | 'documento' 
  | 'valor' 
  | 'encerramento' 
  | 'interacao';

const ACTIVITY_ICONS: Record<ActivityType, string> = {
  criacao: '🆕',
  status: '🔄',
  criticidade: '⚠️',
  responsavel: '👤',
  documento: '📎',
  valor: '💰',
  encerramento: '✅',
  interacao: '💬',
};

export function useSinistroActivities(sinistroId: string) {
  return useQuery({
    queryKey: ["sinistro-activities", sinistroId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("sinistro_activities")
        .select("*")
        .eq("sinistro_id", sinistroId)
        .order("created_at", { ascending: false });
      
      if (error) throw error;
      return data as SinistroActivity[];
    },
    enabled: !!sinistroId,
  });
}

export function useCreateSinistroActivity() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (activity: SinistroActivityInsert) => {
      const { data: userData } = await supabase.auth.getUser();
      
      const insertData: SinistroActivityInsert = {
        ...activity,
        user_id: userData.user?.id || undefined,
      };
      
      const { data, error } = await supabase
        .from("sinistro_activities")
        .insert(insertData)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ 
        queryKey: ["sinistro-activities", variables.sinistro_id] 
      });
    },
  });
}

// Helper function to log activities (can be called from other hooks)
export async function logSinistroActivity(
  sinistroId: string,
  tipo: ActivityType,
  titulo: string,
  descricao?: string,
  metadata?: Json
): Promise<void> {
  try {
    const { data: userData } = await supabase.auth.getUser();
    
    const insertData: SinistroActivityInsert = {
      sinistro_id: sinistroId,
      user_id: userData.user?.id || undefined,
      tipo: tipo,
      titulo: titulo,
      descricao: descricao || null,
      metadata: metadata || null,
    };
    
    const { error } = await supabase
      .from("sinistro_activities")
      .insert(insertData);
    
    if (error) {
      console.error("Erro ao registrar atividade:", error);
    }
  } catch (err) {
    console.error("Erro ao registrar atividade:", err);
  }
}

export { ACTIVITY_ICONS };
