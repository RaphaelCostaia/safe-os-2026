import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/types";
import { toast } from "sonner";
import { assertAffectedRows } from "@/lib/supabaseMutationUtils";

export type SinistroNote = Tables<"sinistro_notes">;
export type SinistroNoteInsert = TablesInsert<"sinistro_notes">;
export type SinistroNoteUpdate = TablesUpdate<"sinistro_notes">;

export function useSinistroNotes(sinistroId: string) {
  return useQuery({
    queryKey: ["sinistro-notes", sinistroId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("sinistro_notes")
        .select("*")
        .eq("sinistro_id", sinistroId)
        .order("is_pinned", { ascending: false })
        .order("created_at", { ascending: false });
      
      if (error) throw error;
      return data as SinistroNote[];
    },
    enabled: !!sinistroId,
  });
}

export function useCreateSinistroNote() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (note: Omit<SinistroNoteInsert, 'autor_id'>) => {
      const { data: { user } } = await supabase.auth.getUser();
      
      const { data, error } = await supabase
        .from("sinistro_notes")
        .insert({
          ...note,
          autor_id: user?.id || null,
        })
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ 
        queryKey: ["sinistro-notes", variables.sinistro_id] 
      });
      toast.success("Anotação criada com sucesso!");
    },
    onError: (error) => {
      toast.error("Erro ao criar anotação: " + error.message);
    },
  });
}

export function useUpdateSinistroNote() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, sinistroId, ...note }: SinistroNoteUpdate & { id: string; sinistroId: string }) => {
      const { data, error } = await supabase
        .from("sinistro_notes")
        .update(note)
        .eq("id", id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ 
        queryKey: ["sinistro-notes", variables.sinistroId] 
      });
      toast.success("Anotação atualizada!");
    },
    onError: (error) => {
      toast.error("Erro ao atualizar anotação: " + error.message);
    },
  });
}

export function useDeleteSinistroNote() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, sinistroId }: { id: string; sinistroId: string }) => {
      const { data, error, count } = await supabase
        .from("sinistro_notes")
        .delete({ count: "exact" })
        .eq("id", id)
        .select("id");
      
      if (error) throw error;

      assertAffectedRows(
        { count, data },
        "Falha ao excluir anotação (permissão insuficiente ou registro não encontrado)"
      );
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ 
        queryKey: ["sinistro-notes", variables.sinistroId] 
      });
      toast.success("Anotação excluída!");
    },
    onError: (error) => {
      toast.error("Erro ao excluir anotação: " + error.message);
    },
  });
}


export function useTogglePinNote() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, sinistroId, isPinned }: { id: string; sinistroId: string; isPinned: boolean }) => {
      const { data, error } = await supabase
        .from("sinistro_notes")
        .update({ is_pinned: !isPinned })
        .eq("id", id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ 
        queryKey: ["sinistro-notes", variables.sinistroId] 
      });
      toast.success(data.is_pinned ? "Anotação fixada!" : "Anotação desafixada!");
    },
    onError: (error) => {
      toast.error("Erro ao fixar anotação: " + error.message);
    },
  });
}
