import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { Tables, TablesInsert } from "@/integrations/supabase/types";
import { assertAffectedRows } from "@/lib/supabaseMutationUtils";

export type ClientDocument = Tables<"client_documents">;
export type ClientDocumentInsert = TablesInsert<"client_documents">;

// Nome do bucket configurado no Supabase
const BUCKET_NAME = "client-documents";

export function useClientDocuments(clientId: string) {
  return useQuery({
    queryKey: ["client_documents", clientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("client_documents")
        .select("*")
        .eq("client_id", clientId)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as ClientDocument[];
    },
    enabled: !!clientId,
  });
}

// Função para obter URL assinada (para buckets privados)
export async function getSignedUrl(filePath: string): Promise<string | null> {
  try {
    const { data, error } = await supabase.storage
      .from(BUCKET_NAME)
      .createSignedUrl(filePath, 3600); // 1 hora de validade

    if (error) {
      console.error("Erro ao criar URL assinada:", error);
      return null;
    }

    return data?.signedUrl || null;
  } catch (err) {
    console.error("Erro ao obter URL assinada:", err);
    return null;
  }
}

// Extrai o path do arquivo a partir da URL armazenada
export function extractFilePath(url: string): string | null {
  try {
    // URL pode ser:
    // - URL pública: .../storage/v1/object/public/bucket-name/path
    // - URL assinada: .../storage/v1/object/sign/bucket-name/path?token=...
    const bucketPattern = new RegExp(`/${BUCKET_NAME}/(.+?)(?:\\?|$)`);
    const match = url.match(bucketPattern);
    if (match && match[1]) {
      return decodeURIComponent(match[1]);
    }
    
    // Fallback: tenta extrair após o nome do bucket
    const parts = url.split(`/${BUCKET_NAME}/`);
    if (parts.length > 1) {
      const pathWithQuery = parts[1];
      return pathWithQuery.split('?')[0];
    }
    
    return null;
  } catch (err) {
    console.error("Erro ao extrair path do arquivo:", err);
    return null;
  }
}

export function useUploadClientDocument() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ 
      clientId, 
      file, 
      tipo 
    }: { 
      clientId: string; 
      file: File; 
      tipo: string;
    }) => {
      const { data: user } = await supabase.auth.getUser();
      
      if (!user.user) {
        throw new Error("Usuário não autenticado");
      }
      
      // Criar path único para o arquivo
      const timestamp = Date.now();
      const safeFileName = file.name.replace(/[^a-zA-Z0-9.-]/g, '_');
      const filePath = `${clientId}/${timestamp}-${safeFileName}`;
      
      console.log("Iniciando upload para:", filePath);
      
      // Upload do arquivo para o storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from(BUCKET_NAME)
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        console.error("Erro no upload:", uploadError);
        throw new Error(`Falha no upload: ${uploadError.message}`);
      }

      console.log("Upload concluído:", uploadData);

      // Para bucket privado, salvamos o path relativo e geramos URL assinada quando necessário
      // Armazenamos uma URL que podemos usar para identificar o arquivo
      const { data: urlData } = supabase.storage
        .from(BUCKET_NAME)
        .getPublicUrl(filePath);

      // Criar registro do documento no banco
      const { data, error } = await supabase
        .from("client_documents")
        .insert({
          client_id: clientId,
          nome: file.name,
          tipo,
          url: urlData.publicUrl, // Armazenamos a URL base para referência
          tamanho: file.size,
          uploaded_by: user.user.id,
        })
        .select()
        .single();

      if (error) {
        // Se falhou ao criar o registro, remove o arquivo do storage
        await supabase.storage.from(BUCKET_NAME).remove([filePath]);
        throw error;
      }

      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["client_documents", variables.clientId] });
      toast.success("Documento enviado com sucesso");
    },
    onError: (error: Error) => {
      console.error("Erro ao enviar documento:", error);
      toast.error(error.message || "Erro ao enviar documento");
    },
  });
}

export function useDeleteClientDocument() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, clientId, url }: { id: string; clientId: string; url: string }) => {
      // 1) Deletar registro do banco (primeiro) para evitar apagar arquivo sem permissão no DB
      const { data, error, count } = await supabase
        .from("client_documents")
        .delete({ count: "exact" })
        .eq("id", id)
        .select("id");

      if (error) throw error;

      assertAffectedRows(
        { count, data },
        "Falha ao excluir documento (permissão insuficiente ou registro não encontrado)"
      );

      // 2) Remover arquivo do storage (best-effort)
      const filePath = extractFilePath(url);
      if (filePath) {
        const { error: storageError } = await supabase.storage
          .from(BUCKET_NAME)
          .remove([filePath]);

        if (storageError) {
          // Não interrompe a operação se o arquivo já não existir
          console.warn("Aviso ao remover arquivo do storage:", storageError);
        }
      }
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["client_documents", variables.clientId] });
      toast.success("Documento excluído");
    },
    onError: (error) => {
      console.error("Erro ao excluir documento:", error);
      toast.error("Erro ao excluir documento");
    },
  });
}


// Hook para baixar/visualizar documento com URL assinada
export function useDocumentUrl() {
  return useMutation({
    mutationFn: async (url: string): Promise<string> => {
      const filePath = extractFilePath(url);
      
      if (!filePath) {
        throw new Error("Caminho do arquivo inválido");
      }

      const signedUrl = await getSignedUrl(filePath);
      
      if (!signedUrl) {
        throw new Error("Não foi possível gerar URL de acesso");
      }

      return signedUrl;
    },
  });
}

// Helper para formatar tamanho do arquivo
export function formatFileSize(bytes: number | null): string {
  if (!bytes) return "0 B";
  const units = ['B', 'KB', 'MB', 'GB'];
  let unitIndex = 0;
  let size = bytes;
  
  while (size >= 1024 && unitIndex < units.length - 1) {
    size /= 1024;
    unitIndex++;
  }
  
  return `${size.toFixed(1)} ${units[unitIndex]}`;
}