import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { parseISO, isBefore, startOfMonth } from "date-fns";
import { toast } from "sonner";
import { resolvePolicyPaymentInfo } from "@/lib/commissionUtils";
import { safeParseMetadata } from "@/hooks/useClients";

export type ComissaoStatus = 'prevista' | 'recebida' | 'atrasada' | 'estornada';
export type TipoLancamento = 'receita_padrao' | 'ajuste_manual' | 'bonus';

export interface ComissaoCalculada {
  id: string;
  isVirtual?: boolean;
  apoliceId: string;
  client_id: string;
  term_id: string | null;
  numeroApolice: string;
  clienteNome: string;
  produtoNome: string;
  produtoCategoria: string;
  seguradora: string;
  valorPremio: number;
  percentualComissao: number | null;
  comissaoPrevista: number;
  comissaoRecebida: number;
  competencia: string; // "YYYY-MM"
  competencia_ano: number;
  competencia_mes: number;
  status: ComissaoStatus;
  tipo_lancamento: TipoLancamento;
  data_recebimento: string | null;
  created_at: string;
}

export function useComissoes() {
  return useQuery({
    queryKey: ["comissoes_entries"],
    queryFn: async () => {
      // Fetch explicit commissions, active policies, client commission terms, and client metadata
      const [comissoesRes, apolicesRes, termsRes, clientsRes] = await Promise.all([
        supabase
          .from("comissoes" as any)
          .select(`
            *,
            apolices (id, numero_apolice, seguradora, valor_premio, data_inicio, produto_id, produtos (id, nome, categoria)),
            clients (id, nome)
          `)
          .order("created_at", { ascending: false }),

        supabase
          .from("apolices")
          .select(`
            id,
            client_id,
            numero_apolice,
            seguradora,
            valor_premio,
            data_inicio,
            data_fim,
            forma_pagamento,
            parcelas,
            observacoes,
            status,
            produtos (id, nome, categoria, comissao_percentual),
            clients (id, nome)
          `)
          .in("status", ["ativa", "em_renovacao", "renovada"])
          .is("deleted_at", null),

        supabase
          .from("client_commission_terms")
          .select("client_id, produto_id, percent, fixed_amount, model, is_active")
          .eq("is_active", true),

        supabase
          .from("clients")
          .select("id, observacoes")
          .is("deleted_at", null),
      ]);

      const clientMetaMap = new Map<string, any>();
      (clientsRes.data || []).forEach((cl: any) => {
        if (cl.id) clientMetaMap.set(cl.id, safeParseMetadata(cl.observacoes));
      });

      const activeCommissions = termsRes.data || [];
      const dbComissoes = comissoesRes.data || [];
      const activeApolices = apolicesRes.data || [];

      const result: ComissaoCalculada[] = [];
      const existingKeys = new Set<string>(); // `${apolice_id}-${YYYY-MM}`

      // 1. Process explicit records from the comissoes table
      for (const item of dbComissoes) {
        const ano = Number(item.competencia_ano);
        const mes = Number(item.competencia_mes);
        const compStr = `${ano}-${String(mes).padStart(2, '0')}`;
        const key = `${item.apolice_id}-${compStr}`;
        existingKeys.add(key);

        result.push({
          id: item.id,
          isVirtual: false,
          apoliceId: item.apolice_id,
          client_id: item.client_id,
          term_id: item.term_id,
          numeroApolice: item.apolices?.numero_apolice || "—",
          clienteNome: item.clients?.nome || "—",
          produtoNome: item.apolices?.produtos?.nome || "—",
          produtoCategoria: item.apolices?.produtos?.categoria || item.apolices?.produtos?.nome || "Outros",
          seguradora: item.apolices?.seguradora || "—",
          valorPremio: Number(item.valor_base_premio) || Number(item.apolices?.valor_premio) || 0,
          percentualComissao: item.percentual_aplicado !== null ? Number(item.percentual_aplicado) : null,
          comissaoPrevista: Number(item.valor_comissao) || 0,
          comissaoRecebida: item.status === 'recebida' ? (Number(item.valor_comissao) || 0) : 0,
          competencia: compStr,
          competencia_ano: ano,
          competencia_mes: mes,
          status: item.status as ComissaoStatus,
          tipo_lancamento: item.tipo_lancamento as TipoLancamento,
          data_recebimento: item.data_recebimento,
          created_at: item.created_at,
        });
      }

      // 2. Generate scheduled installments for active policies that don't have explicit records yet
      const today = new Date();
      const currentMonthStart = startOfMonth(today);

      for (const ap of activeApolices) {
        const clientMeta = ap.client_id ? clientMetaMap.get(ap.client_id) : null;
        const payInfo = resolvePolicyPaymentInfo(ap, activeCommissions, clientMeta);
        const parcelas = payInfo.parcelas || 1;

        let startDate = today;
        if (ap.data_inicio) {
          const parsed = parseISO(ap.data_inicio);
          if (!isNaN(parsed.getTime())) startDate = parsed;
        }

        for (let i = 0; i < parcelas; i++) {
          const installmentDate = new Date(startDate.getFullYear(), startDate.getMonth() + i, 1);
          const iAno = installmentDate.getFullYear();
          const iMes = installmentDate.getMonth() + 1;
          const compStr = `${iAno}-${String(iMes).padStart(2, '0')}`;
          const key = `${ap.id}-${compStr}`;

          if (!existingKeys.has(key)) {
            const isPast = isBefore(installmentDate, currentMonthStart);
            const status: ComissaoStatus = isPast ? 'atrasada' : 'prevista';

            result.push({
              id: `virtual-${ap.id}-${compStr}`,
              isVirtual: true,
              apoliceId: ap.id,
              client_id: ap.client_id,
              term_id: null,
              numeroApolice: ap.numero_apolice || "—",
              clienteNome: (ap.clients as any)?.nome || "—",
              produtoNome: (ap.produtos as any)?.nome || "—",
              produtoCategoria: (ap.produtos as any)?.categoria || (ap.produtos as any)?.nome || "Outros",
              seguradora: ap.seguradora || "—",
              valorPremio: payInfo.valor_premio_parcela,
              percentualComissao: payInfo.percentual,
              comissaoPrevista: payInfo.valor_comissao_parcela,
              comissaoRecebida: 0,
              competencia: compStr,
              competencia_ano: iAno,
              competencia_mes: iMes,
              status,
              tipo_lancamento: 'receita_padrao',
              data_recebimento: null,
              created_at: (ap as any).created_at || new Date().toISOString(),
            });
          }
        }
      }

      // Sort by competencia descending, then client name
      result.sort((a, b) => b.competencia.localeCompare(a.competencia) || a.clienteNome.localeCompare(b.clienteNome));

      return result;
    },
  });
}

export function useClientComissoes(clientId: string) {
  return useQuery({
    queryKey: ["comissoes_entries", clientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("comissoes")
        .select(`
          *,
          apolices (numero_apolice, produtos (nome))
        `)
        .eq("client_id", clientId)
        .order("competencia_ano", { ascending: false })
        .order("competencia_mes", { ascending: false });

      if (error) throw error;

      return (data || []).map(item => ({
        id: item.id,
        apoliceId: item.apolice_id,
        numeroApolice: item.apolices?.numero_apolice || "—",
        produtoNome: item.apolices?.produtos?.nome || "—",
        valorPremio: item.valor_base_premio,
        percentualComissao: item.percentual_aplicado,
        valorComissao: item.valor_comissao,
        competencia: `${item.competencia_ano}-${String(item.competencia_mes).padStart(2, '0')}`,
        status: item.status as ComissaoStatus,
        tipo_lancamento: item.tipo_lancamento as TipoLancamento,
        data_recebimento: item.data_recebimento,
        created_at: item.created_at
      }));
    },
    enabled: !!clientId
  });
}

export function useCreateComissaoEntry() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: {
      apolice_id: string;
      client_id: string;
      term_id?: string | null;
      valor_base_premio: number;
      percentual_aplicado?: number | null;
      valor_comissao: number;
      tipo_lancamento: 'receita_padrao' | 'ajuste_manual' | 'bonus';
      competencia_mes: number;
      competencia_ano: number;
      status: 'prevista' | 'recebida';
    }) => {
      const { data: entry, error } = await supabase
        .from("comissoes")
        .insert(data)
        .select()
        .single();

      if (error) throw error;
      return entry;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["comissoes_entries", variables.client_id] });
      queryClient.invalidateQueries({ queryKey: ["comissoes_entries"] });
      queryClient.invalidateQueries({ queryKey: ["financeiro-dashboard"] });
      toast.success("Lançamento de comissão registrado");
    },
    onError: (error) => {
      console.error("Erro ao criar lançamento:", error);
      toast.error("Erro ao registrar lançamento");
    }
  });
}

export function useMarkComissaoRecebida() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (item: ComissaoCalculada) => {
      const receiptDate = new Date().toISOString().split("T")[0];

      if (item.isVirtual || item.id.startsWith("virtual-")) {
        // Insert newly received commission into public.comissoes
        const { data, error } = await supabase
          .from("comissoes" as any)
          .insert({
            apolice_id: item.apoliceId,
            client_id: item.client_id,
            term_id: item.term_id || null,
            competencia_mes: item.competencia_mes,
            competencia_ano: item.competencia_ano,
            valor_base_premio: item.valorPremio,
            valor_comissao: item.comissaoPrevista,
            percentual_aplicado: item.percentualComissao || null,
            status: "recebida",
            tipo_lancamento: item.tipo_lancamento || "receita_padrao",
            data_recebimento: receiptDate,
          })
          .select()
          .single();

        if (error) throw error;
        return data;
      } else {
        // Update existing record
        const { data, error } = await supabase
          .from("comissoes" as any)
          .update({
            status: "recebida",
            data_recebimento: receiptDate,
          })
          .eq("id", item.id)
          .select()
          .single();

        if (error) throw error;
        return data;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["comissoes_entries"] });
      queryClient.invalidateQueries({ queryKey: ["financeiro-dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["client_commission_history"] });
      toast.success("Comissão marcada como recebida!");
    },
    onError: (error: any) => {
      console.error("Erro ao dar baixa na comissão:", error);
      toast.error("Erro ao registrar recebimento: " + (error?.message || ""));
    },
  });
}

export function useRevertComissaoStatus() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (item: ComissaoCalculada) => {
      if (item.isVirtual) return;

      const { data, error } = await supabase
        .from("comissoes" as any)
        .update({
          status: "prevista",
          data_recebimento: null,
        })
        .eq("id", item.id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["comissoes_entries"] });
      queryClient.invalidateQueries({ queryKey: ["financeiro-dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["client_commission_history"] });
      toast.success("Status revertido para prevista.");
    },
    onError: (error: any) => {
      console.error("Erro ao reverter comissão:", error);
      toast.error("Erro ao reverter status: " + (error?.message || ""));
    },
  });
}

export function useComissoesPeriodos() {
  const { data: comissoes } = useComissoes();
  
  // Extract unique periods from commissions
  const periodos = Array.from(
    new Set(comissoes?.map(c => c.competencia) || [])
  ).sort().reverse();

  return periodos;
}

export function useComissoesProdutos() {
  const { data: comissoes } = useComissoes();
  
  // Extract unique products from commissions
  const produtos = Array.from(
    new Set(comissoes?.map(c => c.produtoCategoria) || [])
  ).sort();

  return produtos;
}
