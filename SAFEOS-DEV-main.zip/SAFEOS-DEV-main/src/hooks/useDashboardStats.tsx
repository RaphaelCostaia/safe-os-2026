import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { differenceInDays } from "date-fns";

export interface DashboardStats {
  // Clients
  totalClients: number;
  activeClients: number;
  newClientsThisMonth: number;
  
  // Policies
  totalPolicies: number;
  activePolicies: number;
  totalPremium: number;
  
  // Renewals
  pendingRenewals: number;
  criticalRenewals: number;
  renewalSuccessRate: number;
  
  // Claims
  openClaims: number;
  criticalClaims: number;
  totalClaimValue: number;
}

export function useDashboardStats() {
  return useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: async (): Promise<DashboardStats> => {
      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
      
      // Fetch all data in parallel (excluding archived/soft-deleted records)
      const [
        clientsResult,
        policiesResult,
        renewalsResult,
        sinistrosResult,
      ] = await Promise.all([
        supabase.from("clients").select("id, status, created_at").is("deleted_at", null),
        supabase.from("apolices").select("id, status, valor_premio, data_fim").is("deleted_at", null),
        supabase.from("renovacoes").select("id, status, data_vencimento"),
        supabase.from("sinistros").select("id, status, criticidade, valor_estimado").is("deleted_at", null),
      ]);

      const clients = clientsResult.data || [];
      const policies = policiesResult.data || [];
      const renewals = renewalsResult.data || [];
      const sinistros = sinistrosResult.data || [];

      // Calculate client stats
      const totalClients = clients.length;
      const activeClients = clients.filter(c => c.status === "ativo").length;
      const newClientsThisMonth = clients.filter(c => 
        new Date(c.created_at) >= new Date(startOfMonth)
      ).length;

      // Calculate policy stats
      const totalPolicies = policies.length;
      const activePolicies = policies.filter(p => p.status === "ativa").length;
      const totalPremium = policies
        .filter(p => p.status === "ativa")
        .reduce((sum, p) => sum + (p.valor_premio || 0), 0);

      // Calculate renewal stats
      const pendingRenewals = renewals.filter(r => r.status === "pendente").length;
      const criticalRenewals = renewals.filter(r => {
        if (r.status === "renovado" || r.status === "cancelado") return false;
        const daysUntil = differenceInDays(new Date(r.data_vencimento), now);
        return daysUntil <= 7 && daysUntil >= 0;
      }).length;
      const completedRenewals = renewals.filter(r => r.status === "renovado").length;
      const lostRenewals = renewals.filter(r => r.status === "cancelado").length;
      const renewalSuccessRate = completedRenewals + lostRenewals > 0 
        ? (completedRenewals / (completedRenewals + lostRenewals)) * 100 
        : 100;

      // Calculate claims stats
      const openStatuses = ["aberto", "em_andamento", "aguardando_cliente", "aguardando_seguradora"];
      const openClaims = sinistros.filter(s => openStatuses.includes(s.status)).length;
      const criticalClaims = sinistros.filter(s => 
        s.criticidade === "critica" && openStatuses.includes(s.status)
      ).length;
      const totalClaimValue = sinistros.reduce((sum, s) => sum + (s.valor_estimado || 0), 0);

      return {
        totalClients,
        activeClients,
        newClientsThisMonth,
        totalPolicies,
        activePolicies,
        totalPremium,
        pendingRenewals,
        criticalRenewals,
        renewalSuccessRate,
        openClaims,
        criticalClaims,
        totalClaimValue,
      };
    },
  });
}

export function useRecentActivity() {
  return useQuery({
    queryKey: ["recent-activity"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("activity_log")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(10);
      
      if (error) throw error;
      return data;
    },
  });
}
