import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useEffect } from "react";
import { format, subMonths, startOfMonth, endOfMonth, parseISO, isBefore, differenceInDays } from "date-fns";
import { calculatePolicyCommission, calculatePolicyCommissionForMonth } from "@/lib/commissionUtils";
import { safeParseMetadata } from "@/hooks/useClients";

export interface FinanceiroKPIsData {
  receitaRecorrenteMensal: number;
  receitaRecorrenteAnual: number;
  totalPremioEmitido: number;
  premioMensalEquivalente: number;
  comissoesPrevistasMes: number;
  comissoesRecebidasMes: number;
  custosFixosMes: number;
  resultadoOperacional: number;
  totalApolicesAtivas: number;
  contasVencidas: number;
  contasVencer7Dias: number;
  totalContasVencidas: number;
  totalContasVencer7: number;
}

export interface TendenciaMensal {
  mes: string;
  mesLabel: string;
  receitaEstimada: number;
  custos: number;
  resultado: number;
  premioEmitido?: number;
}

export interface AlertaFinanceiro {
  id: string;
  tipo: 'vencida' | 'vencer_7' | 'vencer_15' | 'vencer_30' | 'queda_receita';
  titulo: string;
  quantidade?: number;
  valor?: number;
}

export function useFinanceiroRealtime() {
  const queryClient = useQueryClient();

  // Main data query
  const query = useQuery({
    queryKey: ["financeiro-dashboard"],
    queryFn: async () => {
      try {
        const hoje = new Date();
        const inicioMes = startOfMonth(hoje);
        const fimMes = endOfMonth(hoje);
        const em7Dias = new Date(hoje.getTime() + 7 * 24 * 60 * 60 * 1000);

        // Parallel queries for all data with defensive wrappers
        const [
          apolicesResult,
          custosFixosResult,
          contasResult,
          produtosResult,
          commissionsResult,
          clientsResult,
          comissoesResult,
        ] = await Promise.all([
          // Active policies with payment methods, installments, and metadata
          (async () => {
            try {
              const { data, error } = await supabase
                .from("apolices")
                .select(`
                  id,
                  client_id,
                  valor_premio,
                  data_inicio,
                  data_fim,
                  status,
                  forma_pagamento,
                  parcelas,
                  observacoes,
                  produto_id,
                  produtos(comissao_percentual)
                `)
                .in('status', ['ativa', 'em_renovacao', 'renovada'])
                .is("deleted_at", null);
              if (error) throw error;
              return { data, error: null };
            } catch (err) {
              console.warn("useFinanceiroRealtime: apolices query with relation failed, trying simple query:", err);
              try {
                const { data, error } = await supabase
                  .from("apolices")
                  .select("id, client_id, valor_premio, data_inicio, data_fim, status, produto_id, forma_pagamento, parcelas, observacoes")
                  .in('status', ['ativa', 'em_renovacao', 'renovada'])
                  .is("deleted_at", null);
                if (error) throw error;
                return { data, error: null };
              } catch (innerErr) {
                console.error("Critical: failed to fetch apolices in useFinanceiroRealtime:", innerErr);
                return { data: [], error: innerErr };
              }
            }
          })(),

          // Fixed costs
          (async () => {
            try {
              const { data, error } = await supabase
                .from("custos_fixos")
                .select("*")
                .eq("status", "ativo");
              if (error) throw error;
              return { data, error: null };
            } catch (err) {
              console.error("useFinanceiroRealtime: Fallback for custos_fixos:", err);
              return { data: [], error: err };
            }
          })(),

          // All accounts
          (async () => {
            try {
              const { data, error } = await supabase
                .from("contas")
                .select("*");
              if (error) throw error;
              return { data, error: null };
            } catch (err) {
              console.error("useFinanceiroRealtime: Fallback for contas:", err);
              return { data: [], error: err };
            }
          })(),

          // Products for commission rates
          (async () => {
            try {
              const { data, error } = await supabase
                .from("produtos")
                .select("id, comissao_percentual");
              if (error) throw error;
              return { data, error: null };
            } catch (err) {
              console.error("useFinanceiroRealtime: Fallback for produtos:", err);
              return { data: [], error: err };
            }
          })(),

          // Client commission terms
          (async () => {
            try {
              const { data, error } = await supabase
                .from("client_commission_terms")
                .select("client_id, produto_id, percent, fixed_amount, model, is_active")
                .eq("is_active", true);
              if (error) throw error;
              return { data, error: null };
            } catch (err) {
              console.warn("useFinanceiroRealtime: Fallback query without extra columns:", err);
              try {
                const { data, error } = await supabase
                  .from("client_commission_terms")
                  .select("client_id, percent, is_active")
                  .eq("is_active", true);
                if (error) throw error;
                const mapped = (data || []).map(item => ({
                  ...item,
                  produto_id: null,
                  model: 'percentual',
                  fixed_amount: null,
                }));
                return { data: mapped, error: null };
              } catch (innerErr) {
                console.error("Critical: failed to fetch commission terms in useFinanceiroRealtime:", innerErr);
                return { data: [], error: innerErr };
              }
            }
          })(),

          // Clients to parse preferred payment terms
          (async () => {
            try {
              const { data, error } = await supabase
                .from("clients")
                .select("id, observacoes")
                .is("deleted_at", null);
              if (error) throw error;
              return { data, error: null };
            } catch (err) {
              console.warn("useFinanceiroRealtime: clients query fallback:", err);
              return { data: [], error: err };
            }
          })(),

          // Explicit commission entries from public.comissoes
          (async () => {
            try {
              const { data, error } = await supabase
                .from("comissoes" as any)
                .select("*");
              if (error) throw error;
              return { data: data || [], error: null };
            } catch (err) {
              console.warn("useFinanceiroRealtime: Fallback for comissoes:", err);
              return { data: [], error: err };
            }
          })(),
        ]);

        const apolices = (apolicesResult?.data || []).filter((ap: any) => ap && typeof ap === 'object');
        const custosFixos = (custosFixosResult?.data || []).filter((c: any) => c && typeof c === 'object');
        const contas = (contasResult?.data || []).filter((c: any) => c && typeof c === 'object');
        const commissions = (commissionsResult?.data || []).filter((t: any) => t && typeof t === 'object');
        const produtos = (produtosResult?.data || []).filter((p: any) => p && typeof p === 'object');
        const clients = (clientsResult?.data || []).filter((cl: any) => cl && typeof cl === 'object');
        const comissoesTable = (comissoesResult?.data || []).filter((c: any) => c && typeof c === 'object');

        // Build client metadata map for payment preferences
        const clientMetaMap = new Map<string, any>();
        clients.forEach((cl: any) => {
          if (cl.id) {
            clientMetaMap.set(cl.id, safeParseMetadata(cl.observacoes));
          }
        });

        // 1. Total Insurance Premium Issued (Prêmio Emitido das Apólices Ativas)
        const totalPremioEmitido = apolices.reduce((sum, ap) => {
          return sum + (Number(ap.valor_premio) || 0);
        }, 0);

        const premioMensalEquivalente = totalPremioEmitido / 12;

        // 2. Annual Commission Revenue (Receita Anual de Comissões da Corretora)
        const totalComissaoAnual = apolices.reduce((sum, ap) => {
          const clientMeta = ap.client_id ? clientMetaMap.get(ap.client_id) : null;
          const comm = calculatePolicyCommission(ap, commissions, clientMeta);
          return sum + comm.valor;
        }, 0);

        // 3. Monthly Commission Calculations (Previstas vs Recebidas)
        let comissoesPrevistasMes = 0;
        let comissoesRecebidasMes = 0;
        const currentMonth = hoje.getMonth() + 1;
        const currentYear = hoje.getFullYear();
        const apolicesProcessadasMes = new Set<string>();

        // Process explicit commission entries from the comissoes table
        comissoesTable.forEach((item: any) => {
          const cAno = Number(item.competencia_ano);
          const cMes = Number(item.competencia_mes);
          const valor = Number(item.valor_comissao) || 0;
          const isCurrentCompetencia = cAno === currentYear && cMes === currentMonth;

          let isRecebidaEsteMes = false;
          if (item.status === 'recebida') {
            if (item.data_recebimento) {
              try {
                const recDate = parseISO(item.data_recebimento);
                if (!isNaN(recDate.getTime()) && recDate.getFullYear() === currentYear && recDate.getMonth() + 1 === currentMonth) {
                  isRecebidaEsteMes = true;
                }
              } catch (e) {
                // ignore date parse error
              }
            }
            if (isCurrentCompetencia) {
              isRecebidaEsteMes = true;
            }
          }

          if (isRecebidaEsteMes) {
            comissoesRecebidasMes += valor;
            if (item.apolice_id) apolicesProcessadasMes.add(item.apolice_id);
          } else if (isCurrentCompetencia && (item.status === 'prevista' || item.status === 'atrasada')) {
            comissoesPrevistasMes += valor;
            if (item.apolice_id) apolicesProcessadasMes.add(item.apolice_id);
          }
        });

        // For active policies that do not have explicit records in comissoes table for this month, calculate scheduled installments
        apolices.forEach((ap) => {
          if (apolicesProcessadasMes.has(ap.id)) return;

          const clientMeta = ap.client_id ? clientMetaMap.get(ap.client_id) : null;
          const monthCalc = calculatePolicyCommissionForMonth(ap, hoje, commissions, clientMeta);

          if (monthCalc.isScheduled && monthCalc.comissao > 0) {
            comissoesPrevistasMes += monthCalc.comissao;
          }
        });

        // If no scheduled installments in this specific month (e.g. sample policies start in future/past),
        // use the monthly equivalent of annual commission so the broker's active portfolio MRR is represented accurately
        const receitaRecorrenteMensal = comissoesPrevistasMes > 0 
          ? comissoesPrevistasMes 
          : (totalComissaoAnual / 12);

        // Monthly Fixed Costs
        const custosFixosMes = custosFixos.reduce((sum, c) => {
          try {
            if (c.recorrencia === 'mensal') return sum + (c.valor || 0);
            if (c.recorrencia === 'anual') return sum + ((c.valor || 0) / 12);
            if (c.recorrencia === 'trimestral') return sum + ((c.valor || 0) / 3);
            return sum;
          } catch (e) {
            console.warn("useFinanceiroRealtime: error processing custosFixos in loop", c, e);
            return sum;
          }
        }, 0);

        // Accounts payable & overdue
        const contasVencidasData = contas.filter(c => {
          try {
            if (c.status === 'pago') return false;
            if (!c.vencimento) return false;
            const vencimento = parseISO(c.vencimento);
            if (isNaN(vencimento.getTime())) return false;
            return isBefore(vencimento, hoje);
          } catch (e) {
            console.warn("useFinanceiroRealtime: error parsing conta vencimento date", c.vencimento, e);
            return false;
          }
        });

        const contasVancer7Data = contas.filter(c => {
          try {
            if (c.status === 'pago') return false;
            if (!c.vencimento) return false;
            const vencimento = parseISO(c.vencimento);
            if (isNaN(vencimento.getTime())) return false;
            return !isBefore(vencimento, hoje) && isBefore(vencimento, em7Dias);
          } catch (e) {
            console.warn("useFinanceiroRealtime: error parsing conta vencimento date", c.vencimento, e);
            return false;
          }
        });

        const kpis: FinanceiroKPIsData = {
          receitaRecorrenteMensal,
          receitaRecorrenteAnual: totalComissaoAnual,
          totalPremioEmitido,
          premioMensalEquivalente,
          comissoesPrevistasMes: comissoesPrevistasMes > 0 ? comissoesPrevistasMes : receitaRecorrenteMensal,
          comissoesRecebidasMes,
          custosFixosMes,
          resultadoOperacional: receitaRecorrenteMensal - custosFixosMes,
          totalApolicesAtivas: apolices.length,
          contasVencidas: contasVencidasData.length,
          contasVencer7Dias: contasVancer7Data.length,
          totalContasVencidas: contasVencidasData.reduce((sum, c) => sum + (c.valor || 0), 0),
          totalContasVencer7: contasVencer7Data.reduce((sum, c) => sum + (c.valor || 0), 0),
        };

        // Generate alerts
        const alertas: AlertaFinanceiro[] = [];

        if (contasVencidasData.length > 0) {
          alertas.push({
            id: 'vencidas',
            tipo: 'vencida',
            titulo: 'Contas vencidas',
            quantidade: contasVencidasData.length,
            valor: contasVencidasData.reduce((sum, c) => sum + (c.valor || 0), 0),
          });
        }

        if (contasVancer7Data.length > 0) {
          alertas.push({
            id: 'vencer-7',
            tipo: 'vencer_7',
            titulo: 'Vencem em 7 dias',
            quantidade: contasVancer7Data.length,
            valor: contasVancer7Data.reduce((sum, c) => sum + (c.valor || 0), 0),
          });
        }

        // Generate trend data for last 12 months (deterministic based on real commissions and payments)
        const tendencia: TendenciaMensal[] = [];
        for (let i = 11; i >= 0; i--) {
          const mesData = subMonths(hoje, i);
          const mesKey = format(mesData, 'yyyy-MM');
          const mesLabel = format(mesData, 'MMM/yy');

          let comissoesMes = 0;
          let premioMes = 0;

          apolices.forEach((ap) => {
            const clientMeta = ap.client_id ? clientMetaMap.get(ap.client_id) : null;
            const monthCalc = calculatePolicyCommissionForMonth(ap, mesData, commissions, clientMeta);
            if (monthCalc.isScheduled) {
              comissoesMes += monthCalc.comissao;
              premioMes += monthCalc.premio;
            }
          });

          // Fallback to monthly average if no specific month matches were calculated
          if (comissoesMes === 0 && totalComissaoAnual > 0) {
            comissoesMes = totalComissaoAnual / 12;
            premioMes = totalPremioEmitido / 12;
          }

          const custosMes = custosFixos.reduce((sum, c) => {
            try {
              if (c.recorrencia === 'mensal') return sum + (c.valor || 0);
              if (c.recorrencia === 'anual') return sum + ((c.valor || 0) / 12);
              if (c.recorrencia === 'trimestral') return sum + ((c.valor || 0) / 3);
              return sum;
            } catch (e) {
              console.warn("useFinanceiroRealtime: error in custosMes reduce for trend", c, e);
              return sum;
            }
          }, 0);

          tendencia.push({
            mes: mesKey,
            mesLabel,
            receitaEstimada: Math.round(comissoesMes) || 0,
            custos: Math.round(custosMes) || 0,
            resultado: Math.round(comissoesMes - custosMes) || 0,
            premioEmitido: Math.round(premioMes) || 0,
          });
        }

        return { kpis, alertas, tendencia };
      } catch (err) {
        console.error("CRITICAL ERROR IN useFinanceiroRealtime queryFn:", err);
        return {
          kpis: {
            receitaRecorrenteMensal: 0,
            receitaRecorrenteAnual: 0,
            totalPremioEmitido: 0,
            premioMensalEquivalente: 0,
            comissoesPrevistasMes: 0,
            comissoesRecebidasMes: 0,
            custosFixosMes: 0,
            resultadoOperacional: 0,
            totalApolicesAtivas: 0,
            contasVencidas: 0,
            contasVencer7Dias: 0,
            totalContasVencidas: 0,
            totalContasVencer7: 0,
          },
          alertas: [],
          tendencia: [],
        };
      }
    },
    staleTime: 30000, // 30 seconds
    refetchInterval: 60000, // Refetch every minute
  });

  // Subscribe to real-time updates
  useEffect(() => {
    // We use a unique ID for each hook instance to avoid channel name collisions
    // which cause the "cannot add callbacks after subscribe" error
    const instanceId = Math.random().toString(36).substring(7);
    
    const channels = [
      supabase
        .channel(`financeiro-apolices-${instanceId}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'apolices' }, () => {
          queryClient.invalidateQueries({ queryKey: ["financeiro-dashboard"] });
        })
        .subscribe(),

      supabase
        .channel(`financeiro-custos-${instanceId}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'custos_fixos' }, () => {
          queryClient.invalidateQueries({ queryKey: ["financeiro-dashboard"] });
        })
        .subscribe(),

      supabase
        .channel(`financeiro-contas-${instanceId}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'contas' }, () => {
          queryClient.invalidateQueries({ queryKey: ["financeiro-dashboard"] });
        })
        .subscribe(),

      supabase
        .channel(`financeiro-comissoes-${instanceId}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'comissoes' }, () => {
          queryClient.invalidateQueries({ queryKey: ["financeiro-dashboard"] });
        })
        .subscribe(),
    ];

    return () => {
      channels.forEach(channel => {
        supabase.removeChannel(channel);
      });
    };
  }, [queryClient]);

  return query;
}
