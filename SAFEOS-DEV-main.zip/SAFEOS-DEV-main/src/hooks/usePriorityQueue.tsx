import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { differenceInDays } from "date-fns";
import { useAuth } from "@/hooks/useAuth";

export type PriorityLevel = "critica" | "alta" | "media" | "baixa";
export type PriorityItemType = "renovacao" | "financeiro" | "tarefa" | "sinistro";

export interface PriorityItem {
  id: string;
  type: PriorityItemType;
  title: string;
  description: string;
  priority: PriorityLevel;
  dueDate: string;
  daysRemaining: number;
  responsavel?: string;
  metadata?: {
    clientName?: string;
    value?: number;
    status?: string;
    manualPriority?: string;
  };
}

function calculatePriority(
  daysRemaining: number, 
  type: PriorityItemType, 
  isOverdue: boolean,
  manualPriority?: string
): PriorityLevel {
  // For tasks, use manual priority but bump up if overdue
  if (type === "tarefa" && manualPriority) {
    const basePriority = manualPriority as PriorityLevel;
    if (isOverdue && basePriority !== "critica") {
      if (basePriority === "baixa") return "media";
      if (basePriority === "media") return "alta";
      if (basePriority === "alta") return "critica";
    }
    return basePriority;
  }

  if (type === "sinistro") {
    if (manualPriority === "urgente" || manualPriority === "alta") return "critica";
    return "alta";
  }
  
  if (isOverdue) return "critica";
  
  if (type === "financeiro") {
    if (daysRemaining <= 2) return "alta";
    if (daysRemaining <= 7) return "media";
    return "baixa";
  }
  
  if (type === "renovacao") {
    if (daysRemaining <= 7) return "critica";
    if (daysRemaining <= 14) return "alta";
    if (daysRemaining <= 30) return "media";
    return "baixa";
  }
  
  return "media";
}

export function usePriorityQueue(limit: number = 20) {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["priority_queue", limit, user?.id],
    queryFn: async (): Promise<PriorityItem[]> => {
      const now = new Date();
      const items: PriorityItem[] = [];

      // Fetch renovations with policy details
      const { data: renovacoes } = await supabase
        .from("renovacoes")
        .select(`
          id,
          data_vencimento,
          status,
          observacoes,
          apolices (
            numero_apolice,
            seguradora,
            valor_premio,
            clients (nome)
          )
        `)
        .in("status", ["pendente", "em_andamento", "aguardando_cliente"])
        .order("data_vencimento", { ascending: true })
        .limit(limit);

      if (renovacoes) {
        for (const r of renovacoes) {
          const dueDate = new Date(r.data_vencimento);
          const daysRemaining = differenceInDays(dueDate, now);
          const isOverdue = daysRemaining < 0;
          
          items.push({
            id: r.id,
            type: "renovacao",
            title: `Renovação - ${r.apolices?.numero_apolice || "Apólice"}`,
            description: r.apolices?.clients?.nome || "Cliente",
            priority: calculatePriority(daysRemaining, "renovacao", isOverdue),
            dueDate: r.data_vencimento,
            daysRemaining,
            metadata: {
              clientName: r.apolices?.clients?.nome,
              value: r.apolices?.valor_premio,
              status: r.status,
            },
          });
        }
      }

      // Fetch financial accounts
      const { data: contas } = await supabase
        .from("contas")
        .select(`
          id,
          descricao,
          categoria,
          tipo,
          valor,
          vencimento,
          status,
          clients (nome)
        `)
        .in("status", ["pendente", "atrasado"])
        .order("vencimento", { ascending: true })
        .limit(limit);

      if (contas) {
        for (const c of contas) {
          const dueDate = new Date(c.vencimento);
          const daysRemaining = differenceInDays(dueDate, now);
          const isOverdue = daysRemaining < 0;
          
          items.push({
            id: c.id,
            type: "financeiro",
            title: `${c.tipo === "pagar" ? "A Pagar" : "A Receber"} - ${c.categoria}`,
            description: c.descricao,
            priority: calculatePriority(daysRemaining, "financeiro", isOverdue),
            dueDate: c.vencimento,
            daysRemaining,
            metadata: {
              clientName: c.clients?.nome,
              value: c.valor,
              status: c.status,
            },
          });
        }
      }

      // Fetch pending tasks for the current user
      if (user?.id) {
        const { data: tasks } = await supabase
          .from("tasks")
          .select("id, titulo, descricao, prioridade, prazo, status")
          .eq("user_id", user.id)
          .eq("status", "pendente")
          .order("prazo", { ascending: true, nullsFirst: false })
          .limit(limit);

        if (tasks) {
          for (const task of tasks) {
            // Tasks without deadline: use a far future date for sorting
            const hasPrazo = !!task.prazo;
            const dueDate = hasPrazo ? new Date(task.prazo) : new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000);
            const daysRemaining = hasPrazo ? differenceInDays(dueDate, now) : 999;
            const isOverdue = hasPrazo && daysRemaining < 0;

            items.push({
              id: task.id,
              type: "tarefa",
              title: task.titulo,
              description: task.descricao || "Sem descrição",
              priority: calculatePriority(daysRemaining, "tarefa", isOverdue, task.prioridade),
              dueDate: task.prazo || "",
              daysRemaining: hasPrazo ? daysRemaining : 999,
              metadata: {
                status: task.status,
                manualPriority: task.prioridade,
              },
            });
          }
        }

        // Fetch open or critical claims
        const { data: sinistros } = await supabase
          .from("sinistros")
          .select(`
            id,
            numero_sinistro,
            descricao_resumida,
            status,
            criticidade,
            created_at,
            clients (nome)
          `)
          .in("status", ["aberto", "em_atendimento", "documentacao_pendente"])
          .order("created_at", { ascending: false })
          .limit(limit);

        if (sinistros) {
          for (const s of sinistros) {
            const createdAt = new Date(s.created_at);
            // For claims, "daysRemaining" could be days open (inverted for sorting logic)
            const daysOpen = differenceInDays(now, createdAt);
            
            items.push({
              id: s.id,
              type: "sinistro",
              title: `Sinistro - ${s.numero_sinistro}`,
              description: `${s.clients?.nome || "Cliente"} - ${s.descricao_resumida}`,
              priority: calculatePriority(0, "sinistro", false, s.criticidade),
              dueDate: s.created_at,
              daysRemaining: -daysOpen, // Negative means older, which is higher priority in this context
              metadata: {
                clientName: s.clients?.nome,
                status: s.status,
              },
            });
          }
        }
      }

      // Sort by priority and due date
      const priorityOrder: Record<PriorityLevel, number> = {
        critica: 0,
        alta: 1,
        media: 2,
        baixa: 3,
      };

      items.sort((a, b) => {
        const priorityDiff = priorityOrder[a.priority] - priorityOrder[b.priority];
        if (priorityDiff !== 0) return priorityDiff;
        return a.daysRemaining - b.daysRemaining;
      });

      return items.slice(0, limit);
    },
    refetchInterval: 60000, // Refresh every minute
  });
}
