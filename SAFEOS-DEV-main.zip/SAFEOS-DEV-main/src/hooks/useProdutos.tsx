import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/types";
import { toast } from "sonner";
import { invalidateEntityQueries } from "@/lib/queryInvalidation";
import { assertAffectedRows } from "@/lib/supabaseMutationUtils";

export type Produto = Tables<"produtos">;
export type ProdutoInsert = TablesInsert<"produtos">;
export type ProdutoUpdate = TablesUpdate<"produtos">;

export function useProdutos() {
  return useQuery({
    queryKey: ["produtos"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("produtos")
        .select("*")
        .order("categoria", { ascending: true });
      
      if (error) throw error;
      return data as Produto[];
    },
  });
}

export function useProduto(id: string) {
  return useQuery({
    queryKey: ["produtos", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("produtos")
        .select("*")
        .eq("id", id)
        .single();
      
      if (error) throw error;
      return data as Produto;
    },
    enabled: !!id,
  });
}

export function useCreateProduto() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (produto: ProdutoInsert) => {
      // Ensure organization_id is set to avoid RLS rejection
      const { data: { session } } = await supabase.auth.getSession();
      const currentUserId = session?.user?.id;
      let finalOrgId = (produto as any).organization_id;

      if (!finalOrgId && currentUserId) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("organization_id")
          .eq("id", currentUserId)
          .maybeSingle();

        if (profile?.organization_id) {
          finalOrgId = profile.organization_id;
        } else {
          const { data: orgs } = await supabase
            .from("organizations")
            .select("id")
            .order("created_at", { ascending: true })
            .limit(1);
          if (orgs && orgs.length > 0) {
            finalOrgId = orgs[0].id;
          }
        }
      }

      // Auto-generate clean unique code if missing
      const categoryPrefix = (produto.categoria || "PROD").toUpperCase().replace(/[^A-Z]/g, "").slice(0, 4) || "PROD";
      const generatedCode = produto.codigo?.trim() || `${categoryPrefix}-${Math.floor(1000 + Math.random() * 9000)}`;

      const payload: any = {
        ...produto,
        codigo: generatedCode,
        categoria: produto.categoria || "rcp",
        seguradora: produto.seguradora || "Porto Seguro",
        ativo: produto.ativo !== undefined ? produto.ativo : true,
      };

      if (finalOrgId) {
        payload.organization_id = finalOrgId;
      }

      const { data, error } = await supabase
        .from("produtos")
        .insert(payload)
        .select()
        .single();
      
      if (error) {
        // If code conflict, retry once with another unique suffix
        if (error.code === "23505" || error.message?.includes("duplicate")) {
          payload.codigo = `${categoryPrefix}-${Date.now().toString().slice(-5)}`;
          const { data: retryData, error: retryError } = await supabase
            .from("produtos")
            .insert(payload)
            .select()
            .single();
          if (retryError) throw retryError;
          return retryData;
        }
        throw error;
      }
      return data;
    },
    onSuccess: () => {
      invalidateEntityQueries(queryClient, "produtos");
      toast.success("Produto cadastrado com sucesso!");
    },
    onError: (error: Error & { code?: string }) => {
      // Tratamento específico de erros
      if (error.message?.includes("row-level security") || error.message?.includes("policy")) {
        toast.error("Sem permissão para criar produto. Apenas Admin ou Gestor podem criar produtos.");
      } else if (error.message?.includes("duplicate") || error.code === "23505") {
        toast.error("Código do produto já existe. Use outro código.");
      } else if (error.message?.includes("violates check constraint")) {
        toast.error("Dados inválidos. Verifique se a comissão está entre 0 e 100.");
      } else {
        toast.error("Erro ao criar produto: " + error.message);
      }
    },
  });
}

export function useUpdateProduto() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...produto }: ProdutoUpdate & { id: string }) => {
      const { data, error } = await supabase
        .from("produtos")
        .update(produto)
        .eq("id", id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      invalidateEntityQueries(queryClient, "produtos");
      toast.success("Produto atualizado com sucesso!");
    },
    onError: (error: Error & { code?: string }) => {
      if (error.message?.includes("row-level security") || error.message?.includes("policy")) {
        toast.error("Sem permissão para editar produto. Apenas Admin ou Gestor podem editar.");
      } else if (error.message?.includes("duplicate") || error.code === "23505") {
        toast.error("Código do produto já existe. Use outro código.");
      } else {
        toast.error("Erro ao atualizar produto: " + error.message);
      }
    },
  });
}

export function useDeleteProduto() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      // 1. Delete associated client_commission_terms first to prevent foreign key issues
      const { error: prepError } = await supabase
        .from("client_commission_terms")
        .delete()
        .eq("produto_id", id);
      
      if (prepError) {
        console.warn("Could not delete related client_commission_terms:", prepError.message);
      }

      // 2. Delete the product itself
      const { data, error, count } = await supabase
        .from("produtos")
        .delete({ count: "exact" })
        .eq("id", id)
        .select("id");
      
      if (error) throw error;

      assertAffectedRows(
         { count, data },
         "Falha ao excluir produto (permissão insuficiente ou registro não encontrado)"
      );
    },
    onMutate: async (id: string) => {
      await queryClient.cancelQueries({ queryKey: ["produtos"] });
      const previousProdutos = queryClient.getQueryData<Produto[]>(["produtos"]);
      
      if (previousProdutos) {
        queryClient.setQueryData<Produto[]>(
          ["produtos"],
          previousProdutos.filter(p => p.id !== id)
        );
      }
      
      return { previousProdutos };
    },
    onError: (error: Error & { code?: string }, _id, context) => {
      if (context?.previousProdutos) {
        queryClient.setQueryData(["produtos"], context.previousProdutos);
      }
      if (error.message?.includes("row-level security") || error.message?.includes("policy") || error.message?.includes("permissão")) {
        toast.error("Sem permissão para excluir produto. Apenas Admin pode excluir.");
      } else if (error.message?.includes("foreign key") || error.code === "23503") {
        toast.error("Produto está vinculado a apólices. Desative-o em vez de excluir.");
      } else {
        toast.error("Erro ao excluir produto: " + error.message);
      }
    },
    onSuccess: () => {
      toast.success("Produto excluído com sucesso!");
      invalidateEntityQueries(queryClient, "produtos");
    },
  });
}

/**
 * Resolve an existing product ID or create a new/fallback product on-the-fly.
 * Guarantees that an apolice/proposal can always be saved even if the user
 * did not pick a predefined product or left the product field blank.
 */
export async function resolveOrCreateProduto({
  produtoId,
  produtoNome,
  seguradora,
  comissao_percentual,
  organization_id,
}: {
  produtoId?: string | null;
  produtoNome?: string | null;
  seguradora?: string | null;
  comissao_percentual?: number | string | null;
  organization_id?: string | null;
}): Promise<{ id: string; nome: string; produto?: Produto }> {
  // 1. If a valid produtoId is already provided, check/return it
  if (produtoId && typeof produtoId === "string" && produtoId.trim()) {
    const { data: prod } = await supabase
      .from("produtos")
      .select("*")
      .eq("id", produtoId.trim())
      .maybeSingle();

    if (prod) {
      return { id: prod.id, nome: prod.nome, produto: prod };
    }
  }

  // Determine organization_id if not passed
  let finalOrgId = organization_id;
  if (!finalOrgId) {
    const { data: { session } } = await supabase.auth.getSession();
    const userId = session?.user?.id;
    if (userId) {
      const { data: profile } = await supabase
        .from("profiles")
        .select("organization_id")
        .eq("id", userId)
        .maybeSingle();
      if (profile?.organization_id) {
        finalOrgId = profile.organization_id;
      }
    }
  }

  const cleanNome = produtoNome?.trim();

  // 2. If user typed a custom product name
  if (cleanNome && cleanNome.length >= 2) {
    // Check if product with this name already exists (case-insensitive)
    const { data: matchedProds } = await supabase
      .from("produtos")
      .select("*")
      .ilike("nome", cleanNome)
      .limit(1);

    if (matchedProds && matchedProds.length > 0) {
      return { id: matchedProds[0].id, nome: matchedProds[0].nome, produto: matchedProds[0] };
    }

    // Infer category
    const lower = cleanNome.toLowerCase();
    let cat = "rcp";
    if (lower.includes("dit") || lower.includes("incapacidade") || lower.includes("diaria") || lower.includes("diária")) cat = "dit";
    else if (lower.includes("vida") || lower.includes("morte") || lower.includes("invalidez")) cat = "vida";
    else if (lower.includes("saude") || lower.includes("saúde") || lower.includes("odont") || lower.includes("plano")) cat = "saude";
    else if (lower.includes("auto") || lower.includes("carro") || lower.includes("veicul")) cat = "auto";
    else if (lower.includes("resid") || lower.includes("casa")) cat = "residencial";
    else if (lower.includes("empresa") || lower.includes("consultorio") || lower.includes("clínica")) cat = "empresarial";

    const catPrefix = cat.toUpperCase().slice(0, 4);
    const code = `${catPrefix}-${Math.floor(1000 + Math.random() * 9000)}`;
    const parsedComissao = typeof comissao_percentual === "number" 
      ? comissao_percentual 
      : (parseFloat(String(comissao_percentual || 20)) || 20);

    const payload: any = {
      nome: cleanNome,
      categoria: cat,
      seguradora: seguradora || "Porto Seguro",
      comissao_percentual: parsedComissao,
      codigo: code,
      ativo: true,
    };
    if (finalOrgId) payload.organization_id = finalOrgId;

    const { data: newProd, error } = await supabase
      .from("produtos")
      .insert(payload)
      .select()
      .single();

    if (!error && newProd) {
      return { id: newProd.id, nome: newProd.nome, produto: newProd };
    }
  }

  // 3. Fallback: find any existing product in catalog
  const { data: anyProds } = await supabase
    .from("produtos")
    .select("*")
    .order("created_at", { ascending: true })
    .limit(1);

  if (anyProds && anyProds.length > 0) {
    return { id: anyProds[0].id, nome: anyProds[0].nome, produto: anyProds[0] };
  }

  // 4. Create default general insurance product if catalog is empty
  const defaultPayload: any = {
    nome: "Seguro Geral / RCP Médico",
    categoria: "rcp",
    seguradora: seguradora || "Porto Seguro",
    comissao_percentual: 20,
    codigo: "GERAL-001",
    ativo: true,
  };
  if (finalOrgId) defaultPayload.organization_id = finalOrgId;

  const { data: fallbackProd } = await supabase
    .from("produtos")
    .insert(defaultPayload)
    .select()
    .single();

  return {
    id: fallbackProd?.id || "00000000-0000-0000-0000-000000000000",
    nome: fallbackProd?.nome || "Seguro Geral",
    produto: fallbackProd || undefined,
  };
}


