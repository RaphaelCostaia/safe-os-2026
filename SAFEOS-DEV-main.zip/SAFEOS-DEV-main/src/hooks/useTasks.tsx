import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { assertAffectedRows } from "@/lib/supabaseMutationUtils";

export type TaskPriority = "baixa" | "media" | "alta" | "critica";
export type TaskStatus = "pendente" | "concluida" | "cancelada";

export interface Task {
  id: string;
  user_id: string;
  titulo: string;
  descricao: string | null;
  prioridade: TaskPriority;
  prazo: string | null;
  status: TaskStatus;
  created_at: string;
  updated_at: string;
}

export interface TaskInsert {
  titulo: string;
  descricao?: string;
  prioridade: TaskPriority;
  prazo?: string | null;
}

export interface TaskUpdate {
  id: string;
  titulo?: string;
  descricao?: string;
  prioridade?: TaskPriority;
  prazo?: string | null;
  status?: TaskStatus;
}

export function useTasks() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["tasks", user?.id],
    queryFn: async () => {
      if (!user?.id) return [];

      const { data, error } = await supabase
        .from("tasks")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as Task[];
    },
    enabled: !!user?.id,
  });
}

export function usePendingTasks() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["tasks", "pending", user?.id],
    queryFn: async () => {
      if (!user?.id) return [];

      const { data, error } = await supabase
        .from("tasks")
        .select("*")
        .eq("user_id", user.id)
        .eq("status", "pendente")
        .order("prazo", { ascending: true, nullsFirst: false })
        .order("prioridade", { ascending: false });

      if (error) throw error;
      return data as Task[];
    },
    enabled: !!user?.id,
  });
}

export function useCreateTask() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (task: TaskInsert) => {
      if (!user?.id) throw new Error("Usuário não autenticado");

      const { data, error } = await supabase
        .from("tasks")
        .insert({
          user_id: user.id,
          titulo: task.titulo,
          descricao: task.descricao || null,
          prioridade: task.prioridade,
          prazo: task.prazo || null,
        })
        .select()
        .single();

      if (error) throw error;
      return data as Task;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      queryClient.invalidateQueries({ queryKey: ["priority_queue"] });
      toast.success("Tarefa criada com sucesso!");
    },
    onError: (error) => {
      console.error("Erro ao criar tarefa:", error);
      toast.error("Erro ao criar tarefa");
    },
  });
}

export function useUpdateTask() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (task: TaskUpdate) => {
      const { id, ...updateData } = task;

      const { data, error } = await supabase
        .from("tasks")
        .update(updateData)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return data as Task;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      queryClient.invalidateQueries({ queryKey: ["priority_queue"] });
      toast.success("Tarefa atualizada!");
    },
    onError: (error) => {
      console.error("Erro ao atualizar tarefa:", error);
      toast.error("Erro ao atualizar tarefa");
    },
  });
}

export function useCompleteTask() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (taskId: string) => {
      const { data, error } = await supabase
        .from("tasks")
        .update({ status: "concluida" as TaskStatus })
        .eq("id", taskId)
        .select()
        .single();

      if (error) throw error;
      return data as Task;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      queryClient.invalidateQueries({ queryKey: ["priority_queue"] });
      toast.success("Tarefa concluída!");
    },
    onError: (error) => {
      console.error("Erro ao concluir tarefa:", error);
      toast.error("Erro ao concluir tarefa");
    },
  });
}

export function useDeleteTask() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (taskId: string) => {
      const { data, error, count } = await supabase
        .from("tasks")
        .delete({ count: "exact" })
        .eq("id", taskId)
        .select("id");

      if (error) throw error;

      assertAffectedRows(
        { count, data },
        "Falha ao excluir tarefa (permissão insuficiente ou registro não encontrado)"
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tasks"] });
      queryClient.invalidateQueries({ queryKey: ["priority_queue"] });
      toast.success("Tarefa excluída!");
    },
    onError: (error) => {
      console.error("Erro ao excluir tarefa:", error);
      toast.error("Erro ao excluir tarefa");
    },
  });
}

