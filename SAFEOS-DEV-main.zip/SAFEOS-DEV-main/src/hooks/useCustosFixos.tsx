import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { assertAffectedRows } from "@/lib/supabaseMutationUtils";

export interface CustoFixo {
  id: string;
  categoria: string;
  descricao: string;
  valor: number;
  recorrencia: string;
  status: string;
  responsavel_id: string | null;
  created_at: string;
  updated_at: string;
}

export type CustoFixoInsert = Omit<CustoFixo, 'id' | 'created_at' | 'updated_at'>;
export type CustoFixoUpdate = Partial<CustoFixoInsert>;

export function useCustosFixos() {
  const queryClient = useQueryClient();

  const { data: custosFixos = [], isLoading, error } = useQuery({
    queryKey: ['custos-fixos'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('custos_fixos')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as CustoFixo[];
    },
  });

  const createMutation = useMutation({
    mutationFn: async (custo: CustoFixoInsert) => {
      // Fetch current user and their organization_id to avoid RLS mismatch
      const { data: { session } } = await supabase.auth.getSession();
      const currentUserId = session?.user?.id;
      let finalOrgId = (custo as any).organization_id;

      if (!finalOrgId && currentUserId) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("organization_id")
          .eq("id", currentUserId)
          .maybeSingle();
        
        if (profile?.organization_id) {
          finalOrgId = profile.organization_id;
        } else {
          // Fallback to first available organization if no info
          const { data: orgs } = await supabase
            .from("organizations")
            .select("id")
            .order("created_at", { ascending: true })
            .limit(1);
          if (orgs && orgs.length > 0) {
            finalOrgId = orgs[0].id;
          }
        }
      }

      const custoWithOrg = {
        ...custo,
        organization_id: finalOrgId
      };

      const { data, error } = await supabase
        .from('custos_fixos')
        .insert(custoWithOrg)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['custos-fixos'] });
      toast.success('Custo fixo adicionado com sucesso');
    },
    onError: (error: Error) => {
      toast.error(`Erro ao adicionar custo: ${error.message}`);
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: string } & CustoFixoUpdate) => {
      const { data: updated, error } = await supabase
        .from('custos_fixos')
        .update(data)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return updated;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['custos-fixos'] });
      toast.success('Custo fixo atualizado com sucesso');
    },
    onError: (error: Error) => {
      toast.error(`Erro ao atualizar custo: ${error.message}`);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { data, error, count } = await supabase
        .from('custos_fixos')
        .delete({ count: 'exact' })
        .eq('id', id)
        .select('id');

      if (error) throw error;

      assertAffectedRows(
        { count, data },
        'Falha ao remover custo fixo (permissão insuficiente ou registro não encontrado)'
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['custos-fixos'] });
      toast.success('Custo fixo removido com sucesso');
    },
    onError: (error: Error) => {
      toast.error(`Erro ao remover custo: ${error.message}`);
    },
  });

  return {
    custosFixos,
    isLoading,
    error,
    createCusto: createMutation.mutate,
    updateCusto: updateMutation.mutate,
    deleteCusto: deleteMutation.mutate,
    isCreating: createMutation.isPending,
    isUpdating: updateMutation.isPending,
    isDeleting: deleteMutation.isPending,
  };
}

