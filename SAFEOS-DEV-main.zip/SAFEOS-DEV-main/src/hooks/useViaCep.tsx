import { useState, useCallback } from "react";
import { toast } from "sonner";

export interface ViaCepResponse {
  cep: string;
  logradouro: string;
  complemento: string;
  bairro: string;
  localidade: string;
  uf: string;
  erro?: boolean;
}

export interface CepData {
  cep: string;
  logradouro: string;
  bairro: string;
  cidade: string;
  uf: string;
}

export function useViaCep() {
  const [isLoading, setIsLoading] = useState(false);
  const [lastFetchedCep, setLastFetchedCep] = useState<string | null>(null);

  const formatCep = (value: string): string => {
    // Remove everything except digits
    const digits = value.replace(/\D/g, "");
    // Apply mask: 00000-000
    if (digits.length <= 5) {
      return digits;
    }
    return `${digits.slice(0, 5)}-${digits.slice(5, 8)}`;
  };

  const fetchAddress = useCallback(async (cep: string): Promise<CepData | null> => {
    // Clean CEP (remove non-digits)
    const cleanCep = cep.replace(/\D/g, "");
    
    // Validate CEP length
    if (cleanCep.length !== 8) {
      return null;
    }

    // Avoid duplicate fetches for the same CEP
    if (cleanCep === lastFetchedCep) {
      return null;
    }

    setIsLoading(true);
    setLastFetchedCep(cleanCep);

    try {
      const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
      
      if (!response.ok) {
        throw new Error("Erro ao consultar CEP");
      }

      const data: ViaCepResponse = await response.json();

      if (data.erro) {
        toast.error("CEP não encontrado", {
          description: "Verifique o CEP informado ou preencha os campos manualmente.",
        });
        return null;
      }

      toast.success("Endereço encontrado", {
        description: `${data.localidade} - ${data.uf}`,
      });

      return {
        cep: formatCep(cleanCep),
        logradouro: data.logradouro || "",
        bairro: data.bairro || "",
        cidade: data.localidade || "",
        uf: data.uf || "",
      };
    } catch (error) {
      console.error("ViaCEP error:", error);
      toast.error("Falha ao consultar CEP", {
        description: "Tente novamente ou preencha os campos manualmente.",
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [lastFetchedCep]);

  const resetLastFetched = useCallback(() => {
    setLastFetchedCep(null);
  }, []);

  return {
    fetchAddress,
    formatCep,
    isLoading,
    resetLastFetched,
  };
}
