import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/types";
import { toast } from "sonner";
import { logSinistroActivity } from "./useSinistroActivities";
import { invalidateEntityQueries } from "@/lib/queryInvalidation";
import { assertAffectedRows } from "@/lib/supabaseMutationUtils";
import { sanitizePayload } from "@/lib/utils";

export type Sinistro = Tables<"sinistros">;
export type SinistroInsert = TablesInsert<"sinistros">;
export type SinistroUpdate = TablesUpdate<"sinistros">;

export type SinistroWithRelations = Sinistro & {
  clients?: { nome: string; cpf_cnpj: string | null; profissao: string | null } | null;
  apolices?: { numero_apolice: string; seguradora: string; produtos?: { nome: string; categoria?: string } | null } | null;
};

interface UseSinistrosOptions {
  includeArchived?: boolean;
  clientId?: string;
}

export function useSinistros(options: UseSinistrosOptions = {}) {
  const { includeArchived = false, clientId } = options;

  return useQuery({
    queryKey: ["sinistros", { includeArchived, clientId }],
    queryFn: async () => {
      let query = supabase
        .from("sinistros")
        .select(`
          *,
          clients (nome, cpf_cnpj, profissao),
          apolices (numero_apolice, seguradora, produtos (nome, categoria))
        `)
        .order("created_at", { ascending: false });

      if (clientId) {
        query = query.eq("client_id", clientId);
      }

      // By default, filter out archived (soft-deleted) sinistros
      if (!includeArchived) {
        query = query.is("deleted_at", null);
      }
      
      const { data, error } = await query;
      
      if (error) throw error;
      return data as SinistroWithRelations[];
    },
  });
}

export function useSinistro(id: string) {
  return useQuery({
    queryKey: ["sinistros", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("sinistros")
        .select(`
          *,
          clients (nome, cpf_cnpj, profissao, telefone, email),
          apolices (numero_apolice, seguradora, produtos (nome, categoria))
        `)
        .eq("id", id)
        .single();
      
      if (error) throw error;
      return data as SinistroWithRelations;
    },
    enabled: !!id,
  });
}

export function useCreateSinistro() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (sinistro: SinistroInsert) => {
      // Fetch current user and their organization_id to avoid RLS mismatch
      const { data: { session } } = await supabase.auth.getSession();
      const currentUserId = session?.user?.id;
      let finalOrgId = sinistro.organization_id;

      if (!finalOrgId && currentUserId) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("organization_id")
          .eq("id", currentUserId)
          .maybeSingle();
        
        if (profile?.organization_id) {
          finalOrgId = profile.organization_id;
        } else {
          // Fallback to first available organization if no info
          const { data: orgs } = await supabase
            .from("organizations")
            .select("id")
            .order("created_at", { ascending: true })
            .limit(1);
          if (orgs && orgs.length > 0) {
            finalOrgId = orgs[0].id;
          }
        }
      }

      const sinistroWithOrg = {
        ...sinistro,
        organization_id: finalOrgId
      };

      const sanitizedSinistro = sanitizePayload(sinistroWithOrg);
      const { data, error } = await supabase
        .from("sinistros")
        .insert(sanitizedSinistro)
        .select()
        .single();
      
      if (error) throw error;
      
      // Log creation activity
      await logSinistroActivity(
        data.id,
        'criacao',
        'Sinistro criado',
        `Sinistro ${data.numero_sinistro} registrado no sistema`
      );
      
      return data;
    },
    onSuccess: () => {
      invalidateEntityQueries(queryClient, "sinistros");
      toast.success("Sinistro criado com sucesso!");
    },
    onError: (error) => {
      toast.error("Erro ao criar sinistro: " + error.message);
    },
  });
}

const STATUS_LABELS: Record<string, string> = {
  aberto: "Aberto",
  em_andamento: "Em Andamento",
  aguardando_cliente: "Aguardando Cliente",
  aguardando_seguradora: "Aguardando Seguradora",
  encerrado: "Encerrado",
  arquivado: "Arquivado",
};

const CRITICIDADE_LABELS: Record<string, string> = {
  baixa: "Baixa",
  media: "Média",
  alta: "Alta",
  critica: "Crítica",
};

export function useUpdateSinistro() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, previousData, ...sinistro }: SinistroUpdate & { id: string; previousData?: Partial<Sinistro> }) => {
      const sanitizedSinistro = sanitizePayload(sinistro);
      const { data, error } = await supabase
        .from("sinistros")
        .update(sanitizedSinistro)
        .eq("id", id)
        .select()
        .single();
      
      if (error) throw error;
      
      // Log appropriate activity based on what changed
      if (previousData) {
        if (sinistro.status && sinistro.status !== previousData.status) {
          const oldLabel = STATUS_LABELS[previousData.status || ''] || previousData.status;
          const newLabel = STATUS_LABELS[sinistro.status] || sinistro.status;
          await logSinistroActivity(
            id,
            sinistro.status === 'encerrado' || sinistro.status === 'arquivado' ? 'encerramento' : 'status',
            `Status alterado para ${newLabel}`,
            `Status alterado de "${oldLabel}" para "${newLabel}"`
          );
        }
        
        if (sinistro.criticidade && sinistro.criticidade !== previousData.criticidade) {
          const oldLabel = CRITICIDADE_LABELS[previousData.criticidade || ''] || previousData.criticidade;
          const newLabel = CRITICIDADE_LABELS[sinistro.criticidade] || sinistro.criticidade;
          await logSinistroActivity(
            id,
            'criticidade',
            `Criticidade alterada para ${newLabel}`,
            `Criticidade alterada de "${oldLabel}" para "${newLabel}"`
          );
        }
        
        if (sinistro.responsavel_id && sinistro.responsavel_id !== previousData.responsavel_id) {
          await logSinistroActivity(
            id,
            'responsavel',
            'Responsável alterado',
            'Responsável interno do sinistro foi alterado'
          );
        }
        
        if (
          (sinistro.valor_estimado !== undefined && sinistro.valor_estimado !== previousData.valor_estimado) ||
          (sinistro.valor_aprovado !== undefined && sinistro.valor_aprovado !== previousData.valor_aprovado) ||
          (sinistro.valor_pago !== undefined && sinistro.valor_pago !== previousData.valor_pago)
        ) {
          await logSinistroActivity(
            id,
            'valor',
            'Valores atualizados',
            'Valores do sinistro foram atualizados'
          );
        }
      }
      
      return data;
    },
    onSuccess: (_, variables) => {
      invalidateEntityQueries(queryClient, "sinistros");
      queryClient.invalidateQueries({ queryKey: ["sinistro-activities", variables.id] });
      toast.success("Sinistro atualizado com sucesso!");
    },
    onError: (error) => {
      toast.error("Erro ao atualizar sinistro: " + error.message);
    },
  });
}

/**
 * Archive (soft-delete) a sinistro.
 */
export function useArchiveSinistro() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, userId }: { id: string; userId: string }) => {
      // Perform soft delete
      const { data, error, count } = await supabase
        .from("sinistros")
        .update({
          deleted_at: new Date().toISOString(),
          deleted_by: userId,
        })
        .eq("id", id)
        .is("deleted_at", null)
        .select("id, numero_sinistro");

      if (error) throw error;

      assertAffectedRows(
        { count, data },
        "Falha ao arquivar sinistro (permissão insuficiente ou registro não encontrado)"
      );

      // Log archive activity
      if (data && data[0]) {
        await logSinistroActivity(
          id,
          'encerramento',
          'Sinistro arquivado',
          `Sinistro ${data[0].numero_sinistro} foi arquivado`
        );
      }

      return { id };
    },
    onMutate: async ({ id }) => {
      await queryClient.cancelQueries({ queryKey: ["sinistros"] });
      const previousSinistros = queryClient.getQueryData<SinistroWithRelations[]>(["sinistros", { includeArchived: false }]);
      
      if (previousSinistros) {
        queryClient.setQueryData<SinistroWithRelations[]>(
          ["sinistros", { includeArchived: false }],
          previousSinistros.filter(s => s.id !== id)
        );
      }
      
      return { previousSinistros };
    },
    onError: (error, _vars, context) => {
      if (context?.previousSinistros) {
        queryClient.setQueryData(["sinistros", { includeArchived: false }], context.previousSinistros);
      }
      toast.error(error.message);
    },
    onSuccess: () => {
      toast.success("Sinistro arquivado com sucesso!");
      invalidateEntityQueries(queryClient, "sinistros");
    },
  });
}

/**
 * Restore an archived sinistro.
 */
export function useRestoreSinistro() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { data, error, count } = await supabase
        .from("sinistros")
        .update({
          deleted_at: null,
          deleted_by: null,
        })
        .eq("id", id)
        .not("deleted_at", "is", null)
        .select("id");

      if (error) throw error;

      assertAffectedRows(
        { count, data },
        "Falha ao restaurar sinistro (permissão insuficiente ou registro não encontrado)"
      );

      return { id };
    },
    onSuccess: () => {
      toast.success("Sinistro restaurado com sucesso!");
      invalidateEntityQueries(queryClient, "sinistros");
    },
    onError: (error) => {
      toast.error("Erro ao restaurar sinistro: " + error.message);
    },
  });
}

/**
 * @deprecated Use useArchiveSinistro instead for soft delete.
 */
export function useDeleteSinistro() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { data, error, count } = await supabase
        .from("sinistros")
        .delete({ count: "exact" })
        .eq("id", id)
        .select("id");
      
      if (error) throw error;

      assertAffectedRows(
        { count, data },
        "Falha ao excluir sinistro (permissão insuficiente ou registro não encontrado)"
      );
    },
    onMutate: async (id: string) => {
      await queryClient.cancelQueries({ queryKey: ["sinistros"] });
      const previousSinistros = queryClient.getQueryData<SinistroWithRelations[]>(["sinistros", { includeArchived: false }]);
      
      if (previousSinistros) {
        queryClient.setQueryData<SinistroWithRelations[]>(
          ["sinistros", { includeArchived: false }],
          previousSinistros.filter(s => s.id !== id)
        );
      }
      
      return { previousSinistros };
    },
    onError: (error, _id, context) => {
      if (context?.previousSinistros) {
        queryClient.setQueryData(["sinistros", { includeArchived: false }], context.previousSinistros);
      }
      toast.error("Erro ao excluir sinistro: " + error.message);
    },
    onSuccess: () => {
      toast.success("Sinistro excluído com sucesso!");
      invalidateEntityQueries(queryClient, "sinistros");
    },
  });
}
