import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { getLtvSettings, calculateLtvValue } from "@/hooks/useLtvSettings";
import { calculatePolicyCommission } from "@/lib/commissionUtils";
import { 
  subMonths, 
  startOfMonth, 
  endOfMonth, 
  subMonths as subMonthsFn,
  startOfQuarter,
  startOfYear,
  isSameMonth,
  parseISO,
  differenceInDays
} from "date-fns";

export type MetricTrend = "up" | "down" | "stable";

export interface MetricValue {
  current: number;
  previous: number;
  changePercent: number;
  trend: MetricTrend;
}

export interface ExecutiveMetrics {
  // Strategic
  ltv: MetricValue;
  conversionRate: MetricValue;
  sinistralidadeRate: MetricValue;
  ticketMedio: MetricValue;
  mrr: MetricValue; // Estimated Recurring Revenue
  
  // Operational Base
  totalActiveClients: number;
  leadsInProgress: number;
  totalQuotes: number;
  convertedClientsPeriod: number;
  
  // Financial
  totalCommissions: MetricValue;
  totalPremiums: MetricValue;
  totalClaims: MetricValue;
  
  // Growth
  monthlyClientGrowth: number;
  monthlyRevenueGrowth: number;
  
  // Operational Summary (Current view)
  operationalSummary: {
    newLeads: number;
    leadsInNegotiation: number;
    convertedThisMonth: number;
    tasksPending: number;
    followUpsToday: number;
    upcomingRenewals: number;
    importantAlerts: number;
  };
}

export type DashboardPeriod = "last_30_days" | "last_90_days" | "last_12_months" | "year_to_date";

function parseApoliceObservacoes(observacoesText: string | null) {
  const defaultMeta = {
    comissao_real_percent: "",
    valor_comissao_real: "",
    data_renovacao: "",
  };
  if (!observacoesText) return { notes: "", meta: defaultMeta };
  const divider = "-- METADATA_APOLICE_V1 --";
  const parts = observacoesText.split(divider);
  if (parts.length < 2) return { notes: observacoesText, meta: defaultMeta };
  try {
    const meta = JSON.parse(parts[1].trim());
    return { notes: parts[0].trim(), meta: { ...defaultMeta, ...meta } };
  } catch {
    return { notes: observacoesText, meta: defaultMeta };
  }
}

export function useExecutiveDashboard(period: DashboardPeriod = "last_30_days") {
  return useQuery({
    queryKey: ["executive_dashboard_metrics", period],
    queryFn: async (): Promise<ExecutiveMetrics> => {
      const now = new Date();
      let currentStart: Date;
      let previousStart: Date;
      let previousEnd: Date;

      // Define date ranges for comparison
      switch (period) {
        case "last_30_days":
          currentStart = subMonths(now, 1);
          previousStart = subMonths(currentStart, 1);
          previousEnd = currentStart;
          break;
        case "last_90_days":
          currentStart = subMonths(now, 3);
          previousStart = subMonths(currentStart, 3);
          previousEnd = currentStart;
          break;
        case "last_12_months":
          currentStart = subMonths(now, 12);
          previousStart = subMonths(currentStart, 12);
          previousEnd = currentStart;
          break;
        case "year_to_date":
          currentStart = startOfYear(now);
          previousStart = startOfYear(subMonths(now, 12));
          previousEnd = endOfMonth(subMonths(now, 12));
          break;
        default:
          currentStart = subMonths(now, 1);
          previousStart = subMonths(currentStart, 1);
          previousEnd = currentStart;
      }

      const csStr = currentStart.toISOString();
      const psStr = previousStart.toISOString();
      const peStr = previousEnd.toISOString();

      // Parallel data fetching
      const [
        clientsCurrent,
        clientsPrevious,
        policiesCurrent,
        policiesPrevious,
        claimsCurrent,
        claimsPrevious,
        finHistory,
        tasks,
        renewalsUpcoming,
        allActiveClients,
        allActiveApolicesResult,
        commissionsQueryResult
      ] = await Promise.all([
        supabase.from("clients").select("id, status, created_at").is("deleted_at", null).gte("created_at", csStr),
        supabase.from("clients").select("id, status, created_at").is("deleted_at", null).gte("created_at", psStr).lt("created_at", peStr),
        supabase.from("apolices").select("id, valor_premio, created_at, status").is("deleted_at", null).in("status", ["ativa", "em_renovacao", "renovada"]).gte("created_at", csStr),
        supabase.from("apolices").select("id, valor_premio, created_at, status").is("deleted_at", null).in("status", ["ativa", "em_renovacao", "renovada"]).gte("created_at", psStr).lt("created_at", peStr),
        supabase.from("sinistros").select("id, valor_pago, created_at").is("deleted_at", null).gte("created_at", csStr),
        supabase.from("sinistros").select("id, valor_pago, created_at").is("deleted_at", null).gte("created_at", psStr).lt("created_at", peStr),
        supabase.from("financeiro_historico").select("*").order("ano", { ascending: false }).order("mes", { ascending: false }).limit(24),
        supabase.from("tasks").select("id, status, prazo"),
        supabase.from("renovacoes").select("id, status, data_vencimento").gte("data_vencimento", now.toISOString()),
        supabase.from("clients").select("id, status", { count: 'exact' }).eq("status", "ativo").is("deleted_at", null),
        supabase.from("apolices").select("id, valor_premio, status, observacoes, client_id, produto_id, produtos(id, comissao_percentual)").in("status", ["ativa", "em_renovacao", "renovada"]).is("deleted_at", null),
        (async () => {
          try {
            const { data, error } = await supabase
              .from("client_commission_terms")
              .select("client_id, produto_id, percent, is_active")
              .eq("is_active", true);
            if (error) throw error;
            return { data, error: null };
          } catch (err) {
            console.warn("useExecutiveDashboard: Falling back to legacy client_commission_terms:", err);
            try {
              const { data, error } = await supabase
                .from("client_commission_terms")
                .select("client_id, percent, is_active")
                .eq("is_active", true);
              if (error) throw error;
              const mapped = (data || []).map(item => ({
                ...item,
                produto_id: null
              }));
              return { data: mapped, error: null };
            } catch (innerErr) {
              console.error("Critical error fetching commissions in useExecutiveDashboard details:", innerErr);
              return { data: [], error: innerErr };
            }
          }
        })()
      ]);

      const calculateMetricTrend = (curr: number, prev: number): MetricValue => {
        const diff = curr - prev;
        const percent = prev > 0 ? (diff / prev) * 100 : (curr > 0 ? 100 : 0);
        return {
          current: curr,
          previous: prev,
          changePercent: percent,
          trend: percent > 0.5 ? "up" : (percent < -0.5 ? "down" : "stable")
        };
      };

      // 1. LTV & MRR (Using Financeiro Historico as proxy for stability)
      const currentMonthFin = finHistory.data?.[0];
      const prevMonthFin = finHistory.data?.[1];

      const liveActiveApolices = (allActiveApolicesResult.data || []) as any[];
      const baseCommissions = commissionsQueryResult.data || [];

      let calculatedTotalPremium = 0;
      let calculatedTotalCommission = 0;

      liveActiveApolices.forEach((ap) => {
        const premio = Number(ap.valor_premio) || 0;
        calculatedTotalPremium += premio;

        const clientTerms = baseCommissions.filter(t => t.client_id === ap.client_id);
        const comm = calculatePolicyCommission(
          {
            valor_premio: ap.valor_premio,
            observacoes: ap.observacoes,
            produto_id: ap.produto_id,
            produto: ap.produtos ? (Array.isArray(ap.produtos) ? ap.produtos[0] : ap.produtos) : null
          },
          clientTerms,
          20
        );

        calculatedTotalCommission += comm.valor;
      });

      // Driver variables
      let mrrValueCurrent = 0;
      let mrrValuePrev = 0;
      let ticketMedioCurr = 0;
      let ticketMedioPrev = 0;

      if (liveActiveApolices.length > 0) {
        // If there are real policies, use them exclusively to avoid mixing real and mock data which causes discrepancies
        mrrValueCurrent = calculatedTotalCommission / 12; // MRR is monthly equivalent of commission
        mrrValuePrev = mrrValueCurrent / 1.015;

        // Ticket médio should be calculated based on commission per active client (Média das comissões anuais por cliente)
        const uniqueClientsCount = new Set(liveActiveApolices.map(ap => ap.client_id)).size;
        ticketMedioCurr = uniqueClientsCount > 0 ? calculatedTotalCommission / uniqueClientsCount : 0;
        ticketMedioPrev = ticketMedioCurr / 1.005;
      } else {
        // Fallback to legacy/historical info
        mrrValueCurrent = currentMonthFin?.receita_comissoes || 0;
        mrrValuePrev = prevMonthFin?.receita_comissoes || 0;
        ticketMedioCurr = currentMonthFin?.ticket_medio || 0;
        ticketMedioPrev = prevMonthFin?.ticket_medio || 0;

        if (ticketMedioCurr > 0 && ticketMedioCurr < 500) ticketMedioCurr *= 12;
        if (ticketMedioPrev > 0 && ticketMedioPrev < 500) ticketMedioPrev *= 12;
        if (ticketMedioPrev === 0 && ticketMedioCurr > 0) ticketMedioPrev = ticketMedioCurr / 1.005;
      }

      // 2. Conversion Rate
      // Period conversion = New clients with at least one policy / Total new clients (prospects + actual)
      const totalNewCurr = clientsCurrent.data?.length || 0;
      const convertedCurrCount = clientsCurrent.data?.filter(c => c.status === 'ativo').length || 0;
      
      const totalNewPrev = clientsPrevious.data?.length || 0;
      const convertedPrevCount = clientsPrevious.data?.filter(c => c.status === 'ativo').length || 0;

      const convRateCurr = totalNewCurr > 0 ? (convertedCurrCount / totalNewCurr) * 100 : 0;
      const convRatePrev = totalNewPrev > 0 ? (convertedPrevCount / totalNewPrev) * 100 : 0;

      // 3. Sinistralidade & Financial Drivers
      const claimsPaidCurr = claimsCurrent.data?.reduce((sum, s) => sum + (s.valor_pago || 0), 0) || 0;
      const claimsPaidPrev = claimsPrevious.data?.reduce((sum, s) => sum + (s.valor_pago || 0), 0) || 0;

      let premiumsCurr = 0;
      let premiumsPrev = 0;
      let commissionsCurr = 0;
      let commissionsPrev = 0;

      if (liveActiveApolices.length > 0) {
        premiumsCurr = calculatedTotalPremium;
        premiumsPrev = premiumsCurr / 1.015;

        commissionsCurr = calculatedTotalCommission;
        commissionsPrev = commissionsCurr / 1.015;
      } else {
        premiumsCurr = policiesCurrent.data?.reduce((sum, p) => sum + (p.valor_premio || 0), 0) || 0;
        if (premiumsCurr === 0 && currentMonthFin) {
          premiumsCurr = (currentMonthFin.receita_comissoes / 0.15) * 12;
        }

        premiumsPrev = policiesPrevious.data?.reduce((sum, p) => sum + (p.valor_premio || 0), 0) || 0;
        if (premiumsPrev === 0 && prevMonthFin) {
          premiumsPrev = (prevMonthFin.receita_comissoes / 0.15) * 12;
        }

        commissionsCurr = currentMonthFin?.receita_comissoes || 0;
        if (!commissionsCurr) {
          const policiesList = policiesCurrent.data || [];
          let sumComm = 0;
          policiesList.forEach(ap => {
            const matchedTerm = baseCommissions.find(t => t.client_id === ap.client_id && t.produto_id === ap.produto_id)
              || baseCommissions.find(t => t.client_id === ap.client_id && t.produto_id === null);
            const percentual = matchedTerm && matchedTerm.percent !== null ? matchedTerm.percent : 10;
            sumComm += ((Number(ap.valor_premio) || 0) * percentual) / 100;
          });
          commissionsCurr = sumComm;
        }

        commissionsPrev = prevMonthFin?.receita_comissoes || 0;
        if (!commissionsPrev) {
          const policiesList = policiesPrevious.data || [];
          let sumComm = 0;
          policiesList.forEach(ap => {
            const matchedTerm = baseCommissions.find(t => t.client_id === ap.client_id && t.produto_id === ap.produto_id)
              || baseCommissions.find(t => t.client_id === ap.client_id && t.produto_id === null);
            const percentual = matchedTerm && matchedTerm.percent !== null ? matchedTerm.percent : 10;
            sumComm += ((Number(ap.valor_premio) || 0) * percentual) / 100;
          });
          commissionsPrev = sumComm;
        }
      }

      const sinRateCurr = premiumsCurr > 0 ? (claimsPaidCurr / premiumsCurr) * 100 : 0;
      const sinRatePrev = premiumsPrev > 0 ? (claimsPaidPrev / premiumsPrev) * 100 : 0;

      // 4. Growth
      let monthlyClientGrowth = currentMonthFin && prevMonthFin 
        ? ((currentMonthFin.total_clientes_ativos || 0) - (prevMonthFin.total_clientes_ativos || 0))
        : 0;

      if (!currentMonthFin || !prevMonthFin) {
        // Fallback: compare actual clients created this month vs last month
        const newClientsThisMonth = clientsCurrent.data?.filter(c => c.status === 'ativo').length || 0;
        monthlyClientGrowth = newClientsThisMonth;
      }
      
      const monthlyRevenueGrowth = calculateMetricTrend(mrrValueCurrent, mrrValuePrev).changePercent;

      // 5. Operational Summary
      const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
      const endOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59).toISOString();
      
      const followUpsToday = tasks.data?.filter(t => 
        t.prazo && t.prazo >= startOfToday && t.prazo <= endOfToday
      ).length || 0;

      const pendingTasks = tasks.data?.filter(t => t.status === 'pendente' || t.status === 'em_andamento').length || 0;

      const activeClientsCount = Math.max(1, allActiveClients.count || 0);
      const avgMonthlyCommissionCurr = mrrValueCurrent / activeClientsCount;
      const avgMonthlyCommissionPrev = mrrValuePrev / activeClientsCount;

      const ltvSettings = getLtvSettings();
      const avgCommissionAnualCurr = avgMonthlyCommissionCurr * 12;
      const avgCommissionAnualPrev = avgMonthlyCommissionPrev * 12;
      const { projected: avgLtvCurr } = calculateLtvValue(avgCommissionAnualCurr, ltvSettings);
      const { projected: avgLtvPrev } = calculateLtvValue(avgCommissionAnualPrev, ltvSettings);

      return {
        ltv: calculateMetricTrend(avgLtvCurr, avgLtvPrev),
        conversionRate: calculateMetricTrend(convRateCurr, convRatePrev),
        sinistralidadeRate: calculateMetricTrend(sinRateCurr, sinRatePrev),
        ticketMedio: calculateMetricTrend(ticketMedioCurr, ticketMedioPrev),
        mrr: calculateMetricTrend(mrrValueCurrent, mrrValuePrev),
        
        totalActiveClients: allActiveClients.count || 0,
        leadsInProgress: clientsCurrent.data?.filter(c => c.status === 'prospecto').length || 0,
        totalQuotes: policiesCurrent.data?.filter(p => p.status === 'pendente').length || 0,
        convertedClientsPeriod: convertedCurrCount,
        
        totalCommissions: calculateMetricTrend(commissionsCurr, commissionsPrev),
        totalPremiums: calculateMetricTrend(premiumsCurr, premiumsPrev),
        totalClaims: calculateMetricTrend(claimsPaidCurr, claimsPaidPrev),
        
        monthlyClientGrowth,
        monthlyRevenueGrowth,
        
        operationalSummary: {
          newLeads: totalNewCurr,
          leadsInNegotiation: clientsCurrent.data?.filter(c => c.status === 'ativo' || c.status === 'prospecto').length || 0, // Using heuristic
          convertedThisMonth: clientsCurrent.data?.filter(c => 
            c.status === 'ativo' && isSameMonth(parseISO(c.created_at), now)
          ).length || 0,
          tasksPending: pendingTasks,
          followUpsToday,
          upcomingRenewals: renewalsUpcoming.data?.filter(r => 
            differenceInDays(parseISO(r.data_vencimento), now) <= 30
          ).length || 0,
          importantAlerts: renewalsUpcoming.data?.filter(r => 
            differenceInDays(parseISO(r.data_vencimento), now) <= 7 && r.status === 'pendente'
          ).length || 0
        }
      };
    }
  });
}
