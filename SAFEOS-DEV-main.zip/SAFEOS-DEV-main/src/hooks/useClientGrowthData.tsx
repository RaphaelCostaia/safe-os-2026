import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useMemo } from "react";

// Get formatted month name
const MONTH_NAMES = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];

export interface ClientGrowthMonthData {
  month: string;
  monthKey: string; // YYYY-MM for sorting
  novos: number;
  acumulado: number;
}

export interface ClientGrowthSummary {
  totalNovos: number;
  clientesAtivos: number;
  deltaUltimoMes: number;
  retentionRate: number;
}

/**
 * Hook to fetch client growth data from `clients` table
 * Groups by month based on `created_at`
 * Returns last 12 months by default
 */
export function useClientGrowthData(monthsBack: number = 12) {
  const query = useQuery({
    queryKey: ["client_growth_data", monthsBack],
    queryFn: async () => {
      // Fetch all non-archived clients with created_at and status
      const { data, error } = await supabase
        .from("clients")
        .select("id, created_at, status")
        .is("deleted_at", null)
        .order("created_at", { ascending: true });

      if (error) throw error;
      return data || [];
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Process data into monthly growth
  const processedData = useMemo(() => {
    if (!query.data) return null;

    const clients = query.data;
    
    // Group clients by month
    const monthlyCount: Record<string, number> = {};
    
    clients.forEach((client) => {
      const date = new Date(client.created_at);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
      monthlyCount[monthKey] = (monthlyCount[monthKey] || 0) + 1;
    });

    // Generate last N months
    const now = new Date();
    const months: ClientGrowthMonthData[] = [];
    let acumulado = 0;

    // First, calculate cumulative count for clients before our window
    const startDate = new Date(now.getFullYear(), now.getMonth() - monthsBack + 1, 1);
    clients.forEach((client) => {
      const clientDate = new Date(client.created_at);
      if (clientDate < startDate) {
        acumulado++;
      }
    });

    // Now generate monthly data for our window
    for (let i = monthsBack - 1; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
      const novos = monthlyCount[monthKey] || 0;
      acumulado += novos;

      months.push({
        month: MONTH_NAMES[date.getMonth()],
        monthKey,
        novos,
        acumulado,
      });
    }

    // Calculate summary stats
    const totalNovos = months.reduce((sum, m) => sum + m.novos, 0);
    const clientesAtivos = clients.filter(c => c.status === "ativo").length;
    
    // Delta: compare last month to previous month
    const lastMonthNovos = months[months.length - 1]?.novos || 0;
    const prevMonthNovos = months[months.length - 2]?.novos || 0;
    const deltaUltimoMes = lastMonthNovos - prevMonthNovos;

    // Retention rate: active clients / total clients
    const retentionRate = clients.length > 0 
      ? Math.round((clientesAtivos / clients.length) * 1000) / 10 
      : 0;

    const summary: ClientGrowthSummary = {
      totalNovos,
      clientesAtivos,
      deltaUltimoMes,
      retentionRate,
    };

    return { months, summary };
  }, [query.data, monthsBack]);

  return {
    data: processedData,
    isLoading: query.isLoading,
    isError: query.isError,
    error: query.error,
    refetch: query.refetch,
  };
}
