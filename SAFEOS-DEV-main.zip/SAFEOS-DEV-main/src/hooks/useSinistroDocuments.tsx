import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { assertAffectedRows } from "@/lib/supabaseMutationUtils";

// Type definition based on the table structure
export interface SinistroDocument {
  id: string;
  sinistro_id: string;
  client_id: string;
  apolice_id: string | null;
  nome: string;
  tipo: string;
  descricao: string | null;
  data_documento: string;
  url: string;
  tamanho: number | null;
  uploaded_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface SinistroDocumentInsert {
  sinistro_id: string;
  client_id: string;
  apolice_id?: string | null;
  nome: string;
  tipo: string;
  descricao?: string | null;
  data_documento?: string;
  url: string;
  tamanho?: number | null;
  uploaded_by?: string | null;
}

// Bucket name for sinistro documents
const BUCKET_NAME = "sinistro-documents";

// Document types for sinistros
export const sinistroDocumentTypes = [
  { value: "protocolo", label: "Protocolo / Aviso" },
  { value: "laudo", label: "Laudo / Relatório" },
  { value: "comunicacao", label: "E-mail / Comunicação" },
  { value: "juridico", label: "Petição / Documento jurídico" },
  { value: "comprovante", label: "Comprovante" },
  { value: "outros", label: "Outros" },
];

export const typeConfig: Record<string, { label: string; color: string }> = {
  protocolo: { label: "Protocolo", color: "bg-primary/10 text-primary" },
  laudo: { label: "Laudo", color: "bg-success/10 text-success" },
  comunicacao: { label: "Comunicação", color: "bg-info/10 text-info" },
  juridico: { label: "Jurídico", color: "bg-warning/10 text-warning" },
  comprovante: { label: "Comprovante", color: "bg-amber-500/10 text-amber-500" },
  outros: { label: "Outros", color: "bg-secondary text-secondary-foreground" },
};

// Fetch documents for a sinistro
export function useSinistroDocuments(sinistroId: string) {
  return useQuery({
    queryKey: ["sinistro_documents", sinistroId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("sinistro_documents")
        .select("*")
        .eq("sinistro_id", sinistroId)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as SinistroDocument[];
    },
    enabled: !!sinistroId,
  });
}

// Get signed URL for private bucket
export async function getSignedUrl(filePath: string): Promise<string | null> {
  try {
    const { data, error } = await supabase.storage
      .from(BUCKET_NAME)
      .createSignedUrl(filePath, 3600); // 1 hour validity

    if (error) {
      console.error("Error creating signed URL:", error);
      return null;
    }

    return data?.signedUrl || null;
  } catch (err) {
    console.error("Error getting signed URL:", err);
    return null;
  }
}

// Extract file path from stored URL
export function extractFilePath(url: string): string | null {
  try {
    const bucketPattern = new RegExp(`/${BUCKET_NAME}/(.+?)(?:\\?|$)`);
    const match = url.match(bucketPattern);
    if (match && match[1]) {
      return decodeURIComponent(match[1]);
    }
    
    const parts = url.split(`/${BUCKET_NAME}/`);
    if (parts.length > 1) {
      const pathWithQuery = parts[1];
      return pathWithQuery.split('?')[0];
    }
    
    return null;
  } catch (err) {
    console.error("Error extracting file path:", err);
    return null;
  }
}

// Upload document mutation
export function useUploadSinistroDocument() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ 
      sinistroId,
      clientId,
      apoliceId,
      file, 
      tipo,
      descricao,
      dataDocumento,
    }: { 
      sinistroId: string;
      clientId: string;
      apoliceId?: string | null;
      file: File; 
      tipo: string;
      descricao: string;
      dataDocumento: string;
    }) => {
      const { data: user } = await supabase.auth.getUser();
      
      if (!user.user) {
        throw new Error("Usuário não autenticado");
      }
      
      // Create unique file path
      const timestamp = Date.now();
      const safeFileName = file.name.replace(/[^a-zA-Z0-9.-]/g, '_');
      const filePath = `${sinistroId}/${timestamp}-${safeFileName}`;
      
      // Upload file to storage
      const { error: uploadError } = await supabase.storage
        .from(BUCKET_NAME)
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        console.error("Upload error:", uploadError);
        throw new Error(`Falha no upload: ${uploadError.message}`);
      }

      // Get URL reference
      const { data: urlData } = supabase.storage
        .from(BUCKET_NAME)
        .getPublicUrl(filePath);

      // Create document record
      const { data, error } = await supabase
        .from("sinistro_documents")
        .insert({
          sinistro_id: sinistroId,
          client_id: clientId,
          apolice_id: apoliceId || null,
          nome: file.name,
          tipo,
          descricao: descricao.trim() || null,
          data_documento: dataDocumento,
          url: urlData.publicUrl,
          tamanho: file.size,
          uploaded_by: user.user.id,
        })
        .select()
        .single();

      if (error) {
        // Rollback: remove file from storage
        await supabase.storage.from(BUCKET_NAME).remove([filePath]);
        throw error;
      }

      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["sinistro_documents", variables.sinistroId] });
      toast.success("Documento anexado com sucesso");
    },
    onError: (error: Error) => {
      console.error("Error uploading document:", error);
      toast.error(error.message || "Erro ao enviar documento");
    },
  });
}

// Delete document mutation
export function useDeleteSinistroDocument() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, sinistroId, url }: { id: string; sinistroId: string; url: string }) => {
      // 1) Delete DB record first (avoid deleting file if DB deletion is blocked by RLS)
      const { data, error, count } = await supabase
        .from("sinistro_documents")
        .delete({ count: "exact" })
        .eq("id", id)
        .select("id");

      if (error) throw error;

      assertAffectedRows(
        { count, data },
        "Falha ao excluir documento (permissão insuficiente ou registro não encontrado)"
      );

      // 2) Best-effort storage removal
      const filePath = extractFilePath(url);
      if (filePath) {
        const { error: storageError } = await supabase.storage
          .from(BUCKET_NAME)
          .remove([filePath]);

        if (storageError) {
          console.warn("Warning removing file from storage:", storageError);
        }
      }
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["sinistro_documents", variables.sinistroId] });
      toast.success("Documento excluído");
    },
    onError: (error) => {
      console.error("Error deleting document:", error);
      toast.error("Erro ao excluir documento");
    },
  });
}


// Update document description
export function useUpdateSinistroDocument() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ 
      id, 
      sinistroId, 
      descricao 
    }: { 
      id: string; 
      sinistroId: string; 
      descricao: string;
    }) => {
      const { data, error } = await supabase
        .from("sinistro_documents")
        .update({ descricao: descricao.trim() || null })
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["sinistro_documents", variables.sinistroId] });
      toast.success("Descrição atualizada");
    },
    onError: (error) => {
      console.error("Error updating document:", error);
      toast.error("Erro ao atualizar documento");
    },
  });
}

// Hook to get document URL (signed)
export function useSinistroDocumentUrl() {
  return useMutation({
    mutationFn: async (url: string): Promise<string> => {
      const filePath = extractFilePath(url);
      
      if (!filePath) {
        throw new Error("Caminho do arquivo inválido");
      }

      const signedUrl = await getSignedUrl(filePath);
      
      if (!signedUrl) {
        throw new Error("Não foi possível gerar URL de acesso");
      }

      return signedUrl;
    },
  });
}

// Helper to format file size
export function formatFileSize(bytes: number | null): string {
  if (!bytes) return "0 B";
  const units = ['B', 'KB', 'MB', 'GB'];
  let unitIndex = 0;
  let size = bytes;
  
  while (size >= 1024 && unitIndex < units.length - 1) {
    size /= 1024;
    unitIndex++;
  }
  
  return `${size.toFixed(1)} ${units[unitIndex]}`;
}

// Helper to get file icon type
export function getFileIconType(fileName: string): 'image' | 'pdf' | 'doc' | 'file' {
  const ext = fileName.split('.').pop()?.toLowerCase();
  if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext || '')) {
    return 'image';
  }
  if (ext === 'pdf') {
    return 'pdf';
  }
  if (['doc', 'docx'].includes(ext || '')) {
    return 'doc';
  }
  return 'file';
}
