import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface ClientPolicy {
  id: string;
  numero_apolice: string;
  produto_id: string;
  seguradora: string;
  data_inicio: string;
  data_fim: string;
  valor_premio: number;
  status: string;
  observacoes: string | null;
  produto?: {
    nome: string;
    categoria: string;
    comissao_percentual: number | null;
  };
}

export function useClientPolicies(clientId: string) {
  return useQuery({
    queryKey: ["client_policies", clientId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("apolices")
        .select(`
          id,
          numero_apolice,
          produto_id,
          seguradora,
          data_inicio,
          data_fim,
          valor_premio,
          status,
          observacoes,
          produto:produtos(nome, categoria, comissao_percentual)
        `)
        .eq("client_id", clientId)
        .is("deleted_at", null)
        .order("data_fim", { ascending: false });

      if (error) throw error;
      
      return data.map(item => ({
        ...item,
        produto: Array.isArray(item.produto) ? item.produto[0] : item.produto
      })) as ClientPolicy[];
    },
    enabled: !!clientId,
  });
}
