import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { isToday, isPast, parseISO } from "date-fns";
import { toast } from "sonner";

export type OperationType = "tarefa" | "anotação" | "follow-up" | "tip" | "lembrete";
export type OperationPriority = "alta" | "média" | "baixa";

export interface OperationalItem {
  id: string;
  type: OperationType;
  title: string;
  description: string;
  priority: OperationPriority;
  status: "pendente" | "concluido" | "atrasado";
  date: string;
  time?: string;
  client_id?: string;
  client_nome?: string;
  responsavel_id?: string;
  created_at: string;
}

export function useOperationalHub() {
  const queryClient = useQueryClient();

  // Fetch all operational items
  const { data: items, isLoading } = useQuery({
    queryKey: ["operational_items"],
    queryFn: async (): Promise<OperationalItem[]> => {
      const [tasksRes, notesRes, tipsRes] = await Promise.all([
        supabase.from("tasks").select(`*, clients(id, nome)`),
        supabase.from("user_notes").select(`*`),
        supabase.from("user_tips").select(`*`)
      ]);

      const tasks: OperationalItem[] = (tasksRes.data || []).map(t => {
        const prazoDate = t.prazo ? parseISO(t.prazo) : null;
        const status = t.status === "concluido" ? "concluido" : (prazoDate && isPast(prazoDate) && !isToday(prazoDate) ? "atrasado" : "pendente");
        
        return {
          id: t.id,
          type: "tarefa",
          title: t.titulo,
          description: t.descricao || "",
          priority: (t.prioridade as OperationPriority) || "média",
          status: status as any,
          date: t.prazo || t.created_at,
          client_id: t.clients?.id,
          client_nome: t.clients?.nome,
          created_at: t.created_at
        };
      });

      const notes: OperationalItem[] = (notesRes.data || []).map(n => ({
        id: n.id,
        type: "anotação",
        title: "Anotação rápida",
        description: n.conteudo,
        priority: "baixa",
        status: "concluido",
        date: n.created_at,
        created_at: n.created_at
      }));

      const tips: OperationalItem[] = (tipsRes.data || []).map(tip => ({
        id: tip.id,
        type: "tip",
        title: tip.titulo,
        description: tip.descricao || "",
        priority: "média",
        status: "pendente",
        date: tip.created_at,
        created_at: tip.created_at
      }));

      return [...tasks, ...notes, ...tips].sort((a, b) => 
        new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      );
    }
  });

  // Create Item Mutation
  const createItem = useMutation({
    mutationFn: async (item: Partial<OperationalItem>) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Não autenticado");

      if (item.type === "tarefa" || item.type === "follow-up") {
        const { error } = await supabase.from("tasks").insert({
          titulo: item.title,
          descricao: item.description,
          prioridade: item.priority || "média",
          status: "pendente",
          prazo: item.date,
          user_id: user.id,
          cliente_id: item.client_id
        });
        if (error) throw error;
      } else if (item.type === "anotação") {
        const { error } = await supabase.from("user_notes").insert({
          conteudo: item.description,
          user_id: user.id,
          visibilidade: "privada"
        });
        if (error) throw error;
      } else if (item.type === "tip") {
        const { error } = await supabase.from("user_tips").insert({
          titulo: item.title,
          descricao: item.description,
          user_id: user.id,
          ativo: true
        });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["operational_items"] });
      toast.success("Item registrado com sucesso");
    }
  });

  // Update Status
  const updateStatus = useMutation({
    mutationFn: async ({ id, status, type }: { id: string, status: string, type: OperationType }) => {
      if (type === "tarefa" || type === "follow-up") {
        const { error } = await supabase.from("tasks").update({ status }).eq("id", id);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["operational_items"] });
    }
  });

  const deleteItem = useMutation({
    mutationFn: async ({ id, type }: { id: string, type: OperationType }) => {
      let table = "";
      if (type === "tarefa" || type === "follow-up") table = "tasks";
      else if (type === "anotação") table = "user_notes";
      else if (type === "tip") table = "user_tips";

      if (table) {
        const { error } = await supabase.from(table).delete().eq("id", id);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["operational_items"] });
      toast.success("Item removido");
    }
  });

  return {
    items,
    isLoading,
    createItem,
    updateStatus,
    deleteItem
  };
}
