import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./useAuth";
import { 
  AppRole, 
  Resource, 
  Action, 
  hasPermission as checkPermission,
  canAccessResource as checkAccess,
  getAllowedActions as getActions
} from "@/lib/permissions";
import { useCallback } from "react";

export type { AppRole, Resource, Action };

/**
 * Hook to get the current user's role with refresh capability
 */
export function useUserRole() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: ["user_role", user?.id],
    queryFn: async () => {
      if (!user?.id) return null;

      // Hardcoded Super Admin check for owner
      // This ensures the owner always has access regardless of database state
      const masterEmails = ["nexusaionline@gmail.com", "comercial@medsafecorretora.com.br"];
      const userEmail = user.email?.toLowerCase();
      
      if (userEmail && masterEmails.some(email => email.toLowerCase() === userEmail)) {
        console.log("SafeOS Master User detected:", userEmail);
        return "owner" as AppRole;
      }

      const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .single();

      if (error) {
        // If no role found, user might not have been assigned one
        console.warn("No role found for user:", error.message);
        return null;
      }

      return data?.role as AppRole;
    },
    enabled: !!user?.id,
    staleTime: 30 * 1000, // 30 seconds - shorter for more responsive role changes
  });

  // Function to refresh the role immediately
  const refreshRole = useCallback(() => {
    if (user?.id) {
      queryClient.invalidateQueries({ queryKey: ["user_role", user.id] });
      queryClient.invalidateQueries({ queryKey: ["user_role"] });
    }
  }, [queryClient, user?.id]);

  return {
    ...query,
    refreshRole,
  };
}

/**
 * Hook to check if current user has a specific permission
 */
export function useHasPermission(resource: Resource, action: Action): boolean {
  const { data: role, isLoading } = useUserRole();
  
  // While loading, deny access (safe default)
  if (isLoading) return false;
  
  return checkPermission(role, resource, action);
}

/**
 * Hook to check if current user can access a resource
 */
export function useCanAccessResource(resource: Resource): boolean {
  const { data: role, isLoading } = useUserRole();
  
  if (isLoading) return false;
  
  return checkAccess(role, resource);
}

/**
 * Hook to get all allowed actions for current user on a resource
 */
export function useAllowedActions(resource: Resource): Action[] {
  const { data: role, isLoading } = useUserRole();
  
  if (isLoading) return [];
  
  return getActions(role, resource);
}

/**
 * Hook to check if user is admin
 */
export function useIsAdmin(): boolean {
  const { data: role } = useUserRole();
  return role === 'admin' || role === 'owner';
}

/**
 * Hook to check if user is admin or gestor
 */
export function useIsManager(): boolean {
  const { data: role } = useUserRole();
  return role === 'admin' || role === 'gestor' || role === 'owner';
}

/**
 * Combined hook for common permission checks
 */
export function usePermissions() {
  const { data: role, isLoading, refreshRole } = useUserRole();

  const can = useCallback((resource: Resource, action: Action) => {
    return checkPermission(role, resource, action);
  }, [role]);

  return {
    role,
    isLoading,
    isAdmin: role === 'admin' || role === 'owner',
    isManager: role === 'admin' || role === 'gestor' || role === 'owner',
    can,
    hasPermission: can,
    canAccess: (resource: Resource) => checkAccess(role, resource),
    getAllowed: (resource: Resource) => getActions(role, resource),
    refreshRole,
  };
}
