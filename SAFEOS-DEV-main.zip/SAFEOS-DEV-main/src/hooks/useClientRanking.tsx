import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { differenceInMonths, parseISO } from "date-fns";
import { getLtvSettings, calculateLtvValue } from "@/hooks/useLtvSettings";

export type RankingCriterion = 
  | "commission" 
  | "premium" 
  | "relationship" 
  | "ltv" 
  | "products" 
  | "expansion";

export interface RankedClient {
  id: string;
  nome: string;
  cidade: string;
  estado: string;
  status: string;
  totalPremium: number;
  totalCommission: number;
  productCount: number;
  products: string[];
  relationshipMonths: number;
  ltv: number;
  expansionPotential: number; // 0 to 100
}

export function useClientRanking(criterion: RankingCriterion = "commission", limit: number = 10) {
  return useQuery({
    queryKey: ["client_ranking", criterion, limit],
    queryFn: async (): Promise<RankedClient[]> => {
      // Fetch clients and active commission terms in parallel
      const [clientsResult, commissionsResult] = await Promise.all([
        supabase
          .from("clients")
          .select(`
            id, nome, cidade, estado, status, created_at,
            apolices (
              id, valor_premio, status, produto_id,
              produtos (nome, categoria, comissao_percentual)
            )
          `)
          .is("deleted_at", null),
        (async () => {
          try {
            const { data, error } = await supabase
              .from("client_commission_terms")
              .select("client_id, produto_id, percent, is_active")
              .eq("is_active", true);
            if (error) throw error;
            return { data, error: null };
          } catch (err) {
            console.warn("useClientRanking: Falling back to legacy client_commission_terms:", err);
            try {
              const { data, error } = await supabase
                .from("client_commission_terms")
                .select("client_id, percent, is_active")
                .eq("is_active", true);
              if (error) throw error;
              const mapped = (data || []).map(item => ({
                ...item,
                produto_id: null
              }));
              return { data: mapped, error: null };
            } catch (innerErr) {
              console.error("Critical error fetching commissions in useClientRanking details:", innerErr);
              return { data: [], error: innerErr };
            }
          }
        })()
      ]);

      if (clientsResult.error) throw clientsResult.error;
      if (commissionsResult.error) throw commissionsResult.error;

      const clients = clientsResult.data || [];
      const commissions = commissionsResult.data || [];
      const ltvSettings = getLtvSettings();

      const ranked: RankedClient[] = (clients || []).map(client => {
        const activeApolices = (client.apolices as unknown as Array<{ 
          id: string; 
          valor_premio: number; 
          status: string; 
          produto_id: string | null; 
          produtos: { nome: string | null; categoria: string | null; comissao_percentual: number | null } | null;
        }>)?.filter(a => a.status === 'ativa') || [];
        
        const totalPremium = activeApolices.reduce((sum, a) => sum + (a.valor_premio || 0), 0);
        
        // Calculate commission using client-specific commission agreements with fallback to product's default percent
        const totalCommission = activeApolices.reduce((sum, a) => {
          const matchedTerm = commissions.find(t => t.client_id === client.id && t.produto_id === a.produto_id)
            || commissions.find(t => t.client_id === client.id && t.produto_id === null);
          const pct = matchedTerm && matchedTerm.percent !== null ? matchedTerm.percent : (a.produtos?.comissao_percentual || 0);
          return sum + (a.valor_premio * (pct / 100));
        }, 0);

        const products = Array.from(new Set(activeApolices.map(a => a.produtos?.nome).filter(Boolean)));
        const categories = new Set(activeApolices.map(a => a.produtos?.categoria).filter(Boolean));
        
        const relationshipMonths = differenceInMonths(new Date(), parseISO(client.created_at));
        
        // LTV Projection using unified central settings
        const { projected: ltv } = calculateLtvValue(totalCommission, ltvSettings);

        // Expansion Potential: 100 - (20 points per unique category, max 5 categories)
        const expansionPotential = Math.max(0, 100 - (categories.size * 20));

        return {
          id: client.id,
          nome: client.nome,
          cidade: client.cidade || "N/I",
          estado: client.estado || "N/I",
          status: client.status,
          totalPremium,
          totalCommission,
          productCount: products.length,
          products,
          relationshipMonths,
          ltv,
          expansionPotential
        };
      });

      // Sort based on criterion
      return ranked.sort((a, b) => {
        switch (criterion) {
          case "commission": return b.totalCommission - a.totalCommission;
          case "premium": return b.totalPremium - a.totalPremium;
          case "relationship": return b.relationshipMonths - a.relationshipMonths;
          case "ltv": return b.ltv - a.ltv;
          case "products": return b.productCount - a.productCount;
          case "expansion": return b.expansionPotential - a.expansionPotential;
          default: return b.totalCommission - a.totalCommission;
        }
      }).slice(0, limit);
    }
  });
}
