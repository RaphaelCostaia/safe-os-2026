import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables, Json } from "@/integrations/supabase/types";

export type ActivityLog = Tables<"activity_log"> & {
  user_profile?: { full_name: string; email: string } | null;
};

export interface ActivityFilters {
  user_id?: string;
  entity_type?: string;
  action?: string;
  startDate?: string;
  endDate?: string;
  limit?: number;
}

/**
 * Hook to fetch activity logs with filters
 */
export function useActivityLog(filters?: ActivityFilters) {
  return useQuery({
    queryKey: ["activity_log", filters],
    queryFn: async () => {
      let query = supabase
        .from("activity_log")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(filters?.limit || 100);

      if (filters?.user_id) {
        query = query.eq("user_id", filters.user_id);
      }

      if (filters?.entity_type) {
        query = query.eq("entity_type", filters.entity_type);
      }

      if (filters?.action) {
        query = query.eq("action", filters.action);
      }

      if (filters?.startDate) {
        query = query.gte("created_at", filters.startDate);
      }

      if (filters?.endDate) {
        query = query.lte("created_at", filters.endDate);
      }

      const { data, error } = await query;

      if (error) throw error;

      // Fetch user profiles for each log entry
      const userIds = [...new Set(data.map(log => log.user_id).filter(Boolean))];
      
      let profiles: Record<string, { full_name: string; email: string }> = {};
      
      if (userIds.length > 0) {
        const { data: profilesData } = await supabase
          .from("profiles")
          .select("id, full_name, email")
          .in("id", userIds);
        
        if (profilesData) {
          profiles = profilesData.reduce((acc, p) => {
            acc[p.id] = { full_name: p.full_name, email: p.email };
            return acc;
          }, {} as Record<string, { full_name: string; email: string }>);
        }
      }

      // Merge profiles with logs
      const logsWithProfiles: ActivityLog[] = data.map(log => ({
        ...log,
        user_profile: log.user_id ? profiles[log.user_id] || null : null,
      }));

      return logsWithProfiles;
    },
    staleTime: 30 * 1000, // 30 seconds
  });
}

/**
 * Hook to get unique entity types from activity log
 */
export function useActivityEntityTypes() {
  return useQuery({
    queryKey: ["activity_log_entity_types"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("activity_log")
        .select("entity_type")
        .order("entity_type");

      if (error) throw error;

      // Get unique values
      const uniqueTypes = [...new Set(data.map((d) => d.entity_type))];
      return uniqueTypes;
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
}

/**
 * Hook to get unique actions from activity log
 */
export function useActivityActions() {
  return useQuery({
    queryKey: ["activity_log_actions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("activity_log")
        .select("action")
        .order("action");

      if (error) throw error;

      // Get unique values
      const uniqueActions = [...new Set(data.map((d) => d.action))];
      return uniqueActions;
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
}

/**
 * Helper function to log an activity
 * Can be called from anywhere in the app
 */
export async function logActivity(
  entityType: string,
  entityId: string,
  action: string,
  description: string,
  metadata?: Json
): Promise<void> {
  try {
    const {
      data: { user },
    } = await supabase.auth.getUser();

    await supabase.from("activity_log").insert({
      entity_type: entityType,
      entity_id: entityId,
      action,
      description,
      user_id: user?.id || null,
      metadata: metadata || null,
    });
  } catch (error) {
    console.error("Failed to log activity:", error);
    // Don't throw - activity logging should not break the app
  }
}

/**
 * Hook for creating activity log entries
 */
export function useLogActivity() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      entityType,
      entityId,
      action,
      description,
      metadata,
    }: {
      entityType: string;
      entityId: string;
      action: string;
      description: string;
      metadata?: Json;
    }) => {
      await logActivity(entityType, entityId, action, description, metadata);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["activity_log"] });
    },
  });
}

/**
 * Get icon for entity type
 */
export function getEntityTypeIcon(entityType: string): string {
  const icons: Record<string, string> = {
    client: "👤",
    apolice: "📄",
    sinistro: "⚠️",
    renovacao: "🔄",
    conta: "💰",
    team_member: "👥",
    user: "🔐",
    produto: "📦",
    comissao: "💵",
  };
  return icons[entityType] || "📋";
}

/**
 * Get human-readable action name
 */
export function getActionName(action: string): string {
  const names: Record<string, string> = {
    create: "Criação",
    update: "Atualização",
    delete: "Exclusão",
    status_change: "Alteração de status",
    assign: "Atribuição",
    login: "Login",
    logout: "Logout",
    export: "Exportação",
  };
  return names[action] || action;
}

/**
 * Get human-readable entity type name
 */
export function getEntityTypeName(entityType: string): string {
  const names: Record<string, string> = {
    client: "Cliente",
    apolice: "Apólice",
    sinistro: "Sinistro",
    renovacao: "Renovação",
    conta: "Conta",
    team_member: "Membro da Equipe",
    user: "Usuário",
    produto: "Produto",
    comissao: "Comissão",
  };
  return names[entityType] || entityType;
}
