import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { addDays, isBefore, isAfter, format } from "date-fns";

export interface Notification {
  id: string;
  type: "renovacao" | "sinistro" | "cliente" | "apolice" | "sistema";
  title: string;
  message: string;
  createdAt: Date;
  read: boolean;
  entityId?: string;
  entityType?: string;
  priority: "low" | "medium" | "high" | "urgent";
}

export function useNotifications() {
  const queryClient = useQueryClient();

  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ["notifications"],
    queryFn: async () => {
      const today = new Date();
      const in30Days = addDays(today, 30);
      const in7Days = addDays(today, 7);
      const notifications: Notification[] = [];

      // Buscar renovações próximas do vencimento
      const { data: renovacoes } = await supabase
        .from("renovacoes")
        .select(`
          id,
          data_vencimento,
          status,
          apolice:apolices(
            numero_apolice,
            client:clients(nome)
          )
        `)
        .eq("status", "pendente")
        .lte("data_vencimento", format(in30Days, "yyyy-MM-dd"))
        .gte("data_vencimento", format(today, "yyyy-MM-dd"));

      renovacoes?.forEach((r: any) => {
        const vencimento = new Date(r.data_vencimento);
        const isUrgent = isBefore(vencimento, in7Days);
        notifications.push({
          id: `renovacao-${r.id}`,
          type: "renovacao",
          title: isUrgent ? "Renovação Urgente" : "Renovação Pendente",
          message: `Apólice ${r.apolice?.numero_apolice} de ${r.apolice?.client?.nome} vence em ${format(vencimento, "dd/MM/yyyy")}`,
          createdAt: new Date(),
          read: false,
          entityId: r.id,
          entityType: "renovacao",
          priority: isUrgent ? "urgent" : "medium",
        });
      });

      // Buscar sinistros abertos críticos
      const { data: sinistros } = await supabase
        .from("sinistros")
        .select(`
          id,
          numero_sinistro,
          criticidade,
          status,
          descricao_resumida,
          client:clients(nome)
        `)
        .in("status", ["aberto", "em_analise"])
        .in("criticidade", ["alta", "critica"]);

      sinistros?.forEach((s: any) => {
        notifications.push({
          id: `sinistro-${s.id}`,
          type: "sinistro",
          title: s.criticidade === "critica" ? "Sinistro Crítico" : "Sinistro Prioritário",
          message: `${s.numero_sinistro}: ${s.descricao_resumida} - ${s.client?.nome}`,
          createdAt: new Date(),
          read: false,
          entityId: s.id,
          entityType: "sinistro",
          priority: s.criticidade === "critica" ? "urgent" : "high",
        });
      });

      // Buscar atividades recentes (últimas 24h)
      const yesterday = new Date(today.getTime() - 24 * 60 * 60 * 1000);
      const { data: activities } = await supabase
        .from("activity_log")
        .select("*")
        .gte("created_at", yesterday.toISOString())
        .order("created_at", { ascending: false })
        .limit(5);

      activities?.forEach((a) => {
        notifications.push({
          id: `activity-${a.id}`,
          type: a.entity_type === "client" ? "cliente" : "apolice",
          title: a.action === "create" ? "Novo Registro" : "Atualização",
          message: a.description || `${a.entity_type} ${a.action}`,
          createdAt: new Date(a.created_at),
          read: false,
          entityId: a.entity_id,
          entityType: a.entity_type,
          priority: "low",
        });
      });

      // Ordenar por prioridade e data
      const priorityOrder = { urgent: 0, high: 1, medium: 2, low: 3 };
      return notifications.sort((a, b) => {
        const priorityDiff = priorityOrder[a.priority] - priorityOrder[b.priority];
        if (priorityDiff !== 0) return priorityDiff;
        return b.createdAt.getTime() - a.createdAt.getTime();
      });
    },
    refetchInterval: 60000, // Atualiza a cada minuto
  });

  const unreadCount = notifications.filter((n) => !n.read).length;
  const urgentCount = notifications.filter((n) => n.priority === "urgent").length;

  return {
    notifications,
    isLoading,
    unreadCount,
    urgentCount,
  };
}
