import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";

export interface ClientCommissionTerm {
  id: string;
  client_id: string;
  produto_id: string | null;
  model: "percentual" | "fixo" | "misto";
  percent: number | null;
  fixed_amount: number | null;
  starts_at: string | null;
  ends_at: string | null;
  notes: string | null;
  is_active: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface ClientCommissionTermInsert {
  client_id: string;
  produto_id?: string | null;
  model: "percentual" | "fixo" | "misto";
  percent?: number | null;
  fixed_amount?: number | null;
  starts_at?: string | null;
  notes?: string | null;
  is_active?: boolean;
  created_by?: string | null;
}

export interface ClientCommissionTermUpdate {
  model?: "percentual" | "fixo" | "misto";
  percent?: number | null;
  fixed_amount?: number | null;
  starts_at?: string | null;
  notes?: string | null;
  is_active?: boolean;
  produto_id?: string | null;
}

export function normalizeCommissionTerm(term: any): ClientCommissionTerm {
  if (!term) return term;
  
  const model = term.model || (term.type ? (term.type === "percentual" || term.type === "percent" || term.type === "fixo" || term.type === "misto" ? (term.type === "percent" ? "percentual" : term.type) : "percentual") : "percentual");
  
  let percent = term.percent;
  let fixed_amount = term.fixed_amount;
  
  if (percent === undefined || percent === null) {
    if (model === "percentual" || model === "misto") {
      percent = term.value || null;
    }
  }
  
  if (fixed_amount === undefined || fixed_amount === null) {
    if (model === "fixo" || model === "misto") {
      fixed_amount = term.value || null;
    }
  }
  
  return {
    ...term,
    model,
    percent: percent ? parseFloat(percent) : null,
    fixed_amount: fixed_amount ? parseFloat(fixed_amount) : null,
    notes: term.notes !== undefined && term.notes !== null ? term.notes : term.description,
  } as ClientCommissionTerm;
}

// Get active commission for a client (with optional specific product)
export function useClientCommission(clientId: string, produtoId?: string | null) {
  return useQuery({
    queryKey: ["client_commission", clientId, produtoId],
    queryFn: async () => {
      try {
        const query = supabase
          .from("client_commission_terms")
          .select(`
            *,
            produtos (id, nome, categoria)
          `)
          .eq("client_id", clientId)
          .eq("is_active", true);

        if (produtoId) {
          // Look for terms for this specific product, or fallback to general null terms
          const { data, error } = await query
            .or(`produto_id.eq.${produtoId},produto_id.is.null`)
            .order("produto_id", { ascending: false }) // Put specific product_id (non-null) first!
            .order("created_at", { ascending: false });

          if (error) throw error;
          const raw = data?.[0] || null;
          if (!raw) return null;
          return {
            ...normalizeCommissionTerm(raw),
            produtos: (raw as any).produtos
          } as any;
        } else {
          const { data, error } = await query
            .is("produto_id", null)
            .order("created_at", { ascending: false })
            .limit(1)
            .maybeSingle();

          if (error) throw error;
          if (!data) return null;
          return {
            ...normalizeCommissionTerm(data),
            produtos: (data as any).produtos
          } as any;
        }
      } catch (err: any) {
        console.warn("Falling back to legacy layout for useClientCommission due to schema mismatch:", err);
        const { data, error } = await supabase
          .from("client_commission_terms")
          .select(`
            id,
            client_id,
            model,
            percent,
            fixed_amount,
            starts_at,
            ends_at,
            notes,
            is_active,
            created_by,
            created_at,
            updated_at
          `)
          .eq("client_id", clientId)
          .eq("is_active", true)
          .order("created_at", { ascending: false });

        if (error) throw error;
        const res = data && data.length > 0 ? data[0] : null;
        if (!res) return null;
        return normalizeCommissionTerm(res);
      }
    },
    enabled: !!clientId,
  });
}

// Get all active commissions for a client
export function useClientActiveCommissions(clientId: string) {
  return useQuery({
    queryKey: ["client_active_commissions", clientId],
    queryFn: async () => {
      try {
        const { data, error } = await supabase
          .from("client_commission_terms")
          .select(`
            *,
            produtos (id, nome, categoria)
          `)
          .eq("client_id", clientId)
          .eq("is_active", true)
          .order("created_at", { ascending: false });

        if (error) throw error;
        return (data || []).map(raw => ({
          ...normalizeCommissionTerm(raw),
          produtos: (raw as any).produtos
        })) as any;
      } catch (err: any) {
        console.warn("Falling back to legacy layout for useClientActiveCommissions due to schema mismatch:", err);
        const { data, error } = await supabase
          .from("client_commission_terms")
          .select(`
            id,
            client_id,
            model,
            percent,
            fixed_amount,
            starts_at,
            ends_at,
            notes,
            is_active,
            created_by,
            created_at,
            updated_at
          `)
          .eq("client_id", clientId)
          .eq("is_active", true)
          .order("created_at", { ascending: false });

        if (error) throw error;
        return (data || []).map(raw => normalizeCommissionTerm(raw)) as any;
      }
    },
    enabled: !!clientId,
  });
}

// Get full commission history for a client
export function useClientCommissionHistory(clientId: string) {
  return useQuery({
    queryKey: ["client_commission_history", clientId],
    queryFn: async () => {
      let terms: any[] = [];
      try {
        const { data, error } = await supabase
          .from("client_commission_terms")
          .select(`
            *,
            produtos (id, nome, categoria)
          `)
          .eq("client_id", clientId)
          .order("created_at", { ascending: false });

        if (error) throw error;
        terms = data || [];
      } catch (err: any) {
        console.warn("Falling back to legacy layout for useClientCommissionHistory due to schema mismatch:", err);
        const { data, error } = await supabase
          .from("client_commission_terms")
          .select(`
            id,
            client_id,
            model,
            percent,
            fixed_amount,
            starts_at,
            ends_at,
            notes,
            is_active,
            created_by,
            created_at,
            updated_at
          `)
          .eq("client_id", clientId)
          .order("created_at", { ascending: false });

        if (error) throw error;
        terms = data || [];
      }

      // Fetch profile names for created_by users
      const userIds = [...new Set(terms.filter(t => t.created_by).map(t => t.created_by) || [])];
      let profilesMap: Record<string, string> = {};
      
      if (userIds.length > 0) {
        const { data: profiles } = await supabase
          .from("profiles")
          .select("id, full_name")
          .in("id", userIds as string[]);
        
        if (profiles) {
          profilesMap = profiles.reduce((acc, p) => ({ ...acc, [p.id]: p.full_name }), {});
        }
      }

      return terms.map(term => {
        const normalized = normalizeCommissionTerm(term);
        return {
          ...normalized,
          produtos: term.produtos || null,
          profiles: term.created_by ? { full_name: profilesMap[term.created_by] || "Usuário" } : null,
        };
      }) as any;
    },
    enabled: !!clientId,
  });
}

export function useCreateClientCommission() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (data: ClientCommissionTermInsert) => {
      // First, deactivate any existing active terms of the EXACT SAME product (or generic) and set ends_at
      const now = new Date().toISOString().split('T')[0];
      try {
        let deactivateQuery = supabase
          .from("client_commission_terms")
          .update({ is_active: false, ends_at: now })
          .eq("client_id", data.client_id)
          .eq("is_active", true);

        if (data.produto_id) {
          deactivateQuery = deactivateQuery.eq("produto_id", data.produto_id);
        } else {
          deactivateQuery = deactivateQuery.is("produto_id", null);
        }

        await deactivateQuery;
      } catch (deactError) {
        console.warn("Deactivation with product filter failed, falling back to simple client-level deactivation:", deactError);
        try {
          await supabase
            .from("client_commission_terms")
            .update({ is_active: false, ends_at: now })
            .eq("client_id", data.client_id)
            .eq("is_active", true);
        } catch (innerDeact) {
          console.error("Simple client deactivation failed too:", innerDeact);
        }
      }

      // Extract details for the dual-write payload to satisfy any table schema layout (original vs updated)
      const modelVal = data.model;
      const percentVal = data.percent !== undefined && data.percent !== null ? Number(data.percent) : null;
      const fixedAmountVal = data.fixed_amount !== undefined && data.fixed_amount !== null ? Number(data.fixed_amount) : null;
      // In updated layout: value represents either percent or fixed amount depending on model type
      const valueVal = modelVal === "fixo" ? fixedAmountVal : percentVal;
      const notesVal = data.notes || null;
      const startsAtVal = data.starts_at && typeof data.starts_at === "string" && data.starts_at.trim() !== "" ? data.starts_at : now;

      // Fully-populated dual-write payload to satisfy all possible schema restraints and triggers simultaneously
      const unifiedPayload = {
        client_id: data.client_id,
        produto_id: data.produto_id || null,
        model: modelVal,               // Old format property
        type: modelVal,                 // New format property cast-compatible
        percent: percentVal,           // Old format property
        fixed_amount: fixedAmountVal,   // Old format property
        value: valueVal,               // New format property (NOT NULL exception safe)
        notes: notesVal,               // Old format property
        description: notesVal,         // New format property
        starts_at: startsAtVal,
        is_active: true,
        created_by: user?.id || null,
      };

      let newTerm;
      try {
        // Attempt 1: Fully-populated unified layout (all columns)
        const { data: newRow, error = null } = await supabase
          .from("client_commission_terms")
          .insert(unifiedPayload)
          .select()
          .single();

        if (error) throw error;
        newTerm = newRow;
      } catch (firstError) {
        console.warn("Attempt 1 (all columns) failed. Trying Fallback 2 (without produto_id)...", firstError);
        
        try {
          // Attempt 2: Unified payload WITHOUT 'produto_id'
          const unifiedWithoutProduto = { ...unifiedPayload };
          delete (unifiedWithoutProduto as any).produto_id;
          
          const { data: row2, error: err2 } = await supabase
            .from("client_commission_terms")
            .insert(unifiedWithoutProduto)
            .select()
            .single();

          if (err2) throw err2;
          newTerm = row2;
        } catch (error2) {
          console.warn("Attempt 2 (unified without pruto_id) failed. Trying Fallback 3 (legacy fallback without product and compatible columns)...", error2);
          
          try {
            // Attempt 3: Original/legacy columns only (WITHOUT 'produto_id', without 'type'/'value'/'description')
            const legacyWithoutProduto = {
              client_id: data.client_id,
              model: modelVal,
              percent: percentVal,
              fixed_amount: fixedAmountVal,
              starts_at: startsAtVal,
              notes: notesVal,
              is_active: true,
              created_by: user?.id || null,
            };
            const { data: row3, error: err3 } = await supabase
              .from("client_commission_terms")
              .insert(legacyWithoutProduto)
              .select()
              .single();

            if (err3) throw err3;
            newTerm = row3;
          } catch (error3) {
            console.warn("Attempt 3 (legacy without product) failed. Trying Fallback 4 (original full legacy schema)...", error3);
            
            try {
              // Attempt 4: Original legacy schema with 'produto_id'
              const legacyWithProduto = {
                client_id: data.client_id,
                produto_id: data.produto_id || null,
                model: modelVal,
                percent: percentVal,
                fixed_amount: fixedAmountVal,
                starts_at: startsAtVal,
                notes: notesVal,
                is_active: true,
                created_by: user?.id || null,
              };
              const { data: row4, error: err4 } = await supabase
                .from("client_commission_terms")
                .insert(legacyWithProduto)
                .select()
                .single();

              if (err4) throw err4;
              newTerm = row4;
            } catch (error4: any) {
              console.error("Definitive write failure for client_commission_terms:", error4);
              throw error4;
            }
          }
        }
      }

      return newTerm;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["client_commission", variables.client_id] });
      queryClient.invalidateQueries({ queryKey: ["client_active_commissions", variables.client_id] });
      queryClient.invalidateQueries({ queryKey: ["client_commission_history", variables.client_id] });
      queryClient.invalidateQueries({ queryKey: ["all_commissions"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard_commission_metrics"] });
      toast.success("Acordo de comissão salvo com sucesso");
    },
    onError: (error: any) => {
      console.error("Erro ao salvar acordo:", error);
      const msg = error?.message || error?.details || JSON.stringify(error);
      toast.error(`Erro ao salvar acordo de comissão: ${msg}`);
    },
  });
}

export function useUpdateClientCommission() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async ({ id, clientId, data }: { id: string; clientId: string; data: ClientCommissionTermUpdate }) => {
      // Instead of updating, we create a new record and deactivate the old one
      // This maintains full history
      const now = new Date().toISOString().split('T')[0];
      
      // Deactivate the current term
      await supabase
        .from("client_commission_terms")
        .update({ is_active: false, ends_at: now })
        .eq("id", id);

      // Extract details for the dual-write payload to satisfy any table schema layout (original vs updated)
      const modelVal = data.model!;
      const percentVal = data.percent !== undefined && data.percent !== null ? Number(data.percent) : null;
      const fixedAmountVal = data.fixed_amount !== undefined && data.fixed_amount !== null ? Number(data.fixed_amount) : null;
      // In updated layout: value represents either percent or fixed amount depending on model type
      const valueVal = modelVal === "fixo" ? fixedAmountVal : percentVal;
      const notesVal = data.notes || null;
      const startsAtVal = data.starts_at && typeof data.starts_at === "string" && data.starts_at.trim() !== "" ? data.starts_at : now;

      // Fully-populated dual-write payload to satisfy all possible schema restraints and triggers simultaneously
      const unifiedPayload = {
        client_id: clientId,
        produto_id: data.produto_id || null,
        model: modelVal,               // Old format property
        type: modelVal,                 // New format property cast-compatible
        percent: percentVal,           // Old format property
        fixed_amount: fixedAmountVal,   // Old format property
        value: valueVal,               // New format property (NOT NULL exception safe)
        notes: notesVal,               // Old format property
        description: notesVal,         // New format property
        starts_at: startsAtVal,
        is_active: true,
        created_by: user?.id || null,
      };

      let newTerm;
      try {
        // Attempt 1: Fully-populated unified layout (all columns)
        const { data: newRow, error = null } = await supabase
          .from("client_commission_terms")
          .insert(unifiedPayload)
          .select()
          .single();

        if (error) throw error;
        newTerm = newRow;
      } catch (firstError) {
        console.warn("Attempt 1 (all columns updating) failed. Trying Fallback 2 (without produto_id)...", firstError);
        
        try {
          // Attempt 2: Unified payload WITHOUT 'produto_id'
          const unifiedWithoutProduto = { ...unifiedPayload };
          delete (unifiedWithoutProduto as any).produto_id;
          
          const { data: row2, error: err2 } = await supabase
            .from("client_commission_terms")
            .insert(unifiedWithoutProduto)
            .select()
            .single();

          if (err2) throw err2;
          newTerm = row2;
        } catch (error2) {
          console.warn("Attempt 2 (updating without product) failed. Trying Fallback 3 (legacy updates without incompatible columns)...", error2);
          
          try {
            // Attempt 3: Original/legacy columns only (WITHOUT 'produto_id', without 'type'/'value'/'description')
            const legacyWithoutProduto = {
              client_id: clientId,
              model: modelVal,
              percent: percentVal,
              fixed_amount: fixedAmountVal,
              starts_at: startsAtVal,
              notes: notesVal,
              is_active: true,
              created_by: user?.id || null,
            };
            const { data: row3, error: err3 } = await supabase
              .from("client_commission_terms")
              .insert(legacyWithoutProduto)
              .select()
              .single();

            if (err3) throw err3;
            newTerm = row3;
          } catch (error3) {
            console.warn("Attempt 3 (updating legacy without product) failed. Trying Fallback 4 (legacy schema updates with product)...", error3);
            
            try {
              // Attempt 4: Original legacy schema with 'produto_id'
              const legacyWithProduto = {
                client_id: clientId,
                produto_id: data.produto_id || null,
                model: modelVal,
                percent: percentVal,
                fixed_amount: fixedAmountVal,
                starts_at: startsAtVal,
                notes: notesVal,
                is_active: true,
                created_by: user?.id || null,
              };
              const { data: row4, error: err4 } = await supabase
                .from("client_commission_terms")
                .insert(legacyWithProduto)
                .select()
                .single();

              if (err4) throw err4;
              newTerm = row4;
            } catch (error4: any) {
              console.error("Definitive write failure for client_commission_terms update:", error4);
              throw error4;
            }
          }
        }
      }

      return newTerm;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["client_commission", variables.clientId] });
      queryClient.invalidateQueries({ queryKey: ["client_active_commissions", variables.clientId] });
      queryClient.invalidateQueries({ queryKey: ["client_commission_history", variables.clientId] });
      queryClient.invalidateQueries({ queryKey: ["all_commissions"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard_commission_metrics"] });
      toast.success("Acordo de comissão atualizado");
    },
    onError: (error: any) => {
      console.error("Erro ao atualizar acordo:", error);
      const msg = error?.message || error?.details || JSON.stringify(error);
      toast.error(`Erro ao atualizar acordo de comissão: ${msg}`);
    },
  });
}

// Get all active commissions (for Dashboard metrics)
export function useAllActiveCommissions() {
  return useQuery({
    queryKey: ["all_commissions"],
    queryFn: async () => {
      try {
        const { data, error } = await supabase
          .from("client_commission_terms")
          .select("*")
          .eq("is_active", true);

        if (error) throw error;
        return (data || []).map(normalizeCommissionTerm) as ClientCommissionTerm[];
      } catch (err) {
        console.warn("useAllActiveCommissions with select * failed, falling back to legacy layout column list:", err);
        const { data, error } = await supabase
          .from("client_commission_terms")
          .select(`
            id,
            client_id,
            model,
            percent,
            fixed_amount,
            starts_at,
            ends_at,
            notes,
            is_active,
            created_by,
            created_at,
            updated_at
          `)
          .eq("is_active", true);

        if (error) throw error;
        return (data || []).map(raw => normalizeCommissionTerm(raw)) as ClientCommissionTerm[];
      }
    },
  });
}

export function formatCommissionDisplay(term: ClientCommissionTerm | null): string {
  if (!term) return "Não definido";
  
  switch (term.model) {
    case "percentual":
      return `${term.percent}% sobre prêmio`;
    case "fixo":
      return `R$ ${term.fixed_amount?.toLocaleString("pt-BR", { minimumFractionDigits: 2 })} fixo por apólice`;
    case "misto":
      return `${term.percent}% + R$ ${term.fixed_amount?.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`;
    default:
      return "Não definido";
  }
}

export function formatCommissionShort(term: ClientCommissionTerm | null): string {
  if (!term) return "—";
  
  switch (term.model) {
    case "percentual":
      return `${term.percent}%`;
    case "fixo":
      return `R$ ${term.fixed_amount?.toLocaleString("pt-BR", { minimumFractionDigits: 0 })}`;
    case "misto":
      return `${term.percent}% + R$${term.fixed_amount?.toLocaleString("pt-BR", { minimumFractionDigits: 0 })}`;
    default:
      return "—";
  }
}
