import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { assertAffectedRows } from "@/lib/supabaseMutationUtils";

export type NoteVisibility = "pessoal" | "equipe";

export interface UserNote {
  id: string;
  user_id: string;
  conteudo: string;
  tags: string[];
  visibilidade: NoteVisibility;
  created_at: string;
  updated_at: string;
}

export interface UserNoteInsert {
  conteudo: string;
  tags?: string[];
  visibilidade?: NoteVisibility;
}

export interface UserNoteUpdate {
  id: string;
  conteudo?: string;
  tags?: string[];
  visibilidade?: NoteVisibility;
}

export function useUserNotes() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["user_notes", user?.id],
    queryFn: async () => {
      if (!user?.id) return [];

      const { data, error } = await supabase
        .from("user_notes")
        .select("*")
        .or(`user_id.eq.${user.id},visibilidade.eq.equipe`)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as UserNote[];
    },
    enabled: !!user?.id,
  });
}

export function useCreateUserNote() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (note: UserNoteInsert) => {
      if (!user?.id) throw new Error("Usuário não autenticado");

      const { data, error } = await supabase
        .from("user_notes")
        .insert({
          user_id: user.id,
          conteudo: note.conteudo,
          tags: note.tags || [],
          visibilidade: note.visibilidade || "pessoal",
        })
        .select()
        .single();

      if (error) throw error;
      return data as UserNote;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user_notes"] });
      toast.success("Anotação criada!");
    },
    onError: (error) => {
      console.error("Erro ao criar anotação:", error);
      toast.error("Erro ao criar anotação");
    },
  });
}

export function useUpdateUserNote() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (note: UserNoteUpdate) => {
      const { id, ...updateData } = note;

      const { data, error } = await supabase
        .from("user_notes")
        .update(updateData)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return data as UserNote;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user_notes"] });
      toast.success("Anotação atualizada!");
    },
    onError: (error) => {
      console.error("Erro ao atualizar anotação:", error);
      toast.error("Erro ao atualizar anotação");
    },
  });
}

export function useDeleteUserNote() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (noteId: string) => {
      const { data, error, count } = await supabase
        .from("user_notes")
        .delete({ count: "exact" })
        .eq("id", noteId)
        .select("id");

      if (error) throw error;

      assertAffectedRows(
        { count, data },
        "Falha ao excluir anotação (permissão insuficiente ou registro não encontrado)"
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user_notes"] });
      toast.success("Anotação excluída!");
    },
    onError: (error) => {
      console.error("Erro ao excluir anotação:", error);
      toast.error("Erro ao excluir anotação");
    },
  });
}

