import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { STATE_POSITIONS, isValidUF, normalizeUF } from "@/data/brazilGeoData";

export interface ClientLocationData {
  uf: string;
  cidade: string;
  count: number;
  revenue: number;
  topProducts: Record<string, number>;
  profissoes: string[];
  statuses: string[];
  x: number;
  y: number;
  isApproximate: boolean;
}

export interface MapFilters {
  profissao?: string | null;
  status?: string | null;
  tipo_pessoa?: string | null;
  produto_id?: string | null;
  cidade?: string | null;
}

export function useClientMapData(filters?: MapFilters) {
  return useQuery({
    queryKey: ["client_map_data", filters],
    queryFn: async (): Promise<{
      byState: Record<string, { 
        count: number; 
        revenue: number; 
        topProducts: Array<{ name: string; count: number }>;
        topCities: Array<{ name: string; count: number; revenue: number }>;
        cities: ClientLocationData[] 
      }>;
      totalClients: number;
      totalRevenue: number;
      locations: ClientLocationData[];
    }> => {
      let query = supabase
        .from("clients")
        .select(`
          id, cidade, estado, profissao, status, tipo_pessoa,
          apolices (
            id,
            valor_premio,
            produto_id,
            deleted_at,
            produtos (nome)
          )
        `)
        .not("estado", "is", null)
        .is("deleted_at", null);

      if (filters?.status && filters.status !== "all") query = query.eq("status", filters.status);
      if (filters?.tipo_pessoa && filters.tipo_pessoa !== "all") query = query.eq("tipo_pessoa", filters.tipo_pessoa);
      if (filters?.profissao && filters.profissao !== "all") query = query.ilike("profissao", `%${filters.profissao}%`);
      if (filters?.cidade) query = query.ilike("cidade", `%${filters.cidade}%`);

      const { data: clients, error } = await query;
      if (error) throw error;

      let filteredClients = clients || [];

      // Filter by product if requested (Supabase join filtering can be tricky, so we do it here if needed)
      if (filters?.produto_id && filters.produto_id !== "all") {
        filteredClients = filteredClients.filter(c => 
          c.apolices?.some((ap: any) => ap.produto_id === filters.produto_id && ap.deleted_at === null)
        );
      }

      interface StateAggData {
        count: number;
        revenue: number;
        policiesCount: number;
        productCount: Record<string, number>;
        cityAgg: Record<string, { count: number; revenue: number; policiesCount: number }>;
        cities: ClientLocationData[];
      }

      const stateAgg: Record<string, StateAggData> = {};
      let totalRev = 0;
      let totalPoliciesCount = 0;

      filteredClients.forEach((client) => {
        if (!client.estado || !isValidUF(client.estado)) return;
        
        const uf = normalizeUF(client.estado);
        const city = client.cidade?.trim() || "Não informada";
        
        if (!stateAgg[uf]) {
          stateAgg[uf] = {
            count: 0,
            revenue: 0,
            policiesCount: 0,
            productCount: {},
            cityAgg: {},
            cities: []
          };
        }

        const state = stateAgg[uf];
        
        let clientRev = 0;
        const seenPolicyIds = new Set<string>();
        
        const activeApolices = (client.apolices || []).filter((ap: any) => {
          if (!ap) return false;
          if (ap.deleted_at !== null) return false;
          if (seenPolicyIds.has(ap.id)) return false;
          seenPolicyIds.add(ap.id);
          return true;
        });

        // Skip adding the client or incrementing counts if they don't have any active policies (except if filtering for prospects)
        // We always count the client if they are in the filtered set.
        state.count += 1;
        state.policiesCount += activeApolices.length;
        totalPoliciesCount += activeApolices.length;

        activeApolices.forEach((ap: any) => {
          const prem = ap.valor_premio || 0;
          clientRev += prem;
          const prodName = ap.produtos?.nome || "Outros";
          state.productCount[prodName] = (state.productCount[prodName] || 0) + 1;
        });

        state.revenue += clientRev;
        totalRev += clientRev;

        if (!state.cityAgg[city]) {
          state.cityAgg[city] = { count: 0, revenue: 0, policiesCount: 0 };
        }
        state.cityAgg[city].count += 1;
        state.cityAgg[city].revenue += clientRev;
        state.cityAgg[city].policiesCount += activeApolices.length;
      });

      // Format for the component
      interface StateResult {
        count: number;
        revenue: number;
        policiesCount: number;
        topProducts: Array<{ name: string; count: number }>;
        topCities: Array<{ name: string; count: number; revenue: number; policiesCount: number }>;
        cities: ClientLocationData[];
      }
      const byState: Record<string, StateResult> = {};
      const locations: ClientLocationData[] = [];

      Object.entries(stateAgg).forEach(([uf, data]) => {
        const topProducts = Object.entries(data.productCount)
          .map(([name, count]) => ({ name, count: count as number }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 5);

        const topCities = Object.entries(data.cityAgg)
          .map(([name, stats]) => ({ name, count: stats.count, revenue: stats.revenue, policiesCount: stats.policiesCount }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 5);

        const statePos = STATE_POSITIONS.find(s => s.uf === uf);
        
        byState[uf] = {
          count: data.count,
          revenue: data.revenue,
          policiesCount: data.policiesCount,
          topProducts,
          topCities,
          cities: [] // Simplified for now
        };

        // For pins on map (simplified city dots)
        topCities.forEach((city, i) => {
          const cityHash = city.name.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
          locations.push({
            uf,
            cidade: city.name,
            count: city.count, // this remains client count in city
            revenue: city.revenue,
            topProducts: {}, // per city breakdown could be added
            profissoes: [],
            statuses: [],
            x: statePos ? statePos.x + (i * 5) - 10 : 300,
            y: statePos ? statePos.y + (i * 3) - 5 : 300,
            isApproximate: false
          });
        });
      });

      return {
        byState,
        totalClients: filteredClients.length,
        totalRevenue: totalRev,
        totalPolicies: totalPoliciesCount,
        locations
      };
    },
    staleTime: 30 * 1000,
  });
}

// Get unique professions from clients for filter dropdown
export function useClientProfessions() {
  return useQuery({
    queryKey: ["client_professions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("clients")
        .select("profissao")
        .not("profissao", "is", null);

      if (error) throw error;

      const professions = [...new Set(data?.map(c => c.profissao).filter(Boolean) || [])];
      return professions.sort();
    },
  });
}
