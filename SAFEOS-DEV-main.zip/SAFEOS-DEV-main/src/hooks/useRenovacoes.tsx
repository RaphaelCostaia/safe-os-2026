import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/types";
import { toast } from "sonner";
import { invalidateEntityQueries } from "@/lib/queryInvalidation";
import { assertAffectedRows } from "@/lib/supabaseMutationUtils";

export type Renovacao = Tables<"renovacoes">;
export type RenovacaoInsert = TablesInsert<"renovacoes">;
export type RenovacaoUpdate = TablesUpdate<"renovacoes">;

export type RenovacaoWithRelations = Renovacao & {
  apolices?: { 
    numero_apolice: string; 
    seguradora: string;
    valor_premio: number;
    data_inicio: string;
    data_fim: string;
    clients?: { nome: string; email: string | null; telefone: string | null } | null;
    produtos?: { nome: string } | null;
  } | null;
};

export function useRenovacoes() {
  return useQuery({
    queryKey: ["renovacoes"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("renovacoes")
        .select(`
          *,
          apolices (
            numero_apolice, 
            seguradora, 
            valor_premio,
            data_inicio,
            data_fim,
            clients (nome, email, telefone),
            produtos (nome)
          )
        `)
        .order("data_vencimento", { ascending: true });
      
      if (error) throw error;
      return data as RenovacaoWithRelations[];
    },
  });
}

export function useRenovacao(id: string) {
  return useQuery({
    queryKey: ["renovacoes", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("renovacoes")
        .select(`
          *,
          apolices (
            numero_apolice, 
            seguradora, 
            valor_premio,
            clients (nome, email, telefone),
            produtos (nome, categoria)
          )
        `)
        .eq("id", id)
        .single();
      
      if (error) throw error;
      return data as RenovacaoWithRelations;
    },
    enabled: !!id,
  });
}

export function useCreateRenovacao() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (renovacao: RenovacaoInsert) => {
      const { data, error } = await supabase
        .from("renovacoes")
        .insert(renovacao)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      invalidateEntityQueries(queryClient, "renovacoes");
      toast.success("Renovação criada com sucesso!");
    },
    onError: (error) => {
      toast.error("Erro ao criar renovação: " + error.message);
    },
  });
}

export function useUpdateRenovacao() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...renovacao }: RenovacaoUpdate & { id: string }) => {
      const { data, error } = await supabase
        .from("renovacoes")
        .update(renovacao)
        .eq("id", id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      invalidateEntityQueries(queryClient, "renovacoes");
      toast.success("Renovação atualizada com sucesso!");
    },
    onError: (error) => {
      toast.error("Erro ao atualizar renovação: " + error.message);
    },
  });
}

export function useDeleteRenovacao() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { data, error, count } = await supabase
        .from("renovacoes")
        .delete({ count: "exact" })
        .eq("id", id)
        .select("id");
      
      if (error) throw error;

      assertAffectedRows(
        { count, data },
        "Falha ao excluir renovação (permissão insuficiente ou registro não encontrado)"
      );
    },
    onMutate: async (id: string) => {
      await queryClient.cancelQueries({ queryKey: ["renovacoes"] });
      const previousRenovacoes = queryClient.getQueryData<RenovacaoWithRelations[]>(["renovacoes"]);
      
      if (previousRenovacoes) {
        queryClient.setQueryData<RenovacaoWithRelations[]>(
          ["renovacoes"],
          previousRenovacoes.filter(r => r.id !== id)
        );
      }
      
      return { previousRenovacoes };
    },
    onError: (error, _id, context) => {
      if (context?.previousRenovacoes) {
        queryClient.setQueryData(["renovacoes"], context.previousRenovacoes);
      }
      toast.error("Erro ao excluir renovação: " + error.message);
    },
    onSuccess: () => {
      toast.success("Renovação excluída com sucesso!");
      invalidateEntityQueries(queryClient, "renovacoes");
    },
  });
}

