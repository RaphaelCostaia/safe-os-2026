import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { differenceInDays } from "date-fns";

export interface SystemCalculatedMetrics {
  tempoPermanencia: number; // in years (e.g. 3.2)
  taxaRenovacao: number; // in % (e.g. 88.5)
  churnAnual: number; // in % (e.g. 11.5)
  avgAnnualCommission: number; // in R$
  totalClients: number;
  totalPolicies: number;
  totalRenewals: number;
  hasSufficientData: boolean;
  calculatedAt: string;
}

export interface LtvSettings {
  tempoPermanencia: number; // in years
  taxaRenovacao: number; // in %
  churnAnual: number; // in %
  regraCalculo: "anos_retencao" | "taxa_renovacao" | "probabilidade_acumulada";
  modoCalculo: "automatico" | "manual";
  lastAutoSync?: string;
}

const DEFAULT_SETTINGS: LtvSettings = {
  tempoPermanencia: 3,
  taxaRenovacao: 85,
  churnAnual: 15,
  regraCalculo: "anos_retencao",
  modoCalculo: "automatico",
};

/**
 * Fetch database records and compute real statistical indicators
 */
export async function computeSystemMetricsFromDatabase(): Promise<SystemCalculatedMetrics> {
  try {
    const [clientsRes, policiesRes, renewalsRes, commissionsRes] = await Promise.all([
      supabase.from("clients").select("id, created_at, status").is("deleted_at", null),
      supabase.from("apolices").select("id, client_id, data_inicio, data_fim, status, valor_premio, comissao_valor, produto_id").is("deleted_at", null),
      supabase.from("renovacoes").select("id, status, data_renovacao, data_vencimento"),
      supabase.from("client_commission_terms").select("client_id, model, percent, fixed_amount, is_active").eq("is_active", true),
    ]);

    const clients = clientsRes.data || [];
    const policies = policiesRes.data || [];
    const renewals = renewalsRes.data || [];
    const commissions = commissionsRes.data || [];

    // 1. Calculate Renewal Rate & Churn
    let calculatedTaxaRenovacao = 85; // Default fallback
    let renewalSampleCount = 0;

    const finishedRenewals = renewals.filter(r => 
      r.status === "renovada" || 
      r.status === "nao_renovada" || 
      r.status === "cancelada" || 
      r.status === "recusada"
    );

    if (finishedRenewals.length > 0) {
      const renewedCount = finishedRenewals.filter(r => r.status === "renovada").length;
      calculatedTaxaRenovacao = Math.min(100, Math.max(5, (renewedCount / finishedRenewals.length) * 100));
      renewalSampleCount = finishedRenewals.length;
    } else if (policies.length > 0) {
      // Fallback from policy statuses: count policies that are active or renewed vs expired/canceled
      const validPolicies = policies.filter(p => p.status === "ativa" || p.status === "renovada" || p.status === "cancelada" || p.status === "expirada");
      if (validPolicies.length > 0) {
        const retained = validPolicies.filter(p => p.status === "ativa" || p.status === "renovada").length;
        calculatedTaxaRenovacao = Math.min(100, Math.max(10, (retained / validPolicies.length) * 100));
        renewalSampleCount = validPolicies.length;
      }
    }

    // Churn is complementary to renewal rate
    const calculatedChurnAnual = Math.min(95, Math.max(1, 100 - calculatedTaxaRenovacao));

    // 2. Calculate Average Relationship Duration (Permanência Média)
    let calculatedTempoPermanencia = 3;
    const now = new Date();
    const clientDurations: number[] = [];

    clients.forEach(client => {
      const clientPolicies = policies.filter(p => p.client_id === client.id);
      let earliestDate = client.created_at ? new Date(client.created_at) : now;
      let latestDate = now;

      if (clientPolicies.length > 0) {
        clientPolicies.forEach(p => {
          if (p.data_inicio) {
            const start = new Date(p.data_inicio);
            if (start < earliestDate) earliestDate = start;
          }
          if (p.data_fim) {
            const end = new Date(p.data_fim);
            if (end > latestDate) latestDate = end;
          }
        });
      }

      const diffDays = Math.max(30, differenceInDays(latestDate, earliestDate));
      const years = diffDays / 365.25;
      clientDurations.push(years);
    });

    if (clientDurations.length > 0) {
      const avgYears = clientDurations.reduce((a, b) => a + b, 0) / clientDurations.length;
      // If average duration observed is short because the system is relatively recent,
      // combine observed lifespan with theoretical churn-implied permanence: 1 / (churnRate)
      const churnImpliedYears = calculatedChurnAnual > 0 ? (100 / calculatedChurnAnual) : 3;
      const weightedPermanencia = avgYears > 1 ? avgYears : Math.max(1, Math.min(10, (avgYears * 0.4) + (churnImpliedYears * 0.6)));
      calculatedTempoPermanencia = Math.max(1, Math.min(15, Math.round(weightedPermanencia * 10) / 10));
    }

    // 3. Calculate Average Annual Commission (ARPU)
    let totalAnnualCommission = 0;
    const activeClients = clients.filter(c => c.status === "ativo");
    const activeClientsCount = Math.max(1, activeClients.length);

    activeClients.forEach(client => {
      const clientPolicies = policies.filter(p => p.client_id === client.id && p.status === "ativa");
      const clientTotalPremium = clientPolicies.reduce((sum, p) => sum + (p.valor_premio || 0), 0);
      
      const term = commissions.find(t => t.client_id === client.id);
      let clientAnnualComm = 0;

      if (term) {
        if (term.model === "fixo" && term.fixed_amount) {
          clientAnnualComm = term.fixed_amount * 12;
        } else if (term.model === "percentual" && term.percent) {
          clientAnnualComm = clientTotalPremium * (term.percent / 100);
        } else if (term.model === "misto") {
          clientAnnualComm = ((term.fixed_amount || 0) * 12) + (clientTotalPremium * ((term.percent || 0) / 100));
        }
      } else {
        // Estimate 15% standard commission from premiums or actual comissao_valor
        const policiesComm = clientPolicies.reduce((sum, p) => sum + (p.comissao_valor || (p.valor_premio || 0) * 0.15), 0);
        clientAnnualComm = policiesComm > 0 ? policiesComm : (clientTotalPremium * 0.15);
      }

      totalAnnualCommission += clientAnnualComm;
    });

    const avgAnnualCommission = totalAnnualCommission / activeClientsCount;

    return {
      tempoPermanencia: calculatedTempoPermanencia,
      taxaRenovacao: Math.round(calculatedTaxaRenovacao * 10) / 10,
      churnAnual: Math.round(calculatedChurnAnual * 10) / 10,
      avgAnnualCommission: Math.round(avgAnnualCommission * 100) / 100,
      totalClients: clients.length,
      totalPolicies: policies.length,
      totalRenewals: renewals.length,
      hasSufficientData: clients.length > 0 || policies.length > 0 || renewals.length > 0,
      calculatedAt: new Date().toISOString(),
    };
  } catch (error) {
    console.error("Error computing system LTV metrics:", error);
    return {
      tempoPermanencia: DEFAULT_SETTINGS.tempoPermanencia,
      taxaRenovacao: DEFAULT_SETTINGS.taxaRenovacao,
      churnAnual: DEFAULT_SETTINGS.churnAnual,
      avgAnnualCommission: 0,
      totalClients: 0,
      totalPolicies: 0,
      totalRenewals: 0,
      hasSufficientData: false,
      calculatedAt: new Date().toISOString(),
    };
  }
}

export function getLtvSettings(): LtvSettings {
  try {
    const stored = localStorage.getItem("safeos_ltv_settings");
    if (!stored) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(stored);
    const numPermanencia = Number(parsed.tempoPermanencia);
    const numRenovacao = Number(parsed.taxaRenovacao);
    const numChurn = Number(parsed.churnAnual);
    return {
      tempoPermanencia: isNaN(numPermanencia) ? DEFAULT_SETTINGS.tempoPermanencia : numPermanencia,
      taxaRenovacao: isNaN(numRenovacao) ? DEFAULT_SETTINGS.taxaRenovacao : numRenovacao,
      churnAnual: isNaN(numChurn) ? DEFAULT_SETTINGS.churnAnual : numChurn,
      regraCalculo: parsed.regraCalculo ?? DEFAULT_SETTINGS.regraCalculo,
      modoCalculo: parsed.modoCalculo ?? DEFAULT_SETTINGS.modoCalculo,
      lastAutoSync: parsed.lastAutoSync,
    };
  } catch (e) {
    return DEFAULT_SETTINGS;
  }
}

export function calculateLtvValue(commissionAnual: number, settings: LtvSettings): { contracted: number; projected: number } {
  const contracted = commissionAnual;
  let projected = commissionAnual;

  if (settings.regraCalculo === "anos_retencao") {
    projected = commissionAnual * (settings.tempoPermanencia || 3);
  } else if (settings.regraCalculo === "taxa_renovacao") {
    // Standard churn-based projection: LTV = ARPU / Churn = commissionAnual / ChurnRate
    const churnFraction = settings.churnAnual > 0 ? settings.churnAnual / 100 : 0.15;
    projected = commissionAnual / churnFraction;
  } else {
    // probabilidade_acumulada (advanced cumulative probability up to tempoPermanencia)
    let sumMultiplier = 0;
    const decay = (settings.taxaRenovacao || 85) / 100;
    const maxYears = Math.max(1, Math.round(settings.tempoPermanencia || 3));
    for (let year = 1; year <= maxYears; year++) {
      sumMultiplier += Math.pow(decay, year - 1);
    }
    projected = commissionAnual * sumMultiplier;
  }

  return {
    contracted,
    projected,
  };
}

export function useSystemMetricsCalculator() {
  return useQuery({
    queryKey: ["system_calculated_metrics"],
    queryFn: computeSystemMetricsFromDatabase,
    staleTime: 60 * 1000, // 1 minute
  });
}

export function useLtvSettings() {
  const queryClient = useQueryClient();
  const systemMetrics = useSystemMetricsCalculator();

  const query = useQuery({
    queryKey: ["ltv_settings"],
    queryFn: () => {
      const current = getLtvSettings();
      // If modoCalculo is automatic and system metrics are loaded, sync values
      if (current.modoCalculo === "automatico" && systemMetrics.data && systemMetrics.data.hasSufficientData) {
        const syncedSettings: LtvSettings = {
          ...current,
          tempoPermanencia: systemMetrics.data.tempoPermanencia,
          taxaRenovacao: systemMetrics.data.taxaRenovacao,
          churnAnual: systemMetrics.data.churnAnual,
          lastAutoSync: systemMetrics.data.calculatedAt,
        };
        localStorage.setItem("safeos_ltv_settings", JSON.stringify(syncedSettings));
        return syncedSettings;
      }
      return current;
    },
    initialData: DEFAULT_SETTINGS,
  });

  const mutation = useMutation({
    mutationFn: async (newSettings: LtvSettings) => {
      localStorage.setItem("safeos_ltv_settings", JSON.stringify(newSettings));
      return newSettings;
    },
    onSuccess: () => {
      // Invalidate all dashboard metrics and client metrics to trigger updating
      queryClient.invalidateQueries({ queryKey: ["ltv_settings"] });
      queryClient.invalidateQueries({ queryKey: ["system_calculated_metrics"] });
      queryClient.invalidateQueries({ queryKey: ["executive_dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard_advanced_metrics"] });
      queryClient.invalidateQueries({ queryKey: ["client_policies"] });
      queryClient.invalidateQueries({ queryKey: ["client_ranking"] });
      queryClient.invalidateQueries({ queryKey: ["financeiro_historico"] });
    },
  });

  return {
    settings: query.data ?? DEFAULT_SETTINGS,
    systemMetrics: systemMetrics.data,
    isLoadingMetrics: systemMetrics.isLoading,
    isLoading: query.isLoading,
    saveSettings: mutation.mutateAsync,
    isSaving: mutation.isPending,
  };
}

