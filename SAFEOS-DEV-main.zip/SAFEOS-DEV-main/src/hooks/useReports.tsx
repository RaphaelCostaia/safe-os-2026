import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format, subMonths, startOfMonth, endOfMonth } from "date-fns";
import { ptBR } from "date-fns/locale";

export interface MonthlyStats {
  month: string;
  monthLabel: string;
  clientes: number;
  apolices: number;
  sinistros: number;
  receita: number;
  comissao: number;
  renovacoes: number;
  cancelamentos: number;
  isProjected?: boolean;
}

export function useReports(months: number = 12) {
  // Main data query
  const { data: allData, isLoading } = useQuery({
    queryKey: ["reports", "all-data", months],
    queryFn: async () => {
      const today = new Date();
      const startDate = startOfMonth(subMonths(today, months - 1));
      
      // Fetch all required data in parallel
      const [
        { data: clients },
        { data: apolices },
        { data: sinistros },
        { data: renovacoes },
        { data: commissionTerms }
      ] = await Promise.all([
        supabase.from("clients").select("id, created_at").is("deleted_at", null),
        supabase.from("apolices").select("id, client_id, created_at, updated_at, valor_premio, status, seguradora, produto_id, data_fim, observacoes, produtos(categoria, comissao_percentual)").is("deleted_at", null),
        supabase.from("sinistros").select("id, created_at, status, apolice_id").is("deleted_at", null),
        supabase.from("renovacoes").select("id, updated_at, status"),
        (async () => {
          try {
            const { data, error } = await supabase
              .from("client_commission_terms")
              .select("client_id, produto_id, percent, fixed_amount, is_active");
            if (error) throw error;
            return { data, error: null };
          } catch (err) {
            console.warn("useReports: Falling back to legacy client_commission_terms:", err);
            try {
              const { data, error } = await supabase
                .from("client_commission_terms")
                .select("client_id, percent, fixed_amount, is_active");
              if (error) throw error;
              const mapped = (data || []).map(item => ({
                ...item,
                produto_id: null
              }));
              return { data: mapped, error: null };
            } catch (innerErr) {
              console.error("Critical error fetching commissions in useReports details:", innerErr);
              return { data: [], error: innerErr };
            }
          }
        })()
      ]);

      const stats: MonthlyStats[] = [];
      const futureStats: MonthlyStats[] = [];

      // Helper function to parse metadata from apolices.observacoes
      const parseApoliceObservacoes = (observacoesText: string | null) => {
        const defaultMeta = {
          comissao_real_percent: "",
          valor_comissao_real: "",
          data_renovacao: "",
        };
        if (!observacoesText) return { notes: "", meta: defaultMeta };
        const divider = "-- METADATA_APOLICE_V1 --";
        const parts = observacoesText.split(divider);
        if (parts.length < 2) return { notes: observacoesText, meta: defaultMeta };
        try {
          const meta = JSON.parse(parts[1].trim());
          return { notes: parts[0].trim(), meta: { ...defaultMeta, ...meta } };
        } catch {
          return { notes: observacoesText, meta: defaultMeta };
        }
      };

      // Helper to calculate commission for an apolice
      const calculateCommission = (apolice: { client_id: string; valor_premio: number | null; observacoes: string | null; produto_id: string | null; produtos: any }) => {
        const premio = apolice.valor_premio || 0;
        
        // 1. Try to get real commission from apolice metadata
        const { meta } = parseApoliceObservacoes(apolice.observacoes || null);
        const pPercent = meta.comissao_real_percent ? parseFloat(meta.comissao_real_percent) : NaN;
        const pValor = meta.valor_comissao_real ? parseFloat(meta.valor_comissao_real) : NaN;

        if (!isNaN(pValor) && pValor > 0) return pValor;
        if (!isNaN(pPercent) && pPercent > 0) return (premio * pPercent) / 100;

        // 2. Try to get commission from client_commission_terms
        const terms = commissionTerms?.filter(t => t.client_id === apolice.client_id && t.is_active);
        const matchedTerm = terms?.find(t => t.produto_id === apolice.produto_id)
          || terms?.find(t => t.produto_id === null);

        if (matchedTerm) {
          if (matchedTerm.fixed_amount) return matchedTerm.fixed_amount;
          if (matchedTerm.percent) return (premio * matchedTerm.percent) / 100;
        }

        // 3. Fallback to product fallback comissao_percentual
        const prod = apolice.produtos;
        const prodPercent = prod
          ? (Array.isArray(prod) ? prod[0]?.comissao_percentual : (prod as any).comissao_percentual)
          : null;

        if (prodPercent !== null && prodPercent !== undefined) {
          return (premio * prodPercent) / 100;
        }

        return premio * 0.15; // Default 15%
      };

      // Aggregate Past/Present Data
      for (let i = months - 1; i >= 0; i--) {
        const monthDate = subMonths(today, i);
        const monthStart = startOfMonth(monthDate);
        const monthEnd = endOfMonth(monthDate);
        const monthLabel = format(monthDate, "MMM", { locale: ptBR });

        const monthClients = clients?.filter(c => {
          const d = new Date(c.created_at);
          return d >= monthStart && d <= monthEnd;
        }) || [];

        const monthApolices = apolices?.filter(a => {
          const d = a.data_inicio ? new Date(a.data_inicio) : new Date(a.created_at);
          return d >= monthStart && d <= monthEnd;
        }) || [];

        const monthReceita = monthApolices.reduce((sum, a) => sum + (a.valor_premio || 0), 0);
        const monthComissao = monthApolices.reduce((sum, a) => sum + calculateCommission(a as any), 0);

        const monthSinistros = sinistros?.filter(s => {
          const d = new Date(s.created_at);
          return d >= monthStart && d <= monthEnd;
        }) || [];

        const monthRenovacoes = renovacoes?.filter(r => {
          const d = new Date(r.updated_at);
          return r.status === "renovada" && d >= monthStart && d <= monthEnd;
        }) || [];

        const monthCancelamentos = apolices?.filter(a => {
          const d = new Date(a.updated_at);
          return a.status === "cancelada" && d >= monthStart && d <= monthEnd;
        }) || [];

        stats.push({
          month: format(monthDate, "yyyy-MM"),
          monthLabel: monthLabel.charAt(0).toUpperCase() + monthLabel.slice(1),
          clientes: monthClients.length,
          apolices: monthApolices.length,
          sinistros: monthSinistros.length,
          receita: monthReceita,
          comissao: monthComissao,
          renovacoes: monthRenovacoes.length,
          cancelamentos: monthCancelamentos.length,
          isProjected: false
        });
      }

      // Aggregate Future Projections (Next 6 months)
      for (let i = 1; i <= 6; i++) {
        const monthDate = format(subMonths(today, -i), "yyyy-MM");
        const monthLabel = format(subMonths(today, -i), "MMM", { locale: ptBR });
        const monthStart = startOfMonth(subMonths(today, -i));
        const monthEnd = endOfMonth(subMonths(today, -i));

        // Upcoming renewals based on data_fim
        const upcomingRenewals = apolices?.filter(a => {
          const d = new Date(a.data_fim);
          return a.status === "ativa" && d >= monthStart && d <= monthEnd;
        }) || [];

        const projectedReceita = upcomingRenewals.reduce((sum, a) => sum + (a.valor_premio || 0), 0);
        const projectedComissao = upcomingRenewals.reduce((sum, a) => sum + calculateCommission(a as any), 0);

        futureStats.push({
          month: monthDate,
          monthLabel: monthLabel.charAt(0).toUpperCase() + monthLabel.slice(1),
          clientes: 0,
          apolices: upcomingRenewals.length,
          sinistros: 0,
          receita: projectedReceita,
          comissao: projectedComissao,
          renovacoes: 0,
          cancelamentos: 0,
          isProjected: true
        });
      }

      // Category Stats
      const categoryMap = new Map<string, { quantidade: number; valor: number }>();
      apolices?.forEach((a) => {
        const prod = a.produtos;
        const rawCategory = prod
          ? (Array.isArray(prod) ? prod[0]?.categoria : (prod as any).categoria)
          : null;
        const categoria = rawCategory || "Outros";
        
        const current = categoryMap.get(categoria) || { quantidade: 0, valor: 0 };
        categoryMap.set(categoria, {
          quantidade: current.quantidade + 1,
          valor: current.valor + (a.valor_premio || 0),
        });
      });

      const catStats = Array.from(categoryMap.entries()).map(([categoria, data]) => ({
        categoria,
        quantidade: data.quantidade,
        valor: data.valor,
        percentual: (apolices?.length || 0) > 0 ? (data.quantidade / apolices!.length) * 100 : 0,
      }));

      // Seguradora Stats
      const seguradoraMap = new Map<string, { apolices: number; valorTotal: number; sinistros: number }>();
      apolices?.forEach((a) => {
        const current = seguradoraMap.get(a.seguradora) || { apolices: 0, valorTotal: 0, sinistros: 0 };
        const sinistrosCount = sinistros?.filter((s) => s.apolice_id === a.id).length || 0;
        seguradoraMap.set(a.seguradora, {
          apolices: current.apolices + 1,
          valorTotal: current.valorTotal + (a.valor_premio || 0),
          sinistros: current.sinistros + sinistrosCount,
        });
      });

      const segStats = Array.from(seguradoraMap.entries())
        .map(([seguradora, data]) => ({
          seguradora,
          ...data,
        }))
        .sort((a, b) => b.valorTotal - a.valorTotal);

      // Status Distribution
      const statusMap = new Map<string, number>();
      apolices?.forEach((a) => {
        const current = statusMap.get(a.status) || 0;
        statusMap.set(a.status, current + 1);
      });

      const statDist = Array.from(statusMap.entries()).map(([status, count]) => ({
        status: status.charAt(0).toUpperCase() + status.slice(1),
        count,
        percentual: (apolices?.length || 0) > 0 ? (count / apolices!.length) * 100 : 0,
      }));

      // Totals
      const totals = {
        totalClientes: clients?.length || 0,
        totalApolices: apolices?.length || 0,
        apolicesAtivas: apolices?.filter(a => ["ativa", "renovada", "em_renovacao"].includes(a.status)).length || 0,
        totalReceita: apolices?.filter(a => ["ativa", "renovada", "em_renovacao"].includes(a.status)).reduce((sum, a) => sum + (a.valor_premio || 0), 0) || 0,
        totalComissao: apolices?.filter(a => ["ativa", "renovada", "em_renovacao"].includes(a.status)).reduce((sum, a) => sum + calculateCommission(a as any), 0) || 0,
        sinistrosAbertos: sinistros?.filter(s => ["aberto", "em_analise"].includes(s.status)).length || 0,
        renovacoesPendentes: renovacoes?.filter(r => r.status === "pendente").length || 0,
      };

      return {
        monthlyStats: stats,
        futureStats,
        categoryStats: catStats,
        seguradoraStats: segStats,
        statusDistribution: statDist,
        totals
      };
    },
  });

  return {
    monthlyStats: allData?.monthlyStats || [],
    futureStats: allData?.futureStats || [],
    categoryStats: allData?.categoryStats || [],
    seguradoraStats: allData?.seguradoraStats || [],
    statusDistribution: allData?.statusDistribution || [],
    totals: allData?.totals,
    isLoading
  };
}
