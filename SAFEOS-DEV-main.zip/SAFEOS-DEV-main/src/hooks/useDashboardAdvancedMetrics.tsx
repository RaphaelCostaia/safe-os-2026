import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { subDays, subMonths, startOfMonth } from "date-fns";
import { getLtvSettings, calculateLtvValue } from "@/hooks/useLtvSettings";

export interface AdvancedMetrics {
  // LTV
  ltv: {
    average: number;
    hasData: boolean;
    totalClients: number;
    clientsWithCommission: number;
  };
  // Conversion Rate
  conversion: {
    rate: number;
    hasData: boolean;
    totalClients: number;
    convertedClients: number;
    period: string;
  };
  // Sinistralidade
  sinistralidade: {
    rate: number;
    hasData: boolean;
    totalPaid: number;
    totalPremium: number;
    period: string;
  };
}

export type MetricPeriod = "30d" | "90d" | "month" | "year";

/**
 * Hook to calculate advanced dashboard metrics
 * LTV, Conversion Rate, Sinistralidade
 */
export function useDashboardAdvancedMetrics(period: MetricPeriod = "90d") {
  return useQuery({
    queryKey: ["dashboard_advanced_metrics", period],
    queryFn: async (): Promise<AdvancedMetrics> => {
      // Calculate date range based on period
      const now = new Date();
      let startDate: Date;
      let periodLabel: string;

      switch (period) {
        case "30d":
          startDate = subDays(now, 30);
          periodLabel = "últimos 30 dias";
          break;
        case "90d":
          startDate = subDays(now, 90);
          periodLabel = "últimos 90 dias";
          break;
        case "month":
          startDate = startOfMonth(now);
          periodLabel = "mês atual";
          break;
        case "year":
          startDate = subMonths(now, 12);
          periodLabel = "último ano";
          break;
        default:
          startDate = subDays(now, 90);
          periodLabel = "últimos 90 dias";
      }

      const startDateStr = startDate.toISOString();

      // ======= LTV Calculation =======
      const ltvSettings = getLtvSettings();
      // Get all clients with active commission terms
      const { data: commissionData } = await supabase
        .from("client_commission_terms")
        .select(`
          client_id,
          model,
          percent,
          fixed_amount,
          clients!inner (
            id,
            nome,
            status,
            apolices (
              valor_premio,
              status
            )
          )
        `)
        .eq("is_active", true);

      let ltvTotal = 0;
      let clientsWithLTV = 0;

      if (commissionData && commissionData.length > 0) {
        commissionData.forEach((term) => {
          const client = term.clients as any;
          if (!client) return;

          // Calculate active premiums for this client
          const activePremiums = (client.apolices || [])
            .filter((a: any) => a.status === "ativa")
            .reduce((sum: number, a: any) => sum + (a.valor_premio || 0), 0);

          // Estimate monthly commission based on model
          let estimatedMonthlyCommission = 0;
          if (term.model === "fixo" && term.fixed_amount) {
            estimatedMonthlyCommission = term.fixed_amount;
          } else if (term.model === "percentual" && term.percent) {
            estimatedMonthlyCommission = (activePremiums * (term.percent / 100)) / 12;
          } else if (term.model === "misto") {
            estimatedMonthlyCommission =
              (term.fixed_amount || 0) +
              (activePremiums * ((term.percent || 0) / 100)) / 12;
          }

          // Project LTV using centralized formula and settings
          const estimatedAnnualCommission = estimatedMonthlyCommission * 12;
          const { projected: projectedLTV } = calculateLtvValue(estimatedAnnualCommission, ltvSettings);

          if (projectedLTV > 0) {
            ltvTotal += projectedLTV;
            clientsWithLTV++;
          }
        });
      }

      // Get total clients count
      const { count: totalClients } = await supabase
        .from("clients")
        .select("*", { count: "exact", head: true })
        .eq("status", "ativo");

      // ======= Conversion Rate =======
      // Clients created in period
      const { count: newClientsCount } = await supabase
        .from("clients")
        .select("*", { count: "exact", head: true })
        .gte("created_at", startDateStr);

      // Clients with at least one active policy (converted)
      const { data: clientsWithPolicies } = await supabase
        .from("clients")
        .select(`
          id,
          apolices!inner (id, status)
        `)
        .gte("created_at", startDateStr)
        .eq("apolices.status", "ativa");

      const convertedClients = clientsWithPolicies
        ? [...new Set(clientsWithPolicies.map((c) => c.id))].length
        : 0;

      const conversionRate =
        newClientsCount && newClientsCount > 0
          ? (convertedClients / newClientsCount) * 100
          : 0;

      // ======= Sinistralidade =======
      // Total paid in claims in period
      const { data: claimsData } = await supabase
        .from("sinistros")
        .select("valor_pago")
        .gte("data_ocorrencia", startDateStr)
        .is("deleted_at", null);

      const totalPaid = claimsData?.reduce(
        (sum, claim) => sum + (claim.valor_pago || 0),
        0
      ) || 0;

      // Total active premium
      const { data: premiumData } = await supabase
        .from("apolices")
        .select("valor_premio")
        .eq("status", "ativa")
        .is("deleted_at", null);

      const totalPremium = premiumData?.reduce(
        (sum, policy) => sum + (policy.valor_premio || 0),
        0
      ) || 0;

      const sinistralidade =
        totalPremium > 0 ? (totalPaid / totalPremium) * 100 : 0;

      return {
        ltv: {
          average: clientsWithLTV > 0 ? ltvTotal / clientsWithLTV : 0,
          hasData: clientsWithLTV > 0,
          totalClients: totalClients || 0,
          clientsWithCommission: clientsWithLTV,
        },
        conversion: {
          rate: conversionRate,
          hasData: (newClientsCount || 0) > 0,
          totalClients: newClientsCount || 0,
          convertedClients,
          period: periodLabel,
        },
        sinistralidade: {
          rate: sinistralidade,
          hasData: totalPremium > 0,
          totalPaid,
          totalPremium,
          period: periodLabel,
        },
      };
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
}

/**
 * Format LTV value for display
 */
export function formatLTV(value: number): string {
  if (value >= 1000000) {
    return `R$ ${(value / 1000000).toFixed(1)}M`;
  }
  if (value >= 1000) {
    return `R$ ${(value / 1000).toFixed(1)}k`;
  }
  return `R$ ${value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`;
}

/**
 * Get status color for sinistralidade
 */
export function getSinistralidadeStatus(rate: number): {
  color: string;
  label: string;
} {
  if (rate < 30) {
    return { color: "text-success", label: "Saudável" };
  }
  if (rate < 60) {
    return { color: "text-warning", label: "Atenção" };
  }
  return { color: "text-destructive", label: "Crítico" };
}

/**
 * Get status color for conversion rate
 */
export function getConversionStatus(rate: number): {
  color: string;
  label: string;
} {
  if (rate >= 50) {
    return { color: "text-success", label: "Excelente" };
  }
  if (rate >= 30) {
    return { color: "text-warning", label: "Bom" };
  }
  return { color: "text-muted-foreground", label: "Baixo" };
}
