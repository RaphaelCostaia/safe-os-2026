import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface CommissionMetrics {
  ticketMedioComissao: number;
  clientesComComissao: number;
  clientesSemComissao: number;
  totalClientes: number;
  somaComissoes: number;
}

export function useDashboardCommissionMetrics() {
  return useQuery({
    queryKey: ["dashboard_commission_metrics"],
    queryFn: async (): Promise<CommissionMetrics> => {
      // 1. Get all active commission terms
      const { data: commissions, error: commissionsError } = await supabase
        .from("client_commission_terms")
        .select("client_id, model, percent, fixed_amount")
        .eq("is_active", true);

      if (commissionsError) throw commissionsError;

      // 2. Get total clients count
      const { count: totalClients, error: clientsError } = await supabase
        .from("clients")
        .select("*", { count: "exact", head: true })
        .eq("status", "ativo");

      if (clientsError) throw clientsError;

      // 3. Get average premium per client (for percentage-based commissions)
      const { data: apolices, error: apolicesError } = await supabase
        .from("apolices")
        .select("client_id, valor_premio")
        .eq("status", "ativa")
        .is("deleted_at", null);

      if (apolicesError) throw apolicesError;

      // Calculate average premium per client
      const premiumByClient: Record<string, { total: number; count: number }> = {};
      apolices?.forEach((apolice) => {
        if (!premiumByClient[apolice.client_id]) {
          premiumByClient[apolice.client_id] = { total: 0, count: 0 };
        }
        premiumByClient[apolice.client_id].total += Number(apolice.valor_premio) || 0;
        premiumByClient[apolice.client_id].count += 1;
      });

      // 4. Calculate commission value for each client
      let somaComissoes = 0;
      let clientesComComissao = 0;

      commissions?.forEach((commission) => {
        let comissaoValor = 0;

        if (commission.model === "fixo" && commission.fixed_amount) {
          comissaoValor = Number(commission.fixed_amount);
        } else if (commission.model === "percentual" && commission.percent) {
          // Use average premium of client
          const clientPremium = premiumByClient[commission.client_id];
          if (clientPremium && clientPremium.count > 0) {
            const avgPremium = clientPremium.total / clientPremium.count;
            comissaoValor = (Number(commission.percent) / 100) * avgPremium;
          }
        } else if (commission.model === "misto") {
          // Fixed + percentage
          const fixedPart = Number(commission.fixed_amount) || 0;
          let percentPart = 0;
          
          if (commission.percent) {
            const clientPremium = premiumByClient[commission.client_id];
            if (clientPremium && clientPremium.count > 0) {
              const avgPremium = clientPremium.total / clientPremium.count;
              percentPart = (Number(commission.percent) / 100) * avgPremium;
            }
          }
          
          comissaoValor = fixedPart + percentPart;
        }

        if (comissaoValor > 0) {
          somaComissoes += comissaoValor;
          clientesComComissao++;
        }
      });

      const ticketMedioComissao = clientesComComissao > 0 
        ? somaComissoes / clientesComComissao 
        : 0;

      return {
        ticketMedioComissao,
        clientesComComissao,
        clientesSemComissao: (totalClients || 0) - clientesComComissao,
        totalClientes: totalClients || 0,
        somaComissoes,
      };
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
}
