import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

export type SinistroTip = Tables<"sinistro_tips">;

export function useSinistroTips(categoria?: string | null) {
  return useQuery({
    queryKey: ["sinistro-tips", categoria],
    queryFn: async () => {
      let query = supabase
        .from("sinistro_tips")
        .select("*")
        .eq("ativo", true)
        .order("ordem", { ascending: true });
      
      // Get tips that match the category OR are general (no category)
      if (categoria) {
        query = query.or(`categoria.is.null,categoria.eq.${categoria}`);
      } else {
        query = query.is("categoria", null);
      }
      
      const { data, error } = await query;
      
      if (error) throw error;
      return data as SinistroTip[];
    },
  });
}
