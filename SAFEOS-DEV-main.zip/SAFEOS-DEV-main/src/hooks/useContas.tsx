import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { assertAffectedRows } from "@/lib/supabaseMutationUtils";

export interface Conta {
  id: string;
  tipo: 'pagar' | 'receber';
  descricao: string;
  categoria: string;
  valor: number;
  vencimento: string;
  status: string;
  responsavel_id: string | null;
  cliente_id: string | null;
  apolice_id: string | null;
  observacoes: string | null;
  data_pagamento: string | null;
  created_at: string;
  updated_at: string;
}

export type ContaInsert = Omit<Conta, 'id' | 'created_at' | 'updated_at'>;
export type ContaUpdate = Partial<ContaInsert>;

export function useContas(tipo?: 'pagar' | 'receber') {
  const queryClient = useQueryClient();

  const { data: contas = [], isLoading, error } = useQuery({
    queryKey: ['contas', tipo],
    queryFn: async () => {
      let query = supabase
        .from('contas')
        .select('*')
        .order('vencimento', { ascending: true });

      if (tipo) {
        query = query.eq('tipo', tipo);
      }

      const { data, error } = await query;

      if (error) throw error;
      return data as Conta[];
    },
  });

  const createMutation = useMutation({
    mutationFn: async (conta: ContaInsert) => {
      // Fetch current user and their organization_id to avoid RLS mismatch
      const { data: { session } } = await supabase.auth.getSession();
      const currentUserId = session?.user?.id;
      let finalOrgId = (conta as any).organization_id;

      if (!finalOrgId && currentUserId) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("organization_id")
          .eq("id", currentUserId)
          .maybeSingle();
        
        if (profile?.organization_id) {
          finalOrgId = profile.organization_id;
        } else {
          // Fallback to first available organization if no info
          const { data: orgs } = await supabase
            .from("organizations")
            .select("id")
            .order("created_at", { ascending: true })
            .limit(1);
          if (orgs && orgs.length > 0) {
            finalOrgId = orgs[0].id;
          }
        }
      }

      const contaWithOrg = {
        ...conta,
        organization_id: finalOrgId
      };

      const { data, error } = await supabase
        .from('contas')
        .insert(contaWithOrg)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contas'] });
      toast.success('Conta adicionada com sucesso');
    },
    onError: (error: Error) => {
      toast.error(`Erro ao adicionar conta: ${error.message}`);
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: string } & ContaUpdate) => {
      const { data: updated, error } = await supabase
        .from('contas')
        .update(data)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return updated;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contas'] });
      toast.success('Conta atualizada com sucesso');
    },
    onError: (error: Error) => {
      toast.error(`Erro ao atualizar conta: ${error.message}`);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { data, error, count } = await supabase
        .from('contas')
        .delete({ count: 'exact' })
        .eq('id', id)
        .select('id');

      if (error) throw error;

      assertAffectedRows(
        { count, data },
        'Falha ao remover conta (permissão insuficiente ou registro não encontrado)'
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contas'] });
      toast.success('Conta removida com sucesso');
    },
    onError: (error: Error) => {
      toast.error(`Erro ao remover conta: ${error.message}`);
    },
  });

  const marcarComoPago = useMutation({
    mutationFn: async (id: string) => {
      const { data, error } = await supabase
        .from('contas')
        .update({ 
          status: 'pago',
          data_pagamento: new Date().toISOString().split('T')[0]
        })
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contas'] });
      toast.success('Conta marcada como paga');
    },
    onError: (error: Error) => {
      toast.error(`Erro ao atualizar conta: ${error.message}`);
    },
  });

  return {
    contas,
    isLoading,
    error,
    createConta: createMutation.mutate,
    updateConta: updateMutation.mutate,
    deleteConta: deleteMutation.mutate,
    marcarComoPago: marcarComoPago.mutate,
    isCreating: createMutation.isPending,
    isUpdating: updateMutation.isPending,
    isDeleting: deleteMutation.isPending,
  };
}

