import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface TeamMember {
  id: string;
  full_name: string;
  email: string | null;
  phone: string | null;
  role: string;
  department: string | null;
  is_active: boolean;
  user_id: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface TeamMemberInsert {
  full_name: string;
  email?: string | null;
  phone?: string | null;
  role?: string;
  department?: string | null;
  is_active?: boolean;
  user_id?: string | null;
}

export interface TeamMemberUpdate {
  full_name?: string;
  email?: string | null;
  phone?: string | null;
  role?: string;
  department?: string | null;
  is_active?: boolean;
  user_id?: string | null;
}

// Fetch all team members
export function useTeamMembers(onlyActive: boolean = true) {
  return useQuery({
    queryKey: ['team-members', { onlyActive }],
    queryFn: async () => {
      let query = supabase
        .from('team_members')
        .select('*')
        .order('full_name');
      
      if (onlyActive) {
        query = query.eq('is_active', true);
      }
      
      const { data, error } = await query;
      
      if (error) {
        console.error('Error fetching team members:', error);
        throw error;
      }
      
      return data as TeamMember[];
    },
  });
}

// Fetch single team member
export function useTeamMember(id: string | null) {
  return useQuery({
    queryKey: ['team-member', id],
    queryFn: async () => {
      if (!id) return null;
      
      const { data, error } = await supabase
        .from('team_members')
        .select('*')
        .eq('id', id)
        .single();
      
      if (error) {
        console.error('Error fetching team member:', error);
        throw error;
      }
      
      return data as TeamMember;
    },
    enabled: !!id,
  });
}

// Create team member
export function useCreateTeamMember() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: TeamMemberInsert) => {
      const { data: user } = await supabase.auth.getUser();
      
      const { data: result, error } = await supabase
        .from('team_members')
        .insert({
          ...data,
          created_by: user?.user?.id || null,
        })
        .select()
        .single();
      
      if (error) {
        console.error('Error creating team member:', error);
        throw error;
      }
      
      return result as TeamMember;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['team-members'] });
      toast.success('Membro da equipe criado com sucesso!');
    },
    onError: (error: Error) => {
      console.error('Error creating team member:', error);
      if (error.message.includes('duplicate key')) {
        toast.error('Já existe um membro com este email');
      } else {
        toast.error('Erro ao criar membro da equipe');
      }
    },
  });
}

// Update team member - also syncs user_roles if member has a linked account
export function useUpdateTeamMember() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, data }: { id: string; data: TeamMemberUpdate }) => {
      // First, update the team member
      const { data: result, error } = await supabase
        .from('team_members')
        .update(data)
        .eq('id', id)
        .select()
        .single();
      
      if (error) {
        console.error('Error updating team member:', error);
        throw error;
      }

      const updatedMember = result as TeamMember;

      // If role changed and member has a linked user account, sync user_roles
      if (data.role && updatedMember.user_id) {
        const roleToSync = data.role as 'admin' | 'gestor' | 'vendedor' | 'administrativo';
        
        // Only sync if it's a valid app_role (not 'colaborador')
        if (['admin', 'gestor', 'vendedor', 'administrativo'].includes(roleToSync)) {
          const { error: roleError } = await supabase
            .from('user_roles')
            .update({ role: roleToSync })
            .eq('user_id', updatedMember.user_id);
          
          if (roleError) {
            console.error('Error syncing user role:', roleError);
            // Don't throw - team member was updated, just log the role sync failure
            toast.warning('Membro atualizado, mas houve erro ao sincronizar permissões. Tente novamente.');
          }
        }
      }
      
      return updatedMember;
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['team-members'] });
      
      // If role was changed and user has linked account, invalidate user_role cache
      if (variables.data.role && data.user_id) {
        queryClient.invalidateQueries({ queryKey: ['user_role', data.user_id] });
        queryClient.invalidateQueries({ queryKey: ['user_role'] });
      }
      
      toast.success('Membro da equipe atualizado com sucesso!');
    },
    onError: (error: Error) => {
      console.error('Error updating team member:', error);
      if (error.message.includes('duplicate key')) {
        toast.error('Já existe um membro com este email');
      } else {
        toast.error('Erro ao atualizar membro da equipe');
      }
    },
  });
}

// Delete (deactivate) team member
export function useDeleteTeamMember() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: string) => {
      // Soft delete - just deactivate
      const { error } = await supabase
        .from('team_members')
        .update({ is_active: false })
        .eq('id', id);
      
      if (error) {
        console.error('Error deactivating team member:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['team-members'] });
      toast.success('Membro da equipe desativado com sucesso!');
    },
    onError: () => {
      toast.error('Erro ao desativar membro da equipe');
    },
  });
}

// Reactivate team member
export function useReactivateTeamMember() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('team_members')
        .update({ is_active: true })
        .eq('id', id);
      
      if (error) {
        console.error('Error reactivating team member:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['team-members'] });
      toast.success('Membro da equipe reativado com sucesso!');
    },
    onError: () => {
      toast.error('Erro ao reativar membro da equipe');
    },
  });
}

// Link team member to user account
export function useLinkTeamMemberToUser() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ teamMemberId, userId }: { teamMemberId: string; userId: string }) => {
      const { error } = await supabase
        .from('team_members')
        .update({ user_id: userId })
        .eq('id', teamMemberId);
      
      if (error) {
        console.error('Error linking team member to user:', error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['team-members'] });
      toast.success('Conta vinculada com sucesso!');
    },
    onError: () => {
      toast.error('Erro ao vincular conta');
    },
  });
}
