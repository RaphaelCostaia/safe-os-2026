import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format, addMonths, startOfMonth, endOfMonth, parseISO, isWithinInterval } from "date-fns";

export interface CommissionProjection {
  month: string;
  monthLabel: string;
  projected: number;
  realized: number;
}

export interface ClientCommissionHistory {
  clientId: string;
  clientName: string;
  uf: string;
  city: string;
  profissao: string;
  terms: CommissionTerm[];
  currentPercent: number | null;
  projectedMonthly: number;
  totalPremio: number;
  lastModified: string;
  productsCategories: string[];
}

export interface CommissionTerm {
  id: string;
  produto_id?: string | null;
  model: string;
  percent: number | null;
  fixedAmount: number | null;
  startsAt: string | null;
  endsAt: string | null;
  isActive: boolean;
  createdAt: string;
}

export interface CommissionDashboardData {
  projectedCurrentMonth: number;
  projected12Months: number;
  ticketMedioComissao: number;
  topClients: { name: string; projected: number; uf: string }[];
  monthlyProjections: CommissionProjection[];
  byProduct: { category: string; projected: number }[];
  clientHistory: ClientCommissionHistory[];
  totalClients: number;
  clientsWithCommission: number;
  comissaoMediaRealizada: number;
  comissaoMediaPrevista: number;
  receitaRealizada: number;
  receitaPrevista: number;
}

export function useCommissionsDashboard(filters?: {
  periodo?: "atual" | "90dias" | "12meses";
  produto?: string;
  profissao?: string;
  uf?: string;
}) {
  return useQuery({
    queryKey: ["commissions_dashboard", filters],
    queryFn: async (): Promise<CommissionDashboardData> => {
      // 1. Fetch all active commission terms with client info
      let commissions: any[] = [];
      try {
        const { data, error: commError } = await supabase
          .from("client_commission_terms")
          .select(`
            id,
            client_id,
            produto_id,
            model,
            percent,
            fixed_amount,
            starts_at,
            ends_at,
            is_active,
            created_at,
            updated_at,
            clients!inner (
              id,
              nome,
              cidade,
              estado,
              profissao,
              status
            )
          `)
          .eq("clients.status", "ativo");

        if (commError) throw commError;
        commissions = data || [];
      } catch (err) {
        console.warn("useCommissionsDashboard: Error fetching with produto_id, trying fallback:", err);
        const { data, error: commError } = await supabase
          .from("client_commission_terms")
          .select(`
            id,
            client_id,
            model,
            percent,
            fixed_amount,
            starts_at,
            ends_at,
            is_active,
            created_at,
            updated_at,
            clients!inner (
              id,
              nome,
              cidade,
              estado,
              profissao,
              status
            )
          `)
          .eq("clients.status", "ativo");

        if (commError) throw commError;
        commissions = (data || []).map(item => ({
          ...item,
          produto_id: null
        }));
      }

      // 1b. Fetch all active clients to ensure no clients or policies are ignored
      const { data: allActiveClients, error: clientsError } = await supabase
        .from("clients")
        .select("id, nome, cidade, estado, profissao, status")
        .eq("status", "ativo")
        .is("deleted_at", null);

      if (clientsError) throw clientsError;

      // 2. Fetch active apolices
      const { data: apolices, error: apolicesError } = await supabase
        .from("apolices")
        .select(`
          id,
          client_id,
          valor_premio,
          data_inicio,
          data_fim,
          status,
          observacoes,
          produtos (
            id,
            categoria,
            comissao_percentual
          )
        `)
        .in("status", ["ativa", "em_renovacao", "renovada", "pendente"])
        .is("deleted_at", null);

      if (apolicesError) throw apolicesError;

      // Helper function to parse metadata from apolices.observacoes
      const parseApoliceObservacoes = (observacoesText: string | null) => {
        const defaultMeta = {
          comissao_real_percent: "",
          valor_comissao_real: "",
          data_renovacao: "",
        };
        if (!observacoesText) return { notes: "", meta: defaultMeta };
        const divider = "-- METADATA_APOLICE_V1 --";
        const parts = observacoesText.split(divider);
        if (parts.length < 2) return { notes: observacoesText, meta: defaultMeta };
        try {
          const meta = JSON.parse(parts[1].trim());
          return { notes: parts[0].trim(), meta: { ...defaultMeta, ...meta } };
        } catch {
          return { notes: observacoesText, meta: defaultMeta };
        }
      };

      // 3. Build data structures
      const today = new Date();
      const clientDataMap: Map<string, {
        client: { id: string; nome: string; cidade: string; estado: string; profissao: string };
        terms: CommissionTerm[];
        apolices: typeof apolices;
      }> = new Map();

      // Initialize with all active clients
      for (const client of allActiveClients || []) {
        // Apply filters
        if (filters?.profissao && filters.profissao !== "all" && client.profissao !== filters.profissao) continue;
        if (filters?.uf && filters.uf !== "all" && client.estado !== filters.uf) continue;

        clientDataMap.set(client.id, {
          client,
          terms: [],
          apolices: [],
        });
      }

      // Group commissions by client
      for (const comm of commissions || []) {
        const clientData = clientDataMap.get(comm.client_id);
        if (!clientData) continue;

        clientData.terms.push({
          id: comm.id,
          produto_id: comm.produto_id,
          model: comm.model,
          percent: comm.percent,
          fixedAmount: comm.fixed_amount,
          startsAt: comm.starts_at,
          endsAt: comm.ends_at,
          isActive: comm.is_active,
          createdAt: comm.created_at,
        });
      }

      // Attach apolices to clients
      for (const apolice of apolices || []) {
        const produto = apolice.produtos as { id: string; categoria: string; comissao_percentual: number | null } | null;
        if (!produto) continue;

        // Apply product filter
        if (filters?.produto && filters.produto !== "all" && produto.categoria !== filters.produto) continue;

        const clientData = clientDataMap.get(apolice.client_id);
        if (clientData) {
          clientData.apolices.push(apolice);
        }
      }

      // Calculate weighted averages and real totals using real metadata
      const emittedPolicies = (apolices || []).filter(a => (a.status === 'ativa' || a.status === 'em_renovacao' || a.status === 'renovada') && clientDataMap.has(a.client_id));
      const pendingPolicies = (apolices || []).filter(a => a.status === 'pendente' && clientDataMap.has(a.client_id));

      let totalRealPremium = 0;
      let totalRealCommission = 0;
      
      emittedPolicies.forEach(a => {
        const { meta } = parseApoliceObservacoes(a.observacoes);
        const premio = Number(a.valor_premio) || 0;
        let pPercent = meta.comissao_real_percent ? parseFloat(meta.comissao_real_percent) : NaN;
        let pValor = meta.valor_comissao_real ? parseFloat(meta.valor_comissao_real) : NaN;

        if (isNaN(pPercent) || pPercent <= 0) {
          // Find matching commission term for client and product
          const clientTerms = clientDataMap.get(a.client_id)?.terms || [];
          const matchedTerm = clientTerms.find(t => t.isActive && t.produto_id === a.produto_id)
            || clientTerms.find(t => t.isActive && t.produto_id === null);
          pPercent = matchedTerm ? (matchedTerm.percent || 0) : 0;
        }
        if (isNaN(pValor) || pValor <= 0) {
          pValor = (premio * pPercent) / 100;
        }

        totalRealPremium += premio;
        totalRealCommission += pValor;
      });

      const comissaoMediaRealizada = totalRealPremium > 0 
        ? (totalRealCommission / totalRealPremium) * 100 
        : 0;

      let totalPendingPremium = 0;
      let totalPendingCommission = 0;

      pendingPolicies.forEach(a => {
        const { meta } = parseApoliceObservacoes(a.observacoes);
        const premio = Number(a.valor_premio) || 0;
        let pPercent = meta.comissao_real_percent ? parseFloat(meta.comissao_real_percent) : NaN;
        let pValor = meta.valor_comissao_real ? parseFloat(meta.valor_comissao_real) : NaN;

        if (isNaN(pPercent) || pPercent <= 0) {
          // Find matching commission term for client and product
          const clientTerms = clientDataMap.get(a.client_id)?.terms || [];
          const matchedTerm = clientTerms.find(t => t.isActive && t.produto_id === a.produto_id)
            || clientTerms.find(t => t.isActive && t.produto_id === null);
          pPercent = matchedTerm ? (matchedTerm.percent || 0) : 0;
        }
        if (isNaN(pValor) || pValor <= 0) {
          pValor = (premio * pPercent) / 100;
        }

        totalPendingPremium += premio;
        totalPendingCommission += pValor;
      });

      const comissaoMediaPrevista = totalPendingPremium > 0
        ? (totalPendingCommission / totalPendingPremium) * 100
        : 0;

      const receitaRealizada = totalRealCommission;
      const receitaPrevista = totalPendingCommission;

      // 4. Calculate projections
      const clientHistory: ClientCommissionHistory[] = [];
      const byProductMap: Map<string, number> = new Map();
      const monthlyProjectionsMap: Map<string, { projected: number; realized: number }> = new Map();
      const topClientsData: { name: string; projected: number; uf: string }[] = [];

      let totalProjected = 0;
      let totalProjected12 = 0;
      let clientsWithCommission = 0;
      let sumForTicket = 0;

      // Initialize 12 months
      for (let i = 0; i < 12; i++) {
        const monthDate = addMonths(today, i);
        const monthKey = format(monthDate, "yyyy-MM");
        monthlyProjectionsMap.set(monthKey, { projected: 0, realized: 0 });
      }

      for (const [clientId, data] of clientDataMap) {
        const activeTerms = data.terms.filter(t => t.isActive);
        const latestTerm = activeTerms.length > 0 
          ? activeTerms.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0]
          : null;

        // Calculate monthly projection for this client
        let clientMonthlyProjection = 0;
        let clientTotalPremio = 0;
        const productsSet = new Set<string>();

        for (const apolice of data.apolices) {
          // Skip pending (opportunities) in normal active terms projection
          if (apolice.status === "pendente") continue;

          const produto = apolice.produtos as { id: string; categoria: string; comissao_percentual: number | null } | null;
          if (!produto) continue;

          productsSet.add(produto.categoria);

          // Calculate monthly premium
          const premioMensal = (apolice.valor_premio || 0) / 12; // Assume annual premium
          clientTotalPremio += apolice.valor_premio || 0;

          // Find active term for the exact product, or fall back to general active term, or fallback to metadata / product default comissao_percentual
          const { meta } = parseApoliceObservacoes(apolice.observacoes);
          let pPercent = meta.comissao_real_percent ? parseFloat(meta.comissao_real_percent) : NaN;

          if (isNaN(pPercent) || pPercent <= 0) {
            const matchedTerm = data.terms.find(t => t.isActive && t.produto_id === produto.id) 
              || data.terms.find(t => t.isActive && t.produto_id === null);
            pPercent = matchedTerm && matchedTerm.percent !== null ? matchedTerm.percent : (produto.comissao_percentual || 0);
          }

          if (pPercent > 0) {
            const monthlyComm = premioMensal * (pPercent / 100);
            clientMonthlyProjection += monthlyComm;

            // Add to product breakdown
            const currentProductTotal = byProductMap.get(produto.categoria) || 0;
            byProductMap.set(produto.categoria, currentProductTotal + monthlyComm * 12);

            // Add to monthly projections
            if (apolice.data_inicio && apolice.data_fim) {
              try {
                const apoliceStart = parseISO(apolice.data_inicio);
                const apoliceEnd = parseISO(apolice.data_fim);

                if (!isNaN(apoliceStart.getTime()) && !isNaN(apoliceEnd.getTime())) {
                  for (let i = 0; i < 12; i++) {
                    const monthDate = addMonths(today, i);
                    const monthKey = format(monthDate, "yyyy-MM");
                    const monthStart = startOfMonth(monthDate);
                    const monthEnd = endOfMonth(monthDate);

                    // Check if policy is active in this month
                    if (
                      isWithinInterval(monthStart, { start: apoliceStart, end: apoliceEnd }) ||
                      isWithinInterval(monthEnd, { start: apoliceStart, end: apoliceEnd }) ||
                      isWithinInterval(apoliceStart, { start: monthStart, end: monthEnd })
                    ) {
                      const current = monthlyProjectionsMap.get(monthKey)!;
                      if (current) {
                        current.projected += monthlyComm;
                      }
                    }
                  }
                }
              } catch (dateErr) {
                console.warn("useCommissionsDashboard: Error checking dates interval in loop", dateErr);
              }
            }
          }
        }

        if (clientMonthlyProjection > 0) {
          clientsWithCommission++;
          sumForTicket += clientMonthlyProjection;
          totalProjected += clientMonthlyProjection;
          totalProjected12 += clientMonthlyProjection * 12;

          topClientsData.push({
            name: data.client.nome,
            projected: clientMonthlyProjection * 12,
            uf: data.client.estado || "",
          });
        }

        let firstApolicePercent: number | null = null;
        if (data.apolices.length > 0) {
          const firstAp = data.apolices[0];
          const { meta } = parseApoliceObservacoes(firstAp.observacoes);
          const pPercent = meta.comissao_real_percent ? parseFloat(meta.comissao_real_percent) : NaN;
          if (!isNaN(pPercent) && pPercent > 0) {
            firstApolicePercent = pPercent;
          } else {
            const prod = firstAp.produtos as any;
            firstApolicePercent = prod?.comissao_percentual || null;
          }
        }

        if (clientMonthlyProjection > 0 || data.apolices.length > 0 || data.terms.length > 0) {
          clientHistory.push({
            clientId,
            clientName: data.client.nome,
            uf: data.client.estado || "",
            city: data.client.cidade || "",
            profissao: data.client.profissao || "",
            terms: data.terms.sort((a, b) => 
              new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
            ),
            currentPercent: latestTerm ? latestTerm.percent : (firstApolicePercent !== null ? firstApolicePercent : null),
            projectedMonthly: clientMonthlyProjection,
            totalPremio: clientTotalPremio,
            lastModified: latestTerm ? latestTerm.createdAt : (data.apolices.length > 0 ? data.apolices[0].data_inicio : today.toISOString()),
            productsCategories: Array.from(productsSet),
          });
        }
      }

      // Sort and get top 5 clients
      topClientsData.sort((a, b) => b.projected - a.projected);
      const topClients = topClientsData.slice(0, 5);

      // Convert maps to arrays
      const monthlyProjections: CommissionProjection[] = Array.from(monthlyProjectionsMap.entries())
        .map(([month, data]) => ({
          month,
          monthLabel: format(parseISO(`${month}-01`), "MMM/yy"),
          projected: data.projected,
          realized: data.realized,
        }));

      const byProduct = Array.from(byProductMap.entries())
        .map(([category, projected]) => ({ category, projected }))
        .sort((a, b) => b.projected - a.projected);

      // Ticket médio
      const ticketMedioComissao = clientsWithCommission > 0 
        ? sumForTicket / clientsWithCommission 
        : 0;

      return {
        projectedCurrentMonth: totalProjected,
        projected12Months: totalProjected12,
        ticketMedioComissao,
        topClients,
        monthlyProjections,
        byProduct,
        clientHistory: clientHistory.sort((a, b) => b.projectedMonthly - a.projectedMonthly),
        totalClients: clientDataMap.size,
        clientsWithCommission,
        comissaoMediaRealizada,
        comissaoMediaPrevista,
        receitaRealizada,
        receitaPrevista,
      };
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
}

// Hook to get unique filter options
export function useCommissionFilters() {
  return useQuery({
    queryKey: ["commission_filters"],
    queryFn: async () => {
      const { data: clients, error: clientsError } = await supabase
        .from("clients")
        .select("profissao, estado")
        .eq("status", "ativo");

      if (clientsError) throw clientsError;

      const { data: produtos, error: produtosError } = await supabase
        .from("produtos")
        .select("categoria")
        .eq("ativo", true);

      if (produtosError) throw produtosError;

      const profissoes = Array.from(new Set(clients?.map(c => c.profissao).filter(Boolean) as string[])).sort();
      const ufs = Array.from(new Set(clients?.map(c => c.estado).filter(Boolean) as string[])).sort();
      const produtos_categorias = Array.from(new Set(produtos?.map(p => p.categoria) || [])).sort();

      return {
        profissoes,
        ufs,
        produtos: produtos_categorias,
      };
    },
    staleTime: 10 * 60 * 1000, // 10 minutes
  });
}
