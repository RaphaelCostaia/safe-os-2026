import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { differenceInDays, parseISO } from "date-fns";
import { toast } from "sonner";
import { invalidateEntityQueries } from "@/lib/queryInvalidation";
import { updateObservationsCrmStage } from "@/hooks/useClients";

export interface SyncStatusResult {
  hasDivergence: boolean;
  expectedStatus: "ativo" | "inativo" | "prospecto";
  reason: string;
}

/**
 * Calculates what the correct cadastral status should be based on policies.
 * 
 * Rules:
 * 1. If the client has AT LEAST ONE policy with status "ativa" (or "vencendo") and is not expired,
 *    status MUST be "ativo" (Cliente Ativo).
 * 2. If the client has policies, but ALL of them are canceled, expired or ended in the past,
 *    status should be "inativo" (Cliente Inativo).
 * 3. Otherwise (e.g., zero policies), we don't force a correction (could be a prospect, manually active, etc),
 *    but "prospect" status is allowed only if they have ZERO active policies.
 */
export function getExpectedClientStatus(clientStatus: string, policies: any[]): SyncStatusResult {
  const nonDeletedPolicies = (policies || []).filter(p => p && p.deleted_at === null || p.deleted_at === undefined);
  const today = new Date();

  // Helper to determine if a policy is active (Vigente)
  const isPolicyActive = (p: any) => {
    // Check if status is explicitly active (ativa)
    if (p.status !== "ativa" && p.status !== "vencendo") return false;
    
    // Check date expiration
    if (!p.data_fim) return true; // if no end date, treat as active
    try {
      const dbDate = new Date(p.data_fim);
      const days = differenceInDays(dbDate, today);
      return days >= 0;
    } catch {
      return true;
    }
  };

  const activePolicies = nonDeletedPolicies.filter(isPolicyActive);
  const hasActivePolicy = activePolicies.length > 0;
  
  const hasAnyPolicy = nonDeletedPolicies.length > 0;
  const allPoliciesInactive = hasAnyPolicy && nonDeletedPolicies.every(p => {
    if (p.status === "cancelada" || p.status === "expirada") return true;
    if (!p.data_fim) return false;
    try {
      const dbDate = new Date(p.data_fim);
      const days = differenceInDays(dbDate, today);
      return days < 0; // expired in the past
    } catch {
      return false;
    }
  });

  const normalizedStatus = (clientStatus || "").toLowerCase().trim();

  // Rule 1: At least one active policy => Must be ATIVO
  if (hasActivePolicy) {
    if (normalizedStatus !== "ativo") {
      return {
        hasDivergence: true,
        expectedStatus: "ativo",
        reason: `Possui ${activePolicies.length} apólice(s) vigente(s), mas o cadastro está como "${clientStatus}". Situação ajustada automaticamente para Ativo.`
      };
    }
  } 
  // Rule 2: Has policies, but all inactive => Must be INATIVO
  else if (allPoliciesInactive) {
    if (normalizedStatus === "ativo") {
      return {
        hasDivergence: true,
        expectedStatus: "inativo",
        reason: `Todas as apólices (${nonDeletedPolicies.length}) estão canceladas ou expiradas, mas o cadastro consta como "Ativo". Situação recomendada: Inativo.`
      };
    }
  }

  // No forced change needed
  return {
    hasDivergence: false,
    expectedStatus: (normalizedStatus === "ativo" || normalizedStatus === "inativo" || normalizedStatus === "prospecto") 
      ? normalizedStatus as any 
      : "prospecto",
    reason: ""
  };
}

/**
 * Mutation to sync a single client's status in the database based on their policies.
 */
export function useSyncClientStatus() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (clientId: string) => {
      // 1. Fetch client and their policies
      const { data: client, error: clientError } = await supabase
        .from("clients")
        .select(`
          id,
          status,
          observacoes,
          apolices (id, status, data_fim)
        `)
        .eq("id", clientId)
        .is("deleted_at", null)
        .single();

      if (clientError || !client) {
        throw new Error(clientError?.message || "Cliente não encontrado.");
      }

      // Check divergence
      const syncResult = getExpectedClientStatus(client.status, client.apolices);

      if (syncResult.hasDivergence && syncResult.expectedStatus !== client.status) {
        // Sync CRM tag if status was updated
        let finalObs = client.observacoes || "";
        const targetStatus = syncResult.expectedStatus;
        
        // Keep tag sync
        const crmStage = targetStatus === "ativo" ? "convertido" : targetStatus === "inativo" ? "perdido" : "contato";
        finalObs = updateObservationsCrmStage(finalObs, crmStage);

        const { error: updateError } = await supabase
          .from("clients")
          .update({ 
            status: targetStatus,
            observacoes: finalObs,
            updated_at: new Date().toISOString()
          })
          .eq("id", clientId);

        if (updateError) throw updateError;
        return { clientId, updated: true, newStatus: targetStatus, reason: syncResult.reason };
      }

      return { clientId, updated: false, newStatus: client.status, reason: "" };
    },
    onSuccess: (data) => {
      invalidateEntityQueries(queryClient, "clients");
      invalidateEntityQueries(queryClient, "crm_leads");
      if (data && data.updated) {
        toast.success(`Cadastro atualizado: cliente alterado para ${data.newStatus === "ativo" ? "Ativo" : "Inativo"}`);
      }
    }
  });
}

/**
 * Executes a bulk correction of all active/inactive client status discrepancies.
 * Perfect for the "rotina de correção nos cadastros já existentes".
 */
export function useBulkClientStatusSync() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async () => {
      // 1. Fetch all non-deleted clients and their policies
      const { data: clients, error: fetchError } = await supabase
        .from("clients")
        .select(`
          id,
          nome,
          status,
          observacoes,
          apolices (id, status, data_fim)
        `)
        .is("deleted_at", null);

      if (fetchError) throw fetchError;
      if (!clients) return { totalUpdated: 0, details: [] };

      let totalUpdated = 0;
      const details: Array<{ id: string; name: string; oldStatus: string; newStatus: string }> = [];

      // Perform updates sequentially or in batches to avoid locking, and track results
      for (const client of clients) {
        const syncResult = getExpectedClientStatus(client.status, client.apolices);
        
        if (syncResult.hasDivergence && syncResult.expectedStatus !== client.status) {
          const targetStatus = syncResult.expectedStatus;
          let finalObs = client.observacoes || "";
          const crmStage = targetStatus === "ativo" ? "convertido" : targetStatus === "inativo" ? "perdido" : "contato";
          finalObs = updateObservationsCrmStage(finalObs, crmStage);

          const { error: updateError } = await supabase
            .from("clients")
            .update({
              status: targetStatus,
              observacoes: finalObs,
              updated_at: new Date().toISOString()
            })
            .eq("id", client.id);

          if (!updateError) {
            totalUpdated++;
            details.push({
              id: client.id,
              name: client.nome,
              oldStatus: client.status || "",
              newStatus: targetStatus
            });
          } else {
            console.error(`Falha ao sincronizar em lote clt: ${client.nome}`, updateError);
          }
        }
      }

      return { totalUpdated, details };
    },
    onSuccess: (res) => {
      invalidateEntityQueries(queryClient, "clients");
      invalidateEntityQueries(queryClient, "crm_leads");
      if (res && res.totalUpdated > 0) {
        toast.success(`Rotina executada! ${res.totalUpdated} cliente(s) foram corrigidos e sincronizados.`);
      } else {
        toast.success(`Rotina de verificação concluída. Todos os cadastros estão 100% sincronizados!`);
      }
    },
    onError: (err: any) => {
      toast.error(`Erro ao executar rotina de correção em lote: ${err.message || 'Erro desconhecido'}`);
    }
  });
}
