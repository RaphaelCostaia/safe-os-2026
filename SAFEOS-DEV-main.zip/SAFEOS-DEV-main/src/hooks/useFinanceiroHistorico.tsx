import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { parseISO, subMonths, startOfMonth, endOfMonth, isBefore } from "date-fns";

export interface FinanceiroHistoricoMes {
  id: string;
  mes: number;
  ano: number;
  receita_premios: number;
  receita_comissoes: number;
  receita_outras: number;
  receita_total: number;
  custos_fixos: number;
  custos_variaveis: number;
  custos_total: number;
  resultado_operacional: number;
  ticket_medio: number | null;
  total_apolices_ativas: number | null;
  total_clientes_ativos: number | null;
}

// Get formatted month name
const MONTH_NAMES = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];

async function getDynamicFinanceiroHistory(limit: number): Promise<FinanceiroHistoricoMes[]> {
  const hoje = new Date();
  
  // Parallel data fetching for real-time aggregation from active entities
  const [
    apolicesResult,
    custosResult,
    contasResult,
    commissionsResult,
    clientsResult
  ] = await Promise.all([
    supabase
      .from("apolices")
      .select("id, client_id, valor_premio, data_inicio, data_fim, status, created_at, produto_id, produtos(comissao_percentual)")
      .is("deleted_at", null),
    supabase
      .from("custos_fixos")
      .select("*"),
    supabase
      .from("contas")
      .select("*"),
    (async () => {
      try {
        const { data, error } = await supabase
          .from("client_commission_terms")
          .select("client_id, produto_id, percent, is_active")
          .eq("is_active", true);
        if (error) throw error;
        return { data, error: null };
      } catch (err) {
        console.warn("useFinanceiroHistorico: Falling back to legacy client_commission_terms:", err);
        try {
          const { data, error } = await supabase
            .from("client_commission_terms")
            .select("client_id, percent, is_active")
            .eq("is_active", true);
          if (error) throw error;
          const mapped = (data || []).map(item => ({
            ...item,
            produto_id: null
          }));
          return { data: mapped, error: null };
        } catch (innerErr) {
          console.error("Critical error fetching commissions in useFinanceiroHistorico details:", innerErr);
          return { data: [], error: innerErr };
        }
      }
    })(),
    supabase
      .from("clients")
      .select("id, status, created_at")
  ]);

  const apolices = apolicesResult.data || [];
  const custosFixos = custosResult.data || [];
  const contas = contasResult.data || [];
  const commissions = commissionsResult.data || [];
  const clients = clientsResult.data || [];

  const history: FinanceiroHistoricoMes[] = [];

  for (let i = limit - 1; i >= 0; i--) {
    const targetDate = subMonths(hoje, i);
    const mes = targetDate.getMonth() + 1;
    const ano = targetDate.getFullYear();
    const startOfThisMonth = startOfMonth(targetDate);
    const endOfThisMonth = endOfMonth(targetDate);

    // 1. Calculate active clients in this month
    const activeClientsThisMonth = clients.filter(c => {
      const created = c.created_at ? parseISO(c.created_at) : null;
      if (!created || isNaN(created.getTime())) return false;
      return created <= endOfThisMonth && c.status === 'ativo';
    }).length;

    // 2. Premium & commissions of policies active in this month
    let receitaPremios = 0;
    let receitaComissoes = 0;
    let totalApolicesAtivas = 0;

    apolices.forEach((ap) => {
      const dataInicio = ap.data_inicio ? parseISO(ap.data_inicio) : (ap.created_at ? parseISO(ap.created_at) : null);
      let dataFim = ap.data_fim ? parseISO(ap.data_fim) : null;

      if (!dataInicio || isNaN(dataInicio.getTime())) return;
      if (!dataFim || isNaN(dataFim.getTime())) {
        dataFim = new Date(dataInicio.getFullYear() + 1, dataInicio.getMonth(), dataInicio.getDate());
      }

      // Check if active in this month
      if (dataInicio <= endOfThisMonth && dataFim >= startOfThisMonth) {
        if (ap.status === 'ativa' || ap.status === 'em_renovacao' || ap.status === 'renovada') {
          totalApolicesAtivas++;
          const monthlyPremium = (Number(ap.valor_premio) || 0) / 12;
          receitaPremios += monthlyPremium;

          // Find matching commission terms
          const matchedTerm = commissions.find(t => t.client_id === ap.client_id && t.produto_id === ap.produto_id)
            || commissions.find(t => t.client_id === ap.client_id && t.produto_id === null);

          const rawProd = ap.produtos;
          const prodPercent = rawProd 
            ? (Array.isArray(rawProd) ? rawProd[0]?.comissao_percentual : (rawProd as any).comissao_percentual)
            : 0;

          const percentual = matchedTerm && matchedTerm.percent !== null ? matchedTerm.percent : (prodPercent || 0);
          receitaComissoes += (monthlyPremium * percentual) / 100;
        }
      }
    });

    // 3. Custos Fixos & Variaveis
    let custosFixosMes = 0;
    custosFixos.forEach((c) => {
      if (c.status === 'ativo') {
        const created = c.created_at ? parseISO(c.created_at) : null;
        if (created && created > endOfThisMonth) return;

        const valor = Number(c.valor) || 0;
        if (c.recorrencia === 'mensal') {
          custosFixosMes += valor;
        } else if (c.recorrencia === 'anual') {
          custosFixosMes += valor / 12;
        } else if (c.recorrencia === 'trimestral') {
          custosFixosMes += valor / 3;
        }
      }
    });

    let custosVariaveisMes = 0;
    let receitaOutrasMes = 0;

    // Accounts paid/received in the month
    contas.forEach((conta) => {
      const dateToUse = conta.data_pagamento 
        ? parseISO(conta.data_pagamento) 
        : (conta.vencimento ? parseISO(conta.vencimento) : parseISO(conta.created_at));

      if (dateToUse && dateToUse >= startOfThisMonth && dateToUse <= endOfThisMonth) {
        if (conta.tipo === 'pagar') {
          custosVariaveisMes += Number(conta.valor) || 0;
        } else if (conta.tipo === 'receber') {
          receitaOutrasMes += Number(conta.valor) || 0;
        }
      }
    });

    const receitaTotal = receitaComissoes + receitaOutrasMes;
    const custosTotal = custosFixosMes + custosVariaveisMes;
    const resultadoOperacional = receitaTotal - custosTotal;

    const ticketMedio = totalApolicesAtivas > 0 
      ? ((receitaPremios * 12) / totalApolicesAtivas) 
      : 0;

    history.push({
      id: `dynamic-${mes}-${ano}`,
      mes,
      ano,
      receita_premios: Math.round(receitaPremios),
      receita_comissoes: Math.round(receitaComissoes),
      receita_outras: Math.round(receitaOutrasMes),
      receita_total: Math.round(receitaTotal),
      custos_fixos: Math.round(custosFixosMes),
      custos_variaveis: Math.round(custosVariaveisMes),
      custos_total: Math.round(custosTotal),
      resultado_operacional: Math.round(resultadoOperacional),
      ticket_medio: Math.round(ticketMedio),
      total_apolices_ativas: totalApolicesAtivas,
      total_clientes_ativos: activeClientsThisMonth
    });
  }

  return history;
}

export function useFinanceiroHistorico(limit: number = 12) {
  return useQuery({
    queryKey: ["financeiro_historico", limit],
    queryFn: async (): Promise<FinanceiroHistoricoMes[]> => {
      const { data, error } = await supabase
        .from("financeiro_historico")
        .select("*")
        .order("ano", { ascending: false })
        .order("mes", { ascending: false })
        .limit(limit);

      if (error) throw error;

      if (!data || data.length === 0) {
        // Fallback to real-time dynamic calculator to always show true real-time fed facts
        return getDynamicFinanceiroHistory(limit);
      }

      // Return in chronological order (oldest first)
      return (data || []).reverse() as FinanceiroHistoricoMes[];
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
}

// Format for charts
export interface RevenueChartData {
  month: string;
  receita: number;
  despesas: number;
  lucro: number;
}

export function useRevenueChartData(limit: number = 12) {
  return useQuery({
    queryKey: ["revenue_chart_data", limit],
    queryFn: async (): Promise<RevenueChartData[]> => {
      const { data, error } = await supabase
        .from("financeiro_historico")
        .select("mes, ano, receita_total, custos_total, resultado_operacional")
        .order("ano", { ascending: false })
        .order("mes", { ascending: false })
        .limit(limit);

      if (error) throw error;

      if (!data || data.length === 0) {
        const dynamicSummary = await getDynamicFinanceiroHistory(limit);
        return dynamicSummary.map((item) => ({
          month: MONTH_NAMES[item.mes - 1] || `M${item.mes}`,
          receita: Number(item.receita_total) || 0,
          despesas: Number(item.custos_total) || 0,
          lucro: Number(item.resultado_operacional) || 0,
        }));
      }

      // Return in chronological order (oldest first)
      return (data || []).reverse().map((item) => ({
        month: MONTH_NAMES[item.mes - 1] || `M${item.mes}`,
        receita: Number(item.receita_total) || 0,
        despesas: Number(item.custos_total) || 0,
        lucro: Number(item.resultado_operacional) || 0,
      }));
    },
    staleTime: 5 * 60 * 1000,
  });
}

// Product revenue breakdown (calculated from apolices by produto category)
export interface ProductRevenueData {
  month: string;
  rcp: number;
  vida: number;
  dit: number;
  outros: number;
}

export function useProductRevenueData(limit: number = 6) {
  return useQuery({
    queryKey: ["product_revenue_data", limit],
    queryFn: async (): Promise<ProductRevenueData[]> => {
      // Get apolices with produto info for the last N months
      const { data: apolices, error } = await supabase
        .from("apolices")
        .select(`
          valor_premio,
          created_at,
          status,
          produtos (
            nome,
            categoria
          )
        `)
        .in("status", ["ativa", "em_renovacao", "renovada"])
        .is("deleted_at", null);

      if (error) throw error;

      // Group by month and product category
      const monthlyData: Record<string, { rcp: number; vida: number; dit: number; outros: number }> = {};

      apolices?.forEach((apolice) => {
        const date = new Date(apolice.created_at);
        const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
        const premium = Number(apolice.valor_premio) || 0;
        
        // Safe relationship object extraction (supports both single object and array responses)
        const rawProd = apolice.produtos;
        const categoryRaw = rawProd 
          ? (Array.isArray(rawProd) ? rawProd[0]?.categoria : (rawProd as any).categoria)
          : "outros";
        const category = (categoryRaw || "outros").toLowerCase();

        if (!monthlyData[monthKey]) {
          monthlyData[monthKey] = { rcp: 0, vida: 0, dit: 0, outros: 0 };
        }

        if (category.includes("rcp") || category.includes("responsabilidade")) {
          monthlyData[monthKey].rcp += premium;
        } else if (category.includes("vida")) {
          monthlyData[monthKey].vida += premium;
        } else if (category.includes("dit") || category.includes("renda")) {
          monthlyData[monthKey].dit += premium;
        } else {
          monthlyData[monthKey].outros += premium;
        }
      });

      // Sort and return last N months
      const sortedMonths = Object.keys(monthlyData).sort().slice(-limit);

      return sortedMonths.map((monthKey) => {
        const [year, month] = monthKey.split("-");
        return {
          month: MONTH_NAMES[parseInt(month) - 1] || monthKey,
          ...monthlyData[monthKey],
        };
      });
    },
    staleTime: 5 * 60 * 1000,
  });
}
