import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { usePermissions } from "@/hooks/useUserRole";
import { SafeOSLogo } from "@/components/ui/SafeOSLogo";
import { Resource, Action } from "@/lib/permissions";
import { AlertCircle, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ProtectedRouteProps {
  children: React.ReactNode;
  resource?: Resource;
  action?: Action;
}

export function ProtectedRoute({ children, resource, action = 'view' }: ProtectedRouteProps) {
  const { user, loading } = useAuth();
  const { canAccess, can, isLoading: rolesLoading } = usePermissions();
  const location = useLocation();

  if (loading || rolesLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-pulse">
          <SafeOSLogo size="lg" />
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" state={{ from: location }} replace />;
  }

  // Check resource access if specified
  if (resource) {
    const hasAccess = action === 'view' ? canAccess(resource) : can(resource, action);
    
    if (!hasAccess) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4 text-center">
          <div className="w-24 h-24 rounded-full bg-destructive/10 flex items-center justify-center mb-6">
            <Lock className="h-10 w-10 text-destructive" />
          </div>
          <h1 className="text-2xl font-black uppercase tracking-tighter mb-2">Acesso Restrito</h1>
          <p className="text-muted-foreground max-w-md mb-8">
            Você não possui as permissões necessárias para acessar este módulo. 
            Contate o administrador do sistema se acreditar que isso é um erro.
          </p>
          <Button 
            variant="outline" 
            onClick={() => window.history.back()}
            className="rounded-xl px-12"
          >
            Voltar
          </Button>
        </div>
      );
    }
  }

  return <>{children}</>;
}
