import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useNavigate } from "react-router-dom";
import { Eye, EyeOff, Lock, Loader2, CheckCircle2, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

const resetPasswordSchema = z.object({
  password: z
    .string()
    .min(8, "A senha deve ter no mínimo 8 caracteres")
    .regex(/[A-Z]/, "A senha deve conter pelo menos uma letra maiúscula")
    .regex(/[0-9]/, "A senha deve conter pelo menos um número"),
  confirmPassword: z.string(),
}).refine(data => data.password === data.confirmPassword, {
  message: "As senhas não coincidem",
  path: ["confirmPassword"],
});

type ResetPasswordFormData = z.infer<typeof resetPasswordSchema>;

export function ResetPasswordForm() {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isValidSession, setIsValidSession] = useState<boolean | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm<ResetPasswordFormData>({
    resolver: zodResolver(resetPasswordSchema),
  });

  const password = watch("password", "");

  // Check if we have a valid recovery session
  useEffect(() => {
    const checkSession = async () => {
      // 1. Check if we already have a session (Supabase might have auto-logged in from the link)
      const { data: { session: currentSession } } = await supabase.auth.getSession();
      
      // 2. Check for recovery parameters in hash OR query string
      const hashParams = new URLSearchParams(window.location.hash.substring(1));
      const queryParams = new URLSearchParams(window.location.search);
      
      const isRecoveryHash = hashParams.get("type") === "recovery";
      const isRecoveryQuery = queryParams.get("type") === "recovery";
      const hasAccessToken = hashParams.has("access_token") || queryParams.has("access_token");

      console.log("Password Reset Detection:", {
        hasSession: !!currentSession,
        isRecoveryHash,
        isRecoveryQuery,
        hasAccessToken
      });
      
      if (currentSession || isRecoveryHash || isRecoveryQuery || hasAccessToken) {
        setIsValidSession(true);
      } else {
        // If we don't have any indicator, it's likely an invalid or direct access
        setIsValidSession(false);
      }
    };
    
    checkSession();

    // Listen for auth state changes which might happen as the token is processed
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY" || session) {
        setIsValidSession(true);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const onSubmit = async (data: ResetPasswordFormData) => {
    setIsLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({
        password: data.password,
      });

      if (error) {
        toast({
          variant: "destructive",
          title: "Erro ao redefinir senha",
          description: error.message,
        });
        return;
      }

      setIsSuccess(true);
      
      // Sign out to force fresh login with new password
      await supabase.auth.signOut();
      
      setTimeout(() => {
        navigate("/auth", { replace: true });
      }, 3000);
    } catch {
      toast({
        variant: "destructive",
        title: "Erro inesperado",
        description: "Tente novamente mais tarde.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Password strength indicators
  const passwordChecks = {
    length: password.length >= 8,
    uppercase: /[A-Z]/.test(password),
    number: /[0-9]/.test(password),
  };

  if (isValidSession === null) {
    return (
      <div className="flex items-center justify-center min-h-[300px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isValidSession) {
    return (
      <div className="space-y-6">
        <div className="text-center">
          <div className="mx-auto w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mb-4">
            <AlertTriangle className="h-8 w-8 text-destructive" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Link expirado</h1>
          <p className="mt-2 text-muted-foreground">
            Este link de redefinição de senha expirou ou é inválido.
          </p>
        </div>

        <Button
          className="w-full h-11"
          onClick={() => navigate("/auth")}
        >
          Voltar ao login
        </Button>
      </div>
    );
  }

  if (isSuccess) {
    return (
      <div className="space-y-6">
        <div className="text-center">
          <div className="mx-auto w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
            <CheckCircle2 className="h-8 w-8 text-primary" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Senha redefinida!</h1>
          <p className="mt-2 text-muted-foreground">
            Sua senha foi alterada com sucesso. Você será redirecionado para a tela de login.
          </p>
        </div>

        <div className="flex justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center lg:text-left">
        <h1 className="text-2xl font-bold text-foreground">Redefinir senha</h1>
        <p className="mt-2 text-muted-foreground">
          Digite sua nova senha abaixo
        </p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="password">Nova senha</Label>
          <div className="relative">
            <Input
              id="password"
              type={showPassword ? "text" : "password"}
              placeholder="••••••••••"
              {...register("password")}
              className="h-11 pr-10"
              disabled={isLoading}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              disabled={isLoading}
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          {errors.password && (
            <p className="text-sm text-destructive">{errors.password.message}</p>
          )}
          
          {/* Password strength indicators */}
          {password && (
            <div className="space-y-1 mt-2">
              <div className={`flex items-center gap-2 text-xs ${passwordChecks.length ? "text-primary" : "text-muted-foreground"}`}>
                <CheckCircle2 className={`h-3 w-3 ${passwordChecks.length ? "opacity-100" : "opacity-30"}`} />
                Mínimo 8 caracteres
              </div>
              <div className={`flex items-center gap-2 text-xs ${passwordChecks.uppercase ? "text-primary" : "text-muted-foreground"}`}>
                <CheckCircle2 className={`h-3 w-3 ${passwordChecks.uppercase ? "opacity-100" : "opacity-30"}`} />
                Pelo menos uma letra maiúscula
              </div>
              <div className={`flex items-center gap-2 text-xs ${passwordChecks.number ? "text-primary" : "text-muted-foreground"}`}>
                <CheckCircle2 className={`h-3 w-3 ${passwordChecks.number ? "opacity-100" : "opacity-30"}`} />
                Pelo menos um número
              </div>
            </div>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="confirmPassword">Confirmar nova senha</Label>
          <div className="relative">
            <Input
              id="confirmPassword"
              type={showConfirmPassword ? "text" : "password"}
              placeholder="••••••••••"
              {...register("confirmPassword")}
              className="h-11 pr-10"
              disabled={isLoading}
            />
            <button
              type="button"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
              disabled={isLoading}
            >
              {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          {errors.confirmPassword && (
            <p className="text-sm text-destructive">{errors.confirmPassword.message}</p>
          )}
        </div>

        <Button 
          type="submit" 
          className="w-full h-11 gradient-primary"
          disabled={isLoading}
        >
          {isLoading ? (
            <Loader2 className="h-4 w-4 animate-spin mr-2" />
          ) : (
            <Lock className="h-4 w-4 mr-2" />
          )}
          Redefinir senha
        </Button>
      </form>
    </div>
  );
}
