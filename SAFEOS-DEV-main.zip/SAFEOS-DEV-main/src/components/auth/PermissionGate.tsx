import { ReactNode } from "react";
import { useHasPermission, useCanAccessResource, Resource, Action } from "@/hooks/useUserRole";
import { Loader2 } from "lucide-react";

interface PermissionGateProps {
  /** The resource to check permission for */
  resource: Resource;
  /** The action to check (optional - if not provided, checks if user can access resource at all) */
  action?: Action;
  /** Content to render if user has permission */
  children: ReactNode;
  /** Content to render if user doesn't have permission (default: null) */
  fallback?: ReactNode;
  /** Show loading state while checking permissions */
  showLoading?: boolean;
}

/**
 * Component that conditionally renders children based on user permissions.
 * 
 * Usage:
 * ```tsx
 * <PermissionGate resource="sinistros" action="delete">
 *   <Button variant="destructive">Excluir</Button>
 * </PermissionGate>
 * ```
 */
export function PermissionGate({ 
  resource, 
  action, 
  children, 
  fallback = null,
  showLoading = false
}: PermissionGateProps) {
  // If action is specified, check specific permission
  // Otherwise, check if user can access the resource at all
  const hasSpecificPermission = useHasPermission(resource, action || 'view');
  const canAccessResource = useCanAccessResource(resource);
  
  const hasPermission = action ? hasSpecificPermission : canAccessResource;

  if (showLoading && hasPermission === false) {
    return (
      <div className="flex items-center justify-center p-4">
        <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!hasPermission) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
}

/**
 * HOC to wrap a component with permission checking
 */
export function withPermission<P extends object>(
  WrappedComponent: React.ComponentType<P>,
  resource: Resource,
  action?: Action,
  FallbackComponent?: React.ComponentType
) {
  return function WithPermissionComponent(props: P) {
    return (
      <PermissionGate
        resource={resource}
        action={action}
        fallback={FallbackComponent ? <FallbackComponent /> : null}
      >
        <WrappedComponent {...props} />
      </PermissionGate>
    );
  };
}

/**
 * Component that shows "Acesso negado" message
 */
export function AccessDenied() {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center">
      <div className="p-4 rounded-full bg-destructive/10 mb-4">
        <svg
          className="h-8 w-8 text-destructive"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
          />
        </svg>
      </div>
      <h3 className="text-lg font-semibold mb-2">Acesso Negado</h3>
      <p className="text-muted-foreground text-sm">
        Você não tem permissão para acessar este recurso.
      </p>
    </div>
  );
}
