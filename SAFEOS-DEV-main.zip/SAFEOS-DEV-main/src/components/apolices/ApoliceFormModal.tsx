import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Shield, Percent, Coins, Loader2, CreditCard, Calendar } from "lucide-react";
import { useCreateApolice, useUpdateApolice, type ApoliceWithRelations } from "@/hooks/useApolices";
import { useClients, safeParseMetadata } from "@/hooks/useClients";
import { useProdutos, resolveOrCreateProduto } from "@/hooks/useProdutos";
import { ProdutoCombobox } from "@/components/produtos/ProdutoCombobox";
import { useClientActiveCommissions, useCreateClientCommission } from "@/hooks/useClientCommission";
import { useClientPolicies } from "@/hooks/useClientPolicies";
import { toast } from "sonner";

interface ApoliceFormModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  clientId?: string;
  editingApolice?: ApoliceWithRelations | null;
  onSuccess?: () => void;
}

export function ApoliceFormModal({
  isOpen,
  onOpenChange,
  clientId,
  editingApolice = null,
  onSuccess,
}: ApoliceFormModalProps) {
  const { data: clients } = useClients();
  const { data: produtos } = useProdutos();
  
  const createApolice = useCreateApolice();
  const updateApolice = useUpdateApolice();
  const createClientCommission = useCreateClientCommission();

  const [activeEditingApolice, setActiveEditingApolice] = useState<any>(null);

  const [formData, setFormData] = useState({
    numero_apolice: "",
    client_id: "",
    produto_id: "",
    seguradora: "",
    valor_premio: "",
    data_inicio: "",
    data_fim: "",
    status: "ativa",
    comissao_real_percent: "",
    valor_comissao_real: "",
    data_renovacao: "",
    forma_pagamento: "parcelado",
    parcelas: "11",
    meio_pagamento: "boleto",
    observacoes: "",
  });

  const { data: activeCommissions } = useClientActiveCommissions(formData.client_id);
  const { data: clientPolicies } = useClientPolicies(formData.client_id);
  const [salvarAcordoIndividual, setSalvarAcordoIndividual] = useState(true);
  const [customProductName, setCustomProductName] = useState("");

  // Helper to parse observations and metadata
  const parseApoliceObservacoes = (observacoesText: string | null) => {
    const defaultMeta = {
      comissao_real_percent: "",
      valor_comissao_real: "",
      data_renovacao: "",
      forma_pagamento: "parcelado",
      parcelas: "11",
      meio_pagamento: "boleto",
    };
    if (!observacoesText) return { notes: "", meta: defaultMeta };
    const divider = "-- METADATA_APOLICE_V1 --";
    const parts = observacoesText.split(divider);
    if (parts.length < 2) return { notes: observacoesText, meta: defaultMeta };
    try {
      const meta = JSON.parse(parts[1].trim());
      return { notes: parts[0].trim(), meta: { ...defaultMeta, ...meta } };
    } catch {
      return { notes: observacoesText, meta: defaultMeta };
    }
  };

  // Manage activeEditingApolice synchronization with prop
  useEffect(() => {
    if (isOpen) {
      setActiveEditingApolice(editingApolice);
    } else {
      setActiveEditingApolice(null);
    }
  }, [isOpen, editingApolice]);

  // Sync state with props / activeEditingApolice
  useEffect(() => {
    if (isOpen) {
      if (activeEditingApolice) {
        const { notes, meta } = parseApoliceObservacoes(activeEditingApolice.observacoes);
        const explicitForma = (activeEditingApolice as any).forma_pagamento;
        const explicitParcelas = (activeEditingApolice as any).parcelas;
        const resolvedForma = explicitForma || meta.forma_pagamento || (explicitParcelas === 1 ? "a_vista" : "parcelado");
        const resolvedParcelas = explicitParcelas ? String(explicitParcelas) : (meta.parcelas ? String(meta.parcelas) : "11");
        const resolvedMeio = meta.meio_pagamento || "boleto";

        setFormData({
          numero_apolice: (activeEditingApolice._transitionToActive && activeEditingApolice.numero_apolice.startsWith("PROP-")) ? "" : activeEditingApolice.numero_apolice,
          client_id: activeEditingApolice.client_id,
          produto_id: activeEditingApolice.produto_id,
          seguradora: activeEditingApolice.seguradora,
          valor_premio: activeEditingApolice.valor_premio.toString(),
          data_inicio: activeEditingApolice.data_inicio,
          data_fim: activeEditingApolice.data_fim,
          status: activeEditingApolice._transitionToActive ? "ativa" : activeEditingApolice.status,
          comissao_real_percent: meta.comissao_real_percent || "",
          valor_comissao_real: meta.valor_comissao_real || "",
          data_renovacao: meta.data_renovacao || "",
          forma_pagamento: resolvedForma,
          parcelas: resolvedParcelas,
          meio_pagamento: resolvedMeio,
          observacoes: notes || "",
        });
        setCustomProductName(activeEditingApolice.produtos?.nome || "");
      } else {
        const targetClient = clients?.find(c => c.id === clientId);
        let clientForma = "parcelado";
        let clientParcelas = "11";
        let clientMeio = "boleto";
        if (targetClient?.observacoes) {
          const parsed = safeParseMetadata(targetClient.observacoes);
          if (parsed?.forma_pagamento_preferencial) clientForma = parsed.forma_pagamento_preferencial;
          if (parsed?.parcelas_preferenciais) clientParcelas = String(parsed.parcelas_preferenciais);
          if (parsed?.meio_pagamento) clientMeio = parsed.meio_pagamento;
        }

        setFormData({
          numero_apolice: "",
          client_id: clientId || "",
          produto_id: "",
          seguradora: "",
          valor_premio: "",
          data_inicio: "",
          data_fim: "",
          status: "ativa",
          comissao_real_percent: "",
          valor_comissao_real: "",
          data_renovacao: "",
          forma_pagamento: clientForma,
          parcelas: clientForma === "a_vista" ? "1" : clientParcelas,
          meio_pagamento: clientMeio,
          observacoes: "",
        });
        setCustomProductName("");
      }
      setSalvarAcordoIndividual(true);
    }
  }, [isOpen, activeEditingApolice, clientId, clients]);

  // Detect pending proposals of this product
  const pendingProposal = !activeEditingApolice && formData.produto_id && clientPolicies?.find(
    (p) => p.status === "pendente" && p.produto_id === formData.produto_id
  );

  const handleSubmit = async () => {
    if (!formData.client_id) {
      toast.error("O campo Cliente é obrigatório");
      return;
    }
    if (!formData.numero_apolice) {
      toast.error("O Número da Apólice é obrigatório");
      return;
    }
    if (!formData.data_inicio || !formData.data_fim) {
      toast.error("As datas de vigência (Início e Fim) são obrigatórias");
      return;
    }

    // Resolve product ID if not selected or if custom text was typed
    let finalProdutoId = formData.produto_id;
    if (!finalProdutoId) {
      try {
        const resolved = await resolveOrCreateProduto({
          produtoId: formData.produto_id,
          produtoNome: customProductName || (produtos && produtos.length > 0 ? produtos[0].nome : "Seguro Geral / RCP"),
          seguradora: formData.seguradora || "Porto Seguro",
          comissao_percentual: formData.comissao_real_percent || 20,
        });
        finalProdutoId = resolved.id;
      } catch (err) {
        console.warn("Fallback de produto será resolvido na gravação:", err);
      }
    }

    const parcelasNum = formData.forma_pagamento === "a_vista" ? 1 : (parseInt(formData.parcelas, 10) || 11);
    const meta = {
      comissao_real_percent: formData.comissao_real_percent,
      valor_comissao_real: formData.valor_comissao_real,
      data_renovacao: formData.data_renovacao,
      forma_pagamento: formData.forma_pagamento,
      parcelas: parcelasNum,
      meio_pagamento: formData.meio_pagamento,
    };
    
    const divider = "-- METADATA_APOLICE_V1 --";
    const finalObservacoes = `${formData.observacoes.trim()}\n\n${divider}\n${JSON.stringify(meta)}`;

    const data = {
      numero_apolice: formData.numero_apolice,
      client_id: formData.client_id,
      produto_id: finalProdutoId,
      seguradora: formData.seguradora,
      valor_premio: parseFloat(formData.valor_premio) || 0,
      data_inicio: formData.data_inicio,
      data_fim: formData.data_fim,
      status: formData.status,
      forma_pagamento: formData.forma_pagamento,
      parcelas: parcelasNum,
      observacoes: finalObservacoes,
    };

    const handleSuccessCallback = () => {
      if (salvarAcordoIndividual && formData.comissao_real_percent && formData.client_id && finalProdutoId) {
        const pct = parseFloat(formData.comissao_real_percent);
        if (!isNaN(pct) && pct > 0) {
          createClientCommission.mutate({
            client_id: formData.client_id,
            produto_id: finalProdutoId,
            model: "percentual",
            percent: pct,
            starts_at: formData.data_inicio || new Date().toISOString().split('T')[0],
            notes: `Definido individualmente no contrato de apólice #${formData.numero_apolice}`,
          });
        }
      }
      onOpenChange(false);
      if (onSuccess) {
        onSuccess();
      }
    };

    if (activeEditingApolice) {
      updateApolice.mutate({ id: activeEditingApolice.id, ...data }, {
        onSuccess: handleSuccessCallback,
      });
    } else {
      createApolice.mutate(data, {
        onSuccess: handleSuccessCallback,
      });
    }
  };

  const premioNum = parseFloat(formData.valor_premio) || 0;
  const comissaoNum = parseFloat(formData.valor_comissao_real) || ((premioNum * (parseFloat(formData.comissao_real_percent) || 0)) / 100);
  const parcelasNum = formData.forma_pagamento === "a_vista" ? 1 : (parseInt(formData.parcelas, 10) || 11);
  const premioPorParcela = parcelasNum > 0 ? (premioNum / parcelasNum) : 0;
  const comissaoPorParcela = parcelasNum > 0 ? (comissaoNum / parcelasNum) : 0;

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl max-h-[92vh] overflow-y-auto border-border bg-card">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg font-bold">
            <Shield className="h-5 w-5 text-primary" />
            {activeEditingApolice?._transitionToActive 
              ? "Emitir Apólice (Efetivar Proposta)" 
              : activeEditingApolice 
                ? "Editar Apólice / Proposta" 
                : "Nova Apólice / Proposta"}
          </DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-1">
              <Label htmlFor="status" className="text-xs font-bold uppercase text-muted-foreground">Tipo / Estágio</Label>
              <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ativa">Vigente (Ativa)</SelectItem>
                  <SelectItem value="pendente">Pendente / Proposta</SelectItem>
                  <SelectItem value="expirada">Vencida</SelectItem>
                  <SelectItem value="cancelada">Cancelada</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-1">
              <Label htmlFor="numero_apolice" className="text-xs font-bold uppercase text-muted-foreground">Número do Contrato</Label>
              <Input
                id="numero_apolice"
                value={formData.numero_apolice}
                onChange={(e) => setFormData({ ...formData, numero_apolice: e.target.value })}
                placeholder={formData.status === "pendente" ? "PROP-PENDENTE" : "Ex: RCP-2024-001"}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="grid gap-1">
              <Label htmlFor="client_id" className="text-xs font-bold uppercase text-muted-foreground">Cliente</Label>
              <Select 
                value={formData.client_id} 
                onValueChange={(v) => {
                  const targetClient = clients?.find(c => c.id === v);
                  let clientForma = formData.forma_pagamento;
                  let clientParcelas = formData.parcelas;
                  let clientMeio = formData.meio_pagamento;
                  if (targetClient?.observacoes) {
                    const parsed = safeParseMetadata(targetClient.observacoes);
                    if (parsed?.forma_pagamento_preferencial) clientForma = parsed.forma_pagamento_preferencial;
                    if (parsed?.parcelas_preferenciais) clientParcelas = String(parsed.parcelas_preferenciais);
                    if (parsed?.meio_pagamento) clientMeio = parsed.meio_pagamento;
                  }
                  setFormData(prev => ({
                    ...prev,
                    client_id: v,
                    forma_pagamento: clientForma,
                    parcelas: clientForma === "a_vista" ? "1" : clientParcelas,
                    meio_pagamento: clientMeio,
                  }));
                }}
                disabled={!!clientId}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um cliente" />
                </SelectTrigger>
                <SelectContent>
                  {clients?.map((client) => (
                    <SelectItem key={client.id} value={client.id}>{client.nome}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <ProdutoCombobox
              label="Produto do Seguro"
              value={formData.produto_id}
              customValue={customProductName}
              onCustomValueChange={setCustomProductName}
              required={false}
              defaultSeguradora={formData.seguradora || "Porto Seguro"}
              defaultComissao={formData.comissao_real_percent || 20}
              onChange={(v, produto, customNome) => {
                let optPercent = "";
                if (!activeEditingApolice) {
                  const matchedTerm = activeCommissions?.find(t => t.produto_id === v)
                    || activeCommissions?.find(t => t.produto_id === null);
                  optPercent = matchedTerm?.percent !== undefined && matchedTerm?.percent !== null
                    ? String(matchedTerm.percent)
                    : (produto?.comissao_percentual !== null && produto?.comissao_percentual !== undefined ? String(produto.comissao_percentual) : "");
                }
                
                const premio = parseFloat(formData.valor_premio) || 0;
                const pPercent = optPercent ? parseFloat(optPercent) : (parseFloat(formData.comissao_real_percent) || 0);
                const calculatedValor = premio > 0 && pPercent > 0 ? ((premio * pPercent) / 100).toFixed(2) : "";

                setFormData({ 
                  ...formData, 
                  produto_id: v,
                  seguradora: produto?.seguradora || formData.seguradora,
                  comissao_real_percent: optPercent || formData.comissao_real_percent,
                  valor_comissao_real: calculatedValor || formData.valor_comissao_real
                });
                if (customNome !== undefined) {
                  setCustomProductName(customNome);
                }
              }}
            />
          </div>

          {pendingProposal && (
            <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-sm animate-in fade-in duration-300">
              <div className="flex items-start gap-2">
                <span className="text-lg mt-0.5">💡</span>
                <div>
                  <p className="font-bold text-amber-900 dark:text-amber-400">Proposta Pendente Encontrada</p>
                  <p className="text-xs text-amber-800 dark:text-amber-500 mt-0.5">
                    Identificamos uma proposta pendente ({pendingProposal.numero_apolice}) para este produto e cliente.
                  </p>
                </div>
              </div>
              <Button
                type="button"
                size="sm"
                className="bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs whitespace-nowrap self-end sm:self-center"
                onClick={() => {
                  setActiveEditingApolice({
                    ...pendingProposal,
                    _transitionToActive: true,
                  });
                }}
              >
                Vincular & Emitir
              </Button>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-1">
              <Label htmlFor="seguradora" className="text-xs font-bold uppercase text-muted-foreground">Seguradora</Label>
              <Input
                id="seguradora"
                value={formData.seguradora}
                onChange={(e) => setFormData({ ...formData, seguradora: e.target.value })}
                placeholder="Ex: Tokio Marine"
              />
            </div>

            <div className="grid gap-1">
              <Label htmlFor="valor_premio" className="text-xs font-bold uppercase text-muted-foreground">Prêmio Emitido / Estimado (R$)</Label>
              <Input
                id="valor_premio"
                type="number"
                step="0.01"
                value={formData.valor_premio}
                onChange={(e) => {
                  const premioVal = e.target.value;
                  const premio = parseFloat(premioVal) || 0;
                  const pPercent = parseFloat(formData.comissao_real_percent) || 0;
                  const calculatedValor = ((premio * pPercent) / 100).toFixed(2);
                  setFormData({
                    ...formData,
                    valor_premio: premioVal,
                    valor_comissao_real: calculatedValor === "0.00" ? "" : calculatedValor
                  });
                }}
                placeholder="5000.00"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-1">
              <Label htmlFor="data_inicio" className="text-xs font-bold uppercase text-muted-foreground">Início da vigência</Label>
              <Input
                id="data_inicio"
                type="date"
                value={formData.data_inicio}
                onChange={(e) => setFormData({ ...formData, data_inicio: e.target.value })}
                required
              />
            </div>
            <div className="grid gap-1">
              <Label htmlFor="data_fim" className="text-xs font-bold uppercase text-muted-foreground">Vencimento</Label>
              <Input
                id="data_fim"
                type="date"
                value={formData.data_fim}
                onChange={(e) => setFormData({ ...formData, data_fim: e.target.value })}
                required
              />
            </div>
          </div>

          {/* COMMISSION & RENEWAL DATA SECTION */}
          <div className="border-t border-border/40 mt-2 pt-4 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Valores de Comissão & Renovação</h4>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-1">
                <Label htmlFor="comissao_real_percent" className="text-xs font-bold uppercase text-deep-purple flex items-center gap-1">
                  <Percent className="h-3.5 w-3.5" /> Comissão Real %
                </Label>
                <div className="relative">
                  <Input
                    id="comissao_real_percent"
                    type="number"
                    step="0.01"
                    value={formData.comissao_real_percent}
                    onChange={(e) => {
                      const val = e.target.value;
                      const premio = parseFloat(formData.valor_premio) || 0;
                      const pPercent = parseFloat(val) || 0;
                      const calculatedValor = ((premio * pPercent) / 100).toFixed(2);
                      setFormData({ 
                        ...formData, 
                        comissao_real_percent: val,
                        valor_comissao_real: calculatedValor === "0.00" ? "" : calculatedValor
                      });
                    }}
                    placeholder="Ex: 12.5"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-xs font-bold">%</span>
                </div>
              </div>

              <div className="grid gap-1">
                <Label htmlFor="valor_comissao_real" className="text-xs font-bold uppercase text-emerald-800 flex items-center gap-1">
                  <Coins className="h-3.5 w-3.5" /> Valor Comissão Real (R$)
                </Label>
                <Input
                  id="valor_comissao_real"
                  type="number"
                  step="0.01"
                  value={formData.valor_comissao_real}
                  onChange={(e) => {
                    const valInput = e.target.value;
                    const valVal = parseFloat(valInput) || 0;
                    const premio = parseFloat(formData.valor_premio) || 0;
                    let calculatedPercent = formData.comissao_real_percent;
                    if (premio > 0 && valVal > 0) {
                      calculatedPercent = ((valVal / premio) * 100).toFixed(2);
                    }
                    setFormData({
                      ...formData,
                      valor_comissao_real: valInput,
                      comissao_real_percent: calculatedPercent
                    });
                  }}
                  placeholder="Auto-calculado ou valor customizado"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              <div className="grid gap-1">
                <Label htmlFor="data_renovacao" className="text-xs font-bold uppercase text-muted-foreground">Previsão de Próxima Renovação</Label>
                <Input
                  id="data_renovacao"
                  type="date"
                  value={formData.data_renovacao}
                  onChange={(e) => setFormData({ ...formData, data_renovacao: e.target.value })}
                />
              </div>
            </div>

            <div className="flex items-start gap-2.5 p-3 rounded-lg border border-primary/10 bg-primary/5 mt-2">
              <input
                id="salvar_acordo"
                type="checkbox"
                checked={salvarAcordoIndividual}
                onChange={(e) => setSalvarAcordoIndividual(e.target.checked)}
                className="mt-1 h-4 w-4 rounded border-border text-primary focus:ring-primary accent-primary cursor-pointer"
              />
              <div className="grid gap-0.5">
                <Label htmlFor="salvar_acordo" className="text-xs font-semibold text-primary/95 cursor-pointer select-none">
                  Sincronizar Acordo de Comissão com o Cliente
                </Label>
                <p className="text-[10px] text-muted-foreground select-none">
                  Marca este percentual como a negociação individual ativa para este cliente neste produto contratado, atualizando futuros cálculos automaticamente.
                </p>
              </div>
            </div>
          </div>

          {/* SEÇÃO: FORMA DE PAGAMENTO DO SEGURO E CRONOGRAMA DE COMISSÕES */}
          <div className="p-4 rounded-xl border bg-muted/20 space-y-4">
            <div className="flex items-center justify-between border-b border-border/20 pb-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-foreground flex items-center gap-1.5">
                <CreditCard className="h-4 w-4 text-primary" />
                Forma de Pagamento do Seguro (Previsão de Comissões)
              </h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="grid gap-1">
                <Label htmlFor="forma_pagamento" className="text-xs font-bold uppercase text-muted-foreground">Forma de Pagamento</Label>
                <Select 
                  value={formData.forma_pagamento} 
                  onValueChange={(v) => {
                    setFormData({
                      ...formData,
                      forma_pagamento: v,
                      parcelas: v === "a_vista" ? "1" : (formData.parcelas === "1" ? "11" : formData.parcelas)
                    });
                  }}
                >
                  <SelectTrigger id="forma_pagamento">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="parcelado">Parcelado (até 11x ou 12x)</SelectItem>
                    <SelectItem value="a_vista">À Vista (1x)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-1">
                <Label htmlFor="parcelas" className="text-xs font-bold uppercase text-muted-foreground">Número de Parcelas</Label>
                <Select 
                  value={formData.parcelas} 
                  onValueChange={(v) => setFormData({ ...formData, parcelas: v })}
                  disabled={formData.forma_pagamento === "a_vista"}
                >
                  <SelectTrigger id="parcelas">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1x (À vista)</SelectItem>
                    <SelectItem value="2">2x</SelectItem>
                    <SelectItem value="3">3x</SelectItem>
                    <SelectItem value="4">4x</SelectItem>
                    <SelectItem value="5">5x</SelectItem>
                    <SelectItem value="6">6x</SelectItem>
                    <SelectItem value="7">7x</SelectItem>
                    <SelectItem value="8">8x</SelectItem>
                    <SelectItem value="9">9x</SelectItem>
                    <SelectItem value="10">10x</SelectItem>
                    <SelectItem value="11" className="font-semibold text-primary">11x (Padrão Seguradoras)</SelectItem>
                    <SelectItem value="12">12x (Anual integral)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-1">
                <Label htmlFor="meio_pagamento" className="text-xs font-bold uppercase text-muted-foreground">Meio de Pagamento</Label>
                <Select 
                  value={formData.meio_pagamento} 
                  onValueChange={(v) => setFormData({ ...formData, meio_pagamento: v })}
                >
                  <SelectTrigger id="meio_pagamento">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="boleto">Boleto Bancário</SelectItem>
                    <SelectItem value="cartao">Cartão de Crédito</SelectItem>
                    <SelectItem value="debito">Débito em Conta</SelectItem>
                    <SelectItem value="pix">Pix</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Simulação em Tempo Real dos Marcadores: Prêmio Emitido vs Comissão Corretora */}
            {premioNum > 0 && (
              <div className="p-3 rounded-lg border bg-card/70 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs shadow-xs">
                <div>
                  <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider">Prêmio Emitido</span>
                  <span className="font-semibold text-foreground text-sm">
                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(premioNum)}
                  </span>
                  <span className="text-[10px] text-muted-foreground block">
                    {parcelasNum}x de {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(premioPorParcela)}
                  </span>
                </div>
                <div>
                  <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider">Comissão Total Corretora</span>
                  <span className="font-semibold text-emerald-700 dark:text-emerald-400 text-sm">
                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(comissaoNum)}
                  </span>
                  <span className="text-[10px] text-muted-foreground block">
                    {formData.comissao_real_percent ? `${formData.comissao_real_percent}% da produção` : "Base contratual"}
                  </span>
                </div>
                <div>
                  <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider">Comissão Mensal / Parcela</span>
                  <span className="font-bold text-emerald-700 dark:text-emerald-400 text-sm">
                    {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(comissaoPorParcela)} / mês
                  </span>
                  <span className="text-[10px] text-muted-foreground block">
                    {formData.forma_pagamento === "a_vista" ? "Recebimento integral no 1º mês" : `Recebimento em ${parcelasNum} meses`}
                  </span>
                </div>
              </div>
            )}
          </div>

          <div className="grid gap-1">
            <Label htmlFor="observacoes" className="text-xs font-bold uppercase text-muted-foreground">Comentários / Observações</Label>
            <Input
              id="observacoes"
              value={formData.observacoes}
              onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
              placeholder="Insira detalhes adicionais do processo ou termos comerciais"
            />
          </div>
        </div>
        <DialogFooter className="p-4 border-t bg-muted/15 flex gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button 
            onClick={handleSubmit}
            disabled={createApolice.isPending || updateApolice.isPending || !formData.client_id || !formData.numero_apolice || !formData.data_inicio || !formData.data_fim}
          >
            {(createApolice.isPending || updateApolice.isPending) && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            {activeEditingApolice?._transitionToActive 
              ? "Emitir Apólice" 
              : activeEditingApolice 
                ? "Salvar Alterações" 
                : "Salvar Apólice / Proposta"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
