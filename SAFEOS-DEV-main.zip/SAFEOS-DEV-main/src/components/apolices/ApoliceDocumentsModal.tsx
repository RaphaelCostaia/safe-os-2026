import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { 
  Upload, 
  FileText, 
  Trash2, 
  Download, 
  Eye, 
  Loader2,
  File,
  FileImage,
  AlertCircle
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import type { Tables } from "@/integrations/supabase/types";

interface ApoliceDocumentsModalProps {
  apoliceId: string;
  apoliceNumero: string;
  trigger: React.ReactNode;
}

type ApoliceDocument = Tables<"apolice_documents">;

const BUCKET_NAME = "apolice-documents";
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB

export function ApoliceDocumentsModal({ apoliceId, apoliceNumero, trigger }: ApoliceDocumentsModalProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const queryClient = useQueryClient();

  // Fetch documents
  const { data: documents = [], isLoading } = useQuery({
    queryKey: ["apolice-documents", apoliceId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("apolice_documents")
        .select("*")
        .eq("apolice_id", apoliceId)
        .order("created_at", { ascending: false });
      
      if (error) throw error;
      return data as ApoliceDocument[];
    },
    enabled: isOpen,
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (doc: ApoliceDocument) => {
      // Extract file path from URL
      const urlParts = doc.url.split("/");
      const filePath = urlParts.slice(-2).join("/");
      
      // Delete from storage
      const { error: storageError } = await supabase.storage
        .from(BUCKET_NAME)
        .remove([filePath]);
      
      if (storageError) {
        console.warn("Storage delete error:", storageError);
      }
      
      // Delete from database
      const { error: dbError } = await supabase
        .from("apolice_documents")
        .delete()
        .eq("id", doc.id);
      
      if (dbError) throw dbError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["apolice-documents", apoliceId] });
      toast.success("Documento excluído com sucesso");
    },
    onError: (error) => {
      console.error("Delete error:", error);
      toast.error("Erro ao excluir documento");
    },
  });

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > MAX_FILE_SIZE) {
      toast.error("Arquivo muito grande. Máximo: 10MB");
      return;
    }

    setIsUploading(true);

    try {
      const fileExt = file.name.split(".").pop();
      const fileName = `${apoliceId}/${Date.now()}-${file.name}`;

      // Upload to storage
      const { error: uploadError } = await supabase.storage
        .from(BUCKET_NAME)
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: urlData } = supabase.storage
        .from(BUCKET_NAME)
        .getPublicUrl(fileName);

      // Save to database
      const { error: dbError } = await supabase
        .from("apolice_documents")
        .insert({
          apolice_id: apoliceId,
          nome: file.name,
          tipo: file.type || "application/octet-stream",
          url: urlData.publicUrl,
          tamanho: file.size,
        });

      if (dbError) throw dbError;

      queryClient.invalidateQueries({ queryKey: ["apolice-documents", apoliceId] });
      toast.success("Documento anexado com sucesso");
    } catch (error: unknown) {
      const err = error as Error;
      console.error("Upload error:", err);
      toast.error(err.message || "Erro ao fazer upload");
    } finally {
      setIsUploading(false);
      e.target.value = "";
    }
  };

  const handleView = async (doc: ApoliceDocument) => {
    try {
      // For private bucket, generate signed URL
      const urlParts = doc.url.split("/");
      const filePath = urlParts.slice(-2).join("/");
      
      const { data, error } = await supabase.storage
        .from(BUCKET_NAME)
        .createSignedUrl(filePath, 3600); // 1 hour
      
      if (error) throw error;
      
      window.open(data.signedUrl, "_blank");
    } catch (error) {
      console.error("View error:", error);
      // Fallback to direct URL
      window.open(doc.url, "_blank");
    }
  };

  const handleDownload = async (doc: ApoliceDocument) => {
    try {
      const urlParts = doc.url.split("/");
      const filePath = urlParts.slice(-2).join("/");
      
      const { data, error } = await supabase.storage
        .from(BUCKET_NAME)
        .download(filePath);
      
      if (error) throw error;
      
      const url = URL.createObjectURL(data);
      const a = document.createElement("a");
      a.href = url;
      a.download = doc.nome;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Download error:", error);
      toast.error("Erro ao baixar documento");
    }
  };

  const getFileIcon = (tipo: string) => {
    if (tipo.includes("pdf")) return <FileText className="h-5 w-5 text-destructive" />;
    if (tipo.includes("image")) return <FileImage className="h-5 w-5 text-primary" />;
    return <File className="h-5 w-5 text-muted-foreground" />;
  };

  const formatFileSize = (bytes: number | null) => {
    if (!bytes) return "-";
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            Documentos da Apólice {apoliceNumero}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Upload Area */}
          <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
            <Input
              type="file"
              id="apolice-doc-upload"
              className="hidden"
              onChange={handleFileUpload}
              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.xls,.xlsx"
              disabled={isUploading}
            />
            <Label
              htmlFor="apolice-doc-upload"
              className="cursor-pointer flex flex-col items-center gap-2"
            >
              {isUploading ? (
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              ) : (
                <Upload className="h-8 w-8 text-muted-foreground" />
              )}
              <span className="text-sm text-muted-foreground">
                {isUploading ? "Enviando..." : "Clique para anexar apólice, endosso ou documento"}
              </span>
              <span className="text-xs text-muted-foreground">
                PDF, DOC, Excel, Imagens (máx. 10MB)
              </span>
            </Label>
          </div>

          {/* Documents List */}
          <ScrollArea className="h-[300px]">
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : documents.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
                <AlertCircle className="h-8 w-8 mb-2" />
                <p>Nenhum documento anexado</p>
              </div>
            ) : (
              <div className="space-y-2">
                {documents.map((doc) => (
                  <div
                    key={doc.id}
                    className="flex items-center justify-between p-3 rounded-lg border border-border bg-card hover:bg-secondary/30 transition-colors"
                  >
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      {getFileIcon(doc.tipo)}
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{doc.nome}</p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span>{formatFileSize(doc.tamanho)}</span>
                          <span>•</span>
                          <span>{format(new Date(doc.created_at), "dd/MM/yyyy", { locale: ptBR })}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleView(doc)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleDownload(doc)}
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => deleteMutation.mutate(doc)}
                        disabled={deleteMutation.isPending}
                      >
                        {deleteMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Trash2 className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
}
