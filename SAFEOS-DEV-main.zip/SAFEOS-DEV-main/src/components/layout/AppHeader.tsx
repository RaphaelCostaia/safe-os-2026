import { Bell, User, Settings, LogOut, AlertTriangle, RefreshCw, FileText, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CommandMenu } from "./CommandMenu";
import { ThemeToggle } from "./ThemeToggle";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useNotifications, Notification } from "@/hooks/useNotifications";
import { useAuth } from "@/hooks/useAuth";
import { useUserRole } from "@/hooks/useUserRole";
import { useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";

const roleLabels: Record<string, string> = {
  admin: "Administrador",
  gestor: "Gestor",
  vendedor: "Vendedor",
  administrativo: "Administrativo",
};

const getNotificationIcon = (type: Notification["type"]) => {
  switch (type) {
    case "renovacao":
      return <RefreshCw className="h-4 w-4" />;
    case "sinistro":
      return <AlertTriangle className="h-4 w-4" />;
    case "cliente":
      return <Users className="h-4 w-4" />;
    case "apolice":
      return <FileText className="h-4 w-4" />;
    default:
      return <Bell className="h-4 w-4" />;
  }
};

const getPriorityColor = (priority: Notification["priority"]) => {
  switch (priority) {
    case "urgent":
      return "text-destructive bg-destructive/10";
    case "high":
      return "text-warning bg-warning/10";
    case "medium":
      return "text-primary bg-primary/10";
    default:
      return "text-muted-foreground bg-secondary";
  }
};

export function AppHeader() {
  const { notifications, unreadCount, urgentCount, isLoading } = useNotifications();
  const { user, signOut } = useAuth();
  const { data: userRole } = useUserRole();
  const navigate = useNavigate();

  const userInitials = user?.email?.slice(0, 2).toUpperCase() || "US";
  const roleLabel = userRole ? roleLabels[userRole] || userRole : "Usuário";

  const handleSignOut = async () => {
    await signOut();
    navigate("/auth");
  };

  return (
    <header className="flex h-20 shrink-0 items-center justify-between border-b border-border/50 bg-background/80 backdrop-blur-xl px-10 sticky top-0 z-30">
      <div className="flex items-center gap-6 flex-1">
        <div className="hidden lg:block">
           <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/30">Acesso Rápido</p>
        </div>
        <CommandMenu />
      </div>

      <div className="flex items-center gap-6">
        <ThemeToggle />
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="relative h-12 w-12 rounded-2xl hover:bg-muted/50 transition-all group">
              <Bell className="h-5 w-5 text-muted-foreground transition-transform group-hover:rotate-12" />
              {unreadCount > 0 && (
                <Badge 
                  className={cn(
                    "absolute top-2 right-2 h-5 w-5 flex items-center justify-center p-0 text-[10px] font-black border-2 border-background",
                    urgentCount > 0 ? "bg-destructive animate-pulse" : "bg-primary"
                  )}
                >
                  {unreadCount > 9 ? "9+" : unreadCount}
                </Badge>
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-96">
            <DropdownMenuLabel className="flex items-center justify-between">
              <span>Notificações</span>
              {urgentCount > 0 && (
                <Badge variant="destructive" className="text-xs">
                  {urgentCount} urgente{urgentCount > 1 ? "s" : ""}
                </Badge>
              )}
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <ScrollArea className="h-80">
              {isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <span className="text-muted-foreground text-sm">Carregando...</span>
                </div>
              ) : notifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8">
                  <Bell className="h-8 w-8 text-muted-foreground mb-2" />
                  <span className="text-muted-foreground text-sm">Nenhuma notificação</span>
                </div>
              ) : (
                notifications.slice(0, 10).map((notification) => (
                  <DropdownMenuItem 
                    key={notification.id} 
                    className="flex items-start gap-3 py-3 cursor-pointer"
                  >
                    <div className={cn("p-2 rounded-full flex-shrink-0", getPriorityColor(notification.priority))}>
                      {getNotificationIcon(notification.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{notification.title}</span>
                        {notification.priority === "urgent" && (
                          <Badge variant="destructive" className="text-xs px-1 py-0">Urgente</Badge>
                        )}
                      </div>
                      <span className="text-xs text-muted-foreground line-clamp-2">
                        {notification.message}
                      </span>
                    </div>
                  </DropdownMenuItem>
                ))
              )}
            </ScrollArea>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="flex items-center gap-4 h-14 px-3 rounded-[1.25rem] hover:bg-muted/50 transition-all border border-transparent hover:border-muted/30">
              <div className="relative group">
                 <Avatar className="h-10 w-10 border-2 border-primary/20 p-0.5 group-hover:border-primary transition-all duration-500">
                   <AvatarFallback className="bg-primary text-primary-foreground text-xs font-black">
                     {userInitials}
                   </AvatarFallback>
                 </Avatar>
                 <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-background" />
              </div>
              <div className="hidden md:flex flex-col items-start">
                <span className="text-xs font-black tracking-tight">{user?.email?.split("@")[0] || "Usuário"}</span>
                <span className="text-[9px] text-muted-foreground font-black uppercase tracking-widest opacity-50">{roleLabel}</span>
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuLabel>Minha Conta</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate("/perfil")} className="cursor-pointer">
              <User className="mr-2 h-4 w-4" />
              Perfil
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate("/configuracoes")} className="cursor-pointer">
              <Settings className="mr-2 h-4 w-4" />
              Configurações
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem 
              className="text-destructive cursor-pointer"
              onClick={handleSignOut}
            >
              <LogOut className="mr-2 h-4 w-4" />
              Sair
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
