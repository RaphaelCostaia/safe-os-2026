import * as React from "react";
import { useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  Users,
  FileText,
  AlertTriangle,
  Package,
  Wallet,
  BarChart3,
  RefreshCw,
  User,
  Settings,
  Search,
} from "lucide-react";

import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";

export function CommandMenu() {
  const [open, setOpen] = React.useState(false);
  const navigate = useNavigate();

  React.useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((open) => !open);
      }
    };

    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, []);

  const runCommand = React.useCallback((command: () => void) => {
    setOpen(false);
    command();
  }, []);

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="flex h-12 w-full max-w-[320px] items-center gap-3 rounded-2xl border border-border/40 bg-muted/20 px-5 text-xs text-muted-foreground transition-all hover:bg-muted/40 hover:text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 group"
      >
        <Search className="h-4 w-4 opacity-40 group-hover:opacity-100 transition-opacity" />
        <span className="flex-1 text-left font-bold uppercase tracking-widest opacity-60">Search Console...</span>
        <kbd className="pointer-events-none hidden h-6 select-none items-center gap-1 rounded-lg border bg-background px-2 font-mono text-[9px] font-black opacity-30 sm:flex">
          <span className="text-[10px]">⌘</span>K
        </kbd>
      </button>
      <CommandDialog open={open} onOpenChange={setOpen}>
        <CommandInput placeholder="Digite um comando ou busca..." />
        <CommandList>
          <CommandEmpty>Nenhum resultado encontrado.</CommandEmpty>
          <CommandGroup heading="Operacional">
            <CommandItem onSelect={() => runCommand(() => navigate("/"))}>
              <LayoutDashboard className="mr-2 h-4 w-4" />
              <span>Dashboard</span>
            </CommandItem>
            <CommandItem onSelect={() => runCommand(() => navigate("/clientes"))}>
              <Users className="mr-2 h-4 w-4" />
              <span>Clientes</span>
            </CommandItem>
            <CommandItem onSelect={() => runCommand(() => navigate("/apolices"))}>
              <FileText className="mr-2 h-4 w-4" />
              <span>Apólices</span>
            </CommandItem>
            <CommandItem onSelect={() => runCommand(() => navigate("/sinistros"))}>
              <AlertTriangle className="mr-2 h-4 w-4" />
              <span>Sinistros</span>
            </CommandItem>
            <CommandItem onSelect={() => runCommand(() => navigate("/produtos"))}>
              <Package className="mr-2 h-4 w-4" />
              <span>Produtos</span>
            </CommandItem>
          </CommandGroup>
          <CommandSeparator />
          <CommandGroup heading="Estratégico">
            <CommandItem onSelect={() => runCommand(() => navigate("/financeiro"))}>
              <Wallet className="mr-2 h-4 w-4" />
              <span>Financeiro</span>
            </CommandItem>
            <CommandItem onSelect={() => runCommand(() => navigate("/relatorios"))}>
              <BarChart3 className="mr-2 h-4 w-4" />
              <span>Relatórios</span>
            </CommandItem>
            <CommandItem onSelect={() => runCommand(() => navigate("/renovacoes"))}>
              <RefreshCw className="mr-2 h-4 w-4" />
              <span>Renovações</span>
            </CommandItem>
          </CommandGroup>
          <CommandSeparator />
          <CommandGroup heading="Sistema">
            <CommandItem onSelect={() => runCommand(() => navigate("/perfil"))}>
              <User className="mr-2 h-4 w-4" />
              <span>Perfil</span>
            </CommandItem>
            <CommandItem onSelect={() => runCommand(() => navigate("/configuracoes"))}>
              <Settings className="mr-2 h-4 w-4" />
              <span>Configurações</span>
            </CommandItem>
          </CommandGroup>
        </CommandList>
      </CommandDialog>
    </>
  );
}
