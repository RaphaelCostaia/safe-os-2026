import { 
  LayoutDashboard, 
  Users, 
  FileText, 
  RefreshCw, 
  Package, 
  BarChart3, 
  Settings,
  Wallet,
  User,
  ChevronLeft,
  ChevronRight,
  AlertTriangle,
  TrendingUp,
  ShieldAlert
} from "lucide-react";
import { NavLink } from "@/components/NavLink";
import { usePermissions } from "@/hooks/useUserRole";
import { Resource } from "@/lib/permissions";
import { 
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  useSidebar,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { SafeOSLogo } from "@/components/ui/SafeOSLogo";

interface SidebarItem {
  title: string;
  url: string;
  icon: any;
  resource?: Resource;
}

const operationalItems: SidebarItem[] = [
  { title: "Intelligence Hub", url: "/", icon: LayoutDashboard, resource: 'dashboard' },
  { title: "Pipeline CRM", url: "/crm", icon: TrendingUp, resource: 'dashboard' },
  { title: "Central de Clientes", url: "/clientes", icon: Users, resource: 'clients' },
  { title: "Gestão de Apólices", url: "/apolices", icon: FileText, resource: 'apolices' },
  { title: "Centro de Sinistros", url: "/sinistros", icon: AlertTriangle, resource: 'sinistros' },
  { title: "Mix de Produtos", url: "/produtos", icon: Package, resource: 'produtos' },
];

const strategicItems: SidebarItem[] = [
  { title: "BI & Financeiro", url: "/financeiro", icon: Wallet, resource: 'financeiro' },
  { title: "Renovações", url: "/renovacoes", icon: RefreshCw, resource: 'renovacoes' },
  { title: "Relatórios", url: "/relatorios", icon: BarChart3, resource: 'relatorios' },
  { title: "Auditoria", url: "/auditoria", icon: ShieldAlert, resource: 'auditoria' },
];

const systemItems: SidebarItem[] = [
  { title: "Perfil", url: "/perfil", icon: User },
  { title: "Configurações", url: "/configuracoes", icon: Settings, resource: 'configuracoes' },
];

export function AppSidebar({ className }: { className?: string }) {
  const { state, toggleSidebar } = useSidebar();
  const { canAccess } = usePermissions();
  const isCollapsed = state === "collapsed";

  const filterItems = (items: SidebarItem[]) => {
    return items.filter(item => !item.resource || canAccess(item.resource));
  };

  const filteredOpItems = filterItems(operationalItems);
  const filteredStratItems = filterItems(strategicItems);
  const filteredSysItems = filterItems(systemItems);

  return (
    <div
      className="flex-shrink-0 transition-all duration-300 ease-in-out border-r border-sidebar-border"
      style={{
        width: isCollapsed ? "var(--sidebar-width-icon)" : "var(--sidebar-width)"
      }}
    >
      <Sidebar 
        className={cn(
          "bg-sidebar transition-all duration-300 shadow-sm",
          className
        )}
        collapsible="icon"
      >
      <SidebarHeader className="p-4 border-b border-sidebar-border">
        <SafeOSLogo showText={!isCollapsed} size={isCollapsed ? "sm" : "md"} />
      </SidebarHeader>

      <SidebarContent className="px-2 py-4">
        {filteredOpItems.length > 0 && (
          <SidebarGroup>
            {!isCollapsed && (
              <SidebarGroupLabel className="px-5 text-[10px] font-black text-muted-foreground/40 uppercase tracking-[0.2em] mb-4">
                Visão Geral
              </SidebarGroupLabel>
            )}
            <SidebarGroupContent>
              <SidebarMenu className="gap-1.5 px-2">
                {filteredOpItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild>
                      <NavLink 
                        to={item.url} 
                        end={item.url === "/"}
                        className="flex items-center gap-3 px-4 py-3 rounded-2xl text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-all duration-300 group relative"
                        activeClassName="bg-primary/5 text-primary font-black shadow-sm ring-1 ring-primary/10"
                      >
                        <item.icon className="h-5 w-5 shrink-0 transition-transform group-hover:scale-110" />
                        {!isCollapsed && <span className="text-xs uppercase tracking-widest">{item.title}</span>}
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {filteredStratItems.length > 0 && (
          <SidebarGroup className="mt-8">
            {!isCollapsed && (
              <SidebarGroupLabel className="px-5 text-[10px] font-black text-muted-foreground/40 uppercase tracking-[0.2em] mb-4">
                Intelligence & Growth
              </SidebarGroupLabel>
            )}
            <SidebarGroupContent>
              <SidebarMenu className="gap-1.5 px-2">
                {filteredStratItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild>
                      <NavLink 
                        to={item.url} 
                        className="flex items-center gap-3 px-4 py-3 rounded-2xl text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-all duration-300 group"
                        activeClassName="bg-primary/5 text-primary font-black shadow-sm ring-1 ring-primary/10"
                      >
                        <item.icon className="h-5 w-5 shrink-0 transition-transform group-hover:scale-110" />
                        {!isCollapsed && <span className="text-xs uppercase tracking-widest">{item.title}</span>}
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {filteredSysItems.length > 0 && (
          <SidebarGroup className="mt-8">
            {!isCollapsed && (
              <SidebarGroupLabel className="px-5 text-[10px] font-black text-muted-foreground/40 uppercase tracking-[0.2em] mb-4">
                Sistema SafeOS
              </SidebarGroupLabel>
            )}
            <SidebarGroupContent>
              <SidebarMenu className="gap-1.5 px-2">
                {filteredSysItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild>
                      <NavLink 
                        to={item.url} 
                        className="flex items-center gap-3 px-4 py-3 rounded-2xl text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-all duration-300 group"
                        activeClassName="bg-primary/5 text-primary font-black shadow-sm ring-1 ring-primary/10"
                      >
                        <item.icon className="h-5 w-5 shrink-0 transition-transform group-hover:scale-110" />
                        {!isCollapsed && <span className="text-xs uppercase tracking-widest">{item.title}</span>}
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter className="p-4 border-t border-sidebar-border/50">
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleSidebar}
          className="w-full justify-center h-12 rounded-xl text-muted-foreground hover:text-primary hover:bg-primary/5 transition-all font-black text-[10px] uppercase tracking-widest gap-2"
        >
          {isCollapsed ? (
            <ChevronRight className="h-4 w-4" />
          ) : (
            <>
              <ChevronLeft className="h-4 w-4" />
              <span>Ocultar Menu</span>
            </>
          )}
        </Button>
      </SidebarFooter>
    </Sidebar>
    </div>
  );
}
