import React, { Component, ErrorInfo, ReactNode } from "react";
import { AlertCircle, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class GlobalErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center bg-background">
          <div className="bg-destructive/10 p-4 rounded-full mb-6">
            <AlertCircle className="h-12 w-12 text-destructive" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Ops! Algo deu errado.</h1>
          <p className="text-muted-foreground max-w-md mb-8">
            Ocorreu um erro inesperado ao carregar o SafeOS. 
            {this.state.error?.message && (
              <code className="block mt-4 p-2 bg-muted rounded text-xs text-left overflow-auto max-h-32">
                {this.state.error.message}
              </code>
            )}
          </p>
          <div className="flex gap-4">
            <Button onClick={() => window.location.reload()} className="gap-2">
              <RefreshCw className="h-4 w-4" /> Recarregar página
            </Button>
            <Button variant="outline" onClick={() => window.location.href = "/"}>
              Voltar ao início
            </Button>
          </div>
          <p className="mt-12 text-xs text-muted-foreground">
            Se o erro persistir, verifique as variáveis de ambiente VITE_SUPABASE_URL e VITE_SUPABASE_PUBLISHABLE_KEY.
          </p>
        </div>
      );
    }

    return this.props.children;
  }
}
