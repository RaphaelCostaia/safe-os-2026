import { format, isPast, isToday } from "date-fns";
import { ptBR } from "date-fns/locale";
import { usePendingTasks, useCompleteTask, useDeleteTask, Task, TaskPriority } from "@/hooks/useTasks";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Check, Trash2, Calendar, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

const priorityConfig: Record<TaskPriority, { label: string; className: string }> = {
  critica: { label: "Crítica", className: "bg-red-500 text-white hover:bg-red-600" },
  alta: { label: "Alta", className: "bg-orange-500 text-white hover:bg-orange-600" },
  media: { label: "Média", className: "bg-yellow-500 text-black hover:bg-yellow-600" },
  baixa: { label: "Baixa", className: "bg-green-500 text-white hover:bg-green-600" },
};

function TaskItem({ task }: { task: Task }) {
  const completeTask = useCompleteTask();
  const deleteTask = useDeleteTask();

  const isOverdue = task.prazo && isPast(new Date(task.prazo)) && !isToday(new Date(task.prazo));
  const isDueToday = task.prazo && isToday(new Date(task.prazo));

  return (
    <div className="flex items-start gap-3 p-3 rounded-lg border bg-card hover:bg-accent/5 transition-colors">
      <Button
        variant="ghost"
        size="icon"
        className="h-6 w-6 shrink-0 mt-0.5 hover:bg-primary/20"
        onClick={() => completeTask.mutate(task.id)}
        disabled={completeTask.isPending}
      >
        <Check className="h-4 w-4" />
      </Button>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className={cn("font-medium text-sm", isOverdue && "text-destructive")}>
            {task.titulo}
          </span>
          <Badge className={priorityConfig[task.prioridade].className}>
            {priorityConfig[task.prioridade].label}
          </Badge>
          {isOverdue && (
            <Badge variant="destructive" className="gap-1">
              <AlertCircle className="h-3 w-3" />
              Atrasada
            </Badge>
          )}
        </div>

        {task.descricao && (
          <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{task.descricao}</p>
        )}

        {task.prazo && (
          <div className={cn(
            "flex items-center gap-1 text-xs mt-1",
            isOverdue ? "text-destructive" : isDueToday ? "text-orange-600" : "text-muted-foreground"
          )}>
            <Calendar className="h-3 w-3" />
            {format(new Date(task.prazo), "dd/MM/yyyy", { locale: ptBR })}
          </div>
        )}
      </div>

      <Button
        variant="ghost"
        size="icon"
        className="h-6 w-6 shrink-0 text-muted-foreground hover:text-destructive"
        onClick={() => deleteTask.mutate(task.id)}
        disabled={deleteTask.isPending}
      >
        <Trash2 className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}

export function TasksList() {
  const { data: tasks, isLoading } = usePendingTasks();

  if (isLoading) {
    return (
      <div className="space-y-2">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-16 w-full" />
        ))}
      </div>
    );
  }

  if (!tasks || tasks.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <div className="rounded-full bg-muted p-3 mb-3">
          <Check className="h-6 w-6 text-muted-foreground" />
        </div>
        <h3 className="text-sm font-medium">Nenhuma tarefa pendente</h3>
        <p className="text-xs text-muted-foreground mt-1">
          Crie uma nova tarefa usando o botão "+ Tarefa"
        </p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-[300px]">
      <div className="space-y-2 pr-4">
        {tasks.map((task) => (
          <TaskItem key={task.id} task={task} />
        ))}
      </div>
    </ScrollArea>
  );
}
