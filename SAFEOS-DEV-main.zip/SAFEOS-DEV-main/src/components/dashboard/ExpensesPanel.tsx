import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  CreditCard, Building, Users, Zap, Car, Home, AlertCircle, CheckCircle2, Clock, 
  ArrowRight, Wallet, ShoppingCart, Briefcase 
} from "lucide-react";
import { useContas } from "@/hooks/useContas";
import { useMemo } from "react";
import { differenceInDays, parseISO, isAfter, isBefore, startOfToday } from "date-fns";
import { useNavigate } from "react-router-dom";

// Mapeamento de categorias para ícones
const categoryIcons: Record<string, React.ElementType> = {
  infraestrutura: Building,
  pessoal: Users,
  utilidades: Zap,
  tecnologia: CreditCard,
  veiculos: Car,
  imoveis: Home,
  vendas: ShoppingCart,
  operacional: Briefcase,
  default: Wallet,
};

// Determina status baseado na data de vencimento e status no banco
function determineDisplayStatus(
  dbStatus: string, 
  vencimento: string
): "paid" | "pending" | "overdue" {
  if (dbStatus === "pago") return "paid";
  
  const today = startOfToday();
  const dueDate = parseISO(vencimento);
  
  if (isBefore(dueDate, today)) return "overdue";
  return "pending";
}

export function ExpensesPanel() {
  const navigate = useNavigate();
  const { contas, isLoading, error } = useContas("pagar");

  // Processa e categoriza as contas
  const { expenses, categoryTotals, totalExpenses } = useMemo(() => {
    if (!contas || contas.length === 0) {
      return {
        expenses: [],
        categoryTotals: { paid: 0, pending: 0, overdue: 0 },
        totalExpenses: 0,
      };
    }

    const processedExpenses = contas.map((conta) => {
      const displayStatus = determineDisplayStatus(conta.status, conta.vencimento);
      const IconComponent = categoryIcons[conta.categoria?.toLowerCase()] || categoryIcons.default;
      
      return {
        id: conta.id,
        description: conta.descricao,
        category: conta.categoria,
        amount: Number(conta.valor),
        dueDate: conta.vencimento,
        status: displayStatus,
        icon: IconComponent,
        dbStatus: conta.status,
      };
    });

    // Ordena: vencidos primeiro, depois pendentes por data, por último pagos
    processedExpenses.sort((a, b) => {
      const statusOrder = { overdue: 0, pending: 1, paid: 2 };
      if (statusOrder[a.status] !== statusOrder[b.status]) {
        return statusOrder[a.status] - statusOrder[b.status];
      }
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
    });

    const totals = {
      paid: processedExpenses.filter(e => e.status === "paid").reduce((sum, e) => sum + e.amount, 0),
      pending: processedExpenses.filter(e => e.status === "pending").reduce((sum, e) => sum + e.amount, 0),
      overdue: processedExpenses.filter(e => e.status === "overdue").reduce((sum, e) => sum + e.amount, 0),
    };

    const total = totals.paid + totals.pending + totals.overdue;

    return {
      expenses: processedExpenses.slice(0, 10), // Limita a 10 items para o painel
      categoryTotals: totals,
      totalExpenses: total,
    };
  }, [contas]);

  const getStatusBadge = (status: "paid" | "pending" | "overdue") => {
    switch (status) {
      case "paid":
        return <Badge variant="outline" className="bg-success/10 text-success border-success/20"><CheckCircle2 className="w-3 h-3 mr-1" />Pago</Badge>;
      case "pending":
        return <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20"><Clock className="w-3 h-3 mr-1" />Pendente</Badge>;
      case "overdue":
        return <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20"><AlertCircle className="w-3 h-3 mr-1" />Vencido</Badge>;
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold">Contas a Pagar</CardTitle>
            <Skeleton className="h-8 w-32" />
          </div>
          <div className="grid grid-cols-3 gap-3 pt-3">
            <Skeleton className="h-16 rounded-lg" />
            <Skeleton className="h-16 rounded-lg" />
            <Skeleton className="h-16 rounded-lg" />
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-16 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  // Empty state
  if (!contas || contas.length === 0) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold">Contas a Pagar</CardTitle>
            <Button variant="outline" size="sm" onClick={() => navigate("/financeiro")}>
              Adicionar <ArrowRight className="h-3 w-3 ml-1" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center py-8 text-center">
          <Wallet className="h-12 w-12 text-muted-foreground/50 mb-3" />
          <p className="text-sm text-muted-foreground">Nenhuma conta a pagar cadastrada</p>
          <p className="text-xs text-muted-foreground/70">Adicione contas no módulo Financeiro</p>
        </CardContent>
      </Card>
    );
  }

  const progressPercent = totalExpenses > 0 ? (categoryTotals.paid / totalExpenses) * 100 : 0;

  return (
    <Card className="border-border/50 bg-card">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Contas a Pagar</CardTitle>
          <span className="text-2xl font-bold text-foreground">R$ {totalExpenses.toLocaleString('pt-BR')}</span>
        </div>
        
        <div className="grid grid-cols-3 gap-3 pt-3">
          <div className="text-center p-3 rounded-lg bg-success/10">
            <p className="text-xs text-muted-foreground mb-1">Pago</p>
            <p className="text-lg font-bold text-success">R$ {categoryTotals.paid.toLocaleString('pt-BR')}</p>
          </div>
          <div className="text-center p-3 rounded-lg bg-warning/10">
            <p className="text-xs text-muted-foreground mb-1">Pendente</p>
            <p className="text-lg font-bold text-warning">R$ {categoryTotals.pending.toLocaleString('pt-BR')}</p>
          </div>
          <div className="text-center p-3 rounded-lg bg-destructive/10">
            <p className="text-xs text-muted-foreground mb-1">Vencido</p>
            <p className="text-lg font-bold text-destructive">R$ {categoryTotals.overdue.toLocaleString('pt-BR')}</p>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-3">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Progresso do Mês</span>
            <span className="font-medium">{Math.round(progressPercent)}%</span>
          </div>
          <Progress value={progressPercent} className="h-2" />
        </div>

        <div className="divide-y divide-border/50 max-h-[280px] overflow-y-auto">
          {expenses.map((expense) => (
            <div key={expense.id} className="flex items-center justify-between py-3 group hover:bg-secondary/30 -mx-3 px-3 rounded-lg transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-secondary">
                  <expense.icon className="h-4 w-4 text-muted-foreground" />
                </div>
                <div>
                  <p className="font-medium text-sm">{expense.description}</p>
                  <p className="text-xs text-muted-foreground">{expense.category} • Vence {new Date(expense.dueDate).toLocaleDateString('pt-BR')}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-semibold text-sm">R$ {expense.amount.toLocaleString('pt-BR')}</span>
                {getStatusBadge(expense.status)}
              </div>
            </div>
          ))}
        </div>

        {contas.length > 10 && (
          <Button 
            variant="ghost" 
            size="sm" 
            className="w-full text-xs" 
            onClick={() => navigate("/financeiro")}
          >
            Ver todas as {contas.length} contas <ArrowRight className="h-3 w-3 ml-1" />
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
