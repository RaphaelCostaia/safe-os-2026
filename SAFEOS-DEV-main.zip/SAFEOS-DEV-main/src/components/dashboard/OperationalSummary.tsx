import { useExecutiveDashboard, DashboardPeriod } from "@/hooks/useExecutiveDashboard";
import { 
  Users, 
  MessageSquare, 
  CheckCircle2, 
  Clock, 
  Bell, 
  Calendar,
  AlertCircle
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";

interface OperationalSummaryProps {
  period: DashboardPeriod;
}

export function OperationalSummary({ period }: OperationalSummaryProps) {
  const { data: metrics, isLoading } = useExecutiveDashboard(period);
  
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[1, 2, 3, 4].map(i => (
          <Skeleton key={i} className="h-48 w-full rounded-[2.5rem]" />
        ))}
      </div>
    );
  }

  if (!metrics) return null;
  const summary = metrics.operationalSummary;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {/* Leads Section */}
      <div className="bg-card border rounded-3xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="p-2 bg-blue-50 rounded-xl">
             <Users className="h-5 w-5 text-blue-600" />
          </div>
          <Badge variant="secondary" className="font-mono text-xs">CRM</Badge>
        </div>
        <h4 className="text-sm font-semibold text-muted-foreground mb-1">Funil de Vendas</h4>
        <div className="space-y-4 mt-4">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span>Leads Novos</span>
              <span className="font-bold">{summary.newLeads}</span>
            </div>
            <Progress value={Math.min((summary.newLeads / 50) * 100, 100)} className="h-1.5 bg-blue-100" />
          </div>
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span>Em Negociação</span>
              <span className="font-bold">{summary.leadsInNegotiation}</span>
            </div>
            <Progress value={Math.min((summary.leadsInNegotiation / 100) * 100, 100)} className="h-1.5 bg-orange-100" />
          </div>
          <div className="pt-2">
            <p className="text-[10px] text-muted-foreground uppercase font-bold text-center">
              {summary.convertedThisMonth} convertidos este mês
            </p>
          </div>
        </div>
      </div>

      {/* Activities Section */}
      <div className="bg-card border rounded-3xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="p-2 bg-emerald-50 rounded-xl">
             <Clock className="h-5 w-5 text-emerald-600" />
          </div>
          <Badge variant="outline" className="text-emerald-700 bg-emerald-50 border-emerald-100">PROATIVO</Badge>
        </div>
        <h4 className="text-sm font-semibold text-muted-foreground mb-1">Atividades e Tarefas</h4>
        <div className="mt-4 space-y-3">
          <div className="flex items-center justify-between p-2 rounded-xl bg-muted/30">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              <span className="text-xs font-medium">Tarefas Pendentes</span>
            </div>
            <span className="text-sm font-bold">{summary.tasksPending}</span>
          </div>
          <div className="flex items-center justify-between p-2 rounded-xl bg-orange-50 border border-orange-100">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-orange-600" />
              <span className="text-xs font-medium text-orange-800">Follow-ups de Hoje</span>
            </div>
            <span className="text-sm font-bold text-orange-900">{summary.followUpsToday}</span>
          </div>
        </div>
      </div>

      {/* Renewals Section */}
      <div className="bg-card border rounded-3xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="p-2 bg-purple-50 rounded-xl">
             <Calendar className="h-5 w-5 text-purple-600" />
          </div>
          <Badge className="bg-purple-600">30 DIAS</Badge>
        </div>
        <h4 className="text-sm font-semibold text-muted-foreground mb-1">Ciclo de Renovação</h4>
        <div className="mt-4 flex flex-col items-center justify-center py-2">
          <span className="text-4xl font-black text-purple-900">{summary.upcomingRenewals}</span>
          <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest mt-1">
            Renovações Próximas
          </span>
        </div>
      </div>

      {/* Alerts Section */}
      <div className="bg-card border rounded-3xl p-6 shadow-sm border-l-4 border-l-destructive">
        <div className="flex items-center justify-between mb-4">
          <div className="p-2 bg-destructive/5 rounded-xl">
             <Bell className="h-5 w-5 text-destructive" />
          </div>
          <Badge variant="destructive" className="animate-pulse">CRÍTICO</Badge>
        </div>
        <h4 className="text-sm font-semibold text-muted-foreground mb-1">Alertas de Atenção</h4>
        <div className="mt-4 space-y-3">
          <div className="flex items-center gap-3 p-3 rounded-2xl bg-destructive/5 border border-destructive/10">
            <AlertCircle className="h-5 w-5 text-destructive" />
            <div>
              <p className="text-xs font-bold text-destructive">{summary.importantAlerts} Urgências</p>
              <p className="text-[10px] text-muted-foreground italic">Requer ação imediata</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
