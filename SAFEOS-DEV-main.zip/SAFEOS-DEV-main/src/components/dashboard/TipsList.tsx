import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useUserTips, useDeleteUserTip, UserTip } from "@/hooks/useUserTips";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Trash2, Lightbulb, Globe } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

const categoryColors: Record<string, string> = {
  Processo: "bg-blue-500/10 text-blue-700 border-blue-500/30",
  Venda: "bg-green-500/10 text-green-700 border-green-500/30",
  Renovação: "bg-orange-500/10 text-orange-700 border-orange-500/30",
  Sinistro: "bg-red-500/10 text-red-700 border-red-500/30",
  Geral: "bg-gray-500/10 text-gray-700 border-gray-500/30",
};

function TipItem({ tip }: { tip: UserTip }) {
  const { user } = useAuth();
  const deleteTip = useDeleteUserTip();

  const isOwner = tip.user_id === user?.id;
  const categoryClass = categoryColors[tip.categoria || "Geral"] || categoryColors.Geral;

  return (
    <div className="p-3 rounded-lg border bg-card hover:bg-accent/5 transition-colors">
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-medium text-sm">{tip.titulo}</span>
            {tip.categoria && (
              <Badge variant="outline" className={categoryClass}>
                {tip.categoria}
              </Badge>
            )}
            {tip.is_global && (
              <Badge variant="secondary" className="gap-1">
                <Globe className="h-3 w-3" />
                Global
              </Badge>
            )}
          </div>

          {tip.descricao && (
            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{tip.descricao}</p>
          )}

          <div className="text-xs text-muted-foreground mt-2">
            {format(new Date(tip.created_at), "dd/MM/yyyy", { locale: ptBR })}
          </div>
        </div>

        {isOwner && (
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6 shrink-0 text-muted-foreground hover:text-destructive"
            onClick={() => deleteTip.mutate(tip.id)}
            disabled={deleteTip.isPending}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        )}
      </div>
    </div>
  );
}

export function TipsList() {
  const { data: tips, isLoading } = useUserTips();

  if (isLoading) {
    return (
      <div className="space-y-2">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-16 w-full" />
        ))}
      </div>
    );
  }

  if (!tips || tips.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <div className="rounded-full bg-muted p-3 mb-3">
          <Lightbulb className="h-6 w-6 text-muted-foreground" />
        </div>
        <h3 className="text-sm font-medium">Nenhum tip</h3>
        <p className="text-xs text-muted-foreground mt-1">
          Crie um novo tip usando o botão "+ Tip"
        </p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-[300px]">
      <div className="space-y-2 pr-4">
        {tips.map((tip) => (
          <TipItem key={tip.id} tip={tip} />
        ))}
      </div>
    </ScrollArea>
  );
}
