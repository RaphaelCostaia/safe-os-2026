import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Lightbulb, 
  AlertTriangle, 
  TrendingUp, 
  Calendar, 
  CheckCircle2,
  ChevronRight,
  X
} from "lucide-react";
import { useDashboardStats } from "@/hooks/useDashboardStats";

interface Tip {
  id: string;
  type: "warning" | "tip" | "success" | "reminder";
  title: string;
  description: string;
  priority: "high" | "medium" | "low";
  actionLabel?: string;
  actionPath?: string;
}

export function TipsPanel() {
  const { data: stats } = useDashboardStats();
  const [dismissedTips, setDismissedTips] = useState<string[]>([]);

  // Generate dynamic tips based on stats
  const generateTips = (): Tip[] => {
    const tips: Tip[] = [];

    // Critical renewals warning
    if (stats?.criticalRenewals && stats.criticalRenewals > 0) {
      tips.push({
        id: "critical-renewals",
        type: "warning",
        title: "Renovações Urgentes",
        description: `${stats.criticalRenewals} apólice(s) vencem nos próximos 7 dias. Entre em contato com os clientes.`,
        priority: "high",
        actionLabel: "Ver renovações",
        actionPath: "/renovacoes",
      });
    }

    // Open claims
    if (stats?.openClaims && stats.openClaims > 0) {
      tips.push({
        id: "open-claims",
        type: "warning",
        title: "Sinistros em Aberto",
        description: `${stats.openClaims} sinistro(s) aguardando acompanhamento ou resolução.`,
        priority: stats.criticalClaims && stats.criticalClaims > 0 ? "high" : "medium",
        actionLabel: "Ver sinistros",
        actionPath: "/sinistros",
      });
    }

    // New clients celebration
    if (stats?.newClientsThisMonth && stats.newClientsThisMonth > 0) {
      tips.push({
        id: "new-clients",
        type: "success",
        title: "Novos Clientes",
        description: `Parabéns! ${stats.newClientsThisMonth} novo(s) cliente(s) este mês. Continue o bom trabalho!`,
        priority: "low",
      });
    }

    // General tips
    tips.push({
      id: "document-check",
      type: "tip",
      title: "Documentação em Dia",
      description: "Verifique se todos os documentos dos clientes estão atualizados e digitalizados.",
      priority: "low",
    });

    tips.push({
      id: "contact-reminder",
      type: "reminder",
      title: "Relacionamento com Clientes",
      description: "Lembre-se de manter contato regular com clientes inativos para reativá-los.",
      priority: "medium",
      actionLabel: "Ver clientes",
      actionPath: "/clientes",
    });

    // Filter dismissed tips
    return tips.filter(tip => !dismissedTips.includes(tip.id));
  };

  const tips = generateTips();

  const handleDismiss = (tipId: string) => {
    setDismissedTips(prev => [...prev, tipId]);
  };

  const getIcon = (type: Tip["type"]) => {
    switch (type) {
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-warning" />;
      case "tip":
        return <Lightbulb className="h-5 w-5 text-primary" />;
      case "success":
        return <CheckCircle2 className="h-5 w-5 text-success" />;
      case "reminder":
        return <Calendar className="h-5 w-5 text-accent" />;
    }
  };

  const getPriorityBadge = (priority: Tip["priority"]) => {
    switch (priority) {
      case "high":
        return <Badge variant="destructive" className="text-xs">Urgente</Badge>;
      case "medium":
        return <Badge variant="secondary" className="text-xs">Importante</Badge>;
      case "low":
        return null;
    }
  };

  const getBorderColor = (type: Tip["type"]) => {
    switch (type) {
      case "warning":
        return "border-l-warning";
      case "tip":
        return "border-l-primary";
      case "success":
        return "border-l-success";
      case "reminder":
        return "border-l-accent";
    }
  };

  if (tips.length === 0) {
    return null;
  }

  return (
    <Card className="border-border/50 bg-card">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Lightbulb className="h-5 w-5 text-primary" />
          Dicas & Lembretes
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[280px] pr-4">
          <div className="space-y-3">
            {tips.map((tip) => (
              <div
                key={tip.id}
                className={`relative p-4 rounded-lg border border-l-4 ${getBorderColor(tip.type)} bg-secondary/30 hover:bg-secondary/50 transition-colors`}
              >
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 h-6 w-6 opacity-50 hover:opacity-100"
                  onClick={() => handleDismiss(tip.id)}
                >
                  <X className="h-3 w-3" />
                </Button>

                <div className="flex items-start gap-3 pr-6">
                  {getIcon(tip.type)}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium text-sm">{tip.title}</h4>
                      {getPriorityBadge(tip.priority)}
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {tip.description}
                    </p>
                    {tip.actionLabel && tip.actionPath && (
                      <Button
                        variant="link"
                        size="sm"
                        className="h-auto p-0 mt-2 text-primary"
                        onClick={() => window.location.href = tip.actionPath!}
                      >
                        {tip.actionLabel}
                        <ChevronRight className="h-3 w-3 ml-1" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
