import { useExecutiveDashboard, DashboardPeriod } from "@/hooks/useExecutiveDashboard";
import { StatCard } from "./StatCard";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Users, 
  Zap, 
  BarChart3, 
  PieChart, 
  ShieldAlert,
  ArrowUpRight,
  Monitor,
  Target,
  Briefcase
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface ExecutiveMetricsPanelProps {
  period: DashboardPeriod;
}

export function ExecutiveMetricsPanel({ period }: ExecutiveMetricsPanelProps) {
  const { data: metrics, isLoading } = useExecutiveDashboard(period);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      maximumFractionDigits: 0
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return `${value > 0 ? '+' : ''}${value.toFixed(1)}%`;
  };

  const periodLabel = {
    last_30_days: "mês anterior",
    last_90_days: "trimestre anterior",
    last_12_months: "ano anterior",
    year_to_date: "ano passado"
  }[period];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
          <Skeleton key={i} className="h-32 w-full rounded-3xl" />
        ))}
      </div>
    );
  }

  if (!metrics) return null;

  return (
    <div className="space-y-8">
      {/* Strategic KPIs */}
      <section>
        <div className="flex items-center gap-2 mb-4">
          <Target className="h-5 w-5 text-primary" />
          <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Indicadores Estratégicos</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="LTV Médio (Projetado)"
            value={formatCurrency(metrics.ltv.current)}
            change={formatPercent(metrics.ltv.changePercent)}
            trend={metrics.ltv.trend}
            comparison={periodLabel}
            icon={TrendingUp}
            iconColor="text-indigo-600"
            description="Lifetime Value estimado p/ cliente"
          />
          <StatCard
            title="Taxa de Conversão"
            value={`${metrics.conversionRate.current.toFixed(1)}%`}
            change={formatPercent(metrics.conversionRate.changePercent)}
            trend={metrics.conversionRate.trend}
            comparison={periodLabel}
            icon={ArrowUpRight}
            iconColor="text-emerald-600"
            description="Novos clientes / leads totais"
          />
          <StatCard
            title="Sinisitralidade"
            value={`${metrics.sinistralidadeRate.current.toFixed(1)}%`}
            change={formatPercent(metrics.sinistralidadeRate.changePercent)}
            trend={metrics.sinistralidadeRate.trend === "up" ? "down" : "up"} // Desired is down
            changeType={metrics.sinistralidadeRate.current > 60 ? "negative" : "positive"}
            comparison={periodLabel}
            icon={ShieldAlert}
            iconColor="text-amber-600"
            description="Sinistros pagos / Prêmios ativos"
          />
          <StatCard
            title="Recorrência (MRR)"
            value={formatCurrency(metrics.mrr.current)}
            change={formatPercent(metrics.mrr.changePercent)}
            trend={metrics.mrr.trend}
            comparison={periodLabel}
            icon={Zap}
            iconColor="text-primary"
            description="Receita recorrente estimada"
          />
        </div>
      </section>

      {/* Operational Stats */}
      <section>
        <div className="flex items-center gap-2 mb-4">
          <Monitor className="h-5 w-5 text-primary" />
          <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Volume e Performance</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Ticket Médio"
            value={formatCurrency(metrics.ticketMedio.current)}
            change={formatPercent(metrics.ticketMedio.changePercent)}
            trend={metrics.ticketMedio.trend}
            comparison={periodLabel}
            icon={DollarSign}
            iconColor="text-blue-600"
          />
          <StatCard
            title="Clientes Ativos"
            value={metrics.totalActiveClients.toLocaleString()}
            change={`${metrics.monthlyClientGrowth > 0 ? '+' : ''}${metrics.monthlyClientGrowth}`}
            trend={metrics.monthlyClientGrowth >= 0 ? "up" : "down"}
            comparison="vs. mês anterior"
            icon={Users}
            iconColor="text-slate-600"
          />
          <StatCard
            title="Leads em Andamento"
            value={String(metrics.leadsInProgress)}
            icon={BarChart3}
            iconColor="text-orange-500"
            description={`${metrics.totalQuotes} cotações ativas`}
          />
          <StatCard
            title="Conversões no Período"
            value={String(metrics.convertedClientsPeriod)}
            icon={Briefcase}
            iconColor="text-purple-600"
            description="Leads transformados em clientes"
          />
        </div>
      </section>

      {/* Financial Breakdown */}
      <section>
        <div className="flex items-center gap-2 mb-4">
          <PieChart className="h-5 w-5 text-primary" />
          <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Comissões e Prêmios</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="col-span-1 border rounded-3xl p-6 bg-emerald-50/30 border-emerald-100">
             <p className="text-xs font-bold text-emerald-700 uppercase mb-2">Comissões Geradas</p>
             <h3 className="text-4xl font-black text-emerald-900 tracking-tighter">
                {formatCurrency(metrics.totalCommissions.current)}
             </h3>
             <div className="mt-4 flex items-center gap-2">
                <Badge className="bg-emerald-500 hover:bg-emerald-600">
                   {formatPercent(metrics.totalCommissions.changePercent)}
                </Badge>
                <span className="text-[10px] text-muted-foreground font-bold uppercase">vs. {periodLabel}</span>
             </div>
          </div>
          
          <div className="col-span-1 border rounded-3xl p-6 bg-blue-50/30 border-blue-100">
             <p className="text-xs font-bold text-blue-700 uppercase mb-2">Total de Prêmios</p>
             <h3 className="text-4xl font-black text-blue-900 tracking-tighter">
                {formatCurrency(metrics.totalPremiums.current)}
             </h3>
             <div className="mt-4 flex items-center gap-2">
                <Badge className="bg-blue-500 hover:bg-blue-600">
                   {formatPercent(metrics.totalPremiums.changePercent)}
                </Badge>
                <span className="text-[10px] text-muted-foreground font-bold uppercase">vs. {periodLabel}</span>
             </div>
          </div>

          <div className="col-span-1 border rounded-3xl p-6 bg-slate-50 border-slate-200">
             <p className="text-xs font-bold text-slate-700 uppercase mb-2">Sinistros Pagos</p>
             <h3 className="text-4xl font-black text-slate-900 tracking-tighter">
                {formatCurrency(metrics.totalClaims.current)}
             </h3>
             <div className="mt-4 flex items-center gap-2">
                <Badge variant="outline" className={metrics.totalClaims.changePercent > 0 ? "text-destructive border-destructive/20" : "text-emerald-600 border-emerald-200"}>
                   {formatPercent(metrics.totalClaims.changePercent)}
                </Badge>
                <span className="text-[10px] text-muted-foreground font-bold uppercase">Impacto no Período</span>
             </div>
          </div>
        </div>
      </section>
    </div>
  );
}
