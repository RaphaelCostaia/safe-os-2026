import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Building2, TrendingUp, Award } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

interface PartnerMetric {
  name: string;
  policies: number;
  premium: number;
  marketShare: number;
}

export function TopPartnersPanel() {
  const { data: partners, isLoading } = useQuery({
    queryKey: ["top-partners"],
    queryFn: async (): Promise<PartnerMetric[]> => {
      const { data: apolices } = await supabase
        .from("apolices")
        .select("seguradora, valor_premio")
        .eq("status", "ativa")
        .is("deleted_at", null);

      if (!apolices || apolices.length === 0) return [];

      const stats: Record<string, { policies: number; premium: number }> = {};
      let totalPremium = 0;

      apolices.forEach((p) => {
        const name = p.seguradora || "Não Informada";
        if (!stats[name]) {
          stats[name] = { policies: 0, premium: 0 };
        }
        stats[name].policies += 1;
        stats[name].premium += Number(p.valor_premio) || 0;
        totalPremium += Number(p.valor_premio) || 0;
      });

      return Object.entries(stats)
        .map(([name, data]) => ({
          name,
          policies: data.policies,
          premium: data.premium,
          marketShare: totalPremium > 0 ? (data.premium / totalPremium) * 100 : 0
        }))
        .sort((a, b) => b.premium - a.premium)
        .slice(0, 5);
    }
  });

  if (isLoading) return null;

  return (
    <Card className="border-none shadow-sm bg-card">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg font-bold flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              Principais Seguradoras
            </CardTitle>
            <CardDescription className="text-xs">Por volume de prêmio ativo</CardDescription>
          </div>
          <Award className="h-5 w-5 text-amber-500 opacity-50" />
        </div>
      </CardHeader>
      <CardContent className="space-y-5 pt-4">
        {partners?.length === 0 ? (
          <p className="text-center py-6 text-sm text-muted-foreground">Sem dados disponíveis</p>
        ) : (
          partners?.map((partner, index) => (
            <div key={partner.name} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-muted-foreground w-4">{index + 1}.</span>
                  <span className="text-sm font-semibold truncate max-w-[150px]">{partner.name}</span>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold">R$ {partner.premium >= 1000 ? (partner.premium / 1000).toFixed(1) + 'k' : partner.premium.toLocaleString('pt-BR')}</p>
                  <p className="text-[10px] text-muted-foreground">{partner.policies} apólices</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Progress value={partner.marketShare} className="h-1.5" />
                <span className="text-[10px] font-mono font-bold w-10 text-right">{partner.marketShare.toFixed(1)}%</span>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
