import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { MousePointer2, Target, Pencil, RotateCcw, Trash2, Plus, Megaphone, Check } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useUserRole } from "@/hooks/useUserRole";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

interface Campaign {
  id: string;
  nome: string;
  spend: number;
  leads: number;
  conversions: number;
  revenue: number;
  categoria?: string;
  dataCriacao?: string;
}

// Global in-memory fallback state in case both Supabase table is not created yet AND localStorage is disabled/sandboxed
let inMemoryCampaignFallback: Campaign[] = [
  {
    id: "camp_google_rcp",
    nome: "Google Ads - Seguro RCP Médico",
    spend: 2500,
    leads: 120,
    conversions: 18,
    revenue: 12500,
    categoria: "Search Ads",
    dataCriacao: new Date().toISOString().split("T")[0],
  },
  {
    id: "camp_meta_clinicas",
    nome: "Meta Ads - Multirrisco Clínicas",
    spend: 1500,
    leads: 85,
    conversions: 10,
    revenue: 6000,
    categoria: "Social",
    dataCriacao: new Date().toISOString().split("T")[0],
  }
];

export function MarketingROIPanel() {
  const queryClient = useQueryClient();
  const { data: userRole, isLoading: loadingRole } = useUserRole();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"list" | "form">("list");
  
  // State for campaign form
  const [editingCampaignId, setEditingCampaignId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);
  const [formName, setFormName] = useState("");
  const [formSpend, setFormSpend] = useState("");
  const [formLeads, setFormLeads] = useState("");
  const [formConversions, setFormConversions] = useState("");
  const [formRevenue, setFormRevenue] = useState("");
  const [formCategoria, setFormCategoria] = useState("Digital");

  const isManager = userRole === "owner" || userRole === "admin" || userRole === "gestor";
  // Fallback to true if userRole is resolving or not defined, or standard check
  const editAllowed = isManager || !userRole || loadingRole;

  // Load and calculate metrics dynamically
  const { data: metrics, isLoading } = useQuery({
    queryKey: ["marketing-roi-metrics"],
    queryFn: async () => {
      let campaigns: Campaign[] = [];
      let usedSupabase = false;

      // 1. Try fetching from Supabase table 'marketing_campaigns'
      try {
        const { data, error } = await supabase
          .from("marketing_campaigns" as any)
          .select("*")
          .order("created_at", { ascending: false });

        if (!error && data) {
          campaigns = data.map((item: any) => ({
            id: item.id,
            nome: item.nome,
            spend: Number(item.spend) || 0,
            leads: Number(item.leads) || 0,
            conversions: Number(item.conversions) || 0,
            revenue: Number(item.revenue) || 0,
            categoria: item.categoria || "Geral",
            dataCriacao: item.created_at ? item.created_at.split("T")[0] : new Date().toISOString().split("T")[0]
          }));
          usedSupabase = true;
        } else {
          console.warn("Supabase returned empty or error, using local/cache storage fallback.", error);
        }
      } catch (e) {
        console.warn("Failed to query 'marketing_campaigns' table, utilizing local fallback:", e);
      }

      // 2. Local Fallback if Supabase table is not available
      if (!usedSupabase) {
        let storedCampaignsJson = null;
        try {
          storedCampaignsJson = localStorage.getItem("safeos_marketing_campaigns");
        } catch (e) {
          console.warn("localStorage is blocked or unavailable in this sandboxed iFrame setting:", e);
        }

        if (storedCampaignsJson) {
          try {
            campaigns = JSON.parse(storedCampaignsJson);
          } catch (e) {
            console.error("Error parsing campaign JSON from storage:", e);
          }
        } else {
          // Migration check from legacy metrics or fallback setup
          let legacySpend = 0;
          let legacyLeads = 0;
          let legacyConversions = 0;
          let legacyRevenue = 0;

          try {
            legacySpend = Number(localStorage.getItem("safeos_marketing_spend")) || 0;
            legacyLeads = Number(localStorage.getItem("safeos_marketing_leads")) || 0;
            legacyConversions = Number(localStorage.getItem("safeos_marketing_conversions")) || 0;
            legacyRevenue = Number(localStorage.getItem("safeos_marketing_revenue")) || 0;
          } catch (e) {
            console.debug("Legacy localStorage metrics not found or blocked.");
          }

          if (legacySpend > 0 || legacyLeads > 0 || legacyConversions > 0 || legacyRevenue > 0) {
            campaigns = [
              {
                id: "migrada_geral",
                nome: "Campanha Geral (Código Antigo)",
                spend: legacySpend,
                leads: legacyLeads,
                conversions: legacyConversions,
                revenue: legacyRevenue,
                categoria: "Geral",
                dataCriacao: new Date().toISOString().split("T")[0],
              }
            ];
            try {
              localStorage.setItem("safeos_marketing_campaigns", JSON.stringify(campaigns));
            } catch (e) {
              console.debug("Could not write migrated campaigns to cache.");
            }
          } else {
            campaigns = [...inMemoryCampaignFallback];
          }
        }
      }

      // Sum all metrics from campaigns
      const spend = campaigns.reduce((acc, c) => acc + (Number(c.spend) || 0), 0);
      const leads = campaigns.reduce((acc, c) => acc + (Number(c.leads) || 0), 0);
      const conversions = campaigns.reduce((acc, c) => acc + (Number(c.conversions) || 0), 0);
      const revenue = campaigns.reduce((acc, c) => acc + (Number(c.revenue) || 0), 0);

      const roi = spend > 0 ? Math.round(((revenue - spend) / spend) * 100) : 0;
      const cpl = leads > 0 ? Number((spend / leads).toFixed(2)) : 0;
      const cac = conversions > 0 ? Number((spend / conversions).toFixed(2)) : 0;
      const conversionRate = leads > 0 ? Number(((conversions / leads) * 100).toFixed(1)) : 0;

      return {
        campaigns,
        spend,
        leads,
        conversions,
        revenue,
        roi,
        cpl,
        cac,
        conversionRate,
        usedSupabase
      };
    },
  });

  // Save/Edit mutation
  const saveCampaignMutation = useMutation({
    mutationFn: async (campaignToSave: {
      id?: string | null;
      nome: string;
      spend: number;
      leads: number;
      conversions: number;
      revenue: number;
      categoria: string;
    }) => {
      let savedToSupabase = false;

      // 1. Try to save to Supabase
      try {
        if (campaignToSave.id && !campaignToSave.id.startsWith("camp_") && !campaignToSave.id.startsWith("migrada_")) {
          // Edit existing in Supabase (UUID matching)
          const { error } = await supabase
            .from("marketing_campaigns" as any)
            .update({
              nome: campaignToSave.nome,
              spend: campaignToSave.spend,
              leads: campaignToSave.leads,
              conversions: campaignToSave.conversions,
              revenue: campaignToSave.revenue,
              categoria: campaignToSave.categoria,
            })
            .eq("id", campaignToSave.id);

          if (!error) {
            savedToSupabase = true;
          } else {
            throw error;
          }
        } else {
          // Insert new into Supabase
          const { error } = await supabase
            .from("marketing_campaigns" as any)
            .insert({
              nome: campaignToSave.nome,
              spend: campaignToSave.spend,
              leads: campaignToSave.leads,
              conversions: campaignToSave.conversions,
              revenue: campaignToSave.revenue,
              categoria: campaignToSave.categoria,
            });

          if (!error) {
            savedToSupabase = true;
          } else {
            throw error;
          }
        }
      } catch (err) {
        console.warn("Failed to write to Supabase, fallback to local/in-memory update:", err);
      }

      // 2. Local Fallback save
      if (!savedToSupabase) {
        let storedCampaignsJson = null;
        try {
          storedCampaignsJson = localStorage.getItem("safeos_marketing_campaigns");
        } catch (e) {
          console.debug("localStorage not readable:", e);
        }

        const campaigns: Campaign[] = storedCampaignsJson 
          ? JSON.parse(storedCampaignsJson) 
          : [...inMemoryCampaignFallback];

        if (campaignToSave.id) {
          const index = campaigns.findIndex(c => c.id === campaignToSave.id);
          if (index !== -1) {
            campaigns[index] = {
              ...campaigns[index],
              nome: campaignToSave.nome,
              spend: campaignToSave.spend,
              leads: campaignToSave.leads,
              conversions: campaignToSave.conversions,
              revenue: campaignToSave.revenue,
              categoria: campaignToSave.categoria
            };
          }
          const memIndex = inMemoryCampaignFallback.findIndex(c => c.id === campaignToSave.id);
          if (memIndex !== -1) {
            inMemoryCampaignFallback[memIndex] = {
              ...inMemoryCampaignFallback[memIndex],
              nome: campaignToSave.nome,
              spend: campaignToSave.spend,
              leads: campaignToSave.leads,
              conversions: campaignToSave.conversions,
              revenue: campaignToSave.revenue,
              categoria: campaignToSave.categoria
            };
          }
        } else {
          const newCamp: Campaign = {
            id: `camp_${Math.floor(Math.random() * 10000000)}`,
            nome: campaignToSave.nome,
            spend: campaignToSave.spend,
            leads: campaignToSave.leads,
            conversions: campaignToSave.conversions,
            revenue: campaignToSave.revenue,
            categoria: campaignToSave.categoria,
            dataCriacao: new Date().toISOString().split("T")[0]
          };
          campaigns.push(newCamp);
          inMemoryCampaignFallback.push(newCamp);
        }

        try {
          localStorage.setItem("safeos_marketing_campaigns", JSON.stringify(campaigns));
        } catch (e) {
          console.debug("localStorage write failed:", e);
        }
      }

      return { success: true, savedToSupabase };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["marketing-roi-metrics"] });
      if (data.savedToSupabase) {
        toast.success("Campanha gravada em Nuvem no Supabase!");
      } else {
        toast.success("Campanha gravada localmente de forma segura!");
      }
    },
    onError: () => {
      toast.error("Ocorreu um erro ao salvar o registro da campanha.");
    }
  });

  // Delete Campaign Mutation
  const deleteCampaignMutation = useMutation({
    mutationFn: async (id: string) => {
      let deletedFromSupabase = false;

      // 1. Try to delete from Supabase
      try {
        if (!id.startsWith("camp_") && !id.startsWith("migrada_")) {
          const { error } = await supabase
            .from("marketing_campaigns" as any)
            .delete()
            .eq("id", id);

          if (!error) {
            deletedFromSupabase = true;
          } else {
            throw error;
          }
        }
      } catch (e) {
        console.warn("Failed delete from Supabase, reverting to standard cache delete:", e);
      }

      // 2. Local Fallback delete
      let storedCampaignsJson = null;
      try {
        storedCampaignsJson = localStorage.getItem("safeos_marketing_campaigns");
      } catch (e) {
        console.debug("localStorage read failed:", e);
      }

      let campaigns: Campaign[] = storedCampaignsJson
        ? JSON.parse(storedCampaignsJson)
        : [...inMemoryCampaignFallback];

      campaigns = campaigns.filter(c => c.id !== id);
      inMemoryCampaignFallback = inMemoryCampaignFallback.filter(c => c.id !== id);

      try {
        localStorage.setItem("safeos_marketing_campaigns", JSON.stringify(campaigns));
      } catch (e) {
        console.debug("localStorage write failed:", e);
      }

      return { success: true, deletedFromSupabase };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["marketing-roi-metrics"] });
      if (data.deletedFromSupabase) {
        toast.success("Campanha removida com sucesso do Supabase!");
      } else {
        toast.success("Campanha removida do cache local.");
      }
    },
    onError: () => {
      toast.error("Erro ao remover campanha.");
    }
  });

  // Reset Campaigns Mutation
  const resetAllCampaignsMutation = useMutation({
    mutationFn: async () => {
      let resetFromSupabase = false;

      // 1. Try to wipe Supabase table
      try {
        const { error } = await supabase
          .from("marketing_campaigns" as any)
          .delete()
          .neq("nome", "___impossible_name___");

        if (!error) {
          resetFromSupabase = true;
        } else {
          throw error;
        }
      } catch (e) {
        console.warn("Wiping Supabase table failed or not configured, resetting cache:", e);
      }

      // 2. Local and in-memory clean
      try {
        localStorage.removeItem("safeos_marketing_campaigns");
        localStorage.removeItem("safeos_marketing_spend");
        localStorage.removeItem("safeos_marketing_leads");
        localStorage.removeItem("safeos_marketing_conversions");
        localStorage.removeItem("safeos_marketing_revenue");
      } catch (e) {
        console.debug("localStorage clean failed:", e);
      }

      inMemoryCampaignFallback = [];

      return { success: true, resetFromSupabase };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["marketing-roi-metrics"] });
      if (data.resetFromSupabase) {
        toast.success("Histórico redefinido de forma centralizada!");
      } else {
        toast.success("Histórico de cache redefinido com sucesso.");
      }
    },
    onError: () => {
      toast.error("Falha ao redefinir campanhas.");
    }
  });

  const handleOpenAddForm = () => {
    setEditingCampaignId(null);
    setFormName("");
    setFormSpend("");
    setFormLeads("");
    setFormConversions("");
    setFormRevenue("");
    setFormCategoria("Digital");
    setActiveTab("form");
  };

  const handleOpenEditForm = (camp: Campaign) => {
    setEditingCampaignId(camp.id);
    setFormName(camp.nome);
    setFormSpend(String(camp.spend));
    setFormLeads(String(camp.leads));
    setFormConversions(String(camp.conversions));
    setFormRevenue(String(camp.revenue));
    setFormCategoria(camp.categoria || "Digital");
    setActiveTab("form");
  };

  const handleSaveCampaign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      toast.error("O nome da campanha é obrigatório");
      return;
    }

    const spendVal = Math.max(0, Number(formSpend) || 0);
    const leadsVal = Math.max(0, Number(formLeads) || 0);
    const conversionsVal = Math.max(0, Number(formConversions) || 0);
    const revenueVal = Math.max(0, Number(formRevenue) || 0);

    saveCampaignMutation.mutate(
      {
        id: editingCampaignId,
        nome: formName.trim(),
        spend: spendVal,
        leads: leadsVal,
        conversions: conversionsVal,
        revenue: revenueVal,
        categoria: formCategoria
      },
      {
        onSuccess: () => {
          setActiveTab("list");
        }
      }
    );
  };

  const handleDeleteCampaign = (id: string) => {
    deleteCampaignMutation.mutate(id);
  };

  const handleResetAllCampaigns = () => {
    resetAllCampaignsMutation.mutate();
  };

  if (isLoading) return null;

  return (
    <>
      <Card id="marketing-roi-panel-card" className="border-none shadow-sm bg-card overflow-hidden relative group">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-bold flex items-center gap-2">
              <Megaphone className="h-5 w-5 text-indigo-600 animate-pulse" />
              Performance de Marketing
            </CardTitle>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className={`text-[10px] font-bold ${metrics?.roi && metrics.roi > 0 ? 'text-emerald-700 border-emerald-200 bg-emerald-50' : 'text-muted-foreground'}`}>
                ROI {metrics?.roi && metrics.roi > 0 ? `+${metrics?.roi}%` : '0%'}
              </Badge>
              {metrics?.usedSupabase && (
                <Badge variant="outline" className="text-[9px] text-indigo-700 bg-indigo-50 border-indigo-200 flex items-center gap-0.5">
                  <Check className="h-2 w-2" /> Nuvem (Supabase)
                </Badge>
              )}
              {editAllowed && (
                <button
                  id="open-mkt-manager-header-btn"
                  onClick={() => {
                    setActiveTab("list");
                    setIsModalOpen(true);
                  }}
                  className="p-1.5 hover:bg-zinc-100 dark:hover:bg-zinc-805 rounded-md transition-colors text-muted-foreground hover:text-foreground flex items-center gap-1.5 text-xs font-bold border border-zinc-200/50 dark:border-zinc-800 bg-background shadow-xs hover:shadow-sm"
                  title="Alimentar Métricas de Marketing"
                >
                  <Plus className="h-3.5 w-3.5 text-indigo-600 font-bold" />
                  <span className="text-xs font-bold leading-none">Alimentar</span>
                </button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6 pt-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">Investimento Total</p>
              <p className="text-xl font-extrabold text-foreground">
                R$ {metrics?.spend ? metrics.spend.toLocaleString("pt-BR") : "0"}
              </p>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">Faturamento Gerado</p>
              <p className="text-xl font-extrabold text-indigo-700">
                R$ {metrics?.revenue ? metrics.revenue.toLocaleString("pt-BR") : "0"}
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-muted-foreground">Conversão em Contratos / Leads</span>
                <span className="font-bold text-foreground">
                  {metrics?.conversions || 0} de {metrics?.leads || 0} ({metrics?.maxConversionRate || metrics?.conversionRate || 0}%)
                </span>
              </div>
              <Progress value={metrics?.conversionRate || 0} className="h-1.5 bg-zinc-100" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-dashed">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-indigo-50 flex items-center justify-center">
                <MousePointer2 className="h-4 w-4 text-indigo-600" />
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground leading-none font-bold uppercase">CPL Médio</p>
                <p className="text-sm font-bold leading-tight">
                  R$ {metrics?.cpl ? metrics.cpl.toLocaleString("pt-BR", { minimumFractionDigits: 2 }) : "0,00"}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-emerald-50 flex items-center justify-center">
                <Target className="h-4 w-4 text-emerald-600" />
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground leading-none font-bold uppercase">CAC Geral</p>
                <p className="text-sm font-bold leading-tight">
                  R$ {metrics?.cac ? metrics.cac.toLocaleString("pt-BR", { minimumFractionDigits: 2 }) : "0,00"}
                </p>
              </div>
            </div>
          </div>

          {metrics?.campaigns && metrics.campaigns.length > 0 ? (
            <div className="pt-2">
              <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider mb-2">Campanhas Ativas ({metrics.campaigns.length})</p>
              <div className="space-y-1.5 max-h-[140px] overflow-y-auto pr-1">
                {metrics.campaigns.map((c) => {
                  const campRoi = c.spend > 0 ? Math.round(((c.revenue - c.spend) / c.spend) * 100) : 0;
                  return (
                    <div key={c.id} className="flex justify-between items-center text-xs p-2 bg-secondary/20 hover:bg-secondary/40 rounded-lg border border-border/10">
                      <div className="flex flex-col">
                        <span className="font-bold text-foreground max-w-[150px] truncate">{c.nome}</span>
                        <span className="text-[9px] text-muted-foreground">{c.categoria || "Geral"}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right flex flex-col">
                          <span className="font-semibold">R$ {c.spend.toLocaleString("pt-BR")}</span>
                          <span className={`text-[9px] font-bold ${campRoi > 0 ? 'text-emerald-600' : 'text-rose-500'}`}>
                            ROI: {campRoi > 0 ? `+${campRoi}%` : `${campRoi}%`}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="pt-2 text-[11px] text-muted-foreground text-center italic bg-accent/20 p-4 rounded-xl border border-dashed border-border/60 flex flex-col items-center gap-2">
              <span>Nenhuma campanha ativa cadastrada. Alimente suas campanhas para otimizar suas métricas em tempo real.</span>
              {editAllowed && (
                <Button 
                  id="empty-state-mkt-btn"
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setActiveTab("list");
                    setIsModalOpen(true);
                  }}
                  className="bg-indigo-600 hover:bg-indigo-700 hover:text-white text-white border-none text-xs font-semibold h-8 rounded-lg mt-1 px-4 flex items-center gap-1.5 shadow-sm transition-all"
                >
                  <Plus className="h-3.5 w-3.5" /> Alimentar Métricas
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-[480px] border-border bg-card p-0 overflow-hidden text-foreground">
          <DialogHeader className="p-6 pb-4 border-b border-border/10 bg-indigo-50/10">
            <DialogTitle className="flex items-center gap-2 text-indigo-950 font-bold text-lg">
              <Megaphone className="h-5 w-5 text-indigo-600 animate-bounce" />
              Alimentar Métricas de Marketing
            </DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground mt-1 font-medium">
              Insira o investimento e resultados de suas campanhas de marketing para calcular automaticamente o ROI, CPL e CAC em tempo real.
            </DialogDescription>
          </DialogHeader>

          {activeTab === "list" ? (
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Listagem de Campanhas</span>
                <Button 
                  id="mkt-modal-add-campaign-btn"
                  size="sm" 
                  onClick={handleOpenAddForm} 
                  className="bg-indigo-600 hover:bg-indigo-700 text-white flex items-center gap-1 text-xs font-semibold h-8 rounded-lg"
                >
                  <Plus className="h-3.5 w-3.5" /> Adicionar Campanha
                </Button>
              </div>

              <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                {!metrics?.campaigns || metrics.campaigns.length === 0 ? (
                  <div className="text-center py-8 text-sm text-muted-foreground border border-dashed rounded-lg bg-zinc-50/20">
                    Nenhuma campanha cadastrada. Inicie criando uma!
                  </div>
                ) : (
                  metrics.campaigns.map((c) => {
                    const cRoi = c.spend > 0 ? Math.round(((c.revenue - c.spend) / c.spend) * 100) : 0;
                    const cCac = c.conversions > 0 ? (c.spend / c.conversions).toFixed(1) : "0.0";
                    const isConfirming = confirmDeleteId === c.id;

                    if (isConfirming) {
                      return (
                        <div key={c.id} className="p-3 bg-rose-50/60 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40 rounded-xl flex items-center justify-between animate-in fade-in zoom-in-95 duration-150">
                          <div className="flex-1 min-w-0 pr-2">
                            <p className="font-bold text-xs text-rose-800 dark:text-rose-400 truncate">Excluir "{c.nome}"?</p>
                            <p className="text-[10px] text-rose-600 dark:text-rose-500 font-medium mt-0.5">Essa ação recalculará as estatísticas.</p>
                          </div>
                          
                          <div className="flex gap-1.5 shrink-0">
                            <Button 
                              type="button"
                              variant="outline" 
                              size="sm" 
                              className="h-7 rounded-lg text-[10px] font-bold px-2.5 h-8"
                              onClick={() => setConfirmDeleteId(null)}
                            >
                              Cancelar
                            </Button>
                            <Button 
                              type="button"
                              variant="destructive" 
                              size="sm" 
                              className="h-7 rounded-lg text-[10px] font-bold px-2.5 bg-rose-600 hover:bg-rose-700 text-white border-none h-8"
                              onClick={() => {
                                handleDeleteCampaign(c.id);
                                setConfirmDeleteId(null);
                              }}
                            >
                              Confirmar
                            </Button>
                          </div>
                        </div>
                      );
                    }

                    return (
                      <div key={c.id} className="p-3 bg-secondary/15 hover:bg-secondary/25 border border-border/50 rounded-xl flex items-center justify-between">
                        <div>
                          <p className="font-bold text-sm text-foreground">{c.nome}</p>
                          <div className="flex items-center gap-2 mt-1 text-[10px] text-muted-foreground font-semibold">
                            <span className="bg-zinc-100 text-zinc-700 px-1.5 py-0.5 rounded">{c.categoria || "Geral"}</span>
                            <span>Leads: {c.leads}</span>
                            <span>Faturamento: R$ {c.revenue.toLocaleString("pt-BR")}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <div className="text-right">
                            <p className="text-xs font-bold">Investimento: R$ {c.spend.toLocaleString("pt-BR")}</p>
                            <p className={`text-[10px] font-black mt-0.5 ${cRoi > 0 ? 'text-emerald-600' : 'text-rose-500'}`}>
                              ROI: {cRoi > 0 ? `+${cRoi}%` : `${cRoi}%`} • CAC: R$ {cCac}
                            </p>
                          </div>
                          
                          <div className="flex gap-1 ml-2">
                            <Button 
                              type="button"
                              variant="ghost" 
                              size="icon" 
                              className="h-7 w-7 text-muted-foreground hover:text-foreground"
                              onClick={() => handleOpenEditForm(c)}
                            >
                              <Pencil className="h-3.5 w-3.5" />
                            </Button>
                            <Button 
                              type="button"
                              variant="ghost" 
                              size="icon" 
                              className="h-7 w-7 text-destructive hover:bg-destructive/10"
                              onClick={() => setConfirmDeleteId(c.id)}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              <div className="pt-4 border-t border-border/10 flex items-center justify-between">
                {isResetConfirmOpen ? (
                  <div className="flex items-center gap-1 bg-rose-50/65 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40 p-1 rounded-xl animate-in fade-in zoom-in-95 duration-100">
                    <span className="text-[10px] pr-2 font-bold text-rose-800 dark:text-rose-400 pl-1">Zerar tudo mesmo?</span>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setIsResetConfirmOpen(false)}
                      className="h-7 px-2 rounded-lg text-[10px] font-bold"
                    >
                      Não
                    </Button>
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        handleResetAllCampaigns();
                        setIsResetConfirmOpen(false);
                      }}
                      className="h-7 px-2 rounded-lg text-[10px] font-bold bg-rose-600 hover:bg-rose-700 text-white border-none"
                    >
                      Sim
                    </Button>
                  </div>
                ) : (
                  <Button
                    id="mkt-modal-reset-all-btn"
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setIsResetConfirmOpen(true)}
                    className="text-destructive hover:bg-destructive/5 hover:text-destructive border-dashed border-destructive/20 h-9 rounded-xl text-xs font-bold"
                  >
                    <RotateCcw className="h-3.5 w-3.5 mr-1" />
                    Zerar Todas as Campanhas
                  </Button>
                )}

                <Button 
                  id="mkt-modal-close-btn"
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setIsModalOpen(false)}
                  className="h-9 rounded-xl text-xs font-bold"
                >
                  Concluir / Fechar
                </Button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSaveCampaign} className="p-6 space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-950">
                {editingCampaignId ? "Editar Detalhes da Campanha" : "Cadastrar Nova Campanha de Marketing"}
              </h4>

              <div className="space-y-3">
                <div className="grid gap-1.5">
                  <Label htmlFor="campName" className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Identificação / Nome da Campanha</Label>
                  <Input
                    id="campName"
                    placeholder="Ex: Google Ads - RCP Médicos 2026"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="h-10 rounded-xl"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="grid gap-1.5">
                    <Label htmlFor="campCategoria" className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Canal / Categoria</Label>
                    <Input
                      id="campCategoria"
                      placeholder="Ex: Search, Social, E-mail"
                      value={formCategoria}
                      onChange={(e) => setFormCategoria(e.target.value)}
                      className="h-10 rounded-xl"
                    />
                  </div>

                  <div className="grid gap-1.5">
                    <Label htmlFor="campSpend" className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Investimento Total (R$)</Label>
                    <Input
                      id="campSpend"
                      type="number"
                      placeholder="Ex: 1000"
                      value={formSpend}
                      onChange={(e) => setFormSpend(e.target.value)}
                      className="h-10 rounded-xl"
                      min="0"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="grid gap-1.5">
                    <Label htmlFor="campLeads" className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Leads Adquiridos</Label>
                    <Input
                      id="campLeads"
                      type="number"
                      placeholder="Ex: 50"
                      value={formLeads}
                      onChange={(e) => setFormLeads(e.target.value)}
                      className="h-10 rounded-xl"
                      min="0"
                    />
                  </div>

                  <div className="grid gap-1.5">
                    <Label htmlFor="campConversions" className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Conversões (Fechamentos)</Label>
                    <Input
                      id="campConversions"
                      type="number"
                      placeholder="Ex: 5"
                      value={formConversions}
                      onChange={(e) => setFormConversions(e.target.value)}
                      className="h-10 rounded-xl"
                      min="0"
                    />
                  </div>
                </div>

                <div className="grid gap-1.5">
                  <Label htmlFor="campRevenue" className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Faturamento / Receita Convertida (R$)</Label>
                  <Input
                    id="campRevenue"
                    type="number"
                    placeholder="Ex: 8500"
                    value={formRevenue}
                    onChange={(e) => setFormRevenue(e.target.value)}
                    className="h-10 rounded-xl"
                    min="0"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-border/10 flex justify-between gap-2">
                <Button 
                  id="mkt-form-back-btn"
                  type="button" 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setActiveTab("list")}
                  className="h-9 rounded-xl text-xs font-bold"
                >
                  Voltar para Lista
                </Button>

                <div className="flex gap-2">
                  <Button 
                    id="mkt-form-discard-btn"
                    type="button" 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setActiveTab("list")}
                    className="h-9 rounded-xl text-xs font-bold"
                  >
                    Descartar
                  </Button>
                  <Button 
                    id="mkt-form-submit-btn"
                    type="submit" 
                    size="sm" 
                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold h-9 rounded-xl px-4"
                  >
                    {editingCampaignId ? "Salvar Alterações" : "Salvar Campanha"}
                  </Button>
                </div>
              </div>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
