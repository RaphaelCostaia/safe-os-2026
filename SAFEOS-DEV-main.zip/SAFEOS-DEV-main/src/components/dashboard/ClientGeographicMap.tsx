import React, { useState, useMemo } from "react";
import {
  BRAZIL_STATES_PATHS,
  BRAZIL_MAP_VIEWBOX,
  UF_NAMES,
} from "@/data/brazilGeoData";
import { useClientMapData, MapFilters } from "@/hooks/useClientMapData";
import {
  Users,
  DollarSign,
  TrendingUp,
  Map as MapIcon,
  Search,
  Filter,
  BarChart3,
  ChevronRight,
  Info,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { motion, AnimatePresence } from "motion/react";

export function ClientGeographicMap() {
  const [selectedUF, setSelectedUF] = useState<string | null>(null);
  const [filters, setFilters] = useState<MapFilters>({
    status: "all",
    tipo_pessoa: "all",
    profissao: "all",
    produto_id: "all",
  });

  const { data, isLoading } = useClientMapData(filters);

  const maxCount = useMemo(() => {
    if (!data?.byState) return 0;
    return Math.max(...Object.values(data.byState).map((s) => s.count));
  }, [data]);

  const getColor = (count: number) => {
    if (count === 0) return "fill-muted/20";
    const intensity = count / maxCount;
    if (intensity > 0.8) return "fill-primary";
    if (intensity > 0.5) return "fill-primary/70";
    if (intensity > 0.2) return "fill-primary/40";
    return "fill-primary/20";
  };

  const selectedStateData = selectedUF ? data?.byState[selectedUF] : null;

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* MAP COLUMN */}
      <div className="lg:col-span-7 space-y-6">
        <Card className="rounded-[2.5rem] border-none shadow-sm bg-card/50 overflow-hidden">
          <div className="p-8 border-b flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-black tracking-tight flex items-center gap-2">
                <MapIcon className="h-5 w-5 text-primary" />
                Distribuição Territorial
              </h3>
              <p className="text-xs text-muted-foreground font-medium mt-1">
                Clique nos estados para detalhamento regional
              </p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Badge
                variant="secondary"
                className="bg-primary/10 text-primary border-none font-bold"
              >
                {data?.totalClients || 0} Clientes Mapeados
              </Badge>
              <Badge
                variant="secondary"
                className="bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-none font-bold"
              >
                {data?.totalPolicies || 0} Apólices Ativas
              </Badge>
            </div>
          </div>

          <div className="p-8 flex items-center justify-center min-h-[500px] relative">
            {isLoading ? (
              <Skeleton className="w-full h-[400px] rounded-3xl" />
            ) : (
              <svg
                viewBox={BRAZIL_MAP_VIEWBOX}
                className="w-full h-auto max-w-[600px] drop-shadow-2xl"
              >
                {BRAZIL_STATES_PATHS.map((state) => {
                  const stateStats = data?.byState[state.uf];
                  const count = stateStats?.count || 0;
                  const isSelected = selectedUF === state.uf;

                  return (
                    <motion.path
                      key={state.uf}
                      d={state.path}
                      className={`${getColor(count)} stroke-background stroke-[1.5] cursor-pointer transition-all hover:stroke-primary hover:stroke-2`}
                      initial={false}
                      animate={{
                        scale: isSelected ? 1.02 : 1,
                        opacity: isSelected ? 1 : 0.9,
                      }}
                      onClick={() =>
                        setSelectedUF(isSelected ? null : state.uf)
                      }
                    >
                      <title>
                        {UF_NAMES[state.uf]}: {count} clientes
                      </title>
                    </motion.path>
                  );
                })}
              </svg>
            )}

            {/* Map Legend */}
            <div className="absolute bottom-6 right-6 flex flex-col gap-2 bg-white/80 dark:bg-black/80 backdrop-blur-md p-4 rounded-2xl border text-[10px] font-bold uppercase tracking-wider shadow-sm">
              <span className="text-muted-foreground mb-1">
                Concentração Clientes
              </span>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-primary" />
                <span>Alta (+80%)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-primary/40" />
                <span>Média (20-50%)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-muted/20" />
                <span>Sem Clientes</span>
              </div>
            </div>
          </div>
        </Card>

        {/* Global Geographic Ranking Table */}
        <Card className="rounded-[2.5rem] border-none shadow-sm overflow-hidden">
          <div className="p-6 border-b bg-muted/20">
            <h4 className="text-sm font-black uppercase tracking-widest flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Ranking Geográfico (Nacional)
            </h4>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {Object.entries(data?.byState || {})
                .sort((a, b) => b[1].count - a[1].count)
                .slice(0, 5)
                .map(([uf, stateData], index) => (
                  <div key={uf} className="flex items-center gap-4 group">
                    <div className="w-8 h-8 rounded-xl bg-muted flex items-center justify-center font-bold text-xs">
                      #{index + 1}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between text-xs font-bold mb-1">
                        <span>{UF_NAMES[uf]}</span>
                        <span className="text-primary">
                          {stateData.count} Clientes
                        </span>
                      </div>
                      <Progress
                        value={(stateData.count / maxCount) * 100}
                        className="h-1.5"
                      />
                    </div>
                    <div className="text-right w-24">
                      <p className="text-[10px] font-bold text-muted-foreground uppercase">
                        {formatCurrency(stateData.revenue)}
                      </p>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </Card>
      </div>

      {/* DETAILS COLUMN */}
      <div className="lg:col-span-5 space-y-6">
        {/* Filters */}
        <Card className="rounded-[2.5rem] p-6 shadow-sm border-2 border-primary/5">
          <h4 className="text-sm font-black uppercase tracking-widest mb-4 flex items-center gap-2">
            <Filter className="h-4 w-4" /> Filtros Dinâmicos
          </h4>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-muted-foreground uppercase">
                Pesquisar Cidade
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  placeholder="Ex: Rio de Janeiro"
                  className="h-10 pl-9 rounded-xl text-xs bg-muted/20 border-none"
                  value={filters.cidade || ""}
                  onChange={(e) =>
                    setFilters((prev) => ({ ...prev, cidade: e.target.value }))
                  }
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-muted-foreground uppercase">
                  Tipo Pessoa
                </label>
                <Select
                  value={filters.tipo_pessoa || "all"}
                  onValueChange={(v) =>
                    setFilters((prev) => ({ ...prev, tipo_pessoa: v }))
                  }
                >
                  <SelectTrigger className="h-10 rounded-xl text-xs bg-muted/20 border-none">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="fisica">Pessoa Física</SelectItem>
                    <SelectItem value="juridica">Pessoa Jurídica</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-muted-foreground uppercase">
                  Status Client
                </label>
                <Select
                  value={filters.status || "all"}
                  onValueChange={(v) =>
                    setFilters((prev) => ({ ...prev, status: v }))
                  }
                >
                  <SelectTrigger className="h-10 rounded-xl text-xs bg-muted/20 border-none">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="ativo">Ativo</SelectItem>
                    <SelectItem value="prospect">Lead / Prospect</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </Card>

        {/* Selected State Details */}
        <AnimatePresence mode="wait">
          {selectedUF ? (
            <motion.div
              key={selectedUF}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <Card className="rounded-[2.5rem] border-2 border-primary/20 bg-primary/5 p-8 relative overflow-hidden shadow-xl">
                <div className="absolute top-0 right-0 p-8 opacity-10">
                  <BarChart3 className="h-24 w-24" />
                </div>

                <div className="relative">
                  <Badge className="bg-primary text-white font-bold mb-4">
                    {selectedUF}
                  </Badge>
                  <h3 className="text-3xl font-black tracking-tight mb-2">
                    {UF_NAMES[selectedUF]}
                  </h3>
                  <div className="grid grid-cols-3 gap-3 mt-8">
                    <div className="p-3 bg-white/50 dark:bg-black/20 rounded-2xl border border-white/50">
                      <p className="text-[10px] font-bold text-muted-foreground uppercase mb-1">
                        Clientes
                      </p>
                      <p className="text-lg font-black">
                        {selectedStateData?.count || 0}
                      </p>
                    </div>
                    <div className="p-3 bg-white/50 dark:bg-black/20 rounded-2xl border border-white/50">
                      <p className="text-[10px] font-bold text-muted-foreground uppercase mb-1">
                        Apólices
                      </p>
                      <p className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                        {selectedStateData?.policiesCount || 0}
                      </p>
                    </div>
                    <div className="p-3 bg-white/50 dark:bg-black/20 rounded-2xl border border-white/50">
                      <p className="text-[10px] font-bold text-muted-foreground uppercase mb-1">
                        Receita
                      </p>
                      <p className="text-base font-black text-primary">
                        {formatCurrency(selectedStateData?.revenue || 0)}
                      </p>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Top Cities */}
              <Card className="rounded-[2.5rem] p-8 shadow-sm">
                <h4 className="text-sm font-black uppercase tracking-widest mb-6 border-b pb-4 flex items-center gap-2">
                  <ChevronRight className="h-4 w-4 text-primary" /> Principais
                  Cidades
                </h4>
                <div className="space-y-4">
                  {selectedStateData?.topCities.map((city, i) => (
                    <div
                      key={city.name}
                      className="flex items-center justify-between group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-6 h-6 rounded-lg bg-muted flex items-center justify-center text-[10px] font-black">
                          {i + 1}
                        </div>
                        <span className="text-sm font-bold group-hover:text-primary transition-colors">
                          {city.name}
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge
                          variant="outline"
                          className="font-mono text-[10px] h-5"
                        >
                          {city.count} CLTS
                        </Badge>
                        <Badge
                          variant="outline"
                          className="font-mono text-[10px] h-5 border-emerald-500/30 text-emerald-600 dark:text-emerald-400 font-bold"
                        >
                          {city.policiesCount || 0} APOL
                        </Badge>
                        <span className="text-xs font-bold text-muted-foreground w-20 text-right">
                          {formatCurrency(city.revenue)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Product Mix */}
              <Card className="rounded-[2.5rem] p-8 shadow-sm">
                <h4 className="text-sm font-black uppercase tracking-widest mb-6 border-b pb-4 flex items-center gap-2">
                  <ChevronRight className="h-4 w-4 text-primary" /> Mix de
                  Produtos na Região
                </h4>
                <div className="space-y-5">
                  {selectedStateData?.topProducts.map((prod) => (
                    <div key={prod.name} className="space-y-1.5">
                      <div className="flex justify-between text-xs font-bold">
                        <span>{prod.name}</span>
                        <span className="text-muted-foreground">
                          {Math.round(
                            (prod.count / (selectedStateData?.count || 1)) *
                              100,
                          )}
                          %
                        </span>
                      </div>
                      <Progress
                        value={
                          (prod.count / (selectedStateData?.count || 1)) * 100
                        }
                        className="h-1.5"
                      />
                    </div>
                  ))}
                </div>
              </Card>
            </motion.div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center p-12 text-center opacity-40 grayscale border-2 border-dashed rounded-[3rem]">
              <Info className="h-12 w-12 mb-4" />
              <p className="text-sm font-black uppercase tracking-widest">
                Nenhuma região selecionada
              </p>
              <p className="text-xs mt-2 font-medium">
                Interaja com o mapa ao lado para visualizar <br /> insights
                detalhados por estado brasileiro.
              </p>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
