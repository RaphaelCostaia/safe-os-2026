import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, StickyNote, Lightbulb, CheckSquare, ListTodo, AlertTriangle } from "lucide-react";
import { CreateTaskModal } from "./CreateTaskModal";
import { CreateNoteModal } from "./CreateNoteModal";
import { CreateTipModal } from "./CreateTipModal";
import { TasksList } from "./TasksList";
import { NotesList } from "./NotesList";
import { TipsList } from "./TipsList";
import { PriorityQueueList } from "./PriorityQueueList";
import { usePriorityQueue } from "@/hooks/usePriorityQueue";

export function ActionPanel() {
  const [activeTab, setActiveTab] = useState("prioridades");
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [showNoteModal, setShowNoteModal] = useState(false);
  const [showTipModal, setShowTipModal] = useState(false);

  const { data: priorityItems } = usePriorityQueue();
  
  const criticalCount = priorityItems?.filter(
    (item) => item.priority === "critica" || item.priority === "alta"
  ).length || 0;

  return (
    <>
      <Card className="col-span-full lg:col-span-2">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <CardTitle className="text-lg">Ações do Dia</CardTitle>
              {criticalCount > 0 && (
                <span className="flex items-center gap-1 text-xs bg-destructive/10 text-destructive px-2 py-0.5 rounded-full">
                  <AlertTriangle className="h-3 w-3" />
                  {criticalCount} urgentes
                </span>
              )}
            </div>
            <div className="flex gap-1">
              <Button
                variant="outline"
                size="sm"
                className="gap-1 h-8 text-xs"
                onClick={() => setShowNoteModal(true)}
              >
                <Plus className="h-3 w-3" />
                <StickyNote className="h-3 w-3" />
                <span className="hidden sm:inline">Anotação</span>
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="gap-1 h-8 text-xs"
                onClick={() => setShowTipModal(true)}
              >
                <Plus className="h-3 w-3" />
                <Lightbulb className="h-3 w-3" />
                <span className="hidden sm:inline">Tip</span>
              </Button>
              <Button
                variant="default"
                size="sm"
                className="gap-1 h-8 text-xs"
                onClick={() => setShowTaskModal(true)}
              >
                <Plus className="h-3 w-3" />
                <CheckSquare className="h-3 w-3" />
                <span className="hidden sm:inline">Tarefa</span>
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-4 h-9">
              <TabsTrigger value="prioridades" className="text-xs gap-1">
                <ListTodo className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Prioridades</span>
              </TabsTrigger>
              <TabsTrigger value="tarefas" className="text-xs gap-1">
                <CheckSquare className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Tarefas</span>
              </TabsTrigger>
              <TabsTrigger value="anotacoes" className="text-xs gap-1">
                <StickyNote className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Anotações</span>
              </TabsTrigger>
              <TabsTrigger value="tips" className="text-xs gap-1">
                <Lightbulb className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">Tips</span>
              </TabsTrigger>
            </TabsList>

            <div className="mt-4">
              <TabsContent value="prioridades" className="m-0">
                <PriorityQueueList />
              </TabsContent>
              <TabsContent value="tarefas" className="m-0">
                <TasksList />
              </TabsContent>
              <TabsContent value="anotacoes" className="m-0">
                <NotesList />
              </TabsContent>
              <TabsContent value="tips" className="m-0">
                <TipsList />
              </TabsContent>
            </div>
          </Tabs>
        </CardContent>
      </Card>

      <CreateTaskModal open={showTaskModal} onOpenChange={setShowTaskModal} />
      <CreateNoteModal open={showNoteModal} onOpenChange={setShowNoteModal} />
      <CreateTipModal open={showTipModal} onOpenChange={setShowTipModal} />
    </>
  );
}
