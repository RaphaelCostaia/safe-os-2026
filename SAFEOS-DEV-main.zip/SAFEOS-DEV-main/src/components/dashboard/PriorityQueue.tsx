import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  AlertTriangle, 
  Calendar, 
  RefreshCw, 
  DollarSign, 
  CheckSquare,
  ArrowRight,
  Clock,
  AlertCircle
} from "lucide-react";
import { cn } from "@/lib/utils";
import { usePriorityQueue, type PriorityItem, type PriorityLevel } from "@/hooks/usePriorityQueue";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useNavigate } from "react-router-dom";

const priorityConfig: Record<PriorityLevel, { label: string; className: string; icon: React.ElementType }> = {
  critica: { 
    label: "Crítico", 
    className: "bg-destructive/10 text-destructive border-destructive/20",
    icon: AlertTriangle
  },
  alta: { 
    label: "Alta", 
    className: "bg-warning/10 text-warning border-warning/20",
    icon: AlertCircle
  },
  media: { 
    label: "Média", 
    className: "bg-primary/10 text-primary border-primary/20",
    icon: Clock
  },
  baixa: { 
    label: "Baixa", 
    className: "bg-muted text-muted-foreground border-border",
    icon: Clock
  },
};

const typeConfig: Record<string, { icon: React.ElementType; color: string; route: string }> = {
  renovacao: { icon: RefreshCw, color: "text-warning", route: "/renovacoes" },
  financeiro: { icon: DollarSign, color: "text-success", route: "/financeiro" },
  tarefa: { icon: CheckSquare, color: "text-primary", route: "/" },
};

function PriorityQueueItem({ item }: { item: PriorityItem }) {
  const navigate = useNavigate();
  const config = priorityConfig[item.priority];
  const typeConf = typeConfig[item.type];
  const TypeIcon = typeConf.icon;
  const PriorityIcon = config.icon;

  const formatDaysRemaining = (days: number) => {
    if (days < 0) return `${Math.abs(days)} dia(s) atrasado`;
    if (days === 0) return "Vence hoje";
    if (days === 1) return "Vence amanhã";
    return `Vence em ${days} dias`;
  };

  return (
    <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-secondary/50 transition-colors group">
      <div className={cn("p-2 rounded-lg bg-secondary", typeConf.color)}>
        <TypeIcon className="h-4 w-4" />
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <p className="font-medium text-sm truncate">{item.title}</p>
          <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0", config.className)}>
            <PriorityIcon className="h-3 w-3 mr-1" />
            {config.label}
          </Badge>
        </div>
        <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
          <span className="truncate">{item.description}</span>
          {item.metadata?.value && (
            <span className="font-medium text-foreground">
              R$ {item.metadata.value.toLocaleString("pt-BR")}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1 text-xs mt-1">
          <Calendar className="h-3 w-3 text-muted-foreground" />
          <span className={cn(
            item.daysRemaining < 0 ? "text-destructive font-medium" :
            item.daysRemaining <= 2 ? "text-warning" : "text-muted-foreground"
          )}>
            {formatDaysRemaining(item.daysRemaining)}
          </span>
        </div>
      </div>

      <Button 
        variant="ghost" 
        size="icon" 
        className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
        onClick={() => navigate(typeConf.route)}
      >
        <ArrowRight className="h-4 w-4" />
      </Button>
    </div>
  );
}

export function PriorityQueue() {
  const { data: items = [], isLoading } = usePriorityQueue(15);

  const criticalCount = items.filter(i => i.priority === "critica").length;
  const highCount = items.filter(i => i.priority === "alta").length;

  if (isLoading) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-warning" />
            Ações do Dia
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {[1, 2, 3].map(i => (
            <div key={i} className="flex items-center gap-3 p-3">
              <Skeleton className="h-8 w-8 rounded-lg" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  if (items.length === 0) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <CheckSquare className="h-4 w-4 text-success" />
            Ações do Dia
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <CheckSquare className="h-10 w-10 text-success mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              Nenhuma ação pendente no momento
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Você está em dia com suas tarefas!
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50 bg-card">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-warning" />
            Ações do Dia
          </CardTitle>
          <div className="flex items-center gap-2">
            {criticalCount > 0 && (
              <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20 text-xs">
                {criticalCount} crítico{criticalCount > 1 ? "s" : ""}
              </Badge>
            )}
            {highCount > 0 && (
              <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20 text-xs">
                {highCount} alta
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[320px]">
          <div className="px-4 pb-4 space-y-1">
            {items.map((item) => (
              <PriorityQueueItem key={`${item.type}-${item.id}`} item={item} />
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
