import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp } from "lucide-react";
import { useRevenueChartData, useProductRevenueData } from "@/hooks/useFinanceiroHistorico";

export function RevenueChart() {
  const { data: revenueData = [], isLoading: revenueLoading } = useRevenueChartData(12);
  const { data: productData = [], isLoading: productLoading } = useProductRevenueData(6);

  const isLoading = revenueLoading || productLoading;
  const hasRevenueData = revenueData.length > 0 && revenueData.some((d) => d.receita > 0);
  const hasProductData = productData.length > 0 && productData.some((d) => d.rcp > 0 || d.vida > 0 || d.dit > 0 || d.outros > 0);

  if (isLoading) {
    return (
      <Card className="border-border/50 bg-card col-span-2">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Desempenho Financeiro</CardTitle>
          <CardDescription>Receitas, despesas e lucro mensal</CardDescription>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-[300px] w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50 bg-card col-span-2">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg font-semibold">Desempenho Financeiro</CardTitle>
            <CardDescription>Receitas, despesas e lucro mensal</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="revenue" className="space-y-4">
          <TabsList className="bg-secondary">
            <TabsTrigger value="revenue">Receita vs Despesa</TabsTrigger>
            <TabsTrigger value="commission">Por Produto</TabsTrigger>
          </TabsList>

          <TabsContent value="revenue">
            {!hasRevenueData ? (
              <div className="flex flex-col items-center justify-center h-[300px] text-center">
                <TrendingUp className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-sm text-muted-foreground">Sem dados financeiros históricos</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Registre dados na tabela financeiro_historico para visualizar
                </p>
              </div>
            ) : (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={revenueData}>
                    <defs>
                      <linearGradient id="colorReceita" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(217, 91%, 60%)" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="hsl(217, 91%, 60%)" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorLucro" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(142, 71%, 45%)" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="hsl(142, 71%, 45%)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 47%, 16%)" />
                    <XAxis dataKey="month" stroke="hsl(215, 20%, 55%)" fontSize={12} />
                    <YAxis
                      stroke="hsl(215, 20%, 55%)"
                      fontSize={12}
                      tickFormatter={(value) => `${value / 1000}k`}
                    />
                    <Tooltip
                      formatter={(value: number) => `R$ ${value.toLocaleString("pt-BR")}`}
                      contentStyle={{
                        backgroundColor: "hsl(222, 47%, 10%)",
                        border: "1px solid hsl(222, 47%, 16%)",
                        borderRadius: "8px",
                      }}
                      labelStyle={{ color: "hsl(210, 40%, 98%)" }}
                    />
                    <Area
                      type="monotone"
                      dataKey="receita"
                      stroke="hsl(217, 91%, 60%)"
                      fillOpacity={1}
                      fill="url(#colorReceita)"
                      strokeWidth={2}
                      name="Receita"
                    />
                    <Area
                      type="monotone"
                      dataKey="lucro"
                      stroke="hsl(142, 71%, 45%)"
                      fillOpacity={1}
                      fill="url(#colorLucro)"
                      strokeWidth={2}
                      name="Lucro"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            )}
          </TabsContent>

          <TabsContent value="commission">
            {!hasProductData ? (
              <div className="flex flex-col items-center justify-center h-[300px] text-center">
                <TrendingUp className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-sm text-muted-foreground">Sem dados de produtos</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Cadastre apólices vinculadas a produtos para visualizar
                </p>
              </div>
            ) : (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={productData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 47%, 16%)" />
                    <XAxis dataKey="month" stroke="hsl(215, 20%, 55%)" fontSize={12} />
                    <YAxis
                      stroke="hsl(215, 20%, 55%)"
                      fontSize={12}
                      tickFormatter={(value) => `${value / 1000}k`}
                    />
                    <Tooltip
                      formatter={(value: number) => `R$ ${value.toLocaleString("pt-BR")}`}
                      contentStyle={{
                        backgroundColor: "hsl(222, 47%, 10%)",
                        border: "1px solid hsl(222, 47%, 16%)",
                        borderRadius: "8px",
                      }}
                    />
                    <Bar dataKey="rcp" name="RCP" fill="hsl(217, 91%, 60%)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="vida" name="Vida" fill="hsl(262, 83%, 58%)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="dit" name="DIT" fill="hsl(142, 71%, 45%)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="outros" name="Outros" fill="hsl(38, 92%, 50%)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
