import { useNavigate } from "react-router-dom";
import { usePriorityQueue, PriorityItem, PriorityLevel, PriorityItemType } from "@/hooks/usePriorityQueue";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  RefreshCw, 
  DollarSign, 
  CheckSquare, 
  ArrowRight, 
  Calendar,
  AlertCircle,
  AlertTriangle,
  Check
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useCompleteTask } from "@/hooks/useTasks";

const priorityConfig: Record<PriorityLevel, { label: string; className: string; icon: React.ReactNode }> = {
  critica: { 
    label: "Crítica", 
    className: "bg-red-500 text-white hover:bg-red-600",
    icon: <AlertCircle className="h-3 w-3" />
  },
  alta: { 
    label: "Alta", 
    className: "bg-orange-500 text-white hover:bg-orange-600",
    icon: null
  },
  media: { 
    label: "Média", 
    className: "bg-yellow-500 text-black hover:bg-yellow-600",
    icon: null
  },
  baixa: { 
    label: "Baixa", 
    className: "bg-green-500 text-white hover:bg-green-600",
    icon: null
  },
};

const typeConfig: Record<PriorityItemType, { icon: React.ReactNode; color: string; route: string }> = {
  renovacao: { 
    icon: <RefreshCw className="h-4 w-4" />, 
    color: "text-blue-600",
    route: "/renovacoes"
  },
  financeiro: { 
    icon: <DollarSign className="h-4 w-4" />, 
    color: "text-green-600",
    route: "/financeiro"
  },
  tarefa: { 
    icon: <CheckSquare className="h-4 w-4" />, 
    color: "text-purple-600",
    route: ""
  },
  sinistro: { 
    icon: <AlertTriangle className="h-4 w-4" />, 
    color: "text-red-600",
    route: "/sinistros"
  },
};

function formatDaysRemaining(days: number, type?: PriorityItemType): string {
  if (type === "sinistro") {
    const daysOpen = Math.abs(days);
    if (daysOpen === 0) return "Aberto hoje";
    return `Aberto há ${daysOpen} dias`;
  }
  
  if (days < 0) {
    return `${Math.abs(days)} dias atrasado`;
  } else if (days === 0) {
    return "Vence hoje";
  } else if (days === 1) {
    return "Vence amanhã";
  } else {
    return `Vence em ${days} dias`;
  }
}

function PriorityQueueItem({ item }: { item: PriorityItem }) {
  const navigate = useNavigate();
  const completeTask = useCompleteTask();
  
  const config = priorityConfig[item.priority];
  const typeConf = typeConfig[item.type];

  const handleAction = () => {
    if (item.type === "tarefa") {
      completeTask.mutate(item.id);
    } else {
      navigate(typeConf.route);
    }
  };

  return (
    <div className="flex items-start gap-3 p-3 rounded-lg border bg-card hover:bg-accent/5 transition-colors">
      <div className={cn("p-2 rounded-lg bg-muted", typeConf.color)}>
        {typeConf.icon}
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-medium text-sm truncate">{item.title}</span>
          <Badge className={cn("gap-1", config.className)}>
            {config.icon}
            {config.label}
          </Badge>
        </div>

        {item.description && (
          <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{item.description}</p>
        )}

        <div className={cn(
          "flex items-center gap-1 text-xs mt-1",
          item.daysRemaining < 0 ? "text-destructive" : 
          item.daysRemaining <= 2 ? "text-orange-600" : "text-muted-foreground"
        )}>
          <Calendar className="h-3 w-3" />
          {formatDaysRemaining(item.daysRemaining, item.type)}
        </div>
      </div>

      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 shrink-0"
        onClick={handleAction}
        disabled={item.type === "tarefa" && completeTask.isPending}
      >
        {item.type === "tarefa" ? (
          <Check className="h-4 w-4" />
        ) : (
          <ArrowRight className="h-4 w-4" />
        )}
      </Button>
    </div>
  );
}

export function PriorityQueueList() {
  const { data: items, isLoading } = usePriorityQueue();

  if (isLoading) {
    return (
      <div className="space-y-2">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-16 w-full" />
        ))}
      </div>
    );
  }

  if (!items || items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <div className="rounded-full bg-muted p-3 mb-3">
          <Check className="h-6 w-6 text-muted-foreground" />
        </div>
        <h3 className="text-sm font-medium">Tudo em dia!</h3>
        <p className="text-xs text-muted-foreground mt-1">
          Não há itens urgentes no momento
        </p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-[300px]">
      <div className="space-y-2 pr-4">
        {items.slice(0, 20).map((item) => (
          <PriorityQueueItem key={`${item.type}-${item.id}`} item={item} />
        ))}
        {items.length > 20 && (
          <p className="text-xs text-muted-foreground text-center py-2">
            +{items.length - 20} itens adicionais
          </p>
        )}
      </div>
    </ScrollArea>
  );
}
