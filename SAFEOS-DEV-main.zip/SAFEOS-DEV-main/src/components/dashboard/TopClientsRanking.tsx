import React, { useState } from "react";
import { 
  useClientRanking, 
  RankingCriterion, 
  RankedClient 
} from "@/hooks/useClientRanking";
import {
  Trophy,
  TrendingUp,
  Clock,
  Briefcase,
  Target,
  ChevronRight,
  MoreHorizontal,
  Star,
  MapPin,
  ShieldCheck,
  Zap,
  ArrowUpRight
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useNavigate } from "react-router-dom";

export function TopClientsRanking() {
  const [criterion, setCriterion] = useState<RankingCriterion>("commission");
  const { data: clients, isLoading } = useClientRanking(criterion, 15);
  const navigate = useNavigate();

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      maximumFractionDigits: 0
    }).format(value);
  };

  const getRankBadge = (index: number) => {
    if (index === 0) return <div className="w-8 h-8 rounded-full bg-yellow-400 flex items-center justify-center text-white shadow-lg animate-pulse"><Trophy className="h-4 w-4" /></div>;
    if (index === 1) return <div className="w-8 h-8 rounded-full bg-slate-300 flex items-center justify-center text-white shadow-md"><Trophy className="h-4 w-4" /></div>;
    if (index === 2) return <div className="w-8 h-8 rounded-full bg-amber-600 flex items-center justify-center text-white shadow-md"><Trophy className="h-4 w-4" /></div>;
    return <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center font-bold text-xs">{index + 1}</div>;
  };

  return (
    <Card className="rounded-[2.5rem] border-none shadow-sm overflow-hidden bg-card/50">
      <div className="p-8 border-b flex flex-col md:flex-row md:items-center justify-between gap-6 bg-muted/10">
        <div>
           <h3 className="text-2xl font-black tracking-tight flex items-center gap-3">
             <Trophy className="h-6 w-6 text-yellow-500" />
             Ranking de Performance de Clientes
           </h3>
           <p className="text-sm text-muted-foreground mt-1 font-medium">Análise qualitativa e quantitativa da base de maior valor</p>
        </div>
        <div className="flex items-center gap-2">
           <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground mr-2">Ordenar por:</span>
           <Select value={criterion} onValueChange={(v) => setCriterion(v as RankingCriterion)}>
             <SelectTrigger className="w-60 h-11 rounded-2xl bg-white dark:bg-black/40 border-2 border-primary/10 font-bold text-xs uppercase tracking-wider">
               <SelectValue />
             </SelectTrigger>
             <SelectContent>
               <SelectItem value="commission">Maior Comissão Gerada</SelectItem>
               <SelectItem value="premium">Maior Prêmio Total</SelectItem>
               <SelectItem value="relationship">Tempo de Relacionamento</SelectItem>
               <SelectItem value="ltv">Maior LTV Projetado</SelectItem>
               <SelectItem value="products">Mix de Carteira (Produtos)</SelectItem>
               <SelectItem value="expansion">Potencial de Expansão</SelectItem>
             </SelectContent>
           </Select>
        </div>
      </div>

      <div className="p-0 overflow-x-auto">
        <Table>
          <TableHeader className="bg-muted/5">
            <TableRow className="hover:bg-transparent border-none">
              <TableHead className="w-20 text-center font-black uppercase text-[10px] tracking-widest py-6">Rank</TableHead>
              <TableHead className="text-left font-black uppercase text-[10px] tracking-widest py-6">Cliente</TableHead>
              <TableHead className="text-right font-black uppercase text-[10px] tracking-widest py-6">Prêmio / Comissão</TableHead>
              <TableHead className="text-center font-black uppercase text-[10px] tracking-widest py-6">Carteira</TableHead>
              <TableHead className="text-center font-black uppercase text-[10px] tracking-widest py-6">Relacionamento</TableHead>
              <TableHead className="text-center font-black uppercase text-[10px] tracking-widest py-6">Potencial</TableHead>
              <TableHead className="w-16"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell colSpan={7} className="p-8 text-center"><Skeleton className="h-12 w-full rounded-2xl" /></TableCell>
                </TableRow>
              ))
            ) : (
              clients?.map((client, index) => (
                <TableRow 
                  key={client.id} 
                  className="group hover:bg-primary/5 border-b border-muted/20 transition-all cursor-pointer"
                  onClick={() => navigate(`/clientes/${client.id}`)}
                >
                  <TableCell className="text-center py-6">
                    {getRankBadge(index)}
                  </TableCell>
                  <TableCell className="py-6">
                    <div className="flex flex-col">
                       <span className="font-black text-sm group-hover:text-primary transition-colors">{client.nome}</span>
                       <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-medium mt-1">
                          <MapPin className="h-3 w-3" />
                          {client.cidade}, {client.estado}
                          <Separator orientation="vertical" className="h-2" />
                          <Badge variant={client.status === 'ativo' ? 'outline' : 'secondary'} className="h-4 text-[9px] px-1 font-bold uppercase">
                             {client.status}
                          </Badge>
                       </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-right py-6">
                    <div className="flex flex-col items-end">
                       <span className="font-black text-sm">{formatCurrency(client.totalPremium)}</span>
                       <span className="text-[10px] font-bold text-primary uppercase tracking-tighter mt-0.5">
                          Comissão: {formatCurrency(client.totalCommission)}
                       </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-center py-6">
                    <div className="flex flex-wrap justify-center gap-1 max-w-[150px] mx-auto">
                       {client.products.length > 0 ? (
                         <>
                           <Badge className="bg-primary/10 text-primary border-none text-[9px] font-black h-5">
                             {client.products[0]}
                           </Badge>
                           {client.products.length > 1 && (
                             <Badge variant="outline" className="text-[9px] font-black h-5">
                               +{client.products.length - 1}
                             </Badge>
                           )}
                         </>
                       ) : (
                         <span className="text-[9px] text-muted-foreground font-bold italic">Sem apólices</span>
                       )}
                    </div>
                  </TableCell>
                  <TableCell className="text-center py-6">
                     <div className="inline-flex items-center gap-2 px-3 py-1 bg-muted/30 rounded-xl">
                        <Clock className="h-3 w-3 text-muted-foreground" />
                        <span className="text-xs font-black">{client.relationshipMonths}m</span>
                     </div>
                  </TableCell>
                  <TableCell className="text-center py-6">
                    <div className="flex flex-col items-center gap-1.5">
                       <div className="w-24 h-1.5 bg-muted rounded-full overflow-hidden">
                          <div 
                            className={`h-full ${client.expansionPotential > 50 ? 'bg-orange-500' : 'bg-emerald-500'}`} 
                            style={{ width: `${client.expansionPotential}%` }} 
                          />
                       </div>
                       <span className="text-[9px] font-black uppercase tracking-widest opacity-60">
                          {client.expansionPotential > 50 ? 'Oportunidade' : 'Consolidado'}
                       </span>
                    </div>
                  </TableCell>
                  <TableCell className="py-6">
                     <DropdownMenu>
                        <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                           <Button variant="ghost" size="icon" className="group-hover:bg-primary group-hover:text-white transition-all">
                              <MoreHorizontal className="h-4 w-4" />
                           </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                           <DropdownMenuItem className="gap-2 font-bold text-xs" onClick={() => navigate(`/clientes/${client.id}`)}>
                              <Briefcase className="h-3.5 w-3.5" /> Detalhes Perfil
                           </DropdownMenuItem>
                           <DropdownMenuItem className="gap-2 font-bold text-xs text-primary">
                              <Zap className="h-3.5 w-3.5" /> Gerar Proposta Cross
                           </DropdownMenuItem>
                        </DropdownMenuContent>
                     </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <div className="p-6 bg-muted/5 flex items-center justify-between">
         <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest italic">
           * LTV Projetado baseado em ciclo de 3 anos e retenção atual
         </p>
         <Button variant="link" className="text-xs font-bold text-primary gap-2 h-auto p-0">
           Ver Ranking Geral <ArrowUpRight className="h-3 w-3" />
         </Button>
      </div>
    </Card>
  );
}
