import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useApolices } from "@/hooks/useApolices";
import { useMemo } from "react";
import { PieChartIcon } from "lucide-react";

// Colors for product categories
const CATEGORY_COLORS: Record<string, string> = {
  rcp: "hsl(217, 91%, 60%)",
  "responsabilidade civil": "hsl(217, 91%, 60%)",
  vida: "hsl(262, 83%, 58%)",
  dit: "hsl(142, 71%, 45%)",
  renda: "hsl(142, 71%, 45%)",
  consorcio: "hsl(38, 92%, 50%)",
  consórcio: "hsl(38, 92%, 50%)",
  outros: "hsl(199, 89%, 48%)",
};

function getCategoryColor(category: string): string {
  const normalized = category.toLowerCase();
  for (const [key, color] of Object.entries(CATEGORY_COLORS)) {
    if (normalized.includes(key)) {
      return color;
    }
  }
  return CATEGORY_COLORS.outros;
}

function normalizeCategoryName(category: string): string {
  const normalized = category.toLowerCase();
  if (normalized.includes("rcp") || normalized.includes("responsabilidade")) return "RCP";
  if (normalized.includes("vida")) return "Seguro de Vida";
  if (normalized.includes("dit") || normalized.includes("renda")) return "DIT / Renda";
  if (normalized.includes("consorcio") || normalized.includes("consórcio")) return "Consórcios";
  return "Outros";
}

interface PortfolioItem {
  name: string;
  value: number;
  amount: number;
  clients: number;
  color: string;
}

export function PortfolioDistribution() {
  const { data: apolices = [], isLoading } = useApolices();

  const { portfolioData, totalValue, totalClients } = useMemo(() => {
    const activePolicies = apolices.filter((a) => a.status === "ativa");

    // Group by product category
    const categoryMap: Record<string, { amount: number; clientIds: Set<string> }> = {};

    activePolicies.forEach((apolice) => {
      const category = normalizeCategoryName(
        (apolice.produtos as { categoria?: string })?.categoria || "outros"
      );

      if (!categoryMap[category]) {
        categoryMap[category] = { amount: 0, clientIds: new Set() };
      }

      categoryMap[category].amount += Number(apolice.valor_premio) || 0;
      categoryMap[category].clientIds.add(apolice.client_id);
    });

    const totalAmount = Object.values(categoryMap).reduce((sum, cat) => sum + cat.amount, 0);
    const uniqueClientIds = new Set(activePolicies.map((a) => a.client_id));

    const data: PortfolioItem[] = Object.entries(categoryMap)
      .map(([name, { amount, clientIds }]) => ({
        name,
        value: totalAmount > 0 ? Math.round((amount / totalAmount) * 100) : 0,
        amount,
        clients: clientIds.size,
        color: getCategoryColor(name),
      }))
      .sort((a, b) => b.amount - a.amount);

    return {
      portfolioData: data,
      totalValue: totalAmount,
      totalClients: uniqueClientIds.size,
    };
  }, [apolices]);

  if (isLoading) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold">Distribuição da Carteira</CardTitle>
          <CardDescription>Por tipo de produto</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Skeleton className="h-8 w-24" />
            <Skeleton className="h-8 w-16" />
          </div>
          <Skeleton className="h-[200px] w-full" />
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-6 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (portfolioData.length === 0) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold">Distribuição da Carteira</CardTitle>
          <CardDescription>Por tipo de produto</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <PieChartIcon className="h-10 w-10 text-muted-foreground mb-3" />
            <p className="text-sm text-muted-foreground">Nenhuma apólice ativa</p>
            <p className="text-xs text-muted-foreground mt-1">
              Cadastre apólices para visualizar a distribuição
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50 bg-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold">Distribuição da Carteira</CardTitle>
        <CardDescription>Por tipo de produto</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">
              {totalValue >= 1000000
                ? `R$ ${(totalValue / 1000000).toFixed(1)}M`
                : `R$ ${(totalValue / 1000).toFixed(0)}k`}
            </p>
            <p className="text-xs text-muted-foreground">Volume Total</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-primary">{totalClients}</p>
            <p className="text-xs text-muted-foreground">Clientes Ativos</p>
          </div>
        </div>

        <div className="h-[200px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={portfolioData}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={3}
                dataKey="value"
              >
                {portfolioData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} strokeWidth={0} />
                ))}
              </Pie>
              <Tooltip
                formatter={(value: number, name: string, props: { payload: PortfolioItem }) => [
                  `${value}% (R$ ${props.payload.amount >= 1000 ? (props.payload.amount / 1000).toFixed(0) + "k" : props.payload.amount.toLocaleString("pt-BR")})`,
                  props.payload.name,
                ]}
                contentStyle={{
                  backgroundColor: "hsl(222, 47%, 10%)",
                  border: "1px solid hsl(222, 47%, 16%)",
                  borderRadius: "8px",
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="space-y-2 mt-4">
          {portfolioData.map((item) => (
            <div key={item.name} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div
                  className="w-3 h-3 rounded-full shrink-0"
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-sm text-muted-foreground truncate">{item.name}</span>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-sm font-medium">{item.clients} clientes</span>
                <span className="text-sm font-bold w-12 text-right">{item.value}%</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
