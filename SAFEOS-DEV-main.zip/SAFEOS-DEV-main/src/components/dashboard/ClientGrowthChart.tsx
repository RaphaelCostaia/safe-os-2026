import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, Area, AreaChart } from "recharts";
import { useClientGrowthData } from "@/hooks/useClientGrowthData";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, TrendingUp, TrendingDown } from "lucide-react";

export function ClientGrowthChart() {
  const { data, isLoading, isError } = useClientGrowthData(12);

  // Loading state
  if (isLoading) {
    return (
      <Card className="border-border/50 bg-card col-span-2">
        <CardHeader className="pb-2">
          <Skeleton className="h-6 w-64" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-[280px] w-full" />
        </CardContent>
      </Card>
    );
  }

  // Error or no data state
  if (isError || !data || data.months.length === 0) {
    return (
      <Card className="border-border/50 bg-card col-span-2">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            Evolução da Carteira de Clientes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[280px] flex items-center justify-center">
            <div className="text-center text-muted-foreground">
              <Users className="h-12 w-12 mx-auto mb-3 opacity-30" />
              <p className="font-medium">Sem histórico suficiente</p>
              <p className="text-sm">Cadastre clientes para visualizar o crescimento</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const { months, summary } = data;

  // Check if there's any activity
  const hasActivity = summary.totalNovos > 0;

  return (
    <Card className="border-border/50 bg-card col-span-2">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            Evolução da Carteira de Clientes
          </CardTitle>
          <div className="flex gap-6">
            <div className="text-center">
              <p className="text-xl font-bold text-success">+{summary.totalNovos}</p>
              <p className="text-xs text-muted-foreground">Novos (12m)</p>
            </div>
            <div className="text-center">
              <p className="text-xl font-bold text-primary">{summary.clientesAtivos}</p>
              <p className="text-xs text-muted-foreground">Ativos</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1">
                {summary.deltaUltimoMes >= 0 ? (
                  <TrendingUp className="h-4 w-4 text-success" />
                ) : (
                  <TrendingDown className="h-4 w-4 text-destructive" />
                )}
                <p className={`text-xl font-bold ${summary.deltaUltimoMes >= 0 ? 'text-success' : 'text-destructive'}`}>
                  {summary.deltaUltimoMes >= 0 ? '+' : ''}{summary.deltaUltimoMes}
                </p>
              </div>
              <p className="text-xs text-muted-foreground">vs mês anterior</p>
            </div>
            <div className="text-center border-l border-border pl-6">
              <p className="text-xl font-bold text-foreground">{summary.retentionRate}%</p>
              <p className="text-xs text-muted-foreground">Retenção</p>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[280px]">
          {!hasActivity ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center text-muted-foreground">
                <TrendingUp className="h-10 w-10 mx-auto mb-2 opacity-30" />
                <p className="text-sm">Nenhum cliente novo nos últimos 12 meses</p>
              </div>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={months}>
                <defs>
                  <linearGradient id="colorNovos" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(142, 71%, 45%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(142, 71%, 45%)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorAcumulado" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(217, 91%, 60%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(217, 91%, 60%)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
                <XAxis 
                  dataKey="month" 
                  stroke="hsl(var(--muted-foreground))" 
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis 
                  stroke="hsl(var(--muted-foreground))" 
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                  allowDecimals={false}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
                  }}
                  labelStyle={{ color: 'hsl(var(--foreground))' }}
                />
                <Legend />
                <Area 
                  type="monotone" 
                  dataKey="novos" 
                  name="Novos Clientes"
                  stroke="hsl(142, 71%, 45%)" 
                  strokeWidth={2}
                  fill="url(#colorNovos)"
                  dot={{ r: 4, fill: "hsl(142, 71%, 45%)" }}
                  activeDot={{ r: 6 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="acumulado" 
                  name="Total Acumulado"
                  stroke="hsl(217, 91%, 60%)" 
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={{ r: 3, fill: "hsl(217, 91%, 60%)" }}
                />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
