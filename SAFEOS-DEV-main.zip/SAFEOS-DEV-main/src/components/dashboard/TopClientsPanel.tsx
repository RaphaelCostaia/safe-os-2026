import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Crown, TrendingUp, Users } from "lucide-react";
import { useClients } from "@/hooks/useClients";
import { useApolices } from "@/hooks/useApolices";
import { useMemo } from "react";
import { format } from "date-fns";

interface TopClient {
  id: string;
  name: string;
  profession: string;
  totalPremium: number;
  products: number;
  since: string;
}

export function TopClientsPanel() {
  const { data: clients = [], isLoading: clientsLoading } = useClients();
  const { data: apolices = [], isLoading: apolicesLoading } = useApolices();

  const isLoading = clientsLoading || apolicesLoading;

  const topClients = useMemo((): TopClient[] => {
    const activeClients = clients.filter((c) => c.status === "ativo");
    const activePolicies = apolices.filter((a) => a.status === "ativa");

    // Calculate premium and policy count per client
    const clientStats: Record<
      string,
      { totalPremium: number; products: number }
    > = {};

    activePolicies.forEach((apolice) => {
      if (!clientStats[apolice.client_id]) {
        clientStats[apolice.client_id] = { totalPremium: 0, products: 0 };
      }
      clientStats[apolice.client_id].totalPremium += Number(apolice.valor_premio) || 0;
      clientStats[apolice.client_id].products += 1;
    });

    // Map to client data and sort by premium
    return activeClients
      .filter((client) => clientStats[client.id]?.totalPremium > 0)
      .map((client) => ({
        id: client.id,
        name: client.nome,
        profession: client.profissao || "Não informado",
        totalPremium: clientStats[client.id]?.totalPremium || 0,
        products: clientStats[client.id]?.products || 0,
        since: format(new Date(client.created_at), "yyyy"),
      }))
      .sort((a, b) => b.totalPremium - a.totalPremium)
      .slice(0, 5);
  }, [clients, apolices]);

  if (isLoading) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <Crown className="h-5 w-5 text-warning" />
            <CardTitle className="text-lg font-semibold">Top Clientes</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="flex items-center gap-3 p-3">
              <Skeleton className="h-10 w-10 rounded-full" />
              <div className="flex-1 space-y-1">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-3 w-24" />
              </div>
              <Skeleton className="h-8 w-20" />
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  if (topClients.length === 0) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <Crown className="h-5 w-5 text-warning" />
            <CardTitle className="text-lg font-semibold">Top Clientes</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <Users className="h-10 w-10 text-muted-foreground mb-3" />
            <p className="text-sm text-muted-foreground">Nenhum cliente com apólice ativa</p>
            <p className="text-xs text-muted-foreground mt-1">
              Clientes com apólices ativas aparecerão aqui
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50 bg-card">
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <Crown className="h-5 w-5 text-warning" />
          <CardTitle className="text-lg font-semibold">Top Clientes</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {topClients.map((client, index) => (
          <div
            key={client.id}
            className="flex items-center gap-3 p-3 rounded-lg hover:bg-secondary/50 transition-colors group"
          >
            <div className="relative">
              <Avatar className="h-10 w-10">
                <AvatarFallback
                  className={
                    index === 0
                      ? "bg-warning/20 text-warning"
                      : index === 1
                      ? "bg-muted text-muted-foreground"
                      : index === 2
                      ? "bg-orange-500/20 text-orange-400"
                      : "bg-secondary text-foreground"
                  }
                >
                  {client.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")
                    .slice(0, 2)
                    .toUpperCase()}
                </AvatarFallback>
              </Avatar>
              {index < 3 && (
                <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-background border border-border text-xs font-bold">
                  {index + 1}
                </span>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <p className="font-medium text-sm truncate">{client.name}</p>
              <p className="text-xs text-muted-foreground truncate">
                {client.profession} • Cliente desde {client.since}
              </p>
            </div>

            <div className="text-right shrink-0">
              <p className="font-bold text-sm text-foreground">
                R$ {client.totalPremium.toLocaleString("pt-BR", { maximumFractionDigits: 0 })}
              </p>
              <div className="flex items-center justify-end gap-1 text-xs text-muted-foreground">
                <TrendingUp className="h-3 w-3 text-success" />
                <span>{client.products} produto{client.products !== 1 ? "s" : ""}</span>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
