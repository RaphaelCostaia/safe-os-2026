import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface LTVGaugeProps {
  currentLTV: number;
  averageLTV: number;
  projectedLTV: number;
}

export function LTVGauge({ currentLTV, averageLTV, projectedLTV }: LTVGaugeProps) {
  const data = [
    { name: "LTV Atual", value: currentLTV, color: "hsl(217, 91%, 60%)" },
    { name: "Restante", value: projectedLTV - currentLTV, color: "hsl(222, 47%, 14%)" },
  ];

  const percentage = Math.round((currentLTV / projectedLTV) * 100);

  return (
    <Card className="border-border/50 bg-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold">LTV do Cliente</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-center">
          <div className="relative">
            <ResponsiveContainer width={200} height={200}>
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  innerRadius={70}
                  outerRadius={90}
                  startAngle={180}
                  endAngle={0}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} strokeWidth={0} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value: number) => `R$ ${value.toLocaleString('pt-BR')}`}
                  contentStyle={{ 
                    backgroundColor: 'hsl(222, 47%, 10%)', 
                    border: '1px solid hsl(222, 47%, 16%)',
                    borderRadius: '8px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-bold text-foreground">{percentage}%</span>
              <span className="text-xs text-muted-foreground">do potencial</span>
            </div>
          </div>
        </div>
        
        <div className="mt-4 space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">LTV Atual</span>
            <span className="font-semibold text-primary">R$ {currentLTV.toLocaleString('pt-BR')}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Média da Carteira</span>
            <span className="font-semibold">R$ {averageLTV.toLocaleString('pt-BR')}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">LTV Projetado</span>
            <span className="font-semibold text-success">R$ {projectedLTV.toLocaleString('pt-BR')}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
