import { TrendingUp, TrendingDown, DollarSign, Users, FileText, RefreshCw, AlertTriangle, CheckCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatCardProps {
  title: string;
  value: string;
  change?: string;
  changeType?: "positive" | "negative" | "neutral";
  trend?: "up" | "down" | "stable";
  comparison?: string;
  icon: React.ElementType;
  iconColor?: string;
  description?: string;
  className?: string;
}

export function StatCard({ 
  title, 
  value, 
  change, 
  changeType = "neutral", 
  trend,
  comparison,
  icon: Icon,
  iconColor = "text-primary",
  description,
  className
}: StatCardProps) {
  const isPositive = trend === "up" || changeType === "positive";
  const isNegative = trend === "down" || changeType === "negative";

  return (
    <div className={cn("stat-card group p-8 rounded-[2.5rem] border bg-card/50 backdrop-blur-sm shadow-sm transition-all hover:shadow-xl hover:scale-[1.02] duration-500", className)}>
      <div className="flex items-start justify-between">
        <div className="space-y-4">
          <div>
             <p className="text-[10px] font-black text-muted-foreground/60 uppercase tracking-[0.2em] mb-1">{title}</p>
             <p className="text-4xl font-black tracking-tight text-foreground">{value}</p>
          </div>
          {(change || comparison) && (
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center gap-1.5">
                <div className={cn(
                  "flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-black uppercase tracking-wider",
                  isPositive && "text-emerald-600 bg-emerald-50",
                  isNegative && "text-destructive bg-destructive/10",
                  !isPositive && !isNegative && "text-muted-foreground bg-muted"
                )}>
                  {isPositive && <TrendingUp className="h-3 w-3" />}
                  {isNegative && <TrendingDown className="h-3 w-3" />}
                  {change}
                </div>
              </div>
              {comparison && (
                <p className="text-[9px] text-muted-foreground/40 italic font-medium lowercase ml-0.5">
                  comparado ao {comparison}
                </p>
              )}
            </div>
          )}
          {description && (
            <p className="text-xs text-muted-foreground font-medium">{description}</p>
          )}
        </div>
        <div className={cn(
          "flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/5 text-primary shadow-inner transition-transform group-hover:rotate-12 duration-500",
          iconColor
        )}>
          <Icon className="h-7 w-7" strokeWidth={1.5} />
        </div>
      </div>
    </div>
  );
}

interface MiniStatProps {
  label: string;
  value: string;
  icon?: React.ElementType;
  variant?: "default" | "success" | "warning" | "danger";
}

export function MiniStat({ label, value, icon: Icon, variant = "default" }: MiniStatProps) {
  const variantStyles = {
    default: "bg-secondary text-foreground",
    success: "bg-success/10 text-success",
    warning: "bg-warning/10 text-warning",
    danger: "bg-destructive/10 text-destructive"
  };

  return (
    <div className="flex items-center justify-between py-3 border-b border-border/50 last:border-0">
      <div className="flex items-center gap-3">
        {Icon && (
          <div className={cn("p-2 rounded-lg", variantStyles[variant])}>
            <Icon className="h-4 w-4" />
          </div>
        )}
        <span className="text-sm text-muted-foreground">{label}</span>
      </div>
      <span className={cn(
        "font-semibold",
        variant === "success" && "text-success",
        variant === "warning" && "text-warning",
        variant === "danger" && "text-destructive"
      )}>{value}</span>
    </div>
  );
}
