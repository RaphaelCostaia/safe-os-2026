import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertTriangle, Calendar, ArrowRight, Clock, RefreshCw } from "lucide-react";
import { useApolices } from "@/hooks/useApolices";
import { useMemo } from "react";
import { differenceInDays, parseISO, addDays, startOfToday } from "date-fns";
import { useNavigate } from "react-router-dom";

interface PipelineRenewal {
  id: string;
  clientName: string;
  product: string;
  policyNumber: string;
  expiryDate: string;
  premium: number;
  daysRemaining: number;
  status: "critical" | "warning" | "upcoming";
  // Probabilidade heurística simples (baseada em dias restantes - quanto mais tempo, maior chance de renovar)
  probability: number;
}

// Calcula probabilidade heurística baseada em dias restantes
// Mais dias = mais tempo para renovar = maior probabilidade
function calculateProbability(daysRemaining: number): number {
  if (daysRemaining <= 0) return 30; // Já venceu - baixa probabilidade
  if (daysRemaining <= 3) return 50;
  if (daysRemaining <= 7) return 70;
  if (daysRemaining <= 14) return 85;
  return 92; // 15-30 dias
}

// Determina status baseado em dias restantes
function determineStatus(daysRemaining: number): "critical" | "warning" | "upcoming" {
  if (daysRemaining <= 7) return "critical";
  if (daysRemaining <= 14) return "warning";
  return "upcoming";
}

export function RenewalsPipeline() {
  const navigate = useNavigate();
  const { data: apolices, isLoading, error } = useApolices();

  // Filtra apólices ativas com vencimento nos próximos 30 dias
  const { renewals, criticalCount, warningCount, totalPremium } = useMemo(() => {
    if (!apolices || apolices.length === 0) {
      return {
        renewals: [],
        criticalCount: 0,
        warningCount: 0,
        totalPremium: 0,
      };
    }

    const today = startOfToday();
    const thirtyDaysFromNow = addDays(today, 30);

    const upcomingRenewals: PipelineRenewal[] = apolices
      .filter((apolice) => {
        if (apolice.status !== "ativa") return false;
        
        const expiryDate = parseISO(apolice.data_fim);
        const daysRemaining = differenceInDays(expiryDate, today);
        
        // Inclui apólices que vencem nos próximos 30 dias (ou já vencidas há até 7 dias)
        return daysRemaining >= -7 && daysRemaining <= 30;
      })
      .map((apolice) => {
        const expiryDate = parseISO(apolice.data_fim);
        const daysRemaining = differenceInDays(expiryDate, today);
        
        return {
          id: apolice.id,
          clientName: apolice.clients?.nome || "Cliente não identificado",
          product: apolice.produtos?.nome || "Produto não identificado",
          policyNumber: apolice.numero_apolice,
          expiryDate: apolice.data_fim,
          premium: Number(apolice.valor_premio),
          daysRemaining,
          status: determineStatus(daysRemaining),
          probability: calculateProbability(daysRemaining),
        };
      })
      .sort((a, b) => a.daysRemaining - b.daysRemaining); // Mais urgentes primeiro

    const critical = upcomingRenewals.filter(r => r.status === "critical").length;
    const warning = upcomingRenewals.filter(r => r.status === "warning").length;
    const total = upcomingRenewals.reduce((sum, r) => sum + r.premium, 0);

    return {
      renewals: upcomingRenewals.slice(0, 8), // Limita a 8 para o painel
      criticalCount: critical,
      warningCount: warning,
      totalPremium: total,
    };
  }, [apolices]);

  const getStatusStyles = (status: PipelineRenewal["status"]) => {
    switch (status) {
      case "critical":
        return { bg: "bg-destructive/10", text: "text-destructive", border: "border-destructive/30" };
      case "warning":
        return { bg: "bg-warning/10", text: "text-warning", border: "border-warning/30" };
      case "upcoming":
        return { bg: "bg-info/10", text: "text-info", border: "border-info/30" };
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg font-semibold">Pipeline de Renovações</CardTitle>
              <CardDescription>Próximos 30 dias</CardDescription>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3 pt-3">
            <Skeleton className="h-16 rounded-lg" />
            <Skeleton className="h-16 rounded-lg" />
            <Skeleton className="h-16 rounded-lg" />
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  // Empty state
  if (renewals.length === 0) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg font-semibold">Pipeline de Renovações</CardTitle>
              <CardDescription>Próximos 30 dias</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate("/renovacoes")}>
              Ver Histórico <ArrowRight className="h-3 w-3 ml-1" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center py-8 text-center">
          <RefreshCw className="h-12 w-12 text-muted-foreground/50 mb-3" />
          <p className="text-sm text-muted-foreground">Nenhuma renovação nos próximos 30 dias</p>
          <p className="text-xs text-muted-foreground/70">As apólices com vencimento próximo aparecerão aqui</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50 bg-card">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg font-semibold">Pipeline de Renovações</CardTitle>
            <CardDescription>Próximos 30 dias</CardDescription>
          </div>
          <Button variant="outline" size="sm" className="text-xs" onClick={() => navigate("/renovacoes")}>
            Ver Todas <ArrowRight className="h-3 w-3 ml-1" />
          </Button>
        </div>

        <div className="grid grid-cols-3 gap-3 pt-3">
          <div className="text-center p-3 rounded-lg bg-destructive/10 border border-destructive/20">
            <div className="flex items-center justify-center gap-1 mb-1">
              <AlertTriangle className="h-4 w-4 text-destructive" />
              <span className="text-xl font-bold text-destructive">{criticalCount}</span>
            </div>
            <p className="text-xs text-muted-foreground">Crítico (≤7 dias)</p>
          </div>
          <div className="text-center p-3 rounded-lg bg-warning/10 border border-warning/20">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Clock className="h-4 w-4 text-warning" />
              <span className="text-xl font-bold text-warning">{warningCount}</span>
            </div>
            <p className="text-xs text-muted-foreground">Atenção (8-14 dias)</p>
          </div>
          <div className="text-center p-3 rounded-lg bg-primary/10 border border-primary/20">
            <span className="text-xl font-bold text-primary">R$ {(totalPremium / 1000).toFixed(1)}k</span>
            <p className="text-xs text-muted-foreground">Valor Total</p>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-3">
        <div className="divide-y divide-border/50 max-h-[320px] overflow-y-auto">
          {renewals.map((renewal) => {
            const styles = getStatusStyles(renewal.status);
            return (
              <div key={renewal.id} className="py-3 group">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-medium text-sm">{renewal.clientName}</p>
                    <p className="text-xs text-muted-foreground">{renewal.product}</p>
                  </div>
                  <Badge className={`${styles.bg} ${styles.text} border ${styles.border}`}>
                    {renewal.daysRemaining < 0 
                      ? `Vencido há ${Math.abs(renewal.daysRemaining)} dias`
                      : renewal.daysRemaining === 0 
                        ? "Vence hoje"
                        : `${renewal.daysRemaining} dias`
                    }
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {new Date(renewal.expiryDate).toLocaleDateString('pt-BR')}
                  </span>
                  <span className="font-semibold text-foreground">R$ {renewal.premium.toLocaleString('pt-BR')}</span>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Probabilidade de renovação</span>
                    <span className={`font-medium ${renewal.probability >= 80 ? 'text-success' : renewal.probability >= 60 ? 'text-warning' : 'text-destructive'}`}>
                      {renewal.probability}%
                    </span>
                  </div>
                  <Progress value={renewal.probability} className="h-1.5" />
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
