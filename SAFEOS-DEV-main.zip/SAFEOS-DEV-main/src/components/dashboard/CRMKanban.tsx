import React, { useState, useMemo } from "react";
import { 
  DragDropContext, 
  Droppable, 
  Draggable, 
  DropResult 
} from "@hello-pangea/dnd";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { 
  Plus, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Phone, 
  MapPin, 
  User, 
  MessageSquare,
  AlertCircle,
  AlertTriangle,
  Flame,
  Clock,
  Briefcase,
  ChevronRight,
  TrendingUp,
  DollarSign,
  Download,
  ShieldCheck
} from "lucide-react";
import { useBulkClientStatusSync } from "@/hooks/useClientStatusSync";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ClientFormModal } from "@/components/clients/ClientFormModal";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Sparkles } from "lucide-react";
import { OpportunityFormModal } from "@/components/clients/OpportunityFormModal";
import { Client360Sheet } from "@/components/clients/Client360Sheet";
import { useCreateClient, useUpdateClient, getCrmStageFromClient, mapUiStatusToDbStatus, updateObservationsCrmStage, safeParseMetadata, type ClientInsert, type ClientUpdate } from "@/hooks/useClients";
import { useAuth } from "@/hooks/useAuth";
import { useCreateClientCommission } from "@/hooks/useClientCommission";
import { invalidateEntityQueries } from "@/lib/queryInvalidation";
import { differenceInDays, parseISO } from "date-fns";
import { toast } from "sonner";
import { motion, AnimatePresence } from "motion/react";
import { RefreshCw } from "lucide-react";

// Estágios Padrão solicitados
const DEFAULT_STAGES = [
  { id: "contato", title: "Entrou em contato", color: "bg-blue-500", icon: Phone },
  { id: "lead_quente", title: "Lead Quente", color: "bg-orange-500", icon: Flame },
  { id: "qualificado", title: "Médico / Saúde", color: "bg-emerald-500", icon: ShieldCheck },
  { id: "cotacao", title: "Fez Cotação", color: "bg-purple-500", icon: DollarSign },
  { id: "negociacao", title: "Em Negociação", color: "bg-yellow-500", icon: MessageSquare },
  { id: "convertido", title: "Convertido", color: "bg-green-600", icon: TrendingUp },
  { id: "pos_venda", title: "Pós-Venda", color: "bg-slate-500", icon: RefreshCw },
  { id: "perdido", title: "Perdido", color: "bg-destructive", icon: AlertCircle }
];

export interface LeadOpportunity {
  id: string;
  nome: string;
  email: string;
  telefone: string;
  cpf_cnpj: string;
  tipo_pessoa: string;
  data_nascimento: string;
  endereco: string;
  cidade: string;
  estado: string;
  cep: string;
  status: string; // CRM Stage ID
  created_at: string;
  updated_at: string;
  profissao: string;
  observacoes: string;
  responsavel_id: string;
  responsavel_nome?: string;
  valor_potencial?: number;
  is_hot?: boolean;
  has_quote?: boolean;
  daysStagnant?: number;
  dbStatus?: string;
  rawApolices?: any[];
}

export function CRMKanban() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [showFormModal, setShowFormModal] = useState(false);
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const [showOpportunityOfferForClient, setShowOpportunityOfferForClient] = useState<{ id: string; nome: string } | null>(null);
  const [showOpportunityModal, setShowOpportunityModal] = useState(false);
  const [show360Sheet, setShow360Sheet] = useState(false);
  const [leadFor360, setLeadFor360] = useState<LeadOpportunity | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  // Hooks
  const createClient = useCreateClient();
  const updateClient = useUpdateClient();
  const createCommission = useCreateClientCommission();
  const runBulkSync = useBulkClientStatusSync();
  
  // Fetch Leads/Clients
  const { data: leads, isLoading, error: queryError } = useQuery<LeadOpportunity[]>({
    queryKey: ["crm_leads"],
    queryFn: async () => {
      console.log("Fetching CRM leads...");
      const { data: clients, error } = await supabase
        .from("clients")
        .select(`
          id, nome, email, telefone, cpf_cnpj, tipo_pessoa, data_nascimento, endereco, cidade, estado, cep, status, created_at, updated_at, profissao, observacoes, responsavel_id,
          responsavel:profiles!responsavel_id (full_name),
          apolices (valor_premio, status, data_fim)
        `)
        .is("deleted_at", null)
        .order('updated_at', { ascending: false });

      if (error) {
        console.error("CRM Query Error Details:", error);
        throw error;
      }
      
      if (!clients) {
        console.warn("CRM Query: No clients found");
        return [];
      }

      console.log(`CRM Query: Processing ${clients.length} clients`);

      return (clients as any[]).map((c) => {
        const potential = (c.apolices as { valor_premio: number; status: string }[] | undefined)?.find(a => a.status === 'pendente')?.valor_premio || 0;
        const daysStagnant = differenceInDays(new Date(), parseISO(c.updated_at));
        
        // Use centralized helper for stage calculation
        let crmStage = getCrmStageFromClient(c.status, c.observacoes);
        
        // Ensure the stage is valid for the UI columns, otherwise fallback to 'contato'
        if (!DEFAULT_STAGES.some(s => s.id === crmStage)) {
          crmStage = 'contato';
        }

        // Extract responsavel_comercial from metadata inside observacoes if exists
        const meta = safeParseMetadata(c.observacoes);
        const responsavelComercial = meta?.responsavel_comercial || "";

        return {
          ...c,
          id: c.id,
          nome: c.nome,
          telefone: c.telefone || "N/I",
          cidade: c.cidade || "N/I",
          status: crmStage,
          profissao: c.profissao || "",
          observacoes: (c.observacoes || "").replace(/\[ESTAGIO:[^\]]+\]/, '').trim(),
          responsavel_nome: responsavelComercial || c.responsavel?.full_name || "Sem corretor",
          created_at: c.created_at,
          updated_at: c.updated_at,
          valor_potencial: potential,
          is_hot: c.profissao?.toLowerCase().includes("médico") || c.observacoes?.toLowerCase().includes("urgente") || daysStagnant < 2,
          has_quote: (c.apolices as { status: string }[] | undefined)?.some(a => a.status === 'pendente'),
          daysStagnant,
          dbStatus: c.status,
          rawApolices: c.apolices
        } as LeadOpportunity;
      });
    }
  });

  const selectedLead = useMemo(() => {
    if (!selectedLeadId || !leads) return null;
    return leads.find(l => l.id === selectedLeadId) || null;
  }, [selectedLeadId, leads]);

  // Mutation to update stage
  const updateStageMutation = useMutation({
    mutationFn: async ({ id, status: newStage }: { id: string, status: string }) => {
      // Use the standard update hook logic indirectly by using the same mapping
      const dbStatus = mapUiStatusToDbStatus(newStage);
      
      // Fetch current observations to properly sync tags
      const { data: current, error: fetchError } = await supabase
        .from("clients")
        .select("observacoes")
        .eq("id", id)
        .single();
      
      if (fetchError) throw fetchError;

      const newObs = updateObservationsCrmStage(current?.observacoes || "", newStage);

      const { error } = await supabase
        .from("clients")
        .update({ 
          status: dbStatus,
          observacoes: newObs,
          updated_at: new Date().toISOString()
        })
        .eq("id", id);

      if (error) throw error;
      return { id, status: newStage };
    },
    onSuccess: () => {
      // Use centralized invalidation
      invalidateEntityQueries(queryClient, "clients");
      toast.success("Estágio atualizado com sucesso");
    },
    onError: (error: any) => {
      console.error("Move error:", error);
      toast.error("Erro ao mover lead: " + (error.message || "Erro desconhecido"));
    }
  });

  const onDragEnd = (result: DropResult) => {
    const { destination, source, draggableId } = result;

    if (!destination) return;
    if (destination.droppableId === source.droppableId && destination.index === source.index) return;

    updateStageMutation.mutate({ 
      id: draggableId, 
      status: destination.droppableId 
    });
  };

  const filteredLeads = useMemo(() => {
    if (!leads) return [];
    const search = searchTerm.toLowerCase().trim();
    if (!search) return leads;
    
    return leads.filter(l => 
      (l.nome || "").toLowerCase().includes(search) ||
      (l.cidade || "").toLowerCase().includes(search) ||
      (l.telefone || "").toLowerCase().includes(search)
    );
  }, [leads, searchTerm]);

  const columns = useMemo(() => {
    return DEFAULT_STAGES.map(stage => {
      const stageLeads = filteredLeads.filter(l => l.status === stage.id);
      return {
        ...stage,
        leads: stageLeads,
        totalValue: stageLeads.reduce((sum, l) => sum + (l.valor_potencial || 0), 0)
      };
    });
  }, [filteredLeads]);

  const handleFormSubmit = (data: ClientInsert | ClientUpdate, commissionPercent?: number) => {
    // Note: Mapping to DB status and CRM tag is now handled in the useClients hook
    if (selectedLeadId) {
      // Update existing lead
      updateClient.mutate({ id: selectedLeadId, ...data }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["crm_leads"] });
          setShowFormModal(false);
          setSelectedLeadId(null);
        }
      });
    } else {
      // Create new lead
      const clientData = {
        ...(data as ClientInsert),
        responsavel_id: data.responsavel_id || user?.id
      } as ClientInsert;

      createClient.mutate(clientData, {
        onSuccess: (newClient) => {
          // Create commission term for the new client (only if greater than 0)
          if (commissionPercent !== undefined && commissionPercent !== null && !isNaN(commissionPercent) && commissionPercent > 0) {
            createCommission.mutate({
              client_id: newClient.id,
              model: "percentual",
              percent: commissionPercent,
              starts_at: new Date().toISOString().split('T')[0],
              is_active: true,
              created_by: user?.id || null,
            }, {
              onSuccess: () => {
                queryClient.invalidateQueries({ queryKey: ["client_map_data"] });
                queryClient.invalidateQueries({ queryKey: ["clients"] });
                queryClient.invalidateQueries({ queryKey: ["crm_leads"] });
                setShowFormModal(false);
                setShowOpportunityOfferForClient({ id: newClient.id, nome: newClient.nome });
              },
              onError: (err) => {
                console.error("Erro ao criar comissão para o lead:", err);
                // Still close modal and refresh kanban, lead was created
                queryClient.invalidateQueries({ queryKey: ["crm_leads"] });
                setShowFormModal(false);
                setShowOpportunityOfferForClient({ id: newClient.id, nome: newClient.nome });
              }
            });
          } else {
            queryClient.invalidateQueries({ queryKey: ["client_map_data"] });
            queryClient.invalidateQueries({ queryKey: ["clients"] });
            queryClient.invalidateQueries({ queryKey: ["crm_leads"] });
            setShowFormModal(false);
            setShowOpportunityOfferForClient({ id: newClient.id, nome: newClient.nome });
          }
        }
      });
    }
  };

  const handleCardClick = (leadId: string) => {
    setSelectedLeadId(leadId);
    setShowFormModal(true);
  };

  const handleAddNew = () => {
    setSelectedLeadId(null);
    setShowFormModal(true);
  };

  const handleOpen360 = (e: React.MouseEvent, lead: LeadOpportunity) => {
    e.stopPropagation();
    setLeadFor360(lead);
    setShow360Sheet(true);
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await queryClient.invalidateQueries({ queryKey: ["crm_leads"] });
    setTimeout(() => setIsRefreshing(false), 500);
    toast.success("Pipeline sincronizado");
  };

  const handlePhoneClick = (e: React.MouseEvent, phone: string) => {
    e.stopPropagation();
    if (!phone || phone === "N/A") return;
    window.open(`tel:${phone.replace(/\D/g, "")}`, "_self");
  };

  const handleWhatsAppClick = (e: React.MouseEvent, phone: string, name: string) => {
    e.stopPropagation();
    if (!phone || phone === "N/A") return;
    const cleanPhone = phone.replace(/\D/g, "");
    const message = encodeURIComponent(`Olá ${name}, tudo bem? Sou da SafeOS Corretora.`);
    window.open(`https://wa.me/55${cleanPhone}?text=${message}`, "_blank");
  };

  const formatCurrency = (v: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }).format(v);
  };

  const handleExport = () => {
    toast.info("Exportação do Pipeline em processamento...");
  };

  return (
    <div className="h-full flex flex-col gap-4">
      {/* HEADER - Streamlined */}
      <header className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white/20 dark:bg-black/10 p-6 rounded-[2rem] border border-white/10 backdrop-blur-md shadow-xl">
        <div className="flex items-center gap-4">
           <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
              <TrendingUp className="h-6 w-6" />
           </div>
           <div>
              <h1 className="text-2xl font-black tracking-tight">
                 Pipeline <span className="font-serif italic font-light text-primary/70 lowercase tracking-tight">CRM</span>
              </h1>
              <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest opacity-60">
                 Gestão de Oportunidades
              </p>
           </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
           <Button 
             variant="outline" 
             size="icon" 
             className={`h-12 w-12 rounded-2xl bg-white/50 dark:bg-black/20 border-border/40 transition-all hover:scale-110 active:scale-90 ${isRefreshing ? "animate-spin" : ""}`}
             onClick={handleRefresh}
           >
              <RefreshCw className="h-5 w-5 text-primary" />
           </Button>

           <div className="relative group">
             <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
             <Input 
               placeholder="Pesquisar oportunidades..." 
               className="h-12 w-64 pl-11 rounded-2xl bg-white/50 dark:bg-black/20 border-border/40 text-xs font-black uppercase tracking-wider focus-visible:ring-primary/20"
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
             />
           </div>

           <Button 
              className="h-12 px-8 rounded-2xl bg-primary shadow-xl shadow-primary/30 font-black uppercase text-xs tracking-[0.15em] gap-3 hover:shadow-primary/40 hover:scale-105 active:scale-95 transition-all"
              onClick={handleAddNew}
           >
              <Plus className="h-5 w-5" strokeWidth={3} /> Nova Oportunidade
           </Button>
        </div>
      </header>

      {/* PIPELINE SUMMARY BAR */}
      <div className="flex flex-wrap gap-3 px-1">
         {[
           { label: "Total Funil", value: filteredLeads.length, icon: User, color: "bg-blue-500" },
           { label: "Pipeline", value: formatCurrency(filteredLeads.reduce((sum, l) => sum + (l.valor_potencial || 0), 0)), icon: DollarSign, color: "bg-emerald-500" },
           { label: "Hot Leads", value: filteredLeads.filter(l => l.is_hot).length, icon: Flame, color: "bg-orange-500" },
           { label: "Estagnados", value: filteredLeads.filter(l => (l.daysStagnant || 0) > 7).length, icon: Clock, color: "bg-rose-500" }
         ].map((stat, i) => (
           <div key={i} className="flex-1 min-w-[150px] bg-white/30 dark:bg-black/20 p-3 rounded-2xl border border-white/10 flex items-center gap-3">
              <div className={`w-8 h-8 rounded-lg ${stat.color} flex items-center justify-center text-white`}>
                 <stat.icon className="h-4 w-4" />
              </div>
              <div>
                 <p className="text-[8px] font-bold text-muted-foreground uppercase tracking-wider">{stat.label}</p>
                 <p className="text-sm font-black tracking-tight">{stat.value}</p>
              </div>
           </div>
         ))}
      </div>

      {(() => {
        if (!leads) return null;
        const today = new Date();
        const divergentLeads = leads.filter((l: any) => {
          const clientPolicies = l.rawApolices || [];
          const hasActivePolicy = clientPolicies.some((p: any) => {
            if (p.status !== "ativa" && p.status !== "vencendo") return false;
            if (!p.data_fim) return true;
            try {
              return differenceInDays(new Date(p.data_fim), today) >= 0;
            } catch {
              return true;
            }
          });
          return hasActivePolicy && l.dbStatus === "prospecto";
        });

        if (divergentLeads.length === 0) return null;

        return (
          <div className="mx-1 p-4 bg-amber-500/10 border border-amber-500/20 text-amber-900 rounded-[2rem] flex flex-col sm:flex-row sm:items-center justify-between gap-4 animate-in slide-in-from-top-4 duration-300">
            <div className="flex items-start sm:items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/15 flex items-center justify-center text-amber-600 shrink-0">
                <AlertTriangle className="h-5 w-5" />
              </div>
              <div className="space-y-0.5">
                <h4 className="text-sm font-black uppercase tracking-tight text-amber-950">
                  Divergência de Status Cadastral
                </h4>
                <p className="text-xs text-amber-800">
                  Identificamos <strong>{divergentLeads.length} cliente(s)</strong> com apólices vigentes, mas que continuam classificados como <strong>Prospecto</strong>.
                </p>
              </div>
            </div>
            <Button 
              onClick={() => runBulkSync.mutate()} 
              disabled={runBulkSync.isPending}
              className="rounded-2xl h-11 px-6 bg-amber-600 hover:bg-amber-700 text-white font-bold uppercase text-[10px] tracking-wider leading-none shadow-md"
            >
              {runBulkSync.isPending ? "Sincronizando..." : "Executar Rotina de Correção"}
            </Button>
          </div>
        );
      })()}

      <div className="flex-1 overflow-x-auto pb-6 custom-scrollbar scroll-smooth">
        {isLoading ? (
          <div className="flex gap-6 p-2">
            {[1, 2, 3, 4, 5].map(i => (
              <div key={i} className="w-[340px] space-y-4 shrink-0">
                <Skeleton className="h-14 w-full rounded-2xl" />
                <Skeleton className="h-44 w-full rounded-2xl" />
                <Skeleton className="h-44 w-full rounded-2xl" />
              </div>
            ))}
          </div>
        ) : queryError ? (
          <div className="flex flex-col items-center justify-center p-12 bg-destructive/5 rounded-[2rem] border border-destructive/10 text-destructive gap-4 mx-4">
             <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center">
                <AlertCircle className="h-8 w-8" />
             </div>
             <div className="text-center">
                <p className="font-black uppercase tracking-widest text-sm mb-1">Falha na Sincronização</p>
                <p className="text-xs opacity-60 max-w-md mx-auto line-clamp-2">
                  {(queryError as any).message || "Não foi possível conectar ao banco de dados para carregar as oportunidades."}
                </p>
             </div>
             <Button 
               variant="outline" 
               onClick={handleRefresh} 
               className="h-12 px-8 rounded-xl border-destructive/20 hover:bg-destructive/10 hover:text-destructive transition-all gap-2"
             >
                <RefreshCw className="h-4 w-4" /> Tentar Reconciliação
             </Button>
          </div>
        ) : (
          <DragDropContext onDragEnd={onDragEnd}>
            <div className="flex gap-6 h-full min-h-[650px] items-start p-2">
              {columns.map((column) => (
                <div 
                  key={column.id} 
                  className="w-[340px] h-full flex flex-col shrink-0 group/column"
                >
                  {/* Column Header */}
                  <div className="flex items-center justify-between px-5 py-4 mb-4 bg-white/80 dark:bg-black/40 rounded-[1.5rem] border border-white/20 backdrop-blur-xl shadow-lg shadow-black/5 sticky top-0 z-10 transition-all group-hover/column:border-primary/20">
                     <div className="flex items-center gap-3">
                       <div className={`w-10 h-10 rounded-xl ${column.color}/10 flex items-center justify-center text-primary group-hover/column:scale-110 transition-transform`}>
                          <column.icon className={`h-5 w-5 ${column.color === 'bg-destructive' ? 'text-destructive' : 'text-primary'}`} />
                       </div>
                       <div>
                         <h3 className="text-[11px] font-black uppercase tracking-[0.15em] text-foreground leading-none mb-1">{column.title}</h3>
                         <div className="flex items-center gap-1.5 opacity-50">
                            <span className="text-[9px] font-bold uppercase">{column.leads.length} Oportunidade{column.leads.length !== 1 ? 's' : ''}</span>
                         </div>
                       </div>
                     </div>
                     {column.totalValue > 0 && (
                       <Badge variant="outline" className="text-[10px] font-black text-emerald-600 bg-emerald-500/5 border-emerald-500/20 px-2 py-1 rounded-lg">
                          {formatCurrency(column.totalValue)}
                       </Badge>
                     )}
                  </div>

                  {/* Droppable Area */}
                  <Droppable droppableId={column.id}>
                    {(provided, snapshot) => (
                      <div
                        {...provided.droppableProps}
                        ref={provided.innerRef}
                        className={`flex-1 rounded-[2rem] p-3 transition-all duration-300 space-y-4 min-h-[550px] ${
                          snapshot.isDraggingOver ? "bg-primary/5 ring-2 ring-primary/10" : "bg-muted/10 border border-dashed border-border/50"
                        }`}
                      >
                        {column.leads.length === 0 && !snapshot.isDraggingOver && (
                          <div className="h-32 flex flex-col items-center justify-center border-2 border-dashed border-border/30 rounded-[2rem] opacity-20 select-none">
                             <User className="h-8 w-8 mb-2" />
                             <p className="text-[10px] font-black uppercase tracking-[0.2em]">Sem Oportunidades</p>
                          </div>
                        )}
                        {column.leads.map((lead, index) => (
                          <Draggable key={lead.id} draggableId={lead.id} index={index}>
                            {(provided, snapshot) => (
                              <div
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                {...provided.dragHandleProps}
                                style={provided.draggableProps.style}
                                className="group/card"
                              >
                              <Card 
                                onClick={() => handleCardClick(lead.id)}
                                className={`rounded-[2rem] border-border/40 shadow-sm hover:shadow-2xl hover:shadow-primary/10 transition-all duration-300 relative overflow-hidden cursor-pointer active:scale-[0.98] ${
                                  snapshot.isDragging ? "shadow-2xl ring-4 ring-primary rotate-1 scale-105 z-50 bg-background/95 backdrop-blur-md" : "bg-white dark:bg-black/40"
                                }`}
                              >
                                {lead.is_hot && (
                                   <div className="absolute top-0 right-0 p-3 bg-orange-500 text-white rounded-bl-[1.5rem] shadow-lg z-10">
                                      <Flame className="h-4 w-4 animate-pulse" />
                                   </div>
                                )}
                                
                                <CardContent className="p-6 flex flex-col gap-4">
                                  <div className="flex justify-between items-start">
                                     <div>
                                        <h4 className="text-sm font-black tracking-tight leading-tight group-hover/card:text-primary transition-colors line-clamp-1 mb-1">
                                           {lead.nome}
                                        </h4>
                                        <div className="flex items-center gap-2 text-[10px] font-bold text-muted-foreground/60 uppercase tracking-widest">
                                           <Briefcase className="h-3 w-3" />
                                           {lead.profissao || "Individual"}
                                        </div>
                                     </div>
                                  </div>

                                  <div className="grid grid-cols-2 gap-3 py-1">
                                     <div className="flex flex-col gap-1">
                                        <span className="text-[9px] font-black text-muted-foreground/40 uppercase tracking-widest">Localidade</span>
                                        <div className="flex items-center gap-2 text-[11px] font-bold">
                                           <MapPin className="h-3.5 w-3.5 text-primary opacity-60" />
                                           <span className="truncate">{lead.cidade}</span>
                                        </div>
                                     </div>
                                     <div className="flex flex-col gap-1">
                                        <span className="text-[9px] font-black text-muted-foreground/40 uppercase tracking-widest">Responsável</span>
                                        <div className="flex items-center gap-2 text-[11px] font-bold">
                                           <User className="h-3.5 w-3.5 text-primary opacity-60" />
                                           <span className="truncate">{lead.responsavel_nome?.split(' ')[0]}</span>
                                        </div>
                                     </div>
                                  </div>

                                  <div className="flex flex-wrap gap-2 pt-1">
                                     {lead.has_quote && (
                                       <Badge className="text-[9px] h-5 bg-indigo-500 text-white font-black px-2 uppercase border-none rounded-lg shadow-lg shadow-indigo-500/20">
                                          Tem Cotação
                                       </Badge>
                                     )}
                                     {lead.daysStagnant && lead.daysStagnant > 5 && (
                                        <Badge variant="outline" className="text-[9px] h-5 font-black px-2 uppercase border-rose-500/30 text-rose-500 bg-rose-500/5 rounded-lg">
                                           {lead.daysStagnant} Dias Parado
                                        </Badge>
                                     )}
                                  </div>

                                  <div className="pt-2 mt-auto border-t border-border/40 flex items-center justify-between">
                                    <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
                                      <Button
                                        size="icon"
                                        variant="ghost"
                                        className="h-10 w-10 rounded-xl bg-blue-500/5 text-blue-500 hover:bg-blue-500 hover:text-white transition-all shadow-sm"
                                        onClick={(e) => handlePhoneClick(e, lead.telefone)}
                                      >
                                        <Phone className="h-4 w-4" />
                                      </Button>
                                      <Button
                                        size="icon"
                                        variant="ghost"
                                        className="h-10 w-10 rounded-xl bg-green-500/5 text-green-500 hover:bg-green-500 hover:text-white transition-all shadow-sm"
                                        onClick={(e) => handleWhatsAppClick(e, lead.telefone, lead.nome)}
                                      >
                                        <MessageSquare className="h-4 w-4" />
                                      </Button>
                                    </div>
                                    
                                    {lead.valor_potencial && lead.valor_potencial > 0 ? (
                                      <div className="text-right">
                                         <p className="text-[8px] font-black text-muted-foreground uppercase opacity-40">Potencial</p>
                                         <p className="text-sm font-black text-emerald-600 tabular-nums">
                                            {formatCurrency(lead.valor_potencial)}
                                         </p>
                                      </div>
                                    ) : (
                                       <div 
                                         className="h-10 w-10 rounded-xl bg-primary/5 text-primary flex items-center justify-center hover:bg-primary hover:text-white transition-all cursor-pointer shadow-sm"
                                         onClick={(e) => handleOpen360(e, lead)}
                                       >
                                          <ChevronRight className="h-5 w-5" />
                                       </div>
                                    )}
                                  </div>
                                </CardContent>
                              </Card>
                              </div>
                            )}
                          </Draggable>
                        ))}
                        {provided.placeholder}
                      </div>
                    )}
                  </Droppable>
                </div>
              ))}
            </div>
          </DragDropContext>
        )}
      </div>

      <ClientFormModal
        open={showFormModal}
        onOpenChange={(isOpen) => {
          setShowFormModal(isOpen);
          if (!isOpen) setSelectedLeadId(null);
        }}
        editData={selectedLead}
        onSubmit={handleFormSubmit}
        isLoading={createClient.isPending || updateClient.isPending}
      />

      {/* Offer opportunity Dialog */}
      <Dialog open={!!showOpportunityOfferForClient} onOpenChange={(open) => {
        if (!open) setShowOpportunityOfferForClient(null);
      }}>
        <DialogContent className="max-w-md bg-card border-border/70 shadow-xl text-foreground">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 font-bold text-lg text-indigo-950">
              <Sparkles className="h-5 w-5 text-indigo-600 animate-pulse" />
              Lead Adicionado! Cotar Produto?
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground mt-2">
              Os dados de <strong>"{showOpportunityOfferForClient?.nome}"</strong> foram criados.
              Deseja aproveitar o momento e registrar uma **nova oportunidade comercial ou cotar uma proposta** vinculada a este lead?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex gap-2 pt-4 border-t border-border/10">
            <Button variant="outline" size="sm" onClick={() => setShowOpportunityOfferForClient(null)}>
              Não, apenas concluir
            </Button>
            <Button 
              size="sm"
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold"
              onClick={() => {
                setShowOpportunityModal(true);
              }}
            >
              Sim, Criar Oportunidade
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <OpportunityFormModal
        open={showOpportunityModal}
        onOpenChange={(open) => {
          setShowOpportunityModal(open);
          if (!open) {
            setShowOpportunityOfferForClient(null);
          }
        }}
        preSelectedClientId={showOpportunityOfferForClient?.id}
        onSuccess={() => {
          queryClient.invalidateQueries({ queryKey: ["crm_leads"] });
          queryClient.invalidateQueries({ queryKey: ["clients"] });
          queryClient.invalidateQueries({ queryKey: ["apolices"] });
        }}
      />

      <Client360Sheet
        open={show360Sheet}
        onOpenChange={setShow360Sheet}
        client={leadFor360}
      />

      {/* FOOTER INFO - Moved from CRM.tsx */}
      <footer className="flex flex-col md:flex-row items-center justify-between gap-6 px-10 py-6 text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground/40 border-t border-muted/10 mt-6">
         <div className="flex items-center gap-8">
            <span className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-primary" /> Atendimento Ativo</span>
            <span className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-emerald-500" /> Dashboard sincronizado</span>
         </div>
         <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="sm" 
              className="gap-2 text-[10px] uppercase font-black hover:bg-transparent hover:text-primary transition-colors"
              onClick={handleExport}
            >
               <Download className="h-3 w-3" /> Exportar Pipeline
            </Button>
         </div>
      </footer>
    </div>
  );
}
