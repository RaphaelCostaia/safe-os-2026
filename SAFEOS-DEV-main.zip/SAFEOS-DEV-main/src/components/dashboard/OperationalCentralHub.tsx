import React, { useState, useMemo } from "react";
import { 
  useOperationalHub, 
  OperationType, 
  OperationPriority, 
  OperationalItem 
} from "@/hooks/useOperationalHub";
import { 
  Zap, 
  Plus, 
  CheckCircle2, 
  Circle, 
  Clock, 
  AlertTriangle, 
  User, 
  MessageSquare, 
  MoreVertical, 
  Trash2, 
  Edit3,
  Filter,
  Calendar,
  Search,
  ChevronRight,
  TrendingUp,
  Tag,
  ArrowRight
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { format, isToday, isTomorrow, isPast } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "motion/react";

export function OperationalCentralHub() {
  const { items, isLoading, createItem, updateStatus, deleteItem } = useOperationalHub();
  const [activeTab, setActiveTab] = useState("pendentes");
  const [searchTerm, setSearchTerm] = useState("");
  const [isAdding, setIsAdding] = useState(false);
  
  // Quick Add State
  const [newItem, setNewItem] = useState<{
    title: string;
    description: string;
    type: OperationType;
    priority: OperationPriority;
  }>({
    title: "",
    description: "",
    type: "tarefa",
    priority: "média"
  });

  const filteredItems = useMemo(() => {
    if (!items) return [];
    return items.filter(item => {
      const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            item.description.toLowerCase().includes(searchTerm.toLowerCase());
      
      if (!matchesSearch) return false;

      switch (activeTab) {
        case "hoje": return isToday(parseISO(item.date)) && item.status !== "concluido";
        case "atrasadas": return item.status === "atrasado";
        case "concluidas": return item.status === "concluido";
        case "pendentes": return item.status === "pendente" || item.status === "atrasado";
        default: return true;
      }
    });
  }, [items, activeTab, searchTerm]);

  const stats = useMemo(() => {
    if (!items) return { total: 0, pending: 0, overdue: 0, completed: 0 };
    return {
      total: items.length,
      pending: items.filter(i => i.status === "pendente").length,
      overdue: items.filter(i => i.status === "atrasado").length,
      completed: items.filter(i => i.status === "concluido").length
    };
  }, [items]);

  const handleQuickAdd = () => {
    if (!newItem.description && newItem.type === "anotação") return;
    if (!newItem.title && newItem.type !== "anotação") return;

    createItem.mutate(newItem, {
      onSuccess: () => {
        setNewItem({ title: "", description: "", type: "tarefa", priority: "média" });
        setIsAdding(false);
      }
    });
  };

  const getPriorityColor = (p: string) => {
    switch (p) {
      case "alta": return "text-destructive bg-destructive/10 border-destructive/20";
      case "média": return "text-orange-600 bg-orange-50 border-orange-100";
      case "baixa": return "text-blue-600 bg-blue-50 border-blue-100";
      default: return "";
    }
  };

  const getTypeIcon = (type: OperationType) => {
    switch (type) {
      case "tarefa": return <CheckCircle2 className="h-4 w-4" />;
      case "anotação": return <MessageSquare className="h-4 w-4" />;
      case "follow-up": return <TrendingUp className="h-4 w-4" />;
      case "tip": return <Zap className="h-4 w-4" />;
      case "lembrete": return <Calendar className="h-4 w-4" />;
    }
  };

  const formatItemDate = (dateStr: string) => {
    const d = parseISO(dateStr);
    if (isToday(d)) return "Hoje";
    if (isTomorrow(d)) return "Amanhã";
    return format(d, "dd 'de' MMM", { locale: ptBR });
  };

  const parseISO = (str: string) => {
    try { return new Date(str); } catch { return new Date(); }
  };

  return (
    <div className="space-y-8">
      {/* HEADER & SUMMARY */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 bg-muted/20 p-8 rounded-[2.5rem]">
        <div className="flex items-center gap-5">
           <div className="w-14 h-14 rounded-2xl bg-primary flex items-center justify-center shadow-lg shadow-primary/20">
              <Zap className="h-7 w-7 text-white" />
           </div>
           <div>
              <h2 className="text-2xl font-black tracking-tight">Central de Ações do Dia</h2>
              <div className="flex items-center gap-3 mt-1 font-bold text-[10px] uppercase tracking-widest text-muted-foreground">
                 <span className="flex items-center gap-1.5"><Circle className="h-2 w-2 fill-emerald-500 text-emerald-500" /> {stats.completed} Concluídas</span>
                 <Separator orientation="vertical" className="h-3" />
                 <span className="flex items-center gap-1.5"><Circle className="h-2 w-2 fill-destructive text-destructive animate-pulse" /> {stats.overdue} Atrasadas</span>
              </div>
           </div>
        </div>

        <div className="flex items-center gap-3">
           <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Filtrar ações..." 
                className="h-12 w-64 pl-10 rounded-2xl bg-white dark:bg-black/40 border-none shadow-sm text-xs font-bold"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
           </div>
           <Button 
             className="h-12 px-6 rounded-2xl bg-primary text-white font-black uppercase text-xs tracking-wider shadow-lg hover:shadow-xl transition-all gap-2"
             onClick={() => setIsAdding(!isAdding)}
           >
             <Plus className="h-4 w-4" /> Nova Ação
           </Button>
        </div>
      </div>

      {/* QUICK ADD PANEL */}
      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <Card className="rounded-[2.5rem] border-2 border-primary/10 shadow-xl overflow-hidden">
               <div className="p-8 space-y-6">
                  <div className="flex flex-wrap gap-3">
                     {(["tarefa", "anotação", "follow-up", "tip"] as OperationType[]).map(type => (
                       <Button
                         key={type}
                         variant={newItem.type === type ? "default" : "outline"}
                         size="sm"
                         onClick={() => setNewItem({ ...newItem, type })}
                         className="rounded-xl font-bold text-[10px] uppercase h-9 px-4 h-10 transition-all border-2"
                       >
                         {getTypeIcon(type)}
                         <span className="ml-2">{type}</span>
                       </Button>
                     ))}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                     <div className="space-y-4">
                        <Input 
                          placeholder={newItem.type === 'anotação' ? "Assunto da anotação..." : "Título da tarefa ou ação..."}
                          className="h-14 rounded-2xl bg-muted/20 border-none text-sm font-bold px-6"
                          value={newItem.title}
                          onChange={(e) => setNewItem({ ...newItem, title: e.target.value })}
                        />
                        <Input 
                          placeholder={newItem.type === 'anotação' ? "Escreva sua anotação aqui..." : "Detalhes adicionais (opcional)..."}
                          className="h-24 rounded-2xl bg-muted/20 border-none text-sm font-medium px-6 align-top pt-4"
                          value={newItem.description}
                          onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
                        />
                     </div>
                     <div className="space-y-6">
                        <div className="grid grid-cols-2 gap-4">
                           <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Prioridade</label>
                              <Select value={newItem.priority} onValueChange={(v) => setNewItem({ ...newItem, priority: v as any })}>
                                <SelectTrigger className="h-14 rounded-2xl bg-muted/20 border-none font-bold text-xs"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="alta">Alta</SelectItem>
                                  <SelectItem value="média">Média</SelectItem>
                                  <SelectItem value="baixa">Baixa</SelectItem>
                                </SelectContent>
                              </Select>
                           </div>
                           <div className="space-y-2">
                              <label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Prazo</label>
                              <Input type="date" className="h-14 rounded-2xl bg-muted/20 border-none font-bold text-xs" />
                           </div>
                        </div>
                        <div className="flex justify-end pt-2">
                           <Button 
                             onClick={handleQuickAdd} 
                             className="h-14 px-10 rounded-2xl font-black uppercase text-xs tracking-widest gap-2 shadow-lg"
                             disabled={createItem.isPending}
                           >
                             Salvar Registro <ArrowRight className="h-4 w-4" />
                           </Button>
                        </div>
                     </div>
                  </div>
               </div>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* TABS & LIST */}
      <Card className="rounded-[2.5rem] border-none shadow-sm overflow-hidden bg-card/50">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="px-8 pt-8 border-b">
            <TabsList className="bg-transparent h-auto p-0 gap-8">
              {["pendentes", "hoje", "atrasadas", "concluidas"].map(tab => (
                <TabsTrigger 
                  key={tab} 
                  value={tab} 
                  className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-4 data-[state=active]:border-primary rounded-none px-0 pb-6 font-black text-xs uppercase tracking-widest transition-all opacity-40 data-[state=active]:opacity-100"
                >
                  {tab}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          <div className="p-0">
             {isLoading ? (
               <div className="p-8 space-y-4">
                  {[1, 2, 3].map(i => <Skeleton key={i} className="h-20 w-full rounded-2xl" />)}
               </div>
             ) : filteredItems.length > 0 ? (
               <div className="divide-y divide-muted/10">
                 {filteredItems.map((item) => (
                   <div 
                     key={item.id} 
                     className={cn(
                       "p-8 transition-all hover:bg-muted/5 group relative overflow-hidden",
                       item.status === 'atrasado' && "border-l-4 border-l-destructive"
                     )}
                   >
                     <div className="flex items-start gap-6">
                        {/* Status Check */}
                        <div 
                          className={cn(
                            "w-10 h-10 rounded-xl border-2 flex items-center justify-center cursor-pointer transition-all",
                            item.status === "concluido" ? "bg-emerald-500 border-emerald-500 text-white" : "border-muted-foreground/20 hover:border-primary group-hover:scale-110",
                            item.status === "atrasado" && "border-destructive/30"
                          )}
                          onClick={() => updateStatus.mutate({ 
                            id: item.id, 
                            status: item.status === 'concluido' ? 'pendente' : 'concluido',
                            type: item.type
                          })}
                        >
                          {item.status === "concluido" ? <CheckCircle2 className="h-5 w-5" /> : <div className="w-2 h-2 rounded-full bg-muted-foreground/30" />}
                        </div>

                        {/* Content */}
                        <div className="flex-1 space-y-1.5">
                           <div className="flex items-center gap-3">
                              <Badge className={cn("text-[9px] font-black uppercase h-5 rounded-md border-none", getPriorityColor(item.priority))}>
                                {item.priority}
                              </Badge>
                              <Badge variant="outline" className="text-[9px] font-black h-5 uppercase tracking-tighter bg-muted/10 border-none gap-1.5">
                                 {getTypeIcon(item.type)} {item.type}
                              </Badge>
                              {item.client_nome && (
                                <div className="flex items-center gap-1.5 text-[10px] font-bold text-primary bg-primary/5 px-2 py-0.5 rounded-md">
                                   <User className="h-3 w-3" /> {item.client_nome}
                                </div>
                              )}
                           </div>
                           <h3 className={cn("text-sm font-black tracking-tight", item.status === 'concluido' && "line-through opacity-40")}>
                             {item.title || item.description.substring(0, 40) + "..."}
                           </h3>
                           <p className={cn("text-xs text-muted-foreground font-medium line-clamp-2", item.status === 'concluido' && "opacity-30")}>
                             {item.description}
                           </p>
                        </div>

                        {/* Metadata & Actions */}
                        <div className="flex items-center gap-8">
                           <div className="text-right">
                              <p className={cn("text-[10px] font-black uppercase tracking-widest", item.status === 'atrasado' ? "text-destructive" : "text-muted-foreground")}>
                                {formatItemDate(item.date)}
                              </p>
                              {item.status === 'atrasado' && <p className="text-[9px] font-bold text-destructive animate-pulse uppercase">Atrasado!</p>}
                           </div>
                           
                           <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                 <Button variant="ghost" size="icon" className="h-10 w-10 rounded-xl opacity-0 group-hover:opacity-100 transition-all">
                                    <MoreVertical className="h-4 w-4" />
                                 </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                 <DropdownMenuItem className="gap-2 font-bold text-xs"><Edit3 className="h-3.5 w-3.5" /> Editar</DropdownMenuItem>
                                 <DropdownMenuItem 
                                   className="gap-2 font-bold text-xs text-destructive"
                                   onClick={() => deleteItem.mutate({ id: item.id, type: item.type })}
                                 >
                                    <Trash2 className="h-3.5 w-3.5" /> Excluir
                                 </DropdownMenuItem>
                              </DropdownMenuContent>
                           </DropdownMenu>
                        </div>
                     </div>
                   </div>
                 ))}
               </div>
             ) : (
               <div className="py-20 text-center opacity-30 flex flex-col items-center">
                  <CheckCircle2 className="h-16 w-16 mb-4 text-emerald-500" />
                  <p className="text-sm font-black uppercase tracking-widest">Tudo limpo por aqui!</p>
                  <p className="text-xs font-medium mt-1">Você concluiu todas as ações prioritárias desta lista.</p>
               </div>
             )}
          </div>
        </Tabs>
      </Card>

      {/* DAILY PROGRESS */}
      <Card className="rounded-[2.5rem] p-8 border-none shadow-sm bg-primary/5">
         <div className="flex items-center justify-between mb-4">
            <h4 className="text-xs font-black uppercase tracking-widest">Progresso de Produtividade Diária</h4>
            <span className="text-xs font-black text-primary">{Math.round((stats.completed / (stats.total || 1)) * 100)}%</span>
         </div>
         <Progress value={(stats.completed / (stats.total || 1)) * 100} className="h-2 bg-white dark:bg-black/20" />
         <p className="text-[10px] font-bold text-muted-foreground mt-4 italic uppercase tracking-wider">
           "O sucesso é a soma de pequenos esforços repetidos dia após dia."
         </p>
      </Card>
    </div>
  );
}
