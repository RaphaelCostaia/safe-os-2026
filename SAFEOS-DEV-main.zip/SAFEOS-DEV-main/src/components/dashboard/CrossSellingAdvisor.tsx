import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ShieldCheck, ArrowUpRight, Zap, Target, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { useNavigate } from "react-router-dom";

interface Opportunity {
  id: string;
  cliente: string;
  produtoAtual: string;
  oportunidade: string;
  probabilidade: "alta" | "media" | "baixa";
  razao: string;
}

export function CrossSellingAdvisor() {
  const navigate = useNavigate();

  const { data: opportunities, isLoading } = useQuery({
    queryKey: ["cross-selling-opportunities"],
    queryFn: async (): Promise<Opportunity[]> => {
      // Fetch clients and their policies to identify gaps
      const { data: clients } = await supabase
        .from("clients")
        .select("id, nome, tipo_profissional")
        .is("deleted_at", null)
        .limit(20);

      const { data: apolices } = await supabase
        .from("apolices")
        .select("client_id, produto, status")
        .eq("status", "ativa")
        .is("deleted_at", null);

      if (!clients) return [];

      const results: Opportunity[] = [];

      clients.forEach(client => {
        const clientApolices = apolices?.filter(a => a.client_id === client.id) || [];
        const products = clientApolices.map(a => a.produto.toLowerCase());

        // Simple heuristic rules for cross-selling
        if (products.includes("auto") && !products.includes("residencial")) {
          results.push({
            id: `opp-${client.id}-res`,
            cliente: client.nome,
            produtoAtual: "Auto",
            oportunidade: "Residencial",
            probabilidade: "alta",
            razao: "Cliente Auto tem 60% mais chance de fechar Residencial com desconto combo."
          });
        }

        if (client.tipo_profissional?.toLowerCase().includes("médico") && !products.includes("rcp")) {
          results.push({
            id: `opp-${client.id}-rcp`,
            cliente: client.nome,
            produtoAtual: "Nenhum (Profissional)",
            oportunidade: "RCP Médico",
            probabilidade: "alta",
            razao: "Essencial para a categoria profissional do cliente."
          });
        }

        if (products.includes("vida") && !products.includes("previdência")) {
          results.push({
            id: `opp-${client.id}-prev`,
            cliente: client.nome,
            produtoAtual: "Vida",
            oportunidade: "Previdência",
            probabilidade: "media",
            razao: "Perfil focado em proteção familiar de longo prazo."
          });
        }
      });

      return results.slice(0, 5);
    }
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map(i => (
          <Skeleton key={i} className="h-24 w-full rounded-2xl" />
        ))}
      </div>
    );
  }

  return (
    <Card className="border-none shadow-none bg-transparent">
      <CardHeader className="px-0 pt-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            <CardTitle className="text-xl">Oportunidades de Cross-selling</CardTitle>
          </div>
          <Badge variant="secondary" className="font-mono text-[10px]">ALGO DATA</Badge>
        </div>
      </CardHeader>
      <CardContent className="px-0 space-y-3">
        {opportunities?.length === 0 ? (
          <div className="text-center py-8 bg-muted/20 rounded-2xl border border-dashed">
            <Users className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">Continue cadastrando apólices para gerar sugestões.</p>
          </div>
        ) : (
          opportunities?.map((opp) => (
            <div 
              key={opp.id}
              className="group relative flex items-center justify-between p-4 rounded-2xl border bg-card hover:border-primary/30 hover:shadow-md transition-all cursor-pointer"
              onClick={() => navigate(`/clientes?id=${opp.id.split('-')[1]}`)}
            >
              <div className="flex gap-4">
                <div className={cn(
                  "flex h-12 w-12 items-center justify-center rounded-xl",
                  opp.probabilidade === "alta" ? "bg-emerald-500/10 text-emerald-600" :
                  opp.probabilidade === "media" ? "bg-amber-500/10 text-amber-600" : "bg-slate-500/10 text-slate-600"
                )}>
                  <Zap className="h-6 w-6" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm">{opp.cliente}</span>
                    <Badge variant="outline" className="text-[10px] uppercase">{opp.probabilidade}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Sugerir <span className="text-primary font-medium">{opp.oportunidade}</span> (já possui {opp.produtoAtual})
                  </p>
                  <p className="text-[10px] text-muted-foreground italic leading-tight max-w-[240px]">
                    "{opp.razao}"
                  </p>
                </div>
              </div>
              <Button size="icon" variant="ghost" className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity">
                <ArrowUpRight className="h-4 w-4" />
              </Button>
            </div>
          ))
        )}
        {opportunities && opportunities.length > 0 && (
          <Button variant="ghost" className="w-full text-xs text-muted-foreground" onClick={() => navigate('/clientes')}>
            Ver todas as oportunidades
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
