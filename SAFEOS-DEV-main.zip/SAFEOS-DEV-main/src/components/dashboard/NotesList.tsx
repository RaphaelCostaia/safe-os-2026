import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useUserNotes, useDeleteUserNote, UserNote } from "@/hooks/useUserNotes";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Trash2, StickyNote } from "lucide-react";

function NoteItem({ note }: { note: UserNote }) {
  const deleteNote = useDeleteUserNote();

  return (
    <div className="p-3 rounded-lg border bg-card hover:bg-accent/5 transition-colors">
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <p className="text-sm whitespace-pre-wrap break-words">{note.conteudo}</p>
          
          {note.tags && note.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {note.tags.map((tag) => (
                <Badge key={tag} variant="outline" className="text-xs">
                  {tag}
                </Badge>
              ))}
            </div>
          )}

          <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
            <span>{format(new Date(note.created_at), "dd/MM/yyyy HH:mm", { locale: ptBR })}</span>
            {note.visibilidade === "equipe" && (
              <Badge variant="secondary" className="text-xs">
                Equipe
              </Badge>
            )}
          </div>
        </div>

        <Button
          variant="ghost"
          size="icon"
          className="h-6 w-6 shrink-0 text-muted-foreground hover:text-destructive"
          onClick={() => deleteNote.mutate(note.id)}
          disabled={deleteNote.isPending}
        >
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>
    </div>
  );
}

export function NotesList() {
  const { data: notes, isLoading } = useUserNotes();

  if (isLoading) {
    return (
      <div className="space-y-2">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-20 w-full" />
        ))}
      </div>
    );
  }

  if (!notes || notes.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-8 text-center">
        <div className="rounded-full bg-muted p-3 mb-3">
          <StickyNote className="h-6 w-6 text-muted-foreground" />
        </div>
        <h3 className="text-sm font-medium">Nenhuma anotação</h3>
        <p className="text-xs text-muted-foreground mt-1">
          Crie uma nova anotação usando o botão "+ Anotação"
        </p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-[300px]">
      <div className="space-y-2 pr-4">
        {notes.map((note) => (
          <NoteItem key={note.id} note={note} />
        ))}
      </div>
    </ScrollArea>
  );
}
