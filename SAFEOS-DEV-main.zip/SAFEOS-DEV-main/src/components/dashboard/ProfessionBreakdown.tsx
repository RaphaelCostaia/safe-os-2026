import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { useClients } from "@/hooks/useClients";
import { useApolices } from "@/hooks/useApolices";
import { useMemo } from "react";
import { Users } from "lucide-react";

// Colors for professions
const PROFESSION_COLORS = [
  "hsl(217, 91%, 60%)",
  "hsl(262, 83%, 58%)",
  "hsl(142, 71%, 45%)",
  "hsl(38, 92%, 50%)",
  "hsl(199, 89%, 48%)",
  "hsl(0, 0%, 50%)",
];

function normalizeProfession(profession: string | null): string {
  if (!profession) return "Não informado";
  const normalized = profession.toLowerCase().trim();
  
  if (normalized.includes("médico") || normalized.includes("medico")) return "Médicos";
  if (normalized.includes("dentista")) return "Dentistas";
  if (normalized.includes("fisioterapeuta")) return "Fisioterapeutas";
  if (normalized.includes("psicólogo") || normalized.includes("psicologo")) return "Psicólogos";
  if (normalized.includes("nutricionista")) return "Nutricionistas";
  if (normalized.includes("enfermeiro") || normalized.includes("enfermeira")) return "Enfermeiros";
  if (normalized.includes("veterinário") || normalized.includes("veterinario")) return "Veterinários";
  if (normalized.includes("advogado") || normalized.includes("advogada")) return "Advogados";
  if (normalized.includes("contador") || normalized.includes("contadora")) return "Contadores";
  if (normalized.includes("arquiteto") || normalized.includes("arquiteta")) return "Arquitetos";
  if (normalized.includes("engenheiro") || normalized.includes("engenheira")) return "Engenheiros";
  
  // Return the original profession capitalized if it doesn't match any category
  return profession.charAt(0).toUpperCase() + profession.slice(1);
}

interface ProfessionData {
  profession: string;
  clients: number;
  premium: number;
  color: string;
}

export function ProfessionBreakdown() {
  const { data: clients = [], isLoading: clientsLoading } = useClients();
  const { data: apolices = [], isLoading: apolicesLoading } = useApolices();

  const isLoading = clientsLoading || apolicesLoading;

  const professionData = useMemo((): ProfessionData[] => {
    const activeClients = clients.filter((c) => c.status === "ativo");
    const activePolicies = apolices.filter((a) => a.status === "ativa");

    // Map client premiums
    const clientPremiums: Record<string, number> = {};
    activePolicies.forEach((apolice) => {
      if (!clientPremiums[apolice.client_id]) {
        clientPremiums[apolice.client_id] = 0;
      }
      clientPremiums[apolice.client_id] += Number(apolice.valor_premio) || 0;
    });

    // Group by profession
    const professionMap: Record<string, { clients: number; premium: number }> = {};

    activeClients.forEach((client) => {
      const profession = normalizeProfession(client.profissao);
      
      if (!professionMap[profession]) {
        professionMap[profession] = { clients: 0, premium: 0 };
      }

      professionMap[profession].clients += 1;
      professionMap[profession].premium += clientPremiums[client.id] || 0;
    });

    // Sort by client count and take top entries
    return Object.entries(professionMap)
      .map(([profession, data], index) => ({
        profession,
        clients: data.clients,
        premium: data.premium,
        color: PROFESSION_COLORS[index % PROFESSION_COLORS.length],
      }))
      .sort((a, b) => b.clients - a.clients)
      .slice(0, 6);
  }, [clients, apolices]);

  const chartData = professionData.map((p) => ({
    name: p.profession,
    value: p.clients,
    color: p.color,
  }));

  if (isLoading) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold">Clientes por Profissão</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-[180px] w-full" />
          <div className="space-y-2">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (professionData.length === 0) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold">Clientes por Profissão</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <Users className="h-10 w-10 text-muted-foreground mb-3" />
            <p className="text-sm text-muted-foreground">Nenhum cliente ativo</p>
            <p className="text-xs text-muted-foreground mt-1">
              Cadastre clientes com profissão para visualizar
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50 bg-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold">Clientes por Profissão</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[180px] mb-4">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 47%, 16%)" horizontal={false} />
              <XAxis type="number" stroke="hsl(215, 20%, 55%)" fontSize={12} />
              <YAxis
                type="category"
                dataKey="name"
                stroke="hsl(215, 20%, 55%)"
                fontSize={11}
                width={100}
                tickFormatter={(value) => (value.length > 12 ? value.substring(0, 12) + "…" : value)}
              />
              <Tooltip
                formatter={(value: number) => [`${value} clientes`, "Total"]}
                contentStyle={{
                  backgroundColor: "hsl(222, 47%, 10%)",
                  border: "1px solid hsl(222, 47%, 16%)",
                  borderRadius: "8px",
                }}
              />
              <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="space-y-2">
          {professionData.slice(0, 4).map((prof) => (
            <div
              key={prof.profession}
              className="flex items-center justify-between p-2 rounded-lg hover:bg-secondary/50 transition-colors"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-2 h-8 rounded-full shrink-0" style={{ backgroundColor: prof.color }} />
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{prof.profession}</p>
                  <p className="text-xs text-muted-foreground">
                    {prof.premium > 0
                      ? `R$ ${prof.premium >= 1000 ? (prof.premium / 1000).toFixed(0) + "k" : prof.premium.toLocaleString("pt-BR")} em prêmios`
                      : "Sem prêmios ativos"}
                  </p>
                </div>
              </div>
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 shrink-0">
                {prof.clients} cliente{prof.clients !== 1 ? "s" : ""}
              </Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
