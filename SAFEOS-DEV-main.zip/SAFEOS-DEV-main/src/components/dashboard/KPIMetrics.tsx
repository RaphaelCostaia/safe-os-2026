import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Minus, DollarSign, Users, FileCheck, Percent, Bug } from "lucide-react";
import { cn } from "@/lib/utils";
import { useDashboardStats } from "@/hooks/useDashboardStats";
import { useApolices } from "@/hooks/useApolices";
import { useClients } from "@/hooks/useClients";
import { useSinistros } from "@/hooks/useSinistros";
import { useMemo } from "react";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface KPIData {
  label: string;
  value: string;
  change: number;
  changeLabel: string;
  icon: React.ElementType;
  trend: "up" | "down" | "neutral";
  color: string;
  diagnosticInfo?: {
    fonte: string;
    formula: string;
  };
}

interface KPIMetricsProps {
  showDiagnostics?: boolean;
}

export function KPIMetrics({ showDiagnostics = false }: KPIMetricsProps) {
  const { data: stats, isLoading: statsLoading } = useDashboardStats();
  const { data: apolices = [], isLoading: apolicesLoading } = useApolices();
  const { data: clients = [], isLoading: clientsLoading } = useClients();
  const { data: sinistros = [], isLoading: sinistrosLoading } = useSinistros();

  const isLoading = statsLoading || apolicesLoading || clientsLoading || sinistrosLoading;

  const kpis = useMemo((): KPIData[] => {
    // Calculate Ticket Médio from real data based on commission
    const activePolicies = apolices.filter(a => ["ativa", "em_renovacao", "renovada"].includes(a.status));
    const totalPremium = activePolicies.reduce((sum, a) => sum + (a.valor_premio || 0), 0);
    
    const parseApoliceObservacoes = (observacoesText: string | null) => {
      const defaultMeta = {
        comissao_real_percent: "",
        valor_comissao_real: "",
        data_renovacao: "",
      };
      if (!observacoesText) return { notes: "", meta: defaultMeta };
      const divider = "-- METADATA_APOLICE_V1 --";
      const parts = observacoesText.split(divider);
      if (parts.length < 2) return { notes: observacoesText, meta: defaultMeta };
      try {
        const meta = JSON.parse(parts[1].trim());
        return { notes: parts[0].trim(), meta: { ...defaultMeta, ...meta } };
      } catch {
        return { notes: observacoesText, meta: defaultMeta };
      }
    };

    let totalCommission = 0;
    activePolicies.forEach(a => {
      const { meta } = parseApoliceObservacoes(a.observacoes);
      const premio = Number(a.valor_premio) || 0;
      let pPercent = meta.comissao_real_percent ? parseFloat(meta.comissao_real_percent) : NaN;
      let pValor = meta.valor_comissao_real ? parseFloat(meta.valor_comissao_real) : NaN;

      if (isNaN(pPercent) || pPercent <= 0) {
        const prod = a.produtos as any;
        pPercent = prod?.comissao_percentual || 0;
      }
      if (isNaN(pValor) || pValor <= 0) {
        pValor = (premio * pPercent) / 100;
      }
      totalCommission += pValor;
    });

    const uniqueClientsCount = new Set(activePolicies.map(ap => ap.client_id)).size;
    const ticketMedio = uniqueClientsCount > 0 
      ? totalCommission / uniqueClientsCount 
      : 0;

    // Calculate average products per client
    const activeClients = clients.filter(c => c.status === "ativo");
    const clientsWithPolicies = activeClients.filter(c => 
      apolices.some(a => a.client_id === c.id && ["ativa", "em_renovacao", "renovada"].includes(a.status))
    );
    const avgProductsPerClient = clientsWithPolicies.length > 0
      ? activePolicies.length / clientsWithPolicies.length
      : 0;

    // Calculate sinistralidade (claims rate)
    const openStatuses = ["aberto", "em_andamento", "aguardando_cliente", "aguardando_seguradora"];
    const openClaims = sinistros.filter(s => openStatuses.includes(s.status));
    const totalClaimValue = openClaims.reduce((sum, s) => sum + (s.valor_estimado || 0), 0);
    const sinistralidade = totalPremium > 0 
      ? (totalClaimValue / totalPremium) * 100 
      : 0;

    // Calculate conversion rate (active clients / total clients)
    const conversionRate = clients.length > 0
      ? (activeClients.length / clients.length) * 100
      : 0;

    return [
      {
        label: "Ticket Médio (Comissão)",
        value: ticketMedio > 0 
          ? `R$ ${ticketMedio.toLocaleString('pt-BR', { maximumFractionDigits: 0 })}`
          : "R$ 0",
        change: 0,
        changeLabel: `${activePolicies.length} apólices ativas`,
        icon: DollarSign,
        trend: "neutral",
        color: "text-primary",
        diagnosticInfo: {
          fonte: "apolices / comissão",
          formula: "SUM(valor_comissao) / COUNT(*)",
        },
      },
      {
        label: "Taxa de Conversão",
        value: `${conversionRate.toFixed(0)}%`,
        change: 0,
        changeLabel: `${activeClients.length} de ${clients.length} clientes`,
        icon: Percent,
        trend: conversionRate >= 50 ? "up" : "down",
        color: "text-success",
        diagnosticInfo: {
          fonte: "clients",
          formula: "(ativos / total) * 100",
        },
      },
      {
        label: "Produtos por Cliente",
        value: avgProductsPerClient.toFixed(1),
        change: 0,
        changeLabel: "média por cliente ativo",
        icon: Users,
        trend: avgProductsPerClient >= 1 ? "up" : "neutral",
        color: "text-accent",
        diagnosticInfo: {
          fonte: "apolices + clients",
          formula: "COUNT(apolices ativas) / COUNT(clientes com apólice)",
        },
      },
      {
        label: "Taxa de Sinistralidade",
        value: `${sinistralidade.toFixed(1)}%`,
        change: 0,
        changeLabel: `${openClaims.length} sinistros abertos`,
        icon: FileCheck,
        trend: sinistralidade < 30 ? "up" : "down",
        color: "text-warning",
        diagnosticInfo: {
          fonte: "sinistros + apolices",
          formula: "(valor_sinistros / prêmio_total) * 100",
        },
      },
    ];
  }, [apolices, clients, sinistros]);

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} className="border-border/50 bg-card">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="h-8 w-8 rounded-lg bg-secondary animate-pulse" />
                <div className="h-4 w-12 rounded bg-secondary animate-pulse" />
              </div>
              <div className="h-8 w-24 rounded bg-secondary animate-pulse mb-1" />
              <div className="h-3 w-20 rounded bg-secondary animate-pulse" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {kpis.map((kpi) => {
        const TrendIcon = kpi.trend === "up" ? TrendingUp : kpi.trend === "down" ? TrendingDown : Minus;
        const isPositive = (kpi.label === "Taxa de Sinistralidade" && kpi.trend === "up") || 
                          (kpi.label !== "Taxa de Sinistralidade" && kpi.trend === "up");
        
        return (
          <Card key={kpi.label} className="border-border/50 bg-card hover:border-primary/30 transition-colors">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className={cn("p-2 rounded-lg bg-secondary", kpi.color)}>
                  <kpi.icon className="h-4 w-4" />
                </div>
                {kpi.trend !== "neutral" && (
                  <div className={cn(
                    "flex items-center gap-1 text-xs font-medium",
                    isPositive ? "text-success" : "text-destructive"
                  )}>
                    <TrendIcon className="h-3 w-3" />
                  </div>
                )}
              </div>
              <p className="text-2xl font-bold text-foreground mb-1">{kpi.value}</p>
              <p className="text-xs text-muted-foreground">{kpi.changeLabel}</p>
              {showDiagnostics && kpi.diagnosticInfo && (
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Badge variant="outline" className="text-[10px] gap-1 cursor-help mt-2">
                        <Bug className="h-3 w-3" />
                        Dados reais
                      </Badge>
                    </TooltipTrigger>
                    <TooltipContent side="bottom" className="max-w-xs">
                      <div className="space-y-1 text-xs">
                        <p><strong>Fonte:</strong> {kpi.diagnosticInfo.fonte}</p>
                        <p><strong>Fórmula:</strong> {kpi.diagnosticInfo.formula}</p>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
