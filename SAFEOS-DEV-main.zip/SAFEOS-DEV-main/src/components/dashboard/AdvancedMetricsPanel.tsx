import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Tooltip, 
  TooltipContent, 
  TooltipTrigger 
} from "@/components/ui/tooltip";
import { 
  TrendingUp, 
  Users, 
  AlertTriangle, 
  HelpCircle,
  DollarSign,
  UserCheck,
  ShieldAlert
} from "lucide-react";
import { 
  useDashboardAdvancedMetrics, 
  formatLTV, 
  getSinistralidadeStatus, 
  getConversionStatus,
  MetricPeriod
} from "@/hooks/useDashboardAdvancedMetrics";
import { useLtvSettings } from "@/hooks/useLtvSettings";
import { useState } from "react";
import { Button } from "@/components/ui/button";

interface MetricCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ElementType;
  iconColor: string;
  status?: { color: string; label: string };
  hasData: boolean;
  emptyMessage?: string;
  tooltip?: string;
}

function MetricCard({ 
  title, 
  value, 
  subtitle, 
  icon: Icon, 
  iconColor, 
  status,
  hasData,
  emptyMessage = "Dados insuficientes",
  tooltip
}: MetricCardProps) {
  return (
    <Card className="border-border/50 bg-card hover:border-primary/30 transition-colors">
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <p className="text-sm text-muted-foreground">{title}</p>
              {tooltip && (
                <Tooltip>
                  <TooltipTrigger>
                    <HelpCircle className="h-3 w-3 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <p className="text-xs">{tooltip}</p>
                  </TooltipContent>
                </Tooltip>
              )}
            </div>
            {hasData ? (
              <>
                <p className="text-2xl font-bold">{value}</p>
                {subtitle && (
                  <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
                )}
                {status && (
                  <Badge 
                    variant="outline" 
                    className={`mt-2 ${status.color.replace('text-', 'bg-')}/10 ${status.color} border-current/30`}
                  >
                    {status.label}
                  </Badge>
                )}
              </>
            ) : (
              <div className="mt-2">
                <p className="text-sm text-muted-foreground italic">{emptyMessage}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Cadastre clientes e apólices para visualizar
                </p>
              </div>
            )}
          </div>
          <div className={`p-3 rounded-xl bg-opacity-10 ${iconColor.replace('text-', 'bg-')}/10 shrink-0`}>
            <Icon className={`h-5 w-5 ${iconColor}`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function AdvancedMetricsPanel() {
  const [period, setPeriod] = useState<MetricPeriod>("90d");
  const { data: metrics, isLoading, error } = useDashboardAdvancedMetrics(period);
  const { settings: ltvSettings } = useLtvSettings();

  const ltvTooltipText = `Lifetime Value estimado por cliente: ${
    ltvSettings.regraCalculo === "anos_retencao"
      ? `Comissão Anual × ${ltvSettings.tempoPermanencia} anos de retenção média`
      : ltvSettings.regraCalculo === "taxa_renovacao"
      ? `Comissão Anual ÷ Churn (${ltvSettings.churnAnual}%)`
      : `Probabilidade Acumulada (${ltvSettings.tempoPermanencia} anos a ${ltvSettings.taxaRenovacao}%)`
  } (${ltvSettings.modoCalculo === "automatico" ? "cálculo automático pelo sistema" : "configuração manual"})`;

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Métricas Avançadas</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="border-border/50 bg-card">
              <CardContent className="p-5">
                <Skeleton className="h-4 w-24 mb-2" />
                <Skeleton className="h-8 w-32 mb-1" />
                <Skeleton className="h-3 w-20" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Card className="border-destructive/50 bg-destructive/5">
        <CardContent className="py-6 text-center">
          <AlertTriangle className="h-8 w-8 text-destructive mx-auto mb-2" />
          <p className="text-destructive">Erro ao carregar métricas avançadas</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h3 className="font-semibold flex items-center gap-2">
          <TrendingUp className="h-4 w-4 text-primary" />
          Métricas Avançadas
        </h3>
        <div className="flex items-center gap-1 bg-muted/50 rounded-lg p-1">
          {(["30d", "90d", "month", "year"] as MetricPeriod[]).map((p) => (
            <Button
              key={p}
              variant={period === p ? "secondary" : "ghost"}
              size="sm"
              onClick={() => setPeriod(p)}
              className="text-xs"
            >
              {p === "30d" ? "30 dias" : p === "90d" ? "90 dias" : p === "month" ? "Mês" : "Ano"}
            </Button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* LTV */}
        <MetricCard
          title="LTV Médio"
          value={metrics?.ltv.hasData ? formatLTV(metrics.ltv.average) : "-"}
          subtitle={metrics?.ltv.hasData 
            ? `${metrics.ltv.clientsWithCommission} de ${metrics.ltv.totalClients} clientes com comissão`
            : undefined}
          icon={DollarSign}
          iconColor="text-success"
          hasData={metrics?.ltv.hasData || false}
          emptyMessage="Sem dados de comissão"
          tooltip={ltvTooltipText}
        />

        {/* Conversion Rate */}
        <MetricCard
          title="Taxa de Conversão"
          value={metrics?.conversion.hasData 
            ? `${metrics.conversion.rate.toFixed(1)}%` 
            : "-"}
          subtitle={metrics?.conversion.hasData 
            ? `${metrics.conversion.convertedClients} de ${metrics.conversion.totalClients} clientes (${metrics.conversion.period})`
            : undefined}
          icon={UserCheck}
          iconColor="text-primary"
          status={metrics?.conversion.hasData ? getConversionStatus(metrics.conversion.rate) : undefined}
          hasData={metrics?.conversion.hasData || false}
          emptyMessage="Sem clientes no período"
          tooltip="Percentual de clientes que possuem pelo menos uma apólice ativa"
        />

        {/* Sinistralidade */}
        <MetricCard
          title="Sinistralidade"
          value={metrics?.sinistralidade.hasData 
            ? `${metrics.sinistralidade.rate.toFixed(1)}%` 
            : "-"}
          subtitle={metrics?.sinistralidade.hasData 
            ? `R$ ${metrics.sinistralidade.totalPaid.toLocaleString('pt-BR')} / R$ ${metrics.sinistralidade.totalPremium.toLocaleString('pt-BR')}`
            : undefined}
          icon={ShieldAlert}
          iconColor="text-warning"
          status={metrics?.sinistralidade.hasData ? getSinistralidadeStatus(metrics.sinistralidade.rate) : undefined}
          hasData={metrics?.sinistralidade.hasData || false}
          emptyMessage="Sem apólices ativas"
          tooltip="Razão entre o total pago em sinistros e o total de prêmios ativos"
        />
      </div>
    </div>
  );
}
