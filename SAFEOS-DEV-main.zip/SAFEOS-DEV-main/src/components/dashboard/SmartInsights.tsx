import { useState, useEffect } from "react";
import { GoogleGenAI } from "@google/genai";
import { Sparkles, Loader2, AlertCircle, TrendingUp, Info } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion, AnimatePresence } from "motion/react";
import { DashboardStats } from "@/hooks/useDashboardStats";

interface SmartInsightsProps {
  stats: DashboardStats;
  commissions?: {
    somaComissoes: number;
    ticketMedioComissao: number;
    clientesSemComissao: number;
  };
}

export function SmartInsights({ stats, commissions }: SmartInsightsProps) {
  const [insight, setInsight] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function generateInsight() {
      if (!stats || isLoading || insight) return;

      setIsLoading(true);
      setError(null);

      try {
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
        
        const prompt = `
          Você é um consultor estratégico para uma corretora de seguros.
          Analise os seguintes dados da operação e forneça 3 insights rápidos e acionáveis em formato de tópicos curtos.
          Foça em: Riscos (sinistros/renovações), Oportunidades (comissões/clientes sem termo) e Tendência.

          DADOS ATUAIS:
          - Clientes Ativos: ${stats.activeClients}
          - Apólices Ativas: ${stats.activePolicies}
          - Prêmio Total: R$ ${stats.totalPremium.toLocaleString('pt-BR')}
          - Renovações Críticas (<=7 dias): ${stats.criticalRenewals}
          - Sinistros Abertos: ${stats.openClaims}
          - Sinistros Críticos: ${stats.criticalClaims}
          - Taxa de Renovação: ${stats.renewalSuccessRate.toFixed(1)}%
          
          DADOS FINANCEIROS:
          - Comissões Estimadas: R$ ${commissions?.somaComissoes.toLocaleString('pt-BR')}
          - Clientes sem Termo de Comissão: ${commissions?.clientesSemComissao}
          - Ticket Médio Comissão: R$ ${commissions?.ticketMedioComissao.toLocaleString('pt-BR')}

          Responda em PORTUGUÊS, de forma profissional e direta. Use ícones de texto se necessário.
          Evite introduções longas. Vá direto aos pontos.
        `;

        const response = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: prompt,
          config: {
            temperature: 0.7,
            topP: 0.8,
            topK: 40,
          }
        });

        setInsight(response.text || "Não foi possível gerar insights no momento.");
      } catch (err) {
        console.error("Error generating insights:", err);
        setError("Erro ao conectar com a IA.");
      } finally {
        setIsLoading(false);
      }
    }

    generateInsight();
  }, [stats, commissions, insight, isLoading]);

  return (
    <div className="relative overflow-hidden rounded-3xl border bg-gradient-to-br from-primary/5 via-background to-accent/5 p-1">
      <div className="absolute top-0 right-0 p-4 opacity-10">
        <Sparkles className="h-24 w-24 text-primary" />
      </div>
      
      <div className="relative bg-background/60 backdrop-blur-md rounded-[22px] p-6 h-full">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="bg-primary/10 p-2 rounded-lg">
              <Sparkles className="h-5 w-5 text-primary animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-lg tracking-tight">Smart Advisor</h3>
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Insights em Tempo Real</p>
            </div>
          </div>
          <Badge variant="outline" className="bg-primary/5 border-primary/20 text-primary gap-1">
            <TrendingUp className="h-3 w-3" />
            Vibe Analítica
          </Badge>
        </div>

        <div className="min-h-[140px] flex flex-col justify-center">
          <AnimatePresence mode="wait">
            {isLoading ? (
              <motion.div 
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center justify-center space-y-3 py-6"
              >
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <p className="text-sm text-muted-foreground animate-pulse">Analisando sua operação...</p>
              </motion.div>
            ) : error ? (
              <motion.div 
                key="error"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center gap-3 p-4 rounded-xl bg-destructive/5 text-destructive border border-destructive/10"
              >
                <AlertCircle className="h-5 w-5 shrink-0" />
                <p className="text-sm font-medium">{error}</p>
              </motion.div>
            ) : (
              <motion.div 
                key="content"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="prose prose-sm prose-slate max-w-none dark:prose-invert"
              >
                <div className="text-muted-foreground leading-relaxed whitespace-pre-wrap">
                  {insight}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {!isLoading && !error && (
          <div className="mt-6 flex items-center gap-2 text-[10px] text-muted-foreground border-t pt-4">
            <Info className="h-3 w-3" />
            <span>Baseado em dados cruzados de clientes, apólices e sinistros.</span>
          </div>
        )}
      </div>
    </div>
  );
}
