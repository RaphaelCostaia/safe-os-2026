import { useState, useMemo, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { MapPin, Users, Loader2, MapPinned, X, Filter, DollarSign } from "lucide-react";
import { useClientMapData, useClientProfessions, type MapFilters, type ClientLocationData } from "@/hooks/useClientMapData";
import { STATE_POSITIONS, UF_NAMES, BRAZIL_STATES_PATHS, BRAZIL_MAP_VIEWBOX } from "@/data/brazilGeoData";
import { useDashboardFilterOptional } from "@/hooks/useDashboardFilter";

// Real Brazil SVG with state paths - traditional map look
function BrazilSVG({ 
  stateData, 
  hoveredState,
  selectedState,
  onHover,
  onClick
}: { 
  stateData: Record<string, { count: number }>;
  hoveredState: string | null;
  selectedState: string | null;
  onHover: (uf: string | null) => void;
  onClick: (uf: string) => void;
}) {
  // Calculate max count for color scale
  const maxCount = useMemo(() => {
    const counts = Object.values(stateData).map(d => d.count);
    return counts.length > 0 ? Math.max(...counts) : 0;
  }, [stateData]);

  // Color generator - Unified theme colors as requested
  const getFillColor = (count: number, uf: string) => {
    if (count === 0) {
      return "hsl(var(--muted)/0.3)";
    }
    // Choropleth scale based on maximum count
    if (maxCount <= 1) return "hsl(var(--primary))";
    const ratio = count / maxCount;
    if (ratio < 0.33) return "hsl(var(--primary)/0.65)";
    if (ratio < 0.66) return "hsl(var(--primary)/0.85)";
    return "hsl(var(--primary))";
  };

  return (
    <g>
      {BRAZIL_STATES_PATHS.map((state) => {
        const count = stateData[state.uf]?.count || 0;
        const hasClients = count > 0;
        const isHovered = hoveredState === state.uf;
        const isSelected = selectedState === state.uf;
        const isFiltered = selectedState !== null && !isSelected;
        
        return (
          <path
            key={state.uf}
            d={state.path}
            fill={getFillColor(count, state.uf)}
            fillOpacity={
              isSelected ? 1.0 : 
              isFiltered ? 0.3 :
              isHovered ? 1.0 : 0.8
            }
            stroke="var(--map-stroke)"
            strokeWidth={isSelected ? 3 : isHovered ? 2 : 1.5}
            strokeLinejoin="round"
            className="transition-all duration-300 cursor-pointer hover:filter hover:brightness-105 [--map-stroke:hsl(var(--border)/0.5)] dark:[--map-stroke:hsl(var(--border)/0.2)] hover:[--map-stroke:hsl(var(--primary))]"
            onMouseEnter={() => onHover(state.uf)}
            onMouseLeave={() => onHover(null)}
            onClick={() => onClick(state.uf)}
            style={{
              filter: isHovered || isSelected ? 'drop-shadow(0 0 8px rgba(var(--primary),0.3))' : 'none',
              transform: isHovered || isSelected ? 'scale(1.01)' : 'scale(1)',
              transformOrigin: '50% 50%'
            }}
          />
        );
      })}
    </g>
  );
}

// Priority map for small/crowded states (higher = more important to keep visible)
const STATE_PRIORITY: Record<string, number> = {
  DF: 100, SP: 95, RJ: 90, MG: 85, BA: 80,
  RS: 75, PR: 70, SC: 65, GO: 60, PE: 55,
  CE: 50, AM: 45, PA: 40, MT: 35, MA: 30,
  ES: 28, SE: 26, AL: 24, PB: 22, RN: 20,
  PI: 18, TO: 16, MS: 14, RO: 12, AC: 10, RR: 8, AP: 6
};

// Map Legend Component
function MapLegend({ maxCount }: { maxCount: number }) {
  return (
    <div className="flex flex-col gap-3 p-4 bg-card/95 backdrop-blur-md border border-border rounded-2xl shadow-xl min-w-[200px]">
      <p className="text-[11px] font-black uppercase text-foreground tracking-[0.2em] border-b border-border/50 pb-2">Densidade de Clientes</p>
      <div className="flex flex-col gap-2.5 pt-1">
        <div className="flex items-center gap-3">
          <div className="w-4 h-4 rounded shadow-sm border border-border bg-muted/40" />
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Sem Clientes (0)</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-4 h-4 rounded shadow-sm border border-border bg-primary/60" />
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Poucos Clientes</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="w-4 h-4 rounded shadow-sm border border-border bg-primary" />
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Maior Concentração</span>
        </div>
      </div>
    </div>
  );
}

// State labels with collision detection
function StateLabels({ 
  stateData, 
  hoveredState,
  selectedState,
  onHover,
  onClick
}: { 
  stateData: Record<string, { count: number; revenue?: number }>;
  hoveredState: string | null;
  selectedState: string | null;
  onHover: (uf: string | null) => void;
  onClick: (uf: string) => void;
}) {
  // Use optimized positions from data directly
  const resolvedPositions = useMemo(() => {
    return STATE_POSITIONS.map((state) => ({
      uf: state.uf,
      x: state.x,
      y: state.y,
      priority: STATE_PRIORITY[state.uf] || 1,
      hidden: false
    }));
  }, []);

  return (
    <g>
      {resolvedPositions.map((resolved) => {
        const state = STATE_POSITIONS.find(s => s.uf === resolved.uf)!;
        const data = stateData[resolved.uf];
        const count = data?.count || 0;
        const revenue = data?.revenue || 0;
        const hasClients = count > 0;
        const isHovered = hoveredState === resolved.uf;
        const isSelected = selectedState === resolved.uf;
        const isFiltered = selectedState !== null && !isSelected;
        
        return (
          <TooltipProvider key={`label-${state.uf}`} delayDuration={0}>
            <Tooltip>
              <TooltipTrigger asChild>
                <g 
                  onMouseEnter={() => onHover(resolved.uf)}
                  onMouseLeave={() => onHover(null)}
                  onClick={() => onClick(resolved.uf)}
                  style={{ cursor: 'pointer' }}
                >
                  {/* State center dot (always visible for interaction) */}
                  <circle
                    cx={state.x}
                    cy={state.y}
                    r={2.5}
                    fill={
                      isSelected ? "hsl(var(--primary))" :
                      hasClients ? "hsl(var(--primary))" : 
                      "hsl(var(--muted-foreground))"
                    }
                    opacity={isFiltered ? 0.3 : isHovered || isSelected ? 1 : 0.5}
                    className="transition-all duration-200"
                  />
                  
                  {/* Region Labels with extreme contrast */}
                  <text x="130" y="70" fontSize="36" fontWeight="1000" fill="currentColor" stroke="var(--label-stroke)" strokeWidth="1.5" className="select-none pointer-events-none tracking-tighter text-slate-200/50 dark:text-orange-950/20 [--label-stroke:white] dark:[--label-stroke:black]">NORTE</text>
                  <text x="350" y="100" fontSize="36" fontWeight="1000" fill="currentColor" stroke="var(--label-stroke)" strokeWidth="1.5" className="select-none pointer-events-none tracking-tighter text-slate-200/50 dark:text-orange-950/20 [--label-stroke:white] dark:[--label-stroke:black]">NORDESTE</text>
                  <text x="100" y="320" fontSize="36" fontWeight="1000" fill="currentColor" stroke="var(--label-stroke)" strokeWidth="1.5" className="select-none pointer-events-none tracking-tighter text-slate-200/50 dark:text-orange-950/20 [--label-stroke:white] dark:[--label-stroke:black]">CENTRO OESTE</text>
                  <text x="320" y="380" fontSize="36" fontWeight="1000" fill="currentColor" stroke="var(--label-stroke)" strokeWidth="1.5" className="select-none pointer-events-none tracking-tighter text-slate-200/50 dark:text-orange-950/20 [--label-stroke:white] dark:[--label-stroke:black]">SUDESTE</text>
                  <text x="190" y="440" fontSize="36" fontWeight="1000" fill="currentColor" stroke="var(--label-stroke)" strokeWidth="1.5" className="select-none pointer-events-none tracking-tighter text-slate-200/50 dark:text-orange-950/20 [--label-stroke:white] dark:[--label-stroke:black]">SUL</text>
                  
                  {/* UF labels */}
                  <text
                    x={resolved.x}
                    y={resolved.y + 1.2}
                    textAnchor="middle"
                    dominantBaseline="middle"
                    fontSize="10"
                    fontWeight="1000"
                    fill="currentColor"
                    className="pointer-events-none select-none transition-all duration-200 text-slate-100 dark:text-slate-900"
                    style={{ filter: isHovered || isSelected ? 'none' : 'drop-shadow(0 0 2px rgba(0,0,0,0.5))' }}
                  >
                    {state.uf}
                  </text>
                  
                  {/* Count badge for states with clients */}
                  {count > 0 && (
                    <g opacity={isFiltered ? 0.4 : 1}>
                      <circle
                        cx={resolved.x + 11}
                        cy={resolved.y - 7}
                        r={5.5}
                        fill="hsl(var(--success))"
                        stroke="hsl(var(--background))"
                        strokeWidth={1}
                      />
                      <text
                        x={resolved.x + 11}
                        y={resolved.y - 6.5}
                        textAnchor="middle"
                        dominantBaseline="middle"
                        fontSize="6.5"
                        fontWeight="bold"
                        fill="white"
                        className="pointer-events-none"
                      >
                        {count > 99 ? "+" : count}
                      </text>
                    </g>
                  )}
                </g>
              </TooltipTrigger>
              <TooltipContent side="top" className="p-3 min-w-[160px] z-50 bg-black/90 text-white border-white/10" sideOffset={8}>
                <div className="space-y-2">
                  <div className="flex items-center justify-between border-b border-white/10 pb-1.5 mb-1.5">
                    <p className="font-bold text-sm tracking-tight">{UF_NAMES[state.uf] || state.uf}</p>
                    <Badge variant="outline" className="h-5 text-[10px] border-white/30 text-white">{state.uf}</Badge>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-0.5">
                      <p className="text-[10px] text-zinc-400 uppercase font-bold tracking-widest">Clientes</p>
                      <p className="text-sm font-black">{count}</p>
                    </div>
                    {revenue > 0 && (
                      <div className="space-y-0.5">
                        <p className="text-[10px] text-zinc-400 uppercase font-bold tracking-widest">Prêmio</p>
                        <p className="text-sm font-black text-primary-foreground/90">
                          {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', notation: 'compact' }).format(revenue)}
                        </p>
                      </div>
                    )}
                  </div>

                  <p className="text-[10px] text-primary mt-1 font-semibold flex items-center gap-1 animate-pulse">
                    <MapPinned className="h-3 w-3" /> Clique para detalhar
                  </p>
                </div>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        );
      })}
    </g>
  );
}

// City pin for detailed view
function CityPin({ 
  location, 
  isHovered,
  selectedState,
  onHover,
}: { 
  location: ClientLocationData;
  isHovered: boolean;
  selectedState: string | null;
  onHover: (key: string | null) => void;
}) {
  const key = `${location.uf}-${location.cidade}`;
  const size = Math.min(Math.max(location.count + 2, 4), 10);
  const isFiltered = selectedState !== null && selectedState !== location.uf;
  
  return (
    <TooltipProvider>
      <Tooltip open={isHovered}>
        <TooltipTrigger asChild>
          <g 
            onMouseEnter={() => onHover(key)}
            onMouseLeave={() => onHover(null)}
            style={{ cursor: 'pointer' }}
            opacity={isFiltered ? 0.2 : 1}
          >
            {/* Glow/Pulse effect */}
            <circle
              cx={location.x}
              cy={location.y}
              r={size + 6}
              fill="hsl(var(--primary))"
              opacity={isHovered ? 0.4 : 0.15}
              className="animate-pulse transition-all duration-500"
            />
            {/* Shadow */}
            <circle
              cx={location.x}
              cy={location.y + 1}
              r={size}
              fill="black"
              opacity={0.3}
              className="transition-all duration-200"
            />
            {/* Marker */}
            <circle
              cx={location.x}
              cy={location.y}
              r={size}
              fill="hsl(var(--primary))"
              opacity={isHovered ? 1 : 0.9}
              stroke="white"
              strokeWidth="2"
              className="transition-all duration-200 shadow-xl"
              style={{
                filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.3))'
              }}
            />
            {location.count > 1 && (
              <text
                x={location.x}
                y={location.y + 2.5}
                textAnchor="middle"
                fontSize="7"
                fontWeight="900"
                fill="white"
                className="pointer-events-none"
              >
                {location.count}
              </text>
            )}
          </g>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-[200px] z-50 bg-primary text-primary-foreground border-none">
          <div className="space-y-1">
            <p className="font-black uppercase tracking-tighter text-sm">{location.cidade}, {location.uf}</p>
            <p className="text-[10px] font-bold opacity-90">{location.count} CLIENTE{location.count > 1 ? 'S' : ''}</p>
            {location.profissoes.length > 0 && (
              <p className="text-[10px] opacity-80 italic">
                {location.profissoes.slice(0, 2).join(', ')}
              </p>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

export function BrazilMapPanel() {
  const [filters, setFilters] = useState<MapFilters>({ profissao: null, status: null });
  const [hoveredState, setHoveredState] = useState<string | null>(null);
  const [hoveredCity, setHoveredCity] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"states" | "cities">("states");
  
  // Get global dashboard filter (optional - works standalone too)
  const dashboardFilter = useDashboardFilterOptional();
  const selectedUF = dashboardFilter?.filters.selectedUF ?? null;
  
  const { data: mapData, isLoading } = useClientMapData(filters);
  const { data: professions = [] } = useClientProfessions();

  const handleFilterChange = (key: keyof MapFilters, value: string | null) => {
    setFilters(prev => ({ ...prev, [key]: value === "all" ? null : value }));
  };

  const handleStateClick = useCallback((uf: string) => {
    if (dashboardFilter) {
      dashboardFilter.toggleUF(uf);
    }
  }, [dashboardFilter]);

  const handleClearFilter = useCallback(() => {
    if (dashboardFilter) {
      dashboardFilter.clearFilters();
    }
  }, [dashboardFilter]);

  return (
    <Card className="col-span-full lg:col-span-2 border-primary/20 bg-gradient-to-br from-card to-card/80 shadow-2xl relative overflow-visible group">
      {/* Decorative background element */}
      <div className="absolute -top-12 -right-12 w-48 h-48 bg-primary/5 rounded-full blur-3xl pointer-events-none group-hover:bg-primary/10 transition-colors duration-700" />
      
      <CardHeader className="pb-2 relative z-10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-500/20 shadow-[0_0_20px_rgba(59,130,246,0.3)] border border-blue-500/30">
              <MapPinned className="h-6 w-6 text-blue-500" />
            </div>
            <div>
              <CardTitle className="text-xl font-black tracking-tight text-foreground dark:text-foreground flex items-center gap-3">
                Distribuição Territorial
                <Badge className="bg-blue-600/10 text-blue-500 border-blue-500/20 px-3 py-1 text-xs font-black uppercase tracking-widest">
                  {mapData?.totalClients || 0} Clientes Mapeados
                </Badge>
              </CardTitle>
              <p className="text-sm font-medium text-muted-foreground uppercase tracking-widest mt-0.5 opacity-70">
                {selectedUF 
                  ? `Filtrando por ${UF_NAMES[selectedUF] || selectedUF}` 
                  : 'Clique nos estados para detalhamento regional'
                }
              </p>
            </div>
          </div>
          
          <div className="flex flex-wrap items-center gap-2">
            {/* Clear filter button */}
            {selectedUF && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleClearFilter}
                className="h-8 text-xs gap-1"
              >
                <X className="h-3 w-3" />
                Limpar filtro
              </Button>
            )}
            
            <Select 
              value={viewMode} 
              onValueChange={(v: "states" | "cities") => setViewMode(v)}
            >
              <SelectTrigger className="w-[120px] h-8 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="states">Por Estado</SelectItem>
                <SelectItem value="cities">Por Cidade</SelectItem>
              </SelectContent>
            </Select>
            
            <Select 
              value={filters.status || "all"} 
              onValueChange={(v) => handleFilterChange("status", v)}
            >
              <SelectTrigger className="w-[110px] h-8 text-xs">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="ativo">Ativos</SelectItem>
                <SelectItem value="inativo">Inativos</SelectItem>
                <SelectItem value="prospecto">Prospectos</SelectItem>
              </SelectContent>
            </Select>
            
            <Select 
              value={filters.profissao || "all"} 
              onValueChange={(v) => handleFilterChange("profissao", v)}
            >
              <SelectTrigger className="w-[130px] h-8 text-xs">
                <SelectValue placeholder="Profissão" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                <SelectItem value="Médico">Médico</SelectItem>
                <SelectItem value="Dentista">Dentista</SelectItem>
                {professions
                  .filter(p => p !== "Médico" && p !== "Dentista")
                  .slice(0, 10)
                  .map(p => (
                    <SelectItem key={p} value={p || "other"}>{p}</SelectItem>
                  ))
                }
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-2 overflow-visible">
        {isLoading ? (
          <div className="flex items-center justify-center h-[420px]">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="relative overflow-visible p-6 sm:p-14 bg-slate-950 dark:bg-white rounded-[3rem] border-4 border-primary/40 mt-6 shadow-2xl ring-8 ring-black/5">
            {/* Technical grid overlay for texture */}
            <div className="absolute inset-0 rounded-[3rem] opacity-[0.03] pointer-events-none" style={{ 
              backgroundImage: 'radial-gradient(circle, currentColor 1px, transparent 1px)',
              backgroundSize: '25px 25px'
            }} />
            {/* Map container with proper aspect ratio and responsive padding */}
            <div className="w-full flex justify-center overflow-visible p-4 sm:p-8 mb-4 sm:mb-8">
              <svg 
                viewBox={BRAZIL_MAP_VIEWBOX}
                className="w-full max-w-[720px] h-auto min-h-[520px] sm:min-h-[620px]"
                preserveAspectRatio="xMidYMid meet"
                style={{ overflow: 'visible' }}
              >
                <BrazilSVG 
                  stateData={mapData?.byState || {}} 
                  hoveredState={hoveredState}
                  selectedState={selectedUF}
                  onHover={setHoveredState}
                  onClick={handleStateClick}
                />
                
                {viewMode === "states" ? (
                  <StateLabels 
                    stateData={mapData?.byState || {}}
                    hoveredState={hoveredState}
                    selectedState={selectedUF}
                    onHover={setHoveredState}
                    onClick={handleStateClick}
                  />
                ) : (
                  mapData?.locations.map((loc) => (
                    <CityPin
                      key={`${loc.uf}-${loc.cidade}`}
                      location={loc}
                      isHovered={hoveredCity === `${loc.uf}-${loc.cidade}`}
                      selectedState={selectedUF}
                      onHover={setHoveredCity}
                    />
                  ))
                )}
              </svg>
            </div>

            {/* Map UI Overlays */}
            <div className="absolute top-2 right-2 flex flex-col items-end gap-3 pointer-events-none">
              {/* Legend */}
              <div className="pointer-events-auto">
                <MapLegend 
                  maxCount={Math.max(...Object.values(mapData?.byState || {}).map(d => d.count), 0)} 
                />
              </div>

              {/* Summary stats */}
              <div className="bg-card/90 backdrop-blur-md border border-border shadow-md rounded-xl p-3 pointer-events-auto min-w-[140px]">
                <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest mb-2 border-b border-border/50 pb-1">Visão Geral</p>
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <Users className="h-3.5 w-3.5 text-primary" />
                      <span className="text-xs font-bold text-muted-foreground uppercase tracking-tighter">clientes</span>
                    </div>
                    <span className="font-black text-sm">{mapData?.totalClients || 0}</span>
                  </div>
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <DollarSign className="h-3.5 w-3.5 text-emerald-500" />
                      <span className="text-xs font-bold text-muted-foreground uppercase tracking-tighter">prêmio</span>
                    </div>
                    <span className="font-black text-sm text-emerald-600 dark:text-emerald-400">
                      {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', notation: 'compact' }).format(mapData?.totalRevenue || 0)}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Hovered state details - centered or top-left */}
            {hoveredState && mapData?.byState[hoveredState] && (
              <div className="absolute bottom-4 left-4 bg-card/95 backdrop-blur-xl border-2 border-primary/20 rounded-2xl p-4 shadow-2xl max-w-[240px] z-20 animate-in zoom-in-95 fade-in duration-200">
                <div className="flex items-center justify-between mb-2">
                  <p className="font-black text-sm uppercase tracking-tight truncate mr-2">{UF_NAMES[hoveredState] || hoveredState}</p>
                  <Badge variant="outline" className="h-5 text-[10px] font-bold border-primary/20 bg-primary/5 text-primary">
                    {hoveredState}
                  </Badge>
                </div>
                
                <div className="grid grid-cols-2 gap-2 mb-3">
                  <div className="bg-muted/30 p-1.5 rounded-lg">
                    <p className="text-[9px] text-muted-foreground font-bold uppercase tracking-widest leading-tight">Total</p>
                    <p className="text-sm font-black ">{mapData.byState[hoveredState].count} <span className="text-[9px] font-normal opacity-70">cli</span></p>
                  </div>
                  <div className="bg-primary/5 p-1.5 rounded-lg border border-primary/10">
                    <p className="text-[9px] text-primary/70 font-bold uppercase tracking-widest leading-tight">Receita</p>
                    <p className="text-sm font-black text-primary">
                      {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', notation: 'compact' }).format(mapData.byState[hoveredState].revenue)}
                    </p>
                  </div>
                </div>

                {mapData.byState[hoveredState].topCities.length > 0 && (
                  <div className="space-y-1.5">
                    <p className="text-[10px] font-black uppercase text-muted-foreground/80 flex items-center gap-1">
                      <MapPin className="h-2.5 w-2.5" /> Maiores Cidades
                    </p>
                    <div className="space-y-1">
                      {mapData.byState[hoveredState].topCities
                        .sort((a, b) => b.count - a.count)
                        .slice(0, 3)
                        .map(city => (
                          <div key={city.name} className="flex justify-between items-center text-[11px] group">
                            <span className="truncate mr-2 font-medium group-hover:text-primary transition-colors">{city.name}</span>
                            <div className="flex items-center gap-1.5">
                              <span className="text-[10px] text-muted-foreground">{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', notation: 'compact' }).format(city.revenue)}</span>
                              <Badge variant="secondary" className="h-4 text-[9px] px-1 shrink-0 bg-muted/50 border-none font-bold">
                                {city.count}
                              </Badge>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                )}
              </div>
            )}

          </div>
        )}
      </CardContent>
    </Card>
  );
}
