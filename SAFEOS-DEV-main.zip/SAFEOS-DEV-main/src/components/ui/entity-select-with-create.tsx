import { useState, useCallback, ReactNode } from "react";
import { Plus, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

// ============================================================
// TYPES & INTERFACES
// ============================================================

export interface EntityOption {
  id: string;
  label: string;
}

export interface EntityField {
  name: string;
  label: string;
  type?: "text" | "email" | "tel" | "number";
  placeholder?: string;
  required?: boolean;
  validation?: (value: string) => string | null; // Return error message or null
}

export interface EntitySelectWithCreateProps<T extends Record<string, string>> {
  /** Current selected value (entity ID) */
  value: string;
  /** Callback when value changes */
  onChange: (id: string) => void;
  /** List of available options */
  options: EntityOption[];
  /** Placeholder text for select */
  placeholder?: string;
  /** Label for the field */
  label?: string;
  /** Whether the field is required */
  required?: boolean;
  /** Error message to display */
  error?: string;
  /** Whether the select is disabled */
  disabled?: boolean;
  /** Modal configuration */
  createModal: {
    /** Modal title */
    title: string;
    /** Modal description */
    description?: string;
    /** Fields to render in creation form */
    fields: EntityField[];
    /** Function to create the entity - must return the created entity with id */
    onCreate: (data: T) => Promise<{ id: string } | null>;
    /** Optional: Check for duplicates before creating */
    checkDuplicate?: (data: T, options: EntityOption[]) => EntityOption | null;
    /** Button text for add new */
    addButtonText?: string;
    /** Button text for create action */
    createButtonText?: string;
  };
  /** Callback after successful creation (e.g., to invalidate queries) */
  onCreated?: () => Promise<void> | void;
  /** Custom className for the container */
  className?: string;
}

// ============================================================
// COMPONENT
// ============================================================

export function EntitySelectWithCreate<T extends Record<string, string>>({
  value,
  onChange,
  options,
  placeholder = "Selecione uma opção",
  label,
  required = false,
  error,
  disabled = false,
  createModal,
  onCreated,
  className,
}: EntitySelectWithCreateProps<T>) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  // Initialize form data when modal opens
  const openModal = useCallback(() => {
    const initialData: Record<string, string> = {};
    createModal.fields.forEach((field) => {
      initialData[field.name] = "";
    });
    setFormData(initialData);
    setFieldErrors({});
    setIsModalOpen(true);
  }, [createModal.fields]);

  // Close modal and reset state
  const closeModal = useCallback(() => {
    setIsModalOpen(false);
    setFormData({});
    setFieldErrors({});
  }, []);

  // Update a single field value
  const updateField = useCallback((name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
    // Clear error when user types
    setFieldErrors((prev) => {
      if (prev[name]) {
        const updated = { ...prev };
        delete updated[name];
        return updated;
      }
      return prev;
    });
  }, []);

  // Validate all fields
  const validateFields = useCallback((): boolean => {
    const errors: Record<string, string> = {};

    createModal.fields.forEach((field) => {
      const value = formData[field.name]?.trim() || "";

      // Required validation
      if (field.required && !value) {
        errors[field.name] = `${field.label} é obrigatório`;
        return;
      }

      // Email validation
      if (field.type === "email" && value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
          errors[field.name] = "E-mail inválido";
          return;
        }
      }

      // Custom validation
      if (field.validation && value) {
        const customError = field.validation(value);
        if (customError) {
          errors[field.name] = customError;
        }
      }
    });

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  }, [createModal.fields, formData]);

  // Handle create action
  const handleCreate = useCallback(async () => {
    // Validate fields
    if (!validateFields()) {
      toast.error("Preencha os campos corretamente");
      return;
    }

    // Prepare data
    const data = createModal.fields.reduce((acc, field) => {
      acc[field.name as keyof T] = formData[field.name]?.trim() as T[keyof T];
      return acc;
    }, {} as T);

    // Check for duplicates
    if (createModal.checkDuplicate) {
      const existing = createModal.checkDuplicate(data, options);
      if (existing) {
        // Select the existing one instead
        onChange(existing.id);
        closeModal();
        toast.info(`"${existing.label}" já existe e foi selecionado`);
        return;
      }
    }

    setIsCreating(true);

    try {
      // Create entity
      const result = await createModal.onCreate(data);

      if (!result || !result.id) {
        throw new Error("Erro ao criar: ID não retornado");
      }

      // Call onCreated callback (e.g., to invalidate queries)
      if (onCreated) {
        await onCreated();
      }

      // Select the new entity
      onChange(result.id);

      // Close modal with success feedback
      closeModal();
      toast.success("Criado com sucesso");
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : "Erro ao criar";
      toast.error(message);
      // Keep modal open so user can retry
    } finally {
      setIsCreating(false);
    }
  }, [
    validateFields,
    createModal,
    formData,
    options,
    onChange,
    closeModal,
    onCreated,
  ]);

  return (
    <div className={cn("space-y-2", className)}>
      {label && (
        <Label className={cn(error && "text-destructive")}>
          {label}
          {required && " *"}
        </Label>
      )}

      <div className="space-y-2">
        <Select value={value} onValueChange={onChange} disabled={disabled}>
          <SelectTrigger className={cn(error && "border-destructive")}>
            <SelectValue placeholder={placeholder} />
          </SelectTrigger>
          <SelectContent className="bg-popover">
            {options.map((option) => (
              <SelectItem key={option.id} value={option.id}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="text-xs gap-1 h-auto p-1"
          onClick={openModal}
          disabled={disabled}
        >
          <Plus className="h-3 w-3" />
          {createModal.addButtonText || "Adicionar novo"}
        </Button>
      </div>

      {error && <p className="text-xs text-destructive">{error}</p>}

      {/* Creation Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{createModal.title}</DialogTitle>
            {createModal.description && (
              <DialogDescription>{createModal.description}</DialogDescription>
            )}
          </DialogHeader>

          <div className="space-y-4 py-4">
            {createModal.fields.map((field) => (
              <div key={field.name} className="space-y-2">
                <Label
                  htmlFor={`create-${field.name}`}
                  className={cn(fieldErrors[field.name] && "text-destructive")}
                >
                  {field.label}
                  {field.required && " *"}
                </Label>
                <Input
                  id={`create-${field.name}`}
                  type={field.type || "text"}
                  value={formData[field.name] || ""}
                  onChange={(e) => updateField(field.name, e.target.value)}
                  placeholder={field.placeholder}
                  className={cn(fieldErrors[field.name] && "border-destructive")}
                  disabled={isCreating}
                />
                {fieldErrors[field.name] && (
                  <p className="text-xs text-destructive">
                    {fieldErrors[field.name]}
                  </p>
                )}
              </div>
            ))}
          </div>

          <div className="flex justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={closeModal}
              disabled={isCreating}
            >
              Cancelar
            </Button>
            <Button
              type="button"
              onClick={handleCreate}
              disabled={isCreating}
            >
              {isCreating ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Criando...
                </>
              ) : (
                createModal.createButtonText || "Criar e selecionar"
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================================
// HELPER: Create a typed entity select configuration
// ============================================================

export function createEntitySelectConfig<T extends Record<string, string>>(
  config: EntitySelectWithCreateProps<T>["createModal"]
): EntitySelectWithCreateProps<T>["createModal"] {
  return config;
}
