import { cn } from "@/lib/utils";

interface SafeOSLogoProps {
  className?: string;
  showText?: boolean;
  size?: "sm" | "md" | "lg";
}

export function SafeOSLogo({ className, showText = true, size = "md" }: SafeOSLogoProps) {
  const sizes = {
    sm: { icon: 28, text: "text-sm" },
    md: { icon: 40, text: "text-base" },
    lg: { icon: 56, text: "text-xl" },
  };

  const { icon, text } = sizes[size];

  return (
    <div className={cn("flex items-center gap-3", className)}>
      <div className="relative">
        <svg
          width={icon}
          height={icon}
          viewBox="0 0 48 48"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="drop-shadow-lg"
        >
          {/* Outer hexagonal shield */}
          <path
            d="M24 2L44 14V34L24 46L4 34V14L24 2Z"
            className="fill-primary"
            stroke="currentColor"
            strokeWidth="0"
          />
          
          {/* Inner glow effect */}
          <path
            d="M24 6L40 16V32L24 42L8 32V16L24 6Z"
            className="fill-primary-foreground/10"
          />
          
          {/* Shield checkmark / safe symbol */}
          <path
            d="M24 8L38 17V31L24 40L10 31V17L24 8Z"
            className="stroke-primary-foreground"
            strokeWidth="1.5"
            fill="none"
          />
          
          {/* Central S shape with circuit pattern */}
          <path
            d="M18 18C18 18 20 16 24 16C28 16 30 18 30 20C30 22 28 23 24 24C20 25 18 26 18 28C18 30 20 32 24 32C28 32 30 30 30 30"
            className="stroke-primary-foreground"
            strokeWidth="2.5"
            strokeLinecap="round"
            fill="none"
          />
          
          {/* Tech nodes */}
          <circle cx="18" cy="18" r="1.5" className="fill-primary-foreground" />
          <circle cx="30" cy="30" r="1.5" className="fill-primary-foreground" />
          <circle cx="24" cy="24" r="1" className="fill-primary-foreground/60" />
          
          {/* Pulse ring */}
          <circle
            cx="24"
            cy="24"
            r="18"
            className="stroke-primary-foreground/30"
            strokeWidth="0.5"
            fill="none"
            strokeDasharray="3 3"
          />
        </svg>
        
        {/* Animated pulse effect */}
        <div className="absolute inset-0 rounded-full bg-primary/20 animate-pulse-slow opacity-0" />
      </div>
      
      {showText && (
        <div className="flex flex-col animate-fade-in">
          <span className={cn("font-black tracking-tighter text-foreground uppercase italic", text)}>
            Safe<span className="text-primary font-serif lowercase italic font-light ml-0.5">OS</span>
          </span>
          <span className="text-[10px] font-black text-muted-foreground tracking-[0.2em] uppercase opacity-50 -mt-1 scale-90 origin-left">
            Intelligence
          </span>
        </div>
      )}
    </div>
  );
}
