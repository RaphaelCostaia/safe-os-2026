import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Separator } from "@/components/ui/separator";
import { Filter, X, CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";

export interface ClientFiltersState {
  status: string | null;
  profissao: string | null;
  dateFrom: Date | null;
  dateTo: Date | null;
}

interface ClientFiltersProps {
  filters: ClientFiltersState;
  onFiltersChange: (filters: ClientFiltersState) => void;
  profissoes: string[];
}

const statusOptions = [
  { value: "ativo", label: "Ativo" },
  { value: "prospecto", label: "Prospecto" },
  { value: "inativo", label: "Inativo" },
];

export function ClientFilters({ filters, onFiltersChange, profissoes }: ClientFiltersProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [tempFilters, setTempFilters] = useState<ClientFiltersState>(filters);

  const activeFiltersCount = [
    filters.status,
    filters.profissao,
    filters.dateFrom || filters.dateTo,
  ].filter(Boolean).length;

  const handleApply = () => {
    onFiltersChange(tempFilters);
    setIsOpen(false);
  };

  const handleClear = () => {
    const emptyFilters: ClientFiltersState = {
      status: null,
      profissao: null,
      dateFrom: null,
      dateTo: null,
    };
    setTempFilters(emptyFilters);
    onFiltersChange(emptyFilters);
    setIsOpen(false);
  };

  const handleRemoveFilter = (key: keyof ClientFiltersState) => {
    const newFilters = { ...filters };
    if (key === "dateFrom" || key === "dateTo") {
      newFilters.dateFrom = null;
      newFilters.dateTo = null;
    } else {
      newFilters[key] = null;
    }
    onFiltersChange(newFilters);
    setTempFilters(newFilters);
  };

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" className="gap-2">
            <Filter className="h-4 w-4" />
            Filtros
            {activeFiltersCount > 0 && (
              <Badge variant="secondary" className="ml-1 px-1.5 py-0.5 text-[10px]">
                {activeFiltersCount}
              </Badge>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80" align="start">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-medium">Filtros Avançados</h4>
              {activeFiltersCount > 0 && (
                <Button variant="ghost" size="sm" onClick={handleClear} className="h-7 text-xs">
                  Limpar tudo
                </Button>
              )}
            </div>

            <Separator />

            {/* Status */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Status</label>
              <Select
                value={tempFilters.status || "all"}
                onValueChange={(v) => setTempFilters({ ...tempFilters, status: v === "all" ? null : v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Todos os status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os status</SelectItem>
                  {statusOptions.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Profissão */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Profissão</label>
              <Select
                value={tempFilters.profissao || "all"}
                onValueChange={(v) => setTempFilters({ ...tempFilters, profissao: v === "all" ? null : v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Todas as profissões" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as profissões</SelectItem>
                  {profissoes.map((prof) => (
                    <SelectItem key={prof} value={prof}>
                      {prof}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Período de cadastro */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Período de Cadastro</label>
              <div className="grid grid-cols-2 gap-2">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "justify-start text-left font-normal text-xs h-9",
                        !tempFilters.dateFrom && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-1 h-3 w-3" />
                      {tempFilters.dateFrom ? format(tempFilters.dateFrom, "dd/MM/yy") : "De"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={tempFilters.dateFrom || undefined}
                      onSelect={(date) => setTempFilters({ ...tempFilters, dateFrom: date || null })}
                      locale={ptBR}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>

                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "justify-start text-left font-normal text-xs h-9",
                        !tempFilters.dateTo && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-1 h-3 w-3" />
                      {tempFilters.dateTo ? format(tempFilters.dateTo, "dd/MM/yy") : "Até"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={tempFilters.dateTo || undefined}
                      onSelect={(date) => setTempFilters({ ...tempFilters, dateTo: date || null })}
                      locale={ptBR}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            <Separator />

            <div className="flex justify-end gap-2">
              <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)}>
                Cancelar
              </Button>
              <Button size="sm" onClick={handleApply}>
                Aplicar Filtros
              </Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>

      {/* Active filter badges */}
      {filters.status && (
        <Badge variant="secondary" className="gap-1 pr-1">
          Status: {statusOptions.find(s => s.value === filters.status)?.label}
          <Button
            variant="ghost"
            size="icon"
            className="h-4 w-4 p-0 hover:bg-transparent"
            onClick={() => handleRemoveFilter("status")}
          >
            <X className="h-3 w-3" />
          </Button>
        </Badge>
      )}

      {filters.profissao && (
        <Badge variant="secondary" className="gap-1 pr-1">
          Profissão: {filters.profissao}
          <Button
            variant="ghost"
            size="icon"
            className="h-4 w-4 p-0 hover:bg-transparent"
            onClick={() => handleRemoveFilter("profissao")}
          >
            <X className="h-3 w-3" />
          </Button>
        </Badge>
      )}

      {(filters.dateFrom || filters.dateTo) && (
        <Badge variant="secondary" className="gap-1 pr-1">
          Período: {filters.dateFrom ? format(filters.dateFrom, "dd/MM/yy") : "..."} - {filters.dateTo ? format(filters.dateTo, "dd/MM/yy") : "..."}
          <Button
            variant="ghost"
            size="icon"
            className="h-4 w-4 p-0 hover:bg-transparent"
            onClick={() => handleRemoveFilter("dateFrom")}
          >
            <X className="h-3 w-3" />
          </Button>
        </Badge>
      )}
    </div>
  );
}