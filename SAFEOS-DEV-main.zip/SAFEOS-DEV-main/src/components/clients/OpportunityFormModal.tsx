import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useCreateApolice } from "@/hooks/useApolices";
import { useClients } from "@/hooks/useClients";
import { useProdutos, resolveOrCreateProduto } from "@/hooks/useProdutos";
import { ProdutoCombobox } from "@/components/produtos/ProdutoCombobox";
import { useClientActiveCommissions, useCreateClientCommission } from "@/hooks/useClientCommission";
import { Loader2, Sparkles, Percent, Coins, ShieldCheck, Mail, Calendar, UserCheck } from "lucide-react";
import { toast } from "sonner";

interface OpportunityFormModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  preSelectedClientId?: string | null;
  onSuccess?: () => void;
}

export function OpportunityFormModal({
  open,
  onOpenChange,
  preSelectedClientId,
  onSuccess,
}: OpportunityFormModalProps) {
  const { data: clients } = useClients();
  const { data: produtos } = useProdutos();
  const createApolice = useCreateApolice();
  const createClientCommission = useCreateClientCommission();

  const [formData, setFormData] = useState({
    client_id: "",
    produto_id: "",
    seguradora: "",
    valor_premio: "",
    comissao_prevista_percent: "",
    status_proposta: "em cotação", // em cotação, enviada, em negociação, aceita, recusada
    responsavel_comercial: "",
    data_followup: "",
    notes: "",
  });

  const { data: activeCommissions } = useClientActiveCommissions(formData.client_id);
  const [salvarAcordoIndividual, setSalvarAcordoIndividual] = useState(true);
  const [customProductName, setCustomProductName] = useState("");

  useEffect(() => {
    if (open) {
      setFormData({
        client_id: preSelectedClientId || "",
        produto_id: "",
        seguradora: "",
        valor_premio: "",
        comissao_prevista_percent: "",
        status_proposta: "em cotação",
        responsavel_comercial: "",
        data_followup: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 7 days from now as default
        notes: "",
      });
      setCustomProductName("");
      setSalvarAcordoIndividual(true);
    }
  }, [open, preSelectedClientId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.client_id) {
      toast.error("O campo Cliente é obrigatório");
      return;
    }

    // Resolve product ID if not selected or if custom text was typed
    let finalProdutoId = formData.produto_id;
    if (!finalProdutoId) {
      try {
        const resolved = await resolveOrCreateProduto({
          produtoId: formData.produto_id,
          produtoNome: customProductName || (produtos && produtos.length > 0 ? produtos[0].nome : "Seguro Geral / RCP"),
          seguradora: formData.seguradora || "Porto Seguro",
          comissao_percentual: formData.comissao_prevista_percent || 20,
        });
        finalProdutoId = resolved.id;
      } catch (err) {
        console.warn("Fallback de produto será resolvido pelo hook:", err);
      }
    }

    const docNum = `PROP-${Math.floor(100000 + Math.random() * 900000)}`;
    const todayStr = new Date().toISOString().split('T')[0];
    const nextYearStr = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    // Save as dynamic metadata in observacoes for useCommissionsDashboard hook support!
    const meta = {
      comissao_real_percent: formData.comissao_prevista_percent,
      valor_comissao_real: (
        (parseFloat(formData.valor_premio) || 0) * 
        (parseFloat(formData.comissao_prevista_percent) || 0) / 100
      ).toFixed(2),
      data_renovacao: formData.data_followup,
      status_proposta: formData.status_proposta,
      responsavel_comercial: formData.responsavel_comercial,
      origem: "oportunidade",
    };

    const divider = "-- METADATA_APOLICE_V1 --";
    const commentBlock = formData.notes.trim() || `Oportunidade criada via pipeline em estágio: ${formData.status_proposta}`;
    const finalObservacoes = `${commentBlock}\n\n${divider}\n${JSON.stringify(meta)}`;

    createApolice.mutate({
      numero_apolice: docNum,
      client_id: formData.client_id,
      produto_id: finalProdutoId,
      seguradora: formData.seguradora || "A Definir",
      valor_premio: parseFloat(formData.valor_premio) || 0,
      data_inicio: todayStr,
      data_fim: nextYearStr,
      status: "pendente", // Crucial: sets to pendente so it works as Opportunity / Proposal in calculations!
      observacoes: finalObservacoes,
    }, {
      onSuccess: () => {
        if (salvarAcordoIndividual && formData.comissao_prevista_percent && formData.client_id && finalProdutoId) {
          const pct = parseFloat(formData.comissao_prevista_percent);
          if (!isNaN(pct) && pct > 0) {
            createClientCommission.mutate({
              client_id: formData.client_id,
              produto_id: finalProdutoId,
              model: "percentual",
              percent: pct,
              starts_at: todayStr,
              notes: `Definido individualmente na cotação/proposta #${docNum}`,
            });
          }
        }
        toast.success("Oportunidade de negócio registrada com sucesso!");
        onOpenChange(false);
        if (onSuccess) onSuccess();
      },
      onError: (err) => {
        console.error("Erro ao registrar oportunidade:", err);
        toast.error("Erro ao salvar oportunidade na base de dados");
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md bg-card border-border/70 p-0 shadow-xl">
        <DialogHeader className="p-6 pb-4 border-b border-border/20 bg-indigo-50/10">
          <DialogTitle className="flex items-center gap-2 text-indigo-950 font-bold text-lg">
            <Sparkles className="h-5 w-5 text-indigo-600 animate-pulse" />
            Nova Oportunidade / Proposta
          </DialogTitle>
          <DialogDescription className="text-xs text-muted-foreground mt-1">
            Gere uma cotação, proposta comercial ou oportunidade de venda associada ao cliente selecionado.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 p-6">
          <div className="space-y-3">
            <div className="grid gap-1.5">
              <Label htmlFor="client_id" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Cliente Beneficiário</Label>
              <Select 
                value={formData.client_id} 
                onValueChange={(v) => setFormData({ ...formData, client_id: v })}
                disabled={!!preSelectedClientId}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o cliente" />
                </SelectTrigger>
                <SelectContent>
                  {clients?.map((client) => (
                    <SelectItem key={client.id} value={client.id}>{client.nome}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3 items-start">
              <ProdutoCombobox
                label="Produto de Interesse"
                value={formData.produto_id}
                customValue={customProductName}
                onCustomValueChange={setCustomProductName}
                required={false}
                defaultSeguradora={formData.seguradora || "Porto Seguro"}
                defaultComissao={formData.comissao_prevista_percent || 20}
                onChange={(v, prod, customNome) => {
                  const matchedTerm = activeCommissions?.find(t => t.produto_id === v)
                    || activeCommissions?.find(t => t.produto_id === null);
                  
                  const negotiatedPct = matchedTerm?.percent !== undefined && matchedTerm?.percent !== null
                    ? String(matchedTerm.percent)
                    : (prod?.comissao_percentual !== null && prod?.comissao_percentual !== undefined ? String(prod.comissao_percentual) : "");

                  setFormData({ 
                    ...formData, 
                    produto_id: v,
                    seguradora: prod?.seguradora || formData.seguradora,
                    comissao_prevista_percent: negotiatedPct || formData.comissao_prevista_percent
                  });
                  if (customNome !== undefined) {
                    setCustomProductName(customNome);
                  }
                }}
              />

              <div className="grid gap-1.5">
                <Label htmlFor="seguradora" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Seguradora Provável</Label>
                <Input
                  id="seguradora"
                  value={formData.seguradora}
                  onChange={(e) => setFormData({ ...formData, seguradora: e.target.value })}
                  placeholder="Ex: Porto Seguro"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label htmlFor="valor_premio" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Prêmio Estimado (R$)</Label>
                <Input
                  id="valor_premio"
                  type="number"
                  step="0.01"
                  value={formData.valor_premio}
                  onChange={(e) => setFormData({ ...formData, valor_premio: e.target.value })}
                  placeholder="R$ 3.500"
                />
              </div>

              <div className="grid gap-1.5">
                <Label htmlFor="comissao_prevista_percent" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Comissão Prevista (%)</Label>
                <div className="relative">
                  <Input
                    id="comissao_prevista_percent"
                    type="number"
                    step="0.01"
                    value={formData.comissao_prevista_percent}
                    onChange={(e) => setFormData({ ...formData, comissao_prevista_percent: e.target.value })}
                    placeholder="Ex: 12.5"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-muted-foreground">%</span>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-2.5 p-3 rounded-lg border border-purple-100 bg-purple-50/20">
              <input
                id="salvar_acordo_opp"
                type="checkbox"
                checked={salvarAcordoIndividual}
                onChange={(e) => setSalvarAcordoIndividual(e.target.checked)}
                className="mt-1 h-4 w-4 rounded border-gray-300 text-purple-600 focus:ring-purple-500 accent-purple-600 cursor-pointer"
              />
              <div className="grid gap-0.5">
                <Label htmlFor="salvar_acordo_opp" className="text-xs font-semibold text-purple-950 cursor-pointer select-none">
                  Sincronizar Acordo de Comissão com o Cliente
                </Label>
                <p className="text-[10px] text-muted-foreground select-none">
                  Marca este percentual como a negociação individual ativa para este cliente neste produto, atualizando futuros cálculos automaticamente.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label htmlFor="status_proposta" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Status da Proposta</Label>
                <Select 
                  value={formData.status_proposta} 
                  onValueChange={(v) => setFormData({ ...formData, status_proposta: v })}
                >
                  <SelectTrigger className="text-xs font-semibold">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="em cotação">Em Cotação 📊</SelectItem>
                    <SelectItem value="enviada">Enviada ao cliente ✉️</SelectItem>
                    <SelectItem value="em negociação">Em Negociação 🗣️</SelectItem>
                    <SelectItem value="aceita">Aceita (Passar a Vigente) 🎉</SelectItem>
                    <SelectItem value="recusada">Recusada / Baixada</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-1.5">
                <Label htmlFor="data_followup" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Data para Follow-Up</Label>
                <Input
                  id="data_followup"
                  type="date"
                  value={formData.data_followup}
                  onChange={(e) => setFormData({ ...formData, data_followup: e.target.value })}
                />
              </div>
            </div>

            <div className="grid gap-1.5">
              <Label htmlFor="responsavel_comercial" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Responsável Comercial</Label>
              <Input
                id="responsavel_comercial"
                value={formData.responsavel_comercial}
                onChange={(e) => setFormData({ ...formData, responsavel_comercial: e.target.value })}
                placeholder="Ex: Henrique - Executivo de Vendas"
              />
            </div>

            <div className="grid gap-1.5">
              <Label htmlFor="notes" className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Anotações Internas / Escopo</Label>
              <Input
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Ex: Cliente tem interesse em cobrir riscos cibernéticos na clínica"
              />
            </div>
          </div>

          <DialogFooter className="pt-4 border-t border-border/10 flex gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} size="sm">
              Descartar
            </Button>
            <Button type="submit" size="sm" className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold flex gap-1.5" disabled={createApolice.isPending}>
              {createApolice.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
              Registrar Oportunidade
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
