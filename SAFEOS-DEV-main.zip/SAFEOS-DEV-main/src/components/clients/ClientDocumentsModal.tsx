import { useState, useRef } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Paperclip, 
  Upload, 
  FileText, 
  Image, 
  File, 
  Download, 
  Trash2, 
  Eye,
  Clock,
  Loader2,
  AlertCircle
} from "lucide-react";
import { cn } from "@/lib/utils";
import { 
  useClientDocuments, 
  useUploadClientDocument, 
  useDeleteClientDocument,
  useDocumentUrl,
  formatFileSize 
} from "@/hooks/useClientDocuments";
import { DocumentPreviewModal } from "./DocumentPreviewModal";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";

interface ClientDocumentsModalProps {
  clientId: string;
  clientName: string;
  trigger?: React.ReactNode;
}

const documentTypes = [
  { value: "identidade", label: "Identidade" },
  { value: "apolice", label: "Apólice" },
  { value: "comprovante", label: "Comprovante" },
  { value: "contrato", label: "Contrato" },
  { value: "outro", label: "Outro" },
];

const typeConfig: Record<string, { label: string; color: string }> = {
  identidade: { label: "Identidade", color: "bg-primary/10 text-primary" },
  apolice: { label: "Apólice", color: "bg-success/10 text-success" },
  comprovante: { label: "Comprovante", color: "bg-warning/10 text-warning" },
  contrato: { label: "Contrato", color: "bg-info/10 text-info" },
  outro: { label: "Outro", color: "bg-secondary text-secondary-foreground" },
};

const getFileIcon = (fileName: string) => {
  const ext = fileName.split('.').pop()?.toLowerCase();
  if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext || '')) {
    return Image;
  }
  if (ext === 'pdf') {
    return FileText;
  }
  return File;
};

export function ClientDocumentsModal({ clientId, clientName, trigger }: ClientDocumentsModalProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedType, setSelectedType] = useState("outro");
  const [isDragging, setIsDragging] = useState(false);
  const [loadingDocId, setLoadingDocId] = useState<string | null>(null);
  const [previewDoc, setPreviewDoc] = useState<{ url: string; name: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: documents = [], isLoading, error } = useClientDocuments(clientId);
  const uploadDocument = useUploadClientDocument();
  const deleteDocument = useDeleteClientDocument();
  const getDocumentUrl = useDocumentUrl();

  const handleFileSelect = (files: FileList | null) => {
    if (!files) return;
    
    Array.from(files).forEach(file => {
      // Validar tamanho (máximo 10MB)
      if (file.size > 10 * 1024 * 1024) {
        toast.error(`${file.name}: Arquivo muito grande (máx. 10MB)`);
        return;
      }
      
      uploadDocument.mutate({
        clientId,
        file,
        tipo: selectedType,
      });
    });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileSelect(e.dataTransfer.files);
  };

  const handleDelete = (docId: string, url: string) => {
    if (confirm("Tem certeza que deseja excluir este documento?")) {
      deleteDocument.mutate({ id: docId, clientId, url });
    }
  };

  const handleView = (doc: { url: string; nome: string }) => {
    // Open in-app preview modal instead of new tab
    setPreviewDoc({ url: doc.url, name: doc.nome });
  };

  const handleDownload = async (docId: string, url: string, fileName: string) => {
    setLoadingDocId(docId);
    try {
      const signedUrl = await getDocumentUrl.mutateAsync(url);
      
      const response = await fetch(signedUrl);
      if (!response.ok) {
        throw new Error("Falha ao baixar arquivo");
      }
      
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(downloadUrl);
      
      toast.success("Download iniciado");
    } catch (err) {
      console.error("Erro ao baixar documento:", err);
      toast.error("Não foi possível baixar o documento. Tente novamente.");
    } finally {
      setLoadingDocId(null);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary">
            <Paperclip className="h-4 w-4" />
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Paperclip className="h-5 w-5 text-primary" />
            Documentos - {clientName}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Upload Area */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Tipo do documento" />
                </SelectTrigger>
                <SelectContent>
                  {documentTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div 
              className={cn(
                "border-2 border-dashed rounded-lg p-6 text-center transition-colors cursor-pointer",
                isDragging 
                  ? "border-primary bg-primary/5" 
                  : "border-border/50 hover:border-primary/50 hover:bg-primary/5"
              )}
              onClick={() => fileInputRef.current?.click()}
              onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
            >
              {uploadDocument.isPending ? (
                <Loader2 className="h-8 w-8 mx-auto mb-2 text-primary animate-spin" />
              ) : (
                <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
              )}
              <p className="text-sm font-medium">
                {uploadDocument.isPending ? "Enviando..." : "Clique ou arraste arquivos"}
              </p>
              <p className="text-xs text-muted-foreground mt-1">PDF, JPG, PNG até 10MB</p>
            </div>
            
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".pdf,.jpg,.jpeg,.png,.gif,.doc,.docx"
              className="hidden"
              onChange={(e) => handleFileSelect(e.target.files)}
            />
          </div>

          {/* Error State */}
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
              <AlertCircle className="h-4 w-4" />
              <span>Erro ao carregar documentos. Tente novamente.</span>
            </div>
          )}

          {/* Documents List */}
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-muted-foreground">
              {documents.length} documento{documents.length !== 1 ? 's' : ''}
            </p>
          </div>

          <ScrollArea className="h-[300px] pr-4">
            {isLoading ? (
              <div className="space-y-2">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : documents.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Paperclip className="h-10 w-10 mx-auto mb-2 opacity-30" />
                <p className="text-sm">Nenhum documento</p>
                <p className="text-xs">Faça upload de documentos do cliente</p>
              </div>
            ) : (
              <div className="space-y-2">
                {documents.map((doc) => {
                  const FileIcon = getFileIcon(doc.nome);
                  const config = typeConfig[doc.tipo] || typeConfig.outro;
                  const isLoadingThis = loadingDocId === doc.id;
                  
                  return (
                    <div
                      key={doc.id}
                      className="flex items-center gap-3 p-3 rounded-lg border border-border/50 bg-card hover:bg-secondary/20 transition-colors group"
                    >
                      <div className={cn(
                        "p-2 rounded-lg",
                        doc.nome.endsWith('.pdf') ? "bg-destructive/10" : 
                        doc.nome.match(/\.(jpg|jpeg|png|gif|webp)$/i) ? "bg-success/10" : "bg-secondary"
                      )}>
                        <FileIcon className={cn(
                          "h-5 w-5",
                          doc.nome.endsWith('.pdf') ? "text-destructive" : 
                          doc.nome.match(/\.(jpg|jpeg|png|gif|webp)$/i) ? "text-success" : "text-muted-foreground"
                        )} />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{doc.nome}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className={cn("text-[10px] px-1.5", config.color)}>
                            {config.label}
                          </Badge>
                          <span className="text-[10px] text-muted-foreground">
                            {formatFileSize(doc.tamanho)}
                          </span>
                          <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                            <Clock className="h-2.5 w-2.5" />
                            {format(new Date(doc.created_at), "dd/MM/yyyy", { locale: ptBR })}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-7 w-7"
                          onClick={() => handleView(doc)}
                          title="Visualizar"
                        >
                          <Eye className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          variant="ghost" 
                          size="icon" 
                          className="h-7 w-7"
                          onClick={() => handleDownload(doc.id, doc.url, doc.nome)}
                          disabled={isLoadingThis}
                        >
                          <Download className="h-3.5 w-3.5" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-7 w-7 text-destructive hover:text-destructive"
                          onClick={() => handleDelete(doc.id, doc.url)}
                          disabled={deleteDocument.isPending || isLoadingThis}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </ScrollArea>
        </div>
      </DialogContent>

      {/* Document Preview Modal */}
      <DocumentPreviewModal
        open={!!previewDoc}
        onOpenChange={(open) => !open && setPreviewDoc(null)}
        documentUrl={previewDoc?.url || ""}
        documentName={previewDoc?.name || ""}
      />
    </Dialog>
  );
}