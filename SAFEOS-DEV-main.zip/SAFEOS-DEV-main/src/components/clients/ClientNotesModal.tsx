import { useState, useRef } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { MessageSquare, Plus, Clock, User, Trash2, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { 
  useClientNotes, 
  useCreateClientNote, 
  useDeleteClientNote 
} from "@/hooks/useClientNotes";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface ClientNotesModalProps {
  clientId: string;
  clientName: string;
  trigger?: React.ReactNode;
}

export function ClientNotesModal({ clientId, clientName, trigger }: ClientNotesModalProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [newNote, setNewNote] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const { data: notes = [], isLoading } = useClientNotes(clientId);
  const createNote = useCreateClientNote();
  const deleteNote = useDeleteClientNote();

  const handleAddNote = () => {
    if (!newNote.trim()) return;
    
    createNote.mutate(
      { client_id: clientId, conteudo: newNote },
      { onSuccess: () => setNewNote("") }
    );
  };

  const handleDelete = (noteId: string) => {
    deleteNote.mutate({ id: noteId, clientId });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary">
            <MessageSquare className="h-4 w-4" />
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-primary" />
            Anotações - {clientName}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* New Note Input */}
          <div className="space-y-3 p-4 rounded-lg bg-secondary/30 border border-border/50">
            <Textarea
              ref={textareaRef}
              placeholder="Adicionar nova anotação..."
              value={newNote}
              onChange={(e) => setNewNote(e.target.value)}
              className="min-h-[80px] resize-none"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && e.ctrlKey) {
                  handleAddNote();
                }
              }}
            />
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">
                Ctrl+Enter para enviar
              </span>
              <Button 
                size="sm" 
                onClick={handleAddNote} 
                disabled={!newNote.trim() || createNote.isPending}
              >
                {createNote.isPending ? (
                  <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                ) : (
                  <Plus className="h-4 w-4 mr-1" />
                )}
                Adicionar
              </Button>
            </div>
          </div>

          {/* Notes List */}
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-muted-foreground">
              {notes.length} anotação{notes.length !== 1 ? 'ões' : ''}
            </p>
          </div>

          <ScrollArea className="h-[300px] pr-4">
            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-24 w-full" />
                ))}
              </div>
            ) : notes.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <MessageSquare className="h-10 w-10 mx-auto mb-2 opacity-30" />
                <p className="text-sm">Nenhuma anotação</p>
                <p className="text-xs">Adicione anotações sobre o cliente</p>
              </div>
            ) : (
              <div className="space-y-3">
                {notes.map((note) => (
                  <div
                    key={note.id}
                    className="p-3 rounded-lg border border-border/50 bg-card hover:bg-secondary/20 transition-colors group"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-sm flex-1">{note.conteudo}</p>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive"
                        onClick={() => handleDelete(note.id)}
                        disabled={deleteNote.isPending}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground mt-2">
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {format(new Date(note.created_at), "dd MMM yyyy, HH:mm", { locale: ptBR })}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
}
