import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  User, 
  Save, 
  HelpCircle, 
  Percent, 
  AlertCircle, 
  MapPin, 
  Loader2, 
  Briefcase, 
  Contact, 
  Building2, 
  Tag, 
  CheckCircle2,
  Phone,
  Mail,
  HeartIcon,
  CreditCard
} from "lucide-react";
import { UF_LIST, isValidUF, normalizeUF, normalizeCity } from "@/data/brazilGeoData";
import { useViaCep } from "@/hooks/useViaCep";
import { safeParseMetadata, updateObservationsCrmStage, type Client, type ClientInsert, type ClientUpdate } from "@/hooks/useClients";
import { toast } from "sonner";

const PRODUCT_OPTIONS = [
  { id: "rcp_medico", label: "RCP Médico" },
  { id: "seguro_vida", label: "Seguro de vida" },
  { id: "seguro_saude", label: "Seguro saúde" },
  { id: "seguro_empresarial", label: "Seguro empresarial" },
  { id: "seguro_clinica", label: "Seguro clínica/consultório" },
  { id: "seguro_cyber", label: "Seguro cyber" },
  { id: "seguro_equipamentos", label: "Seguro equipamentos" },
  { id: "outros", label: "Outros" },
];

interface ClientFormModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: ClientInsert | ClientUpdate, commissionPercent?: number) => void;
  editData?: Client | null;
  isLoading?: boolean;
}

export function ClientFormModal({
  open,
  onOpenChange,
  onSubmit,
  editData,
  isLoading,
}: ClientFormModalProps) {
  const [formData, setFormData] = useState<Partial<ClientInsert>>({
    nome: "",
    email: "",
    telefone: "",
    cpf_cnpj: "",
    tipo_pessoa: "fisica",
    profissao: "",
    data_nascimento: "",
    endereco: "",
    cidade: "",
    estado: "",
    cep: "",
    status: "prospecto",
    observacoes: "",
  });

  // Basic and metadata nested fields in observacoes
  const [crmUf, setCrmUf] = useState("");
  const [especialidade, setEspecialidade] = useState("");
  const [tipoAtuacao, setTipoAtuacao] = useState(""); // autônomo, PJ, clínica própria, hospital, residência, plantonista, empresa
  const [nomeClinica, setNomeClinica] = useState("");
  const [cnpjVinculado, setCnpjVinculado] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [origemLead, setOrigemLead] = useState("");
  const [canalAquisicao, setCanalAquisicao] = useState("");
  const [responsavelComercial, setResponsavelComercial] = useState("");
  const [tags, setTags] = useState("");
  const [produtosInteresse, setProdutosInteresse] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState("basico");

  // Commission and payment terms fields
  const [commissionPercent, setCommissionPercent] = useState<string>("");
  const [commissionError, setCommissionError] = useState<string>("");
  const [formaPagamentoPreferencial, setFormaPagamentoPreferencial] = useState<string>("parcelado");
  const [parcelasPreferenciais, setParcelasPreferenciais] = useState<string>("11");
  const [meioPagamentoPreferencial, setMeioPagamentoPreferencial] = useState<string>("boleto");

  const [locationErrors, setLocationErrors] = useState<{ cidade?: string; estado?: string }>({});
  const [cepFilled, setCepFilled] = useState(false);
  
  const { fetchAddress, formatCep, isLoading: isLoadingCep, resetLastFetched } = useViaCep();

  useEffect(() => {
    if (editData) {
      // Parse metadata from observacoes
      const rawObs = editData.observacoes || "";
      const divider = "-- METADATA_JSON_V1 --";
      const parts = rawObs.split(divider);
      const noteContent = (parts[0] || "").replace(/\[ESTAGIO:[^\]]+\]/gi, "").trim();
      let meta = {
        crm_uf: "",
        especialidade: "",
        tipo_atuacao: "",
        nome_clinica: "",
        cnpj_vinculado: "",
        whatsapp: "",
        origem_lead: "",
        canal_aquisicao: "",
        responsavel_comercial: "",
        tags: "",
        produtos_interesse: [] as string[],
        parceria_comissao: "",
        forma_pagamento_preferencial: "parcelado",
        parcelas_preferenciais: "11",
        meio_pagamento: "boleto",
      };

      const parsedMeta = safeParseMetadata(rawObs);
      if (parsedMeta) {
        meta = { ...meta, ...parsedMeta };
      }

      setFormData({
        nome: editData.nome || "",
        email: editData.email || "",
        telefone: editData.telefone || "",
        cpf_cnpj: editData.cpf_cnpj || "",
        tipo_pessoa: editData.tipo_pessoa || "fisica",
        profissao: editData.profissao || "",
        data_nascimento: editData.data_nascimento || "",
        endereco: editData.endereco || "",
        cidade: editData.cidade || "",
        estado: editData.estado || "",
        cep: editData.cep || "",
        status: editData.status || "prospecto",
        observacoes: noteContent,
      });

      setCrmUf(meta.crm_uf || "");
      setEspecialidade(meta.especialidade || "");
      setTipoAtuacao(meta.tipo_atuacao || "");
      setNomeClinica(meta.nome_clinica || "");
      setCnpjVinculado(meta.cnpj_vinculado || "");
      setWhatsapp(meta.whatsapp || "");
      setOrigemLead(meta.origem_lead || "");
      setCanalAquisicao(meta.canal_aquisicao || "");
      setResponsavelComercial(meta.responsavel_comercial || "");
      setTags(meta.tags || "");
      setProdutosInteresse(meta.produtos_interesse || []);
      setCommissionPercent(meta.parceria_comissao || "");
      setFormaPagamentoPreferencial(meta.forma_pagamento_preferencial || (meta.parcelas_preferenciais === "1" ? "a_vista" : "parcelado"));
      setParcelasPreferenciais(meta.parcelas_preferenciais ? String(meta.parcelas_preferenciais) : "11");
      setMeioPagamentoPreferencial(meta.meio_pagamento || "boleto");
    } else {
      setFormData({
        nome: "",
        email: "",
        telefone: "",
        cpf_cnpj: "",
        tipo_pessoa: "fisica",
        profissao: "",
        data_nascimento: "",
        endereco: "",
        cidade: "",
        estado: "",
        cep: "",
        status: "prospecto",
        observacoes: "",
      });
      setCrmUf("");
      setEspecialidade("");
      setTipoAtuacao("");
      setNomeClinica("");
      setCnpjVinculado("");
      setWhatsapp("");
      setOrigemLead("");
      setCanalAquisicao("");
      setResponsavelComercial("");
      setTags("");
      setProdutosInteresse([]);
      setCommissionPercent("");
      setFormaPagamentoPreferencial("parcelado");
      setParcelasPreferenciais("11");
      setMeioPagamentoPreferencial("boleto");
    }
    setCommissionError("");
    setLocationErrors({});
    setCepFilled(false);
    setActiveTab("basico");
    resetLastFetched();
  }, [editData, open, resetLastFetched]);

  // Handle CEP auto-complete with debounce
  const handleCepChange = useCallback(async (value: string) => {
    const formatted = formatCep(value);
    setFormData(prev => ({ ...prev, cep: formatted }));
    
    // Check if CEP has 8 digits
    const digits = formatted.replace(/\D/g, "");
    if (digits.length === 8) {
      const result = await fetchAddress(digits);
      if (result) {
        setFormData(prev => ({
          ...prev,
          cidade: result.cidade,
          estado: result.uf,
          endereco: result.logradouro || prev.endereco,
        }));
        setCepFilled(true);
        setLocationErrors({});
      }
    } else {
      setCepFilled(false);
    }
  }, [fetchAddress, formatCep]);

  const validateCommission = (value: string): boolean => {
    if (!value.trim()) {
      setCommissionError("");
      return true;
    }
    
    const numValue = parseFloat(value.replace(',', '.'));
    if (isNaN(numValue)) {
      setCommissionError("Valor inválido");
      return false;
    }
    if (numValue < 0) {
      setCommissionError("Valor mínimo: 0%");
      return false;
    }
    if (numValue > 100) {
      setCommissionError("Valor máximo: 100%");
      return false;
    }
    
    setCommissionError("");
    return true;
  };

  const validateLocation = (): boolean => {
    const errors: { cidade?: string; estado?: string } = {};
    
    if (formData.estado?.trim() && !isValidUF(formData.estado)) {
      errors.estado = "UF inválida (digite a sigla como SP, RJ, etc)";
    }
    
    setLocationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleCommissionChange = (value: string) => {
    const sanitized = value.replace(/[^0-9.,]/g, '');
    setCommissionPercent(sanitized);
    if (sanitized) {
      validateCommission(sanitized);
    } else {
      setCommissionError("");
    }
  };

  const handleProductInterestToggle = (id: string) => {
    setProdutosInteresse(prev => 
      prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.nome?.trim()) {
      toast.error("O campo Nome é obrigatório");
      setActiveTab("basico");
      return;
    }
    
    // Telefone or WhatsApp is required
    if (!formData.telefone?.trim() && !whatsapp.trim()) {
      toast.error("Pelo menos um contato (Telefone ou WhatsApp) é obrigatório");
      setActiveTab("basico");
      return;
    }
    
    // Validate location
    if (!validateLocation()) {
      toast.error("Cidade e Estado são obrigatórios");
      setActiveTab("comercial");
      return;
    }
    
    // Validate commission (completely optional)
    if (commissionPercent && !validateCommission(commissionPercent)) {
      setActiveTab("parceria");
      return;
    }
    
    // Build serialized metadata inside observacoes
    const metadata = {
      crm_uf: crmUf,
      especialidade: especialidade,
      tipo_atuacao: tipoAtuacao,
      nome_clinica: nomeClinica,
      cnpj_vinculado: cnpjVinculado,
      whatsapp: whatsapp,
      origem_lead: origemLead,
      canal_aquisicao: canalAquisicao,
      responsavel_comercial: responsavelComercial,
      tags: tags,
      produtos_interesse: produtosInteresse,
      parceria_comissao: commissionPercent,
      forma_pagamento_preferencial: formaPagamentoPreferencial,
      parcelas_preferenciais: formaPagamentoPreferencial === "a_vista" ? 1 : (parseInt(parcelasPreferenciais, 10) || 11),
      meio_pagamento: meioPagamentoPreferencial,
    };

    const cleanNotes = (formData.observacoes || "").trim();
    const divider = "-- METADATA_JSON_V1 --";
    const finalObservacoes = `${cleanNotes}\n\n${divider}\n${JSON.stringify(metadata)}`;

    // Normalize values and convert empty strings to null before submitting
    const payload = { 
      ...formData,
      cpf_cnpj: formData.cpf_cnpj ? formData.cpf_cnpj.replace(/\D/g, "") : null,
      observacoes: finalObservacoes,
      estado: formData.estado ? normalizeUF(formData.estado) : undefined,
      cidade: formData.cidade ? normalizeCity(formData.cidade) : undefined,
    };
    
    Object.keys(payload).forEach((key) => {
      const k = key as keyof typeof payload;
      if (payload[k] === "") {
        (payload as any)[k] = null;
      }
    });

    let parsedCommission: number | undefined;
    if (commissionPercent.trim()) {
      parsedCommission = parseFloat(commissionPercent.replace(',', '.'));
    }
    
    onSubmit(payload as ClientInsert, parsedCommission);
  };

  const isDoctor = formData.profissao?.toLowerCase().includes("méd") || 
                   formData.profissao?.toLowerCase().includes("med") ||
                   especialidade.trim().length > 0 ||
                   crmUf.trim().length > 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[92vh] overflow-y-auto border-border/60 bg-card shadow-lg p-0">
        <DialogHeader className="p-6 pb-4 border-b border-border/30 bg-muted/20">
          <DialogTitle className="flex items-center gap-2 text-xl font-bold tracking-tight">
            <User className="h-5 w-5 text-primary" />
            {editData ? "Editar Cliente / Lead" : "Novo Cliente / Lead"}
          </DialogTitle>
          <DialogDescription className="text-sm text-muted-foreground mt-1">
            {editData 
              ? "Atualize os dados e parcerias deste cliente de forma segura."
              : "Preencha a ficha do cliente. O funil e os cálculos de BI serão atualizados automaticamente."
            }
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-0">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-4 w-full bg-muted/40 border-b border-border/20 rounded-none h-12">
              <TabsTrigger value="basico" className="text-xs font-semibold uppercase tracking-wider h-full rounded-none">
                Básicos & Contato
              </TabsTrigger>
              <TabsTrigger value="profissional" className="text-xs font-semibold uppercase tracking-wider h-full rounded-none">
                Profissionais {isDoctor && "⚕️"}
              </TabsTrigger>
              <TabsTrigger value="comercial" className="text-xs font-semibold uppercase tracking-wider h-full rounded-none">
                Endereço & Comercial
              </TabsTrigger>
              <TabsTrigger value="parceria" className="text-xs font-semibold uppercase tracking-wider h-full rounded-none">
                Condições & Parceria
              </TabsTrigger>
            </TabsList>

            <div className="p-6 min-h-[380px]">
              {/* TAB 1: BÁSICOS */}
              <TabsContent value="basico" className="space-y-4 mt-0">
                <div className="flex items-center gap-2 border-b border-border/10 pb-2 mb-4">
                  <Contact className="h-4 w-4 text-primary" />
                  <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Dados Principais</h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label htmlFor="nome" className="text-xs font-semibold uppercase tracking-wider">Nome Completo *</Label>
                    <Input
                      id="nome"
                      value={formData.nome}
                      onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                      placeholder="Nome do cliente"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="tipo_pessoa" className="text-xs font-semibold uppercase tracking-wider">Tipo de Pessoa</Label>
                    <Select 
                      value={formData.tipo_pessoa} 
                      onValueChange={(v) => setFormData({ ...formData, tipo_pessoa: v })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fisica">Pessoa Física</SelectItem>
                        <SelectItem value="juridica">Pessoa Jurídica</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <Label htmlFor="cpf_cnpj" className="text-xs font-semibold uppercase tracking-wider">
                      {formData.tipo_pessoa === "juridica" ? "CNPJ" : "CPF"}
                    </Label>
                    <Input
                      id="cpf_cnpj"
                      value={formData.cpf_cnpj}
                      onChange={(e) => setFormData({ ...formData, cpf_cnpj: e.target.value })}
                      placeholder={formData.tipo_pessoa === "juridica" ? "00.000.000/0000-00" : "000.000.000-00"}
                    />
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="data_nascimento" className="text-xs font-semibold uppercase tracking-wider">
                      {formData.tipo_pessoa === "juridica" ? "Data de Abertura" : "Nascimento"}
                    </Label>
                    <Input
                      id="data_nascimento"
                      type="date"
                      value={formData.data_nascimento}
                      onChange={(e) => setFormData({ ...formData, data_nascimento: e.target.value })}
                    />
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="profissao" className="text-xs font-semibold uppercase tracking-wider">Profissão / Ramo</Label>
                    <Input
                      id="profissao"
                      value={formData.profissao}
                      onChange={(e) => setFormData({ ...formData, profissao: e.target.value })}
                      placeholder="Ex: Médico, Engenheiro, etc."
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 border-b border-border/10 pb-2 mb-2 mt-6">
                  <Phone className="h-4 w-4 text-primary" />
                  <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Informações de Contato</h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <Label htmlFor="email" className="text-xs font-semibold uppercase tracking-wider">E-mail</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="email@exemplo.com"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between items-center">
                      <Label htmlFor="telefone" className="text-xs font-semibold uppercase tracking-wider">Telefone</Label>
                      <span className="text-[10px] text-muted-foreground font-semibold uppercase tracking-widest">Obrigatório s/ Whats</span>
                    </div>
                    <Input
                      id="telefone"
                      value={formData.telefone}
                      onChange={(e) => setFormData({ ...formData, telefone: e.target.value })}
                      placeholder="(00) 0000-0000"
                    />
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="whatsapp" className="text-xs font-semibold uppercase tracking-wider">WhatsApp</Label>
                    <Input
                      id="whatsapp"
                      value={whatsapp}
                      onChange={(e) => setWhatsapp(e.target.value)}
                      placeholder="(00) 90000-0000"
                    />
                  </div>
                </div>
              </TabsContent>

              {/* TAB 2: PROFISSIONAIS */}
              <TabsContent value="profissional" className="space-y-5 mt-0">
                <div className="flex items-center gap-2 border-b border-border/10 pb-2 mb-4">
                  <Briefcase className="h-4 w-4 text-indigo-500" />
                  <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Ficha de Atuação Especializada (Saúde/Geral)</h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <div className="flex justify-between items-center">
                      <Label htmlFor="crm_uf" className="text-xs font-semibold uppercase tracking-wider">CRM / UF</Label>
                      <span className="text-[10px] text-primary font-black uppercase tracking-widest">Obrigatório p/ Médicos</span>
                    </div>
                    <Input
                      id="crm_uf"
                      value={crmUf}
                      onChange={(e) => setCrmUf(e.target.value)}
                      placeholder="Ex: 12345/SP"
                    />
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="especialidade" className="text-xs font-semibold uppercase tracking-wider">Especialidade Principal</Label>
                    <Input
                      id="especialidade"
                      value={especialidade}
                      onChange={(e) => setEspecialidade(e.target.value)}
                      placeholder="Ex: Cardiologia, Dermatologia..."
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold uppercase tracking-wider">Tipo de Atuação / Vínculo</Label>
                    <Select value={tipoAtuacao} onValueChange={setTipoAtuacao}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o formato" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="autonomo">Autônomo (Consultório Próprio)</SelectItem>
                        <SelectItem value="pj">Prestador de Serviço PJ</SelectItem>
                        <SelectItem value="clinica_propria">Sócio de Clínica</SelectItem>
                        <SelectItem value="hospital">Corpo Clínico (Hospital)</SelectItem>
                        <SelectItem value="residencia">Residência Médica</SelectItem>
                        <SelectItem value="plantonista">Plantonista</SelectItem>
                        <SelectItem value="empresa">Empresa Estabelecida</SelectItem>
                        <SelectItem value="outros">Outros formatos</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="nome_clinica" className="text-xs font-semibold uppercase tracking-wider">Nome da Clínica / Empresa</Label>
                    <Input
                      id="nome_clinica"
                      value={nomeClinica}
                      onChange={(e) => setNomeClinica(e.target.value)}
                      placeholder="Ex: MedCorp Serviços"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <Label htmlFor="cnpj_vinculado" className="text-xs font-semibold uppercase tracking-wider">CNPJ Vinculado</Label>
                    <Input
                      id="cnpj_vinculado"
                      value={cnpjVinculado}
                      onChange={(e) => setCnpjVinculado(e.target.value)}
                      placeholder="00.000.000/0000-00"
                    />
                  </div>
                </div>

                <div className="p-4 border border-indigo-100 rounded-xl bg-indigo-50/20 text-indigo-900/80 text-xs leading-relaxed">
                  🩺 <strong>Nota Técnica:</strong> O preenchimento da ficha médica/profissional auxilia nas recomendações de produtos pelo comitê e melhora o fit de cotação do produto <strong>RCP Médico</strong>.
                </div>
              </TabsContent>

              {/* TAB 3: ENDEREÇO & COMERCIAL */}
              <TabsContent value="comercial" className="space-y-4 mt-0">
                <div className="flex items-center gap-2 border-b border-border/10 pb-2 mb-2">
                  <MapPin className="h-4 w-4 text-emerald-500" />
                  <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Localização</h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <Label htmlFor="cep" className="text-xs font-semibold uppercase tracking-wider">CEP</Label>
                    <div className="relative">
                      <Input
                        id="cep"
                        value={formData.cep}
                        onChange={(e) => handleCepChange(e.target.value)}
                        placeholder="00000-000"
                        maxLength={9}
                      />
                      {isLoadingCep && (
                        <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
                      )}
                    </div>
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="cidade" className="text-xs font-semibold uppercase tracking-wider">Cidade *</Label>
                    <Input
                      id="cidade"
                      value={formData.cidade}
                      onChange={(e) => {
                        setFormData({ ...formData, cidade: e.target.value });
                        setLocationErrors(prev => ({ ...prev, cidade: undefined }));
                      }}
                      className={locationErrors.cidade ? "border-destructive" : ""}
                    />
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="estado" className="text-xs font-semibold uppercase tracking-wider">Estado (UF) *</Label>
                    <Select 
                      value={formData.estado?.toUpperCase() || ""} 
                      onValueChange={(v) => {
                        setFormData({ ...formData, estado: v });
                        setLocationErrors(prev => ({ ...prev, estado: undefined }));
                      }}
                    >
                      <SelectTrigger className={locationErrors.estado ? "border-destructive" : ""}>
                        <SelectValue placeholder="UF" />
                      </SelectTrigger>
                      <SelectContent>
                        {UF_LIST.map(uf => (
                          <SelectItem key={uf} value={uf}>{uf}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-1">
                  <Label htmlFor="endereco" className="text-xs font-semibold uppercase tracking-wider">Logradouro / Endereço</Label>
                  <Input
                    id="endereco"
                    value={formData.endereco}
                    onChange={(e) => setFormData({ ...formData, endereco: e.target.value })}
                    placeholder="Rua, número, complemento"
                  />
                </div>

                <div className="flex items-center gap-2 border-b border-border/10 pb-2 mb-2 mt-6">
                  <Tag className="h-4 w-4 text-emerald-500" />
                  <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Engajamento Comercial</h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold uppercase tracking-wider">Status CRM / Pipeline</Label>
                    <Select 
                      value={formData.status} 
                      onValueChange={(v) => setFormData({ ...formData, status: v })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="prospecto">Prospecto / Lead</SelectItem>
                        <SelectItem value="contato">Contatado</SelectItem>
                        <SelectItem value="lead_quente">Lead Quente 🔥</SelectItem>
                        <SelectItem value="cotacao">Sob Cotação</SelectItem>
                        <SelectItem value="negociacao">Em Negociação</SelectItem>
                        <SelectItem value="ativo">Convertido (Ativo) 🎉</SelectItem>
                        <SelectItem value="perdido">Perdido</SelectItem>
                        <SelectItem value="inativo">Inativo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="origem_lead" className="text-xs font-semibold uppercase tracking-wider">Origem do Lead</Label>
                    <Input
                      id="origem_lead"
                      value={origemLead}
                      onChange={(e) => setOrigemLead(e.target.value)}
                      placeholder="Ex: Google, Parcerias"
                    />
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="canal_aquisicao" className="text-xs font-semibold uppercase tracking-wider">Canal de Aquisição</Label>
                    <Input
                      id="canal_aquisicao"
                      value={canalAquisicao}
                      onChange={(e) => setCanalAquisicao(e.target.value)}
                      placeholder="Ex: Inbound, Whatsapp"
                    />
                  </div>

                  <div className="space-y-1">
                    <Label htmlFor="responsavel_comercial" className="text-xs font-semibold uppercase tracking-wider">Responsável Comercial</Label>
                    <Input
                      id="responsavel_comercial"
                      value={responsavelComercial}
                      onChange={(e) => setResponsavelComercial(e.target.value)}
                      placeholder="Responsável pela conta"
                    />
                  </div>
                </div>

                {/* PRODUTOS DE INTERESSE */}
                <div className="space-y-2 mt-4">
                  <Label className="text-xs font-semibold uppercase tracking-wider">Produtos de Interesse</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 border rounded-xl bg-muted/20">
                    {PRODUCT_OPTIONS.map((prod) => (
                      <div key={prod.id} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`prod_${prod.id}`} 
                          checked={produtosInteresse.includes(prod.id)}
                          onCheckedChange={() => handleProductInterestToggle(prod.id)}
                        />
                        <Label htmlFor={`prod_${prod.id}`} className="text-xs font-medium cursor-pointer">
                          {prod.label}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-1 mt-4">
                  <Label htmlFor="observacoes" className="text-xs font-semibold uppercase tracking-wider">Observações / Histórico de Negócios</Label>
                  <Textarea
                    id="observacoes"
                    value={formData.observacoes}
                    onChange={(e) => setFormData({ ...formData, observacoes: e.target.value })}
                    placeholder="Notas comerciais e histórico de contatos do corretor..."
                    rows={2}
                  />
                </div>
              </TabsContent>

              {/* TAB 4: CONDIÇÕES DE PAGAMENTO & PARCERIA */}
              <TabsContent value="parceria" className="space-y-6 mt-0">
                {/* 1. FORMA DE PAGAMENTO PREFERENCIAL DO SEGURO */}
                <div className="p-4 border rounded-xl bg-card space-y-4 shadow-sm">
                  <div className="flex items-center gap-2 border-b pb-2">
                    <CreditCard className="h-4 w-4 text-primary" />
                    <h4 className="text-sm font-bold uppercase tracking-wider text-foreground">
                      Forma de Pagamento do Seguro (Previsão de Comissões)
                    </h4>
                  </div>

                  <p className="text-xs text-muted-foreground leading-relaxed">
                    Configure a forma preferencial de pagamento dos seguros deste cliente (à vista ou dividido em até 11x/12x). 
                    O módulo Financeiro usará essa informação para projetar automaticamente o cronograma mensal de comissões da corretora.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1">
                    <div className="space-y-1.5">
                      <Label htmlFor="forma_pagamento_pref" className="text-xs font-semibold uppercase tracking-wider">
                        Forma de Pagamento
                      </Label>
                      <Select 
                        value={formaPagamentoPreferencial} 
                        onValueChange={(val) => {
                          setFormaPagamentoPreferencial(val);
                          if (val === "a_vista") {
                            setParcelasPreferenciais("1");
                          } else if (parcelasPreferenciais === "1") {
                            setParcelasPreferenciais("11");
                          }
                        }}
                      >
                        <SelectTrigger id="forma_pagamento_pref">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="parcelado">Parcelado (até 11x ou 12x)</SelectItem>
                          <SelectItem value="a_vista">À Vista (1x)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-1.5">
                      <Label htmlFor="parcelas_pref" className="text-xs font-semibold uppercase tracking-wider">
                        Parcelas Padrão
                      </Label>
                      <Select 
                        value={parcelasPreferenciais} 
                        onValueChange={setParcelasPreferenciais}
                        disabled={formaPagamentoPreferencial === "a_vista"}
                      >
                        <SelectTrigger id="parcelas_pref">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1x (À vista)</SelectItem>
                          <SelectItem value="2">2x</SelectItem>
                          <SelectItem value="3">3x</SelectItem>
                          <SelectItem value="4">4x</SelectItem>
                          <SelectItem value="5">5x</SelectItem>
                          <SelectItem value="6">6x</SelectItem>
                          <SelectItem value="7">7x</SelectItem>
                          <SelectItem value="8">8x</SelectItem>
                          <SelectItem value="9">9x</SelectItem>
                          <SelectItem value="10">10x</SelectItem>
                          <SelectItem value="11" className="font-semibold text-primary">11x (Padrão Seguradoras)</SelectItem>
                          <SelectItem value="12">12x (Anual integral)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-1.5">
                      <Label htmlFor="meio_pagamento_pref" className="text-xs font-semibold uppercase tracking-wider">
                        Meio de Pagamento
                      </Label>
                      <Select 
                        value={meioPagamentoPreferencial} 
                        onValueChange={setMeioPagamentoPreferencial}
                      >
                        <SelectTrigger id="meio_pagamento_pref">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="boleto">Boleto Bancário</SelectItem>
                          <SelectItem value="cartao">Cartão de Crédito</SelectItem>
                          <SelectItem value="debito">Débito em Conta</SelectItem>
                          <SelectItem value="pix">Pix</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 p-2.5 rounded-lg bg-muted/40 border text-xs text-muted-foreground">
                    <span className="font-semibold text-foreground">Regra Automática:</span>
                    {formaPagamentoPreferencial === "a_vista" ? (
                      <span>Comissão integral provisionada na primeira parcela / mês de início da apólice.</span>
                    ) : (
                      <span>Comissão distribuída uniformemente ao longo de {parcelasPreferenciais} meses subsequentes.</span>
                    )}
                  </div>
                </div>

                {/* 2. CANAL DE PARCERIA & INDICAÇÃO */}
                <div className="p-4 border border-purple-100 rounded-xl bg-purple-50/20 space-y-4 shadow-sm">
                  <div className="flex items-center gap-2 border-b border-purple-200/50 pb-2">
                    <Percent className="h-4 w-4 text-purple-600" />
                    <h4 className="text-sm font-bold uppercase tracking-wider text-purple-950">
                      Canal de Parceria, Comissionamento & Indicação (Opcional)
                    </h4>
                  </div>

                  <p className="text-xs text-muted-foreground leading-relaxed">
                    Defina incentivos de vendas específicos, canais de indicação, acordos comerciais ou parcerias pontuais de comissionamento. 
                    Este valor será salvo como referência secundária e <strong>não é obrigatório</strong>.
                  </p>

                  <div className="space-y-2 max-w-sm">
                    <div className="flex items-center gap-2">
                      <Label htmlFor="commission_percent" className="text-xs font-bold uppercase tracking-wider text-purple-950">
                        Comissão Acordada (Incentivo Geral %)
                      </Label>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild type="button">
                            <HelpCircle className="h-4 w-4 text-muted-foreground cursor-help" />
                          </TooltipTrigger>
                          <TooltipContent className="max-w-[280px]">
                            <p>O percentual configurado aqui é opcional e serve para referências de acordos de canais parceiros. O BI do dashboard calcula comissões com base em apólices reais.</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>

                    <div className="relative max-w-[200px]">
                      <Input
                        id="commission_percent"
                        value={commissionPercent}
                        onChange={(e) => handleCommissionChange(e.target.value)}
                        placeholder="Ex: 10 ou 12.5"
                        className={commissionError ? "border-destructive text-sm" : "text-sm"}
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground font-semibold text-xs">%</span>
                    </div>

                    {commissionError && (
                      <div className="flex items-center gap-1 text-destructive text-xs">
                        <AlertCircle className="h-3 w-3" />
                        {commissionError}
                      </div>
                    )}
                  </div>
                </div>

                <div className="p-4 border border-zinc-200/60 rounded-xl bg-muted/10 text-xs leading-relaxed text-muted-foreground">
                  🔒 <strong>Garantia de Integridade:</strong> A Medsafe garante a imutabilidade do histórico do cliente. Nenhuma regra de comissionamento anterior é excluída ao modificar o perfil do cliente.
                </div>
              </TabsContent>
            </div>
          </Tabs>

          {/* Dynamic Progress indicator or CTA footer */}
          <div className="flex items-center justify-between gap-3 px-6 py-4 border-t border-border/40 bg-muted/10">
            <div className="text-xs text-muted-foreground flex items-center gap-1.5 font-medium">
              <CheckCircle2 className="h-4 w-4 text-primary" />
              Preenchimento pontual e incremental
            </div>
            <div className="flex gap-3">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)} size="sm">
                Cancelar
              </Button>
              <Button type="submit" disabled={isLoading} size="sm" className="gap-2 font-semibold">
                {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                {editData ? "Salvar Perfil" : "Criar Perfil"}
              </Button>
            </div>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
