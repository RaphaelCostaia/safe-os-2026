import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Percent, 
  DollarSign, 
  Edit, 
  Save, 
  X, 
  Calendar, 
  Loader2,
  History,
  User,
  ArrowRight,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  Plus,
  Package
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  useClientActiveCommissions,
  useClientCommissionHistory,
  useCreateClientCommission,
  useUpdateClientCommission,
  formatCommissionShort,
  type ClientCommissionTermInsert,
} from "@/hooks/useClientCommission";
import { useProdutos } from "@/hooks/useProdutos";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface ClientCommissionSectionProps {
  clientId: string;
}

type CommissionModel = "percentual" | "fixo" | "misto";

interface FormData {
  produtoId: string; // "" means General
  model: CommissionModel;
  percent: string;
  fixedAmount: string;
  startsAt: string;
  notes: string;
}

const modelLabels: Record<CommissionModel, string> = {
  percentual: "Percentual (%) sobre prêmio",
  fixo: "Valor fixo (R$) por apólice",
  misto: "Misto (% + valor fixo)",
};

export function ClientCommissionSection({ clientId }: ClientCommissionSectionProps) {
  const { data: activeCommissions = [], isLoading } = useClientActiveCommissions(clientId);
  const { data: history = [], isLoading: historyLoading } = useClientCommissionHistory(clientId);
  const { data: products = [] } = useProdutos();
  const createCommission = useCreateClientCommission();
  const updateCommission = useUpdateClientCommission();
  
  const [isEditing, setIsEditing] = useState(false);
  const [editingTermId, setEditingTermId] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    produtoId: "",
    model: "percentual",
    percent: "",
    fixedAmount: "",
    startsAt: "",
    notes: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleEdit = (term: any) => {
    setEditingTermId(term.id);
    setFormData({
      produtoId: term.produto_id || "",
      model: term.model,
      percent: term.percent?.toString() || "",
      fixedAmount: term.fixed_amount?.toString() || "",
      startsAt: term.starts_at || "",
      notes: term.notes || "",
    });
    setIsEditing(true);
  };

  const handleAddNew = () => {
    setEditingTermId(null);
    setFormData({
      produtoId: "",
      model: "percentual",
      percent: "",
      fixedAmount: "",
      startsAt: new Date().toISOString().split('T')[0],
      notes: "",
    });
    setIsEditing(true);
  };

  const resetForm = () => {
    setFormData({
      produtoId: "",
      model: "percentual",
      percent: "",
      fixedAmount: "",
      startsAt: "",
      notes: "",
    });
    setErrors({});
    setIsEditing(false);
    setEditingTermId(null);
  };

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (formData.model === "percentual" || formData.model === "misto") {
      const percent = parseFloat(formData.percent);
      if (!formData.percent || isNaN(percent) || percent <= 0 || percent > 100) {
        newErrors.percent = "Informe um percentual válido (0-100%)";
      }
    }

    if (formData.model === "fixo" || formData.model === "misto") {
      const amount = parseFloat(formData.fixedAmount);
      if (!formData.fixedAmount || isNaN(amount) || amount <= 0) {
        newErrors.fixedAmount = "Informe um valor válido maior que zero";
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = () => {
    if (!validate()) return;

    const payload: ClientCommissionTermInsert = {
      client_id: clientId,
      produto_id: formData.produtoId === "none" || !formData.produtoId ? null : formData.produtoId,
      model: formData.model,
      percent: formData.model !== "fixo" ? parseFloat(formData.percent) : null,
      fixed_amount: formData.model !== "percentual" ? parseFloat(formData.fixedAmount) : null,
      starts_at: formData.startsAt || null,
      notes: formData.notes || null,
      is_active: true,
    };

    if (editingTermId) {
      updateCommission.mutate(
        { id: editingTermId, clientId, data: payload },
        { onSuccess: () => resetForm() }
      );
    } else {
      createCommission.mutate(payload, { onSuccess: () => resetForm() });
    }
  };

  const isPending = createCommission.isPending || updateCommission.isPending;

  if (isLoading) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Percent className="h-4 w-4 text-primary" />
            Acordos de Comissão do Cliente
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Skeleton className="h-4 w-48" />
          <Skeleton className="h-4 w-32" />
        </CardContent>
      </Card>
    );
  }

  if (!isEditing) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Percent className="h-4 w-4 text-primary" />
              Acordos de Comissão do Cliente
            </CardTitle>
            <div className="flex items-center gap-2">
              {history.length > 0 && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setShowHistory(!showHistory)}
                  className="text-muted-foreground text-xs"
                >
                  <History className="h-3.5 w-3.5 mr-1" />
                  Histórico ({history.length})
                  {showHistory ? <ChevronUp className="h-3 w-3 ml-1" /> : <ChevronDown className="h-3 w-3 ml-1" />}
                </Button>
              )}
              <Button size="sm" className="h-8 text-xs bg-primary hover:bg-primary/95 text-primary-foreground" onClick={handleAddNew}>
                <Plus className="h-3.5 w-3.5 mr-1" />
                Definir Acordo
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          
          <div className="text-xs text-muted-foreground pb-1">
            Configure tarifas de comissões negociadas que sobrepõem as regras gerais para manter um controle financeiro individualizado.
          </div>

          {activeCommissions.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {activeCommissions.map((comm) => (
                <div key={comm.id} className="p-4 rounded-xl border border-border bg-card/60 relative group hover:border-primary/30 transition-all">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="space-y-1">
                      <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1">
                        <Package className="h-3 w-3 text-primary/70" />
                        {comm.produtos?.nome ? comm.produtos.nome : "REGRA GERAL"}
                      </div>
                      <Badge variant="outline" className="text-[10px] scale-95 origin-left">
                        {modelLabels[comm.model]}
                      </Badge>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => handleEdit(comm)}
                    >
                      <Edit className="h-3.5 w-3.5" />
                    </Button>
                  </div>

                  <div className="flex items-baseline gap-2 mt-3">
                    <span className="text-2xl font-bold text-foreground">
                      {formatCommissionShort(comm)}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {comm.model === "percentual" ? "sobre prêmio" : 
                       comm.model === "fixo" ? "por apólice" : ""}
                    </span>
                  </div>

                  {comm.starts_at && (
                    <div className="flex items-center gap-1 text-[11px] text-muted-foreground mt-4">
                      <Calendar className="h-3 w-3" />
                      Vigente desde {format(new Date(comm.starts_at), "dd/MM/yyyy", { locale: ptBR })}
                    </div>
                  )}

                  {comm.notes && (
                    <p className="text-xs text-muted-foreground border-l-2 border-primary/20 pl-2 mt-2 italic">
                      "{comm.notes}"
                    </p>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="flex items-center gap-3 p-4 bg-amber-500/5 border border-amber-500/10 rounded-xl">
              <AlertTriangle className="h-5 w-5 text-amber-500 shrink-0" />
              <div>
                <p className="text-sm font-semibold text-foreground">Comissões não configuradas no cliente</p>
                <p className="text-xs text-muted-foreground">
                  Tratando as vendas para este cliente com comissão zerada. Cadastre um acordo para que o financeiro calcule automaticamente.
                </p>
              </div>
            </div>
          )}

          {/* History Section */}
          {showHistory && history.length > 0 && (
            <>
              <Separator />
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Histórico de Alterações</p>
                <ScrollArea className="h-[200px]">
                  <div className="space-y-2 pr-3">
                    {history.map((term) => (
                      <div 
                        key={term.id} 
                        className={cn(
                          "p-3 rounded-lg border text-xs",
                          term.is_active 
                            ? "bg-primary/5 border-primary/20" 
                            : "bg-secondary/30 border-border/50"
                        )}
                      >
                        <div className="flex items-center justify-between mb-1 gap-2 flex-wrap">
                          <div className="flex items-center gap-1.5">
                            <span className="font-semibold text-foreground">{term.produtos?.nome ? term.produtos.nome : "Regra Geral"}</span>
                            <span>•</span>
                            <span className="font-medium">{formatCommissionShort(term)}</span>
                            {term.is_active && (
                              <Badge variant="outline" className="text-[9px] px-1 bg-success/5 text-success border-success/20">
                                Ativo
                              </Badge>
                            )}
                          </div>
                          <span className="text-[10px] text-muted-foreground">
                            {format(new Date(term.created_at), "dd/MM/yy HH:mm", { locale: ptBR })}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-muted-foreground mt-2">
                          {term.profiles?.full_name && (
                            <span className="flex items-center gap-1">
                              <User className="h-2.5 w-2.5" />
                              {term.profiles.full_name}
                            </span>
                          )}
                          {term.starts_at && (
                            <span>• Início: {format(new Date(term.starts_at), "dd/MM/yyyy")}</span>
                          )}
                          {term.ends_at && (
                            <>
                              <ArrowRight className="h-2.5 w-2.5" />
                              <span>Fim: {format(new Date(term.ends_at), "dd/MM/yyyy")}</span>
                            </>
                          )}
                        </div>
                        {term.notes && (
                          <p className="text-[11px] text-muted-foreground mt-1.5 italic pl-2 border-l border-border">
                            "{term.notes}"
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-primary/30 bg-card">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Percent className="h-4 w-4 text-primary" />
            {editingTermId ? "Editar Acordo de Comissão" : "Novo Acordo de Comissão"}
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={resetForm} disabled={isPending}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        
        {/* Product Select */}
        <div className="space-y-2">
          <Label>Produto Vinculado (Opcional)</Label>
          <Select
            value={formData.produtoId}
            onValueChange={(value) => setFormData(prev => ({ ...prev, produtoId: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Selecione um produto (Vazio = Regra Geral)" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">
                Regra Geral (Todos os produtos)
              </SelectItem>
              {products.map((p) => (
                <SelectItem key={p.id} value={p.id}>
                  {p.nome} ({p.categoria})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-[10px] text-muted-foreground">
            Deixe em branco (ou selecione Regra Geral) para que este acordo se aplique por padrão a todas as apólices unificadas deste cliente.
          </p>
        </div>

        {/* Model Select */}
        <div className="space-y-2">
          <Label>Modelo de Comissão</Label>
          <Select
            value={formData.model}
            onValueChange={(value: CommissionModel) => setFormData(prev => ({ ...prev, model: value }))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="percentual">
                <div className="flex items-center gap-2">
                  <Percent className="h-3.5 w-3.5" />
                  Percentual (%) sobre prêmio
                </div>
              </SelectItem>
              <SelectItem value="fixo">
                <div className="flex items-center gap-2">
                  <DollarSign className="h-3.5 w-3.5" />
                  Valor fixo (R$) por apólice
                </div>
              </SelectItem>
              <SelectItem value="misto">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-medium">%+R$</span>
                  Misto (percentual + fixo)
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Percent Field */}
        {(formData.model === "percentual" || formData.model === "misto") && (
          <div className="space-y-2">
            <Label>Percentual (%)</Label>
            <div className="relative">
              <Input
                type="number"
                min="0"
                max="100"
                step="0.1"
                placeholder="Ex: 15"
                value={formData.percent}
                onChange={(e) => setFormData(prev => ({ ...prev, percent: e.target.value }))}
                className={cn(errors.percent && "border-destructive")}
              />
              <Percent className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
            {errors.percent && (
              <p className="text-xs text-destructive">{errors.percent}</p>
            )}
          </div>
        )}

        {/* Fixed Amount Field */}
        {(formData.model === "fixo" || formData.model === "misto") && (
          <div className="space-y-2">
            <Label>Valor Fixo (R$)</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                R$
              </span>
              <Input
                type="number"
                min="0"
                step="0.01"
                placeholder="0,00"
                value={formData.fixedAmount}
                onChange={(e) => setFormData(prev => ({ ...prev, fixedAmount: e.target.value }))}
                className={cn("pl-10", errors.fixedAmount && "border-destructive")}
              />
            </div>
            {errors.fixedAmount && (
              <p className="text-xs text-destructive">{errors.fixedAmount}</p>
            )}
          </div>
        )}

        {/* Start Date */}
        <div className="space-y-2">
          <Label>Data de Início (opcional)</Label>
          <Input
            type="date"
            value={formData.startsAt}
            onChange={(e) => setFormData(prev => ({ ...prev, startsAt: e.target.value }))}
          />
        </div>

        {/* Notes */}
        <div className="space-y-2">
          <Label>Observações (opcional)</Label>
          <Textarea
            placeholder="Detalhes ou condições especiais do acordo..."
            value={formData.notes}
            onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
            rows={2}
          />
        </div>

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <Button onClick={handleSave} disabled={isPending} className="flex-1">
            {isPending ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            Salvar Acordo
          </Button>
          <Button variant="outline" onClick={resetForm} disabled={isPending}>
            Cancelar
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
