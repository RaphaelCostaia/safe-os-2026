import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Download, 
  ExternalLink, 
  X, 
  FileText, 
  Image as ImageIcon,
  File,
  AlertCircle,
  Loader2,
  RefreshCw
} from "lucide-react";
import { cn } from "@/lib/utils";
import { getSignedUrl, extractFilePath } from "@/hooks/useClientDocuments";
import { toast } from "sonner";

interface DocumentPreviewModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  documentUrl: string;
  documentName: string;
}

type PreviewType = "image" | "pdf" | "unsupported";

function getPreviewType(fileName: string): PreviewType {
  const ext = fileName.split('.').pop()?.toLowerCase() || '';
  if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(ext)) {
    return "image";
  }
  if (ext === 'pdf') {
    return "pdf";
  }
  return "unsupported";
}

// Simple in-memory cache for signed URLs (5 min expiry)
const urlCache = new Map<string, { url: string; expires: number }>();
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

async function getCachedSignedUrl(originalUrl: string): Promise<string | null> {
  const cached = urlCache.get(originalUrl);
  if (cached && cached.expires > Date.now()) {
    return cached.url;
  }

  const filePath = extractFilePath(originalUrl);
  if (!filePath) return null;

  const signedUrl = await getSignedUrl(filePath);
  if (signedUrl) {
    urlCache.set(originalUrl, {
      url: signedUrl,
      expires: Date.now() + CACHE_DURATION,
    });
  }
  return signedUrl;
}

export function DocumentPreviewModal({
  open,
  onOpenChange,
  documentUrl,
  documentName,
}: DocumentPreviewModalProps) {
  const [signedUrl, setSignedUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const previewType = getPreviewType(documentName);

  useEffect(() => {
    if (!open || !documentUrl) {
      setSignedUrl(null);
      setIsLoading(true);
      setError(null);
      return;
    }

    let mounted = true;

    const loadUrl = async () => {
      setIsLoading(true);
      setError(null);

      try {
        const url = await getCachedSignedUrl(documentUrl);
        if (!mounted) return;

        if (url) {
          setSignedUrl(url);
        } else {
          setError("Não foi possível gerar URL de acesso ao documento.");
        }
      } catch (err) {
        if (!mounted) return;
        console.error("Erro ao carregar documento:", err);
        setError("Erro ao carregar documento. Tente novamente.");
      } finally {
        if (mounted) {
          setIsLoading(false);
        }
      }
    };

    loadUrl();

    return () => {
      mounted = false;
    };
  }, [open, documentUrl]);

  const handleDownload = async () => {
    if (!signedUrl) return;

    try {
      const response = await fetch(signedUrl);
      if (!response.ok) throw new Error("Falha ao baixar");

      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = documentName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(downloadUrl);

      toast.success("Download iniciado");
    } catch (err) {
      console.error("Erro ao baixar:", err);
      toast.error("Erro ao baixar documento");
    }
  };

  const handleOpenExternal = () => {
    if (signedUrl) {
      window.open(signedUrl, '_blank', 'noopener,noreferrer');
    }
  };

  const handleRetry = () => {
    // Clear cache for this URL and retry
    urlCache.delete(documentUrl);
    setIsLoading(true);
    setError(null);
    
    getCachedSignedUrl(documentUrl).then(url => {
      if (url) {
        setSignedUrl(url);
      } else {
        setError("Não foi possível carregar o documento.");
      }
      setIsLoading(false);
    }).catch(() => {
      setError("Erro ao carregar documento.");
      setIsLoading(false);
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col p-0">
        <DialogHeader className="p-4 pb-2 border-b border-border/50">
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2 text-base font-medium truncate pr-4">
              {previewType === "image" && <ImageIcon className="h-4 w-4 text-success shrink-0" />}
              {previewType === "pdf" && <FileText className="h-4 w-4 text-destructive shrink-0" />}
              {previewType === "unsupported" && <File className="h-4 w-4 text-muted-foreground shrink-0" />}
              <span className="truncate">{documentName}</span>
            </DialogTitle>
            <div className="flex items-center gap-2 shrink-0">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleDownload}
                disabled={!signedUrl || isLoading}
              >
                <Download className="h-4 w-4 mr-1" />
                Baixar
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleOpenExternal}
                disabled={!signedUrl || isLoading}
              >
                <ExternalLink className="h-4 w-4 mr-1" />
                Nova aba
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div className="flex-1 min-h-0 overflow-auto bg-secondary/30 p-4">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-96 gap-3">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">Carregando documento...</p>
            </div>
          ) : error ? (
            <div className="flex flex-col items-center justify-center h-96 gap-4">
              <div className="p-4 rounded-full bg-destructive/10">
                <AlertCircle className="h-8 w-8 text-destructive" />
              </div>
              <div className="text-center">
                <p className="font-medium text-foreground">{error}</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Verifique sua conexão e tente novamente.
                </p>
              </div>
              <Button variant="outline" onClick={handleRetry}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Tentar novamente
              </Button>
            </div>
          ) : previewType === "image" && signedUrl ? (
            <div className="flex items-center justify-center min-h-[400px]">
              <img
                src={signedUrl}
                alt={documentName}
                className="max-w-full max-h-[70vh] object-contain rounded-lg shadow-lg"
                onError={() => setError("Não foi possível carregar a imagem.")}
              />
            </div>
          ) : previewType === "pdf" && signedUrl ? (
            <div className="h-[70vh] w-full">
              <iframe
                src={signedUrl}
                className="w-full h-full rounded-lg border border-border/50"
                title={documentName}
              />
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-96 gap-4">
              <div className="p-4 rounded-full bg-muted">
                <File className="h-8 w-8 text-muted-foreground" />
              </div>
              <div className="text-center">
                <p className="font-medium text-foreground">
                  Visualização não disponível
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  Este tipo de arquivo não pode ser visualizado diretamente.
                </p>
              </div>
              <Button onClick={handleDownload} disabled={!signedUrl}>
                <Download className="h-4 w-4 mr-2" />
                Baixar arquivo
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
