import { useState } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useClientPolicies } from "@/hooks/useClientPolicies";
import { useCreateComissaoEntry } from "@/hooks/useComissoes";
import { Loader2, Save, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

interface CommissionAdjustmentDialogProps {
  clientId: string;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CommissionAdjustmentDialog({ 
  clientId, 
  isOpen, 
  onOpenChange 
}: CommissionAdjustmentDialogProps) {
  const { data: policies } = useClientPolicies(clientId);
  const createEntry = useCreateComissaoEntry();
  
  const [formData, setFormData] = useState({
    apolice_id: "",
    valor_comissao: "",
    tipo_lancamento: "ajuste_manual" as const,
    competencia_mes: new Date().getMonth() + 1,
    competencia_ano: new Date().getFullYear(),
    status: "recebida" as const,
    notes: ""
  });

  const handleSave = () => {
    if (!formData.apolice_id) return toast.error("Selecione uma apólice");
    if (!formData.valor_comissao) return toast.error("Informe o valor");

    createEntry.mutate({
      ...formData,
      client_id: clientId,
      valor_base_premio: 0, // Manual adjustment usually doesn't change premium base in this simple view
      valor_comissao: parseFloat(formData.valor_comissao),
      competencia_mes: Number(formData.competencia_mes),
      competencia_ano: Number(formData.competencia_ano),
    }, {
      onSuccess: () => {
        onOpenChange(false);
        setFormData({
          apolice_id: "",
          valor_comissao: "",
          tipo_lancamento: "ajuste_manual",
          competencia_mes: new Date().getMonth() + 1,
          competencia_ano: new Date().getFullYear(),
          status: "recebida",
          notes: ""
        });
      }
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Ajuste Operacional de Comissão</DialogTitle>
          <DialogDescription>
            Registre correções, bônus ou estornos manuais para este cliente.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          <div className="space-y-2">
            <Label>Apólice de Referência</Label>
            <Select 
              value={formData.apolice_id} 
              onValueChange={(v) => setFormData(f => ({ ...f, apolice_id: v }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione a apólice" />
              </SelectTrigger>
              <SelectContent>
                {policies?.map(p => (
                  <SelectItem key={p.id} value={p.id}>
                    {p.produtos?.nome} (#{p.numero_apolice})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Mês Referência</Label>
              <Input 
                type="number" 
                min={1} 
                max={12} 
                value={formData.competencia_mes}
                onChange={(e) => setFormData(f => ({ ...f, competencia_mes: parseInt(e.target.value) }))}
              />
            </div>
            <div className="space-y-2">
              <Label>Ano Referência</Label>
              <Input 
                type="number" 
                value={formData.competencia_ano}
                onChange={(e) => setFormData(f => ({ ...f, competencia_ano: parseInt(e.target.value) }))}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Tipo de Lançamento</Label>
            <Select 
              value={formData.tipo_lancamento} 
              onValueChange={(v: "ajuste_manual" | "bonus") => setFormData(f => ({ ...f, tipo_lancamento: v }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ajuste_manual">Ajuste Manual</SelectItem>
                <SelectItem value="bonus">Bônus / Campanha</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Valor da Comissão (R$)</Label>
            <Input 
              type="number" 
              step="0.01" 
              placeholder="0,00"
              value={formData.valor_comissao}
              onChange={(e) => setFormData(f => ({ ...f, valor_comissao: e.target.value }))}
            />
            <p className="text-[10px] text-muted-foreground">Use valores negativos para estornos.</p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button onClick={handleSave} disabled={createEntry.isPending}>
            {createEntry.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
            Confirmar Lançamento
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
