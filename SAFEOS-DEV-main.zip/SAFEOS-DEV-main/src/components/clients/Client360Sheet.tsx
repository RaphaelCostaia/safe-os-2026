import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  User, 
  FileText, 
  AlertTriangle, 
  Wallet, 
  StickyNote, 
  Files, 
  Phone, 
  Mail, 
  MapPin, 
  Calendar,
  DollarSign
} from "lucide-react";
import { useClientPolicies, type ClientPolicy } from "@/hooks/useClientPolicies";
import { useSinistros, type Sinistro } from "@/hooks/useSinistros";
import { useClientNotes, type ClientNote } from "@/hooks/useClientNotes";
import { useClientCommissionHistory } from "@/hooks/useClientCommission";
import { useClientDocuments } from "@/hooks/useClientDocuments";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";
import type { Client } from "@/hooks/useClients";

interface Client360SheetProps {
  client: Client | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function Client360Sheet({ client, open, onOpenChange }: Client360SheetProps) {
  const { data: policies } = useClientPolicies(client?.id);
  const { data: sinistros } = useSinistros({ clientId: client?.id });
  const { data: notes } = useClientNotes(client?.id);
  const { data: commissionTerms } = useClientCommissionHistory(client?.id);
  const { data: documents } = useClientDocuments(client?.id);

  if (!client) return null;

  const totalPremium = policies?.reduce((acc: number, p: ClientPolicy) => acc + (p.valor_premio || 0), 0) || 0;
  const activePolicies = policies?.filter((p: ClientPolicy) => p.status === "ativa").length || 0;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-[600px] lg:max-w-[800px] overflow-hidden flex flex-col p-0">
        <SheetHeader className="p-6 border-b bg-muted/30">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                <User className="h-6 w-6 text-primary" />
              </div>
              <div>
                <SheetTitle className="text-2xl font-bold">{client.nome}</SheetTitle>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant={client.status === "ativo" ? "default" : "secondary"}>
                    {client.status === "ativo" ? "Ativo" : "Inativo"}
                  </Badge>
                  <span className="text-sm text-muted-foreground">{client.cpf_cnpj}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6">
            <div className="p-3 rounded-lg bg-background border">
              <p className="text-xs text-muted-foreground mb-1">Apólices Ativas</p>
              <p className="text-lg font-bold">{activePolicies}</p>
            </div>
            <div className="p-3 rounded-lg bg-background border">
              <p className="text-xs text-muted-foreground mb-1">Prêmio Total</p>
              <p className="text-lg font-bold">R$ {totalPremium.toLocaleString('pt-BR')}</p>
            </div>
            <div className="p-3 rounded-lg bg-background border">
              <p className="text-xs text-muted-foreground mb-1">Sinistros</p>
              <p className="text-lg font-bold text-destructive">{sinistros?.length || 0}</p>
            </div>
            <div className="p-3 rounded-lg bg-background border">
              <p className="text-xs text-muted-foreground mb-1">Desde</p>
              <p className="text-lg font-bold">
                {format(new Date(client.created_at), "yyyy", { locale: ptBR })}
              </p>
            </div>
          </div>
        </SheetHeader>

        <Tabs defaultValue="resumo" className="flex-1 overflow-hidden flex flex-col">
          <div className="px-6 border-b">
            <TabsList className="w-full justify-start h-12 bg-transparent gap-6">
              <TabsTrigger value="resumo" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 h-12">Resumo</TabsTrigger>
              <TabsTrigger value="apolices" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 h-12">Apólices</TabsTrigger>
              <TabsTrigger value="sinistros" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 h-12">Sinistros</TabsTrigger>
              <TabsTrigger value="comissoes" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 h-12">Comissões</TabsTrigger>
              <TabsTrigger value="documentos" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 h-12">Docs</TabsTrigger>
            </TabsList>
          </div>

          <ScrollArea className="flex-1 p-6">
            {/* Resumo */}
            <TabsContent value="resumo" className="space-y-6 mt-0">
              <section className="space-y-4 text-sm">
                <h3 className="font-semibold flex items-center gap-2">
                  <User className="h-4 w-4" /> Dados de Contato
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Mail className="h-4 w-4" /> {client.email || "Não informado"}
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Phone className="h-4 w-4" /> {client.telefone || "Não informado"}
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground col-span-full">
                    <MapPin className="h-4 w-4" /> 
                    {client.endereco ? `${client.endereco}, ${client.cidade}/${client.estado}` : "Sem endereço cadastrado"}
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Calendar className="h-4 w-4" /> 
                    Nasc: {client.data_nascimento ? format(new Date(client.data_nascimento), "dd/MM/yyyy") : "Não informado"}
                  </div>
                </div>
              </section>

              <section className="space-y-4">
                <h3 className="font-semibold flex items-center gap-2 text-sm">
                  <StickyNote className="h-4 w-4" /> Anotações Recentes
                </h3>
                <div className="space-y-3">
                  {notes?.slice(0, 3).map((note: ClientNote) => (
                    <div key={note.id} className="p-3 rounded-lg border bg-muted/20 text-sm">
                      <p className="line-clamp-2">{note.conteudo}</p>
                      <p className="text-[10px] text-muted-foreground mt-2">
                        {format(new Date(note.created_at), "dd/MM/yyyy HH:mm")}
                      </p>
                    </div>
                  ))}
                  {(!notes || notes.length === 0) && (
                    <p className="text-sm text-muted-foreground">Nenhuma anotação registrada.</p>
                  )}
                </div>
              </section>
            </TabsContent>

            {/* Apólices */}
            <TabsContent value="apolices" className="space-y-4 mt-0">
              {policies?.map((policy: ClientPolicy) => (
                <div key={policy.id} className="p-4 rounded-xl border hover:bg-muted/10 transition-colors">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <p className="font-bold">{policy.seguradora}</p>
                      <p className="text-xs text-muted-foreground">#{policy.numero_apolice}</p>
                    </div>
                    <Badge variant={policy.status === "ativa" ? "default" : "secondary"}>
                      {policy.status}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-muted-foreground">Prêmio:</span>
                      <p className="font-medium">R$ {policy.valor_premio?.toLocaleString('pt-BR')}</p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Vencimento:</span>
                      <p className="font-medium">{format(new Date(policy.data_fim), "dd/MM/yyyy")}</p>
                    </div>
                  </div>
                </div>
              ))}
              {(!policies || policies.length === 0) && (
                <p className="text-sm text-muted-foreground text-center py-8">Nenhuma apólice encontrada.</p>
              )}
            </TabsContent>

            {/* Sinistros */}
            <TabsContent value="sinistros" className="space-y-4 mt-0">
              {sinistros?.map((sinistro: Sinistro) => (
                <div key={sinistro.id} className="p-4 rounded-xl border border-destructive/20 bg-destructive/5">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <p className="font-bold flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4 text-destructive" />
                        {sinistro.numero_sinistro}
                      </p>
                      <p className="text-xs text-muted-foreground">{sinistro.descricao_resumida}</p>
                    </div>
                    <Badge variant="outline" className={cn(
                      sinistro.status === "aberto" ? "border-destructive text-destructive" : ""
                    )}>
                      {sinistro.status}
                    </Badge>
                  </div>
                  <div className="text-xs mt-2 text-muted-foreground">
                    Ocorrência: {format(new Date(sinistro.data_ocorrencia), "dd/MM/yyyy")}
                  </div>
                </div>
              ))}
              {(!sinistros || sinistros.length === 0) && (
                <div className="text-center py-8">
                  <p className="text-sm text-muted-foreground">Nenhum sinistro registrado.</p>
                </div>
              )}
            </TabsContent>

            {/* Comissões */}
            <TabsContent value="comissoes" className="space-y-4 mt-0">
              <div className="bg-primary/5 rounded-lg p-4 mb-4 border border-primary/10">
                <p className="text-sm font-medium mb-1">Ajuste de Margem por Cliente</p>
                <p className="text-xs text-muted-foreground">
                  Histórico cronológico de comissões acordadas.
                </p>
              </div>
              <div className="space-y-4 relative before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-border">
                {commissionTerms?.map((term: { id: string; percent: number; is_active: boolean; starts_at: string; ends_at: string | null; notes: string | null }) => (
                  <div key={term.id} className="relative pl-8">
                    <div className="absolute left-0 top-1.5 h-5 w-5 rounded-full border-4 border-background bg-primary"></div>
                    <div className="p-3 rounded-lg border bg-card">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-bold text-primary">{term.percent}% de Comissão</span>
                        {term.is_active && <Badge variant="outline" className="text-[10px] bg-success/10 text-success border-success/20">Ativo</Badge>}
                      </div>
                      <p className="text-[10px] text-muted-foreground">
                        Vigência: {term.starts_at ? format(new Date(term.starts_at), "dd/MM/yyyy") : "Início"} 
                        {term.ends_at ? ` até ${format(new Date(term.ends_at), "dd/MM/yyyy")}` : " - Atual"}
                      </p>
                      {term.notes && <p className="text-xs mt-2 text-muted-foreground italic">"{term.notes}"</p>}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* Documentos */}
            <TabsContent value="documentos" className="space-y-3 mt-0">
              {documents?.map((doc: { id: string; nome: string; tipo: string; tamanho: number; url: string }) => (
                <div key={doc.id} className="flex items-center justify-between p-3 rounded-lg border bg-background hover:bg-muted/10 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded bg-muted">
                      <Files className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">{doc.nome}</p>
                      <p className="text-[10px] text-muted-foreground">
                        {doc.tipo} • {doc.tamanho ? `${(doc.tamanho / 1024).toFixed(1)} KB` : "Tamanho desconhecido"}
                      </p>
                    </div>
                  </div>
                  <a href={doc.url} target="_blank" rel="noreferrer">
                    <FileText className="h-4 w-4 text-primary cursor-pointer" />
                  </a>
                </div>
              ))}
              {(!documents || documents.length === 0) && (
                <p className="text-sm text-muted-foreground text-center py-8">Nenhum documento anexado.</p>
              )}
            </TabsContent>
          </ScrollArea>
        </Tabs>
      </SheetContent>
    </Sheet>
  );
}
