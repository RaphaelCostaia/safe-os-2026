import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Calendar, 
  Shield, 
  Heart, 
  Car, 
  Home, 
  FileText,
  AlertCircle,
  CheckCircle,
  Clock,
  Package
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useClientPolicies, type ClientPolicy } from "@/hooks/useClientPolicies";

interface ClientTimelineProps {
  clientId: string;
  clientName: string;
}

const categoryIcons: Record<string, React.ElementType> = {
  "rc_profissional": Shield,
  "vida": Heart,
  "dit": FileText,
  "auto": Car,
  "residencial": Home,
  "consorcio": FileText,
  "saude": Heart,
  "empresarial": Package,
};

const categoryLabels: Record<string, string> = {
  "rc_profissional": "RC Profissional",
  "vida": "Seguro de Vida",
  "dit": "DIT / Renda Protegida",
  "auto": "Seguro Auto",
  "residencial": "Seguro Residencial",
  "consorcio": "Consórcio",
  "saude": "Plano de Saúde",
  "empresarial": "Seguro Empresarial",
};

export function ClientTimeline({ clientId, clientName }: ClientTimelineProps) {
  const { data: policies = [], isLoading } = useClientPolicies(clientId);

  const calculateDaysRemaining = (endDate: string) => {
    const end = new Date(endDate);
    const today = new Date();
    const diff = Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return diff;
  };

  const calculateProgress = (startDate: string, endDate: string) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const today = new Date();
    const total = end.getTime() - start.getTime();
    const elapsed = today.getTime() - start.getTime();
    return Math.min(100, Math.max(0, (elapsed / total) * 100));
  };

  const getStatusConfig = (status: string, daysRemaining: number) => {
    if (status === "cancelada" || status === "vencida" || status === "expirada" || daysRemaining < 0) {
      return { 
        color: "text-destructive", 
        bgColor: "bg-destructive/10", 
        borderColor: "border-destructive/30",
        icon: AlertCircle,
        label: status === "cancelada" ? "Cancelada" : "Vencida"
      };
    }
    if (daysRemaining <= 30) {
      return { 
        color: "text-warning", 
        bgColor: "bg-warning/10", 
        borderColor: "border-warning/30",
        icon: Clock,
        label: "Vencendo"
      };
    }
    if (status === "pendente") {
      return { 
        color: "text-muted-foreground", 
        bgColor: "bg-muted/50", 
        borderColor: "border-border",
        icon: Clock,
        label: "Pendente"
      };
    }
    return { 
      color: "text-success", 
      bgColor: "bg-success/10", 
      borderColor: "border-success/30",
      icon: CheckCircle,
      label: "Ativa"
    };
  };

  if (isLoading) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg">Apólices</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2].map((i) => (
            <div key={i} className="space-y-2">
              <Skeleton className="h-20 w-full" />
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50 bg-card">
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between">
          <CardTitle className="text-lg">Apólices do Cliente</CardTitle>
          <Badge variant="outline" className="text-xs">
            {policies.length} apólice{policies.length !== 1 ? 's' : ''}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {policies.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="h-10 w-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">Nenhuma apólice encontrada</p>
            <p className="text-xs">As apólices do cliente aparecerão aqui</p>
          </div>
        ) : (
          <div className="relative">
            {policies.map((policy, index) => {
              const daysRemaining = calculateDaysRemaining(policy.data_fim);
              const progress = calculateProgress(policy.data_inicio, policy.data_fim);
              const statusConfig = getStatusConfig(policy.status, daysRemaining);
              const categoria = policy.produto?.categoria || "outro";
              const ProductIcon = categoryIcons[categoria] || FileText;
              const StatusIcon = statusConfig.icon;

              return (
                <div 
                  key={policy.id} 
                  className={cn(
                    "relative pl-8 pb-6 last:pb-0",
                    index !== policies.length - 1 && "border-l-2 border-border/50 ml-3"
                  )}
                >
                  {/* Timeline dot */}
                  <div className={cn(
                    "absolute -left-[5px] top-0 w-4 h-4 rounded-full border-2 bg-background",
                    statusConfig.borderColor
                  )}>
                    <div className={cn("w-2 h-2 rounded-full m-0.5", statusConfig.bgColor)} />
                  </div>

                  {/* Policy Card */}
                  <div className={cn(
                    "rounded-lg border p-4 transition-all hover:shadow-md",
                    statusConfig.borderColor,
                    statusConfig.bgColor
                  )}>
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className={cn("p-2 rounded-lg", statusConfig.bgColor)}>
                          <ProductIcon className={cn("h-5 w-5", statusConfig.color)} />
                        </div>
                        <div>
                          <p className="font-medium">
                            {policy.produto?.nome || categoryLabels[categoria] || "Produto"}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {policy.seguradora} • #{policy.numero_apolice}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <StatusIcon className={cn("h-4 w-4", statusConfig.color)} />
                        <Badge className={cn("text-xs", statusConfig.bgColor, statusConfig.color, "border-0")}>
                          {statusConfig.label}
                        </Badge>
                      </div>
                    </div>

                    {/* Dates and Progress */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-1 text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          <span>Início: {new Date(policy.data_inicio).toLocaleDateString('pt-BR')}</span>
                        </div>
                        <div className="flex items-center gap-1 text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          <span>Fim: {new Date(policy.data_fim).toLocaleDateString('pt-BR')}</span>
                        </div>
                      </div>
                      
                      <Progress value={progress} className="h-2" />
                      
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">
                          {daysRemaining > 0 
                            ? `${daysRemaining} dias restantes` 
                            : daysRemaining === 0 
                              ? "Vence hoje!" 
                              : `Vencida há ${Math.abs(daysRemaining)} dias`
                          }
                        </span>
                        <span className="text-sm font-semibold">
                          R$ {policy.valor_premio.toLocaleString('pt-BR')}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
