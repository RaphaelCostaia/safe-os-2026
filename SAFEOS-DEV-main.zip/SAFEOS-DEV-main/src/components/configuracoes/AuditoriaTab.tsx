import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  History,
  Search,
  RefreshCw,
  Filter,
  Loader2,
  Eye,
  Calendar,
  User,
  FileText,
} from "lucide-react";
import {
  useActivityLog,
  useActivityEntityTypes,
  useActivityActions,
  ActivityLog,
  getEntityTypeIcon,
  getActionName,
  getEntityTypeName,
} from "@/hooks/useActivityLog";
import { format, subDays } from "date-fns";
import { ptBR } from "date-fns/locale";

export function AuditoriaTab() {
  const [filters, setFilters] = useState({
    entity_type: "",
    action: "",
    startDate: format(subDays(new Date(), 30), "yyyy-MM-dd"),
    endDate: format(new Date(), "yyyy-MM-dd"),
    limit: 100,
  });
  const [selectedLog, setSelectedLog] = useState<ActivityLog | null>(null);

  const { data: logs, isLoading, refetch } = useActivityLog({
    entity_type: filters.entity_type || undefined,
    action: filters.action || undefined,
    startDate: filters.startDate ? `${filters.startDate}T00:00:00` : undefined,
    endDate: filters.endDate ? `${filters.endDate}T23:59:59` : undefined,
    limit: filters.limit,
  });

  const { data: entityTypes } = useActivityEntityTypes();
  const { data: actions } = useActivityActions();

  const clearFilters = () => {
    setFilters({
      entity_type: "",
      action: "",
      startDate: format(subDays(new Date(), 30), "yyyy-MM-dd"),
      endDate: format(new Date(), "yyyy-MM-dd"),
      limit: 100,
    });
  };

  const getActionBadgeVariant = (action: string): "default" | "secondary" | "destructive" | "outline" => {
    if (action === "delete") return "destructive";
    if (action === "create") return "default";
    if (action === "update" || action === "status_change") return "secondary";
    return "outline";
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="border-border/50 bg-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg flex items-center gap-2">
                <History className="h-5 w-5 text-primary" />
                Histórico de Atividades
              </CardTitle>
              <CardDescription>
                Registro de todas as ações realizadas no sistema
              </CardDescription>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => refetch()}
              disabled={isLoading}
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4" />
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
            <div className="space-y-2">
              <Label className="text-xs">Tipo de Entidade</Label>
              <Select
                value={filters.entity_type}
                onValueChange={(value) =>
                  setFilters({ ...filters, entity_type: value === "all" ? "" : value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Todos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  {entityTypes?.map((type) => (
                    <SelectItem key={type} value={type}>
                      {getEntityTypeIcon(type)} {getEntityTypeName(type)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-xs">Ação</Label>
              <Select
                value={filters.action}
                onValueChange={(value) =>
                  setFilters({ ...filters, action: value === "all" ? "" : value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Todas" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas</SelectItem>
                  {actions?.map((action) => (
                    <SelectItem key={action} value={action}>
                      {getActionName(action)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-xs">Data Início</Label>
              <Input
                type="date"
                value={filters.startDate}
                onChange={(e) =>
                  setFilters({ ...filters, startDate: e.target.value })
                }
              />
            </div>

            <div className="space-y-2">
              <Label className="text-xs">Data Fim</Label>
              <Input
                type="date"
                value={filters.endDate}
                onChange={(e) =>
                  setFilters({ ...filters, endDate: e.target.value })
                }
              />
            </div>

            <div className="flex items-end">
              <Button
                variant="ghost"
                size="sm"
                onClick={clearFilters}
                className="w-full"
              >
                <Filter className="h-4 w-4 mr-2" />
                Limpar Filtros
              </Button>
            </div>
          </div>

          {/* Results count */}
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-muted-foreground">
              {logs?.length || 0} registros encontrados
            </p>
          </div>

          {/* Table */}
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : logs?.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <History className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Nenhuma atividade encontrada</p>
              <p className="text-sm">Tente ajustar os filtros</p>
            </div>
          ) : (
            <div className="border rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[180px]">Data/Hora</TableHead>
                    <TableHead>Usuário</TableHead>
                    <TableHead>Ação</TableHead>
                    <TableHead>Entidade</TableHead>
                    <TableHead>Descrição</TableHead>
                    <TableHead className="w-[70px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {logs?.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell className="font-mono text-xs">
                        {format(new Date(log.created_at), "dd/MM/yyyy HH:mm:ss", {
                          locale: ptBR,
                        })}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">
                            {log.user_profile?.full_name || "Sistema"}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getActionBadgeVariant(log.action)}>
                          {getActionName(log.action)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span>{getEntityTypeIcon(log.entity_type)}</span>
                          <span className="text-sm">
                            {getEntityTypeName(log.entity_type)}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="max-w-[300px] truncate">
                        {log.description || "-"}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setSelectedLog(log)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Detail Modal */}
      <Dialog open={!!selectedLog} onOpenChange={() => setSelectedLog(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Detalhes da Atividade
            </DialogTitle>
          </DialogHeader>
          {selectedLog && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-xs text-muted-foreground">Data/Hora</Label>
                  <p className="font-mono text-sm">
                    {format(new Date(selectedLog.created_at), "dd/MM/yyyy HH:mm:ss", {
                      locale: ptBR,
                    })}
                  </p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Usuário</Label>
                  <p className="text-sm">
                    {selectedLog.user_profile?.full_name || "Sistema"}
                  </p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Ação</Label>
                  <Badge variant={getActionBadgeVariant(selectedLog.action)}>
                    {getActionName(selectedLog.action)}
                  </Badge>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Entidade</Label>
                  <p className="text-sm">
                    {getEntityTypeIcon(selectedLog.entity_type)}{" "}
                    {getEntityTypeName(selectedLog.entity_type)}
                  </p>
                </div>
              </div>

              <div>
                <Label className="text-xs text-muted-foreground">ID da Entidade</Label>
                <p className="font-mono text-xs bg-muted p-2 rounded">
                  {selectedLog.entity_id}
                </p>
              </div>

              <div>
                <Label className="text-xs text-muted-foreground">Descrição</Label>
                <p className="text-sm">{selectedLog.description || "-"}</p>
              </div>

              {selectedLog.metadata && (
                <div>
                  <Label className="text-xs text-muted-foreground">Metadados</Label>
                  <pre className="text-xs bg-muted p-3 rounded overflow-auto max-h-40">
                    {JSON.stringify(selectedLog.metadata, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
