import { useState, useRef, useEffect, useMemo } from "react";
import { 
  Search, 
  Plus, 
  Check, 
  Sparkles, 
  X, 
  ShieldCheck, 
  ChevronDown, 
  Loader2
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useProdutos, useCreateProduto, type Produto } from "@/hooks/useProdutos";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export interface ProdutoComboboxProps {
  value: string;
  onChange: (produtoId: string, produto?: Produto, customNome?: string) => void;
  customValue?: string;
  onCustomValueChange?: (text: string) => void;
  label?: string;
  placeholder?: string;
  required?: boolean;
  error?: string;
  disabled?: boolean;
  defaultSeguradora?: string;
  defaultComissao?: string | number;
  className?: string;
  hideLabel?: boolean;
  onBlur?: () => void;
}

// Sugestões padrão especializadas para corretoras médicas (MedSafe)
const DEFAULT_MEDSAFE_PRODUCTS = [
  { nome: "RCP Médico Individual", categoria: "rcp", seguradora: "Porto Seguro", comissao: 20 },
  { nome: "RCP Profissional da Saúde", categoria: "rcp", seguradora: "Akad Seguros", comissao: 20 },
  { nome: "RCP Clínica e PJ Médica", categoria: "rcp", seguradora: "Akad Seguros", comissao: 20 },
  { nome: "DIT - Diária de Incapacidade Temporária", categoria: "dit", seguradora: "Unimed Seguros", comissao: 25 },
  { nome: "Seguro de Vida Médico", categoria: "vida", seguradora: "MAG Seguros", comissao: 25 },
  { nome: "Plano de Saúde Individual / PME", categoria: "saude", seguradora: "SulAmérica", comissao: 10 },
  { nome: "Seguro Consultório / Clínicas", categoria: "empresarial", seguradora: "Porto Seguro", comissao: 18 },
];

export function ProdutoCombobox({
  value,
  onChange,
  customValue,
  onCustomValueChange,
  label = "Produto",
  placeholder = "Digite ou selecione o produto (opcional)",
  required = false,
  error,
  disabled = false,
  defaultSeguradora = "Porto Seguro",
  defaultComissao = 20,
  className,
  hideLabel = false,
  onBlur,
}: ProdutoComboboxProps) {
  const { data: produtos = [], isLoading } = useProdutos();
  const createProduto = useCreateProduto();

  const [isOpen, setIsOpen] = useState(false);
  const [inputText, setInputText] = useState("");
  const [showFullCreateModal, setShowFullCreateModal] = useState(false);
  const [isCreatingQuick, setIsCreatingQuick] = useState(false);

  // Full modal creation form state
  const [modalForm, setModalForm] = useState({
    nome: "",
    categoria: "rcp",
    seguradora: defaultSeguradora || "Porto Seguro",
    comissao_percentual: String(defaultComissao || 20),
    codigo: "",
    descricao: "",
  });

  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Identify currently selected product
  const selectedProduct = useMemo(() => {
    return produtos.find((p) => p.id === value);
  }, [produtos, value]);

  // Keep internal text in sync with selected product or customValue
  useEffect(() => {
    if (selectedProduct) {
      setInputText(selectedProduct.nome);
    } else if (customValue !== undefined) {
      setInputText(customValue);
    } else if (!value) {
      setInputText("");
    }
  }, [selectedProduct, value, customValue]);

  // Handle outside click to close dropdown safely without modal dismissal
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isOpen]);

  // Filter products by search query
  const filteredProducts = useMemo(() => {
    const q = inputText.trim().toLowerCase();
    if (!q) return produtos;
    return produtos.filter((p) => {
      const matchName = p.nome?.toLowerCase().includes(q);
      const matchCat = p.categoria?.toLowerCase().includes(q);
      const matchSeg = p.seguradora?.toLowerCase().includes(q);
      const matchCod = p.codigo?.toLowerCase().includes(q);
      return matchName || matchCat || matchSeg || matchCod;
    });
  }, [produtos, inputText]);

  // Check if search query matches an existing product name exactly
  const hasExactMatch = useMemo(() => {
    const q = inputText.trim().toLowerCase();
    if (!q) return false;
    return produtos.some((p) => p.nome.trim().toLowerCase() === q);
  }, [produtos, inputText]);

  // Infer category from product name
  const inferCategory = (name: string): string => {
    const lower = name.toLowerCase();
    if (lower.includes("rcp") || lower.includes("responsabilidade civil") || lower.includes("médic") || lower.includes("erro")) return "rcp";
    if (lower.includes("dit") || lower.includes("incapacidade") || lower.includes("diaria") || lower.includes("diária")) return "dit";
    if (lower.includes("vida") || lower.includes("morte") || lower.includes("invalidez")) return "vida";
    if (lower.includes("saude") || lower.includes("saúde") || lower.includes("odont") || lower.includes("hospital")) return "saude";
    if (lower.includes("auto") || lower.includes("veicul") || lower.includes("veícul") || lower.includes("carro") || lower.includes("moto")) return "auto";
    if (lower.includes("resid") || lower.includes("casa") || lower.includes("lar")) return "residencial";
    if (lower.includes("empresa") || lower.includes("consultorio") || lower.includes("consultório") || lower.includes("clinica") || lower.includes("clínica")) return "empresarial";
    return "rcp";
  };

  // Quick creation of product when user types custom text
  const handleCreateQuick = async (nameToCreate: string) => {
    const cleanName = nameToCreate.trim();
    if (!cleanName || cleanName.length < 2) {
      toast.error("O nome do produto deve ter no mínimo 2 caracteres");
      return;
    }

    setIsCreatingQuick(true);
    const inferredCat = inferCategory(cleanName);
    const categoryPrefix = inferredCat.toUpperCase().slice(0, 4);
    const autoCode = `${categoryPrefix}-${Math.floor(1000 + Math.random() * 9000)}`;

    try {
      const newProd = await createProduto.mutateAsync({
        nome: cleanName,
        categoria: inferredCat,
        seguradora: defaultSeguradora || "Porto Seguro",
        comissao_percentual: typeof defaultComissao === "number" ? defaultComissao : (parseFloat(String(defaultComissao)) || 20),
        codigo: autoCode,
        ativo: true,
      });

      if (newProd?.id) {
        setInputText(newProd.nome);
        onChange(newProd.id, newProd, newProd.nome);
        if (onCustomValueChange) onCustomValueChange(newProd.nome);
        setIsOpen(false);
        toast.success(`Produto "${cleanName}" cadastrado e selecionado!`);
      }
    } catch (err: any) {
      console.error("Erro ao cadastrar produto rápido:", err);
      toast.error(err.message || "Não foi possível criar o produto.");
    } finally {
      setIsCreatingQuick(false);
    }
  };

  // Handle detailed modal creation
  const handleDetailedCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!modalForm.nome.trim()) {
      toast.error("O nome do produto é obrigatório");
      return;
    }

    setIsCreatingQuick(true);
    const cleanName = modalForm.nome.trim();
    const cleanCat = modalForm.categoria || inferCategory(cleanName);
    const categoryPrefix = cleanCat.toUpperCase().slice(0, 4);
    const autoCode = modalForm.codigo.trim() || `${categoryPrefix}-${Math.floor(1000 + Math.random() * 9000)}`;

    try {
      const newProd = await createProduto.mutateAsync({
        nome: cleanName,
        categoria: cleanCat,
        seguradora: modalForm.seguradora.trim() || defaultSeguradora || "Porto Seguro",
        comissao_percentual: parseFloat(modalForm.comissao_percentual) || 20,
        codigo: autoCode,
        descricao: modalForm.descricao.trim() || null,
        ativo: true,
      });

      if (newProd?.id) {
        setInputText(newProd.nome);
        onChange(newProd.id, newProd, newProd.nome);
        if (onCustomValueChange) onCustomValueChange(newProd.nome);
        setShowFullCreateModal(false);
        setIsOpen(false);
        toast.success(`Produto "${cleanName}" cadastrado com sucesso!`);
      }
    } catch (err: any) {
      console.error("Erro ao cadastrar produto detalhado:", err);
      toast.error(err.message || "Falha ao salvar produto");
    } finally {
      setIsCreatingQuick(false);
    }
  };

  const getCategoryBadgeClass = (categoria: string) => {
    switch (categoria.toLowerCase()) {
      case "rcp":
        return "bg-indigo-100 text-indigo-800 border-indigo-200";
      case "dit":
        return "bg-purple-100 text-purple-800 border-purple-200";
      case "vida":
        return "bg-rose-100 text-rose-800 border-rose-200";
      case "saude":
        return "bg-emerald-100 text-emerald-800 border-emerald-200";
      case "auto":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "residencial":
        return "bg-amber-100 text-amber-800 border-amber-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const text = e.target.value;
    setInputText(text);
    setIsOpen(true);

    if (onCustomValueChange) {
      onCustomValueChange(text);
    }

    // Check if what was typed exactly matches an existing product
    const exact = produtos.find((p) => p.nome.trim().toLowerCase() === text.trim().toLowerCase());
    if (exact) {
      onChange(exact.id, exact, text);
    } else {
      // Pass empty ID and the custom text so caller knows custom text was typed
      onChange("", undefined, text);
    }
  };

  const handleClear = () => {
    setInputText("");
    onChange("", undefined, "");
    if (onCustomValueChange) onCustomValueChange("");
    if (inputRef.current) inputRef.current.focus();
  };

  return (
    <div className={cn("relative grid gap-1.5", className)} ref={containerRef}>
      {!hideLabel && (
        <div className="flex items-center justify-between">
          <Label className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
            {label}
            {required && <span className="text-destructive">*</span>}
            <span className="text-[10px] font-normal lowercase text-muted-foreground/75">
              ({required ? "obrigatório" : "opcional"})
            </span>
          </Label>
          <button
            type="button"
            onClick={() => {
              setModalForm({
                nome: inputText.trim() || "",
                categoria: inputText ? inferCategory(inputText) : "rcp",
                seguradora: defaultSeguradora || "Porto Seguro",
                comissao_percentual: String(defaultComissao || 20),
                codigo: "",
                descricao: "",
              });
              setShowFullCreateModal(true);
            }}
            className="text-[11px] font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 transition"
          >
            <Plus className="h-3 w-3" />
            Novo Produto
          </button>
        </div>
      )}

      {/* Main Direct Interactive Input */}
      <div className="relative">
        <div className="relative flex items-center">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground/70 pointer-events-none" />
          
          <Input
            ref={inputRef}
            type="text"
            disabled={disabled}
            value={inputText}
            onChange={handleInputChange}
            onFocus={() => !disabled && setIsOpen(true)}
            onBlur={onBlur}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                if (filteredProducts.length === 1) {
                  const p = filteredProducts[0];
                  setInputText(p.nome);
                  onChange(p.id, p, p.nome);
                  setIsOpen(false);
                } else if (inputText.trim().length >= 2 && !hasExactMatch) {
                  handleCreateQuick(inputText);
                }
              } else if (e.key === "Escape") {
                setIsOpen(false);
              }
            }}
            placeholder={placeholder}
            className={cn(
              "pl-9 pr-16 h-9 text-xs transition-colors",
              selectedProduct && "font-medium text-gray-900 border-indigo-200 bg-indigo-50/20",
              error && "border-destructive focus-visible:ring-destructive"
            )}
          />

          <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
            {selectedProduct && (
              <Badge className={cn("text-[9px] uppercase px-1 py-0 hidden sm:inline-flex", getCategoryBadgeClass(selectedProduct.categoria))}>
                {selectedProduct.categoria}
              </Badge>
            )}

            {inputText ? (
              <button
                type="button"
                onClick={handleClear}
                disabled={disabled}
                className="p-1 text-muted-foreground hover:text-destructive transition rounded"
                title="Limpar seleção"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            ) : null}

            <button
              type="button"
              onClick={() => !disabled && setIsOpen(!isOpen)}
              className="p-1 text-muted-foreground hover:text-gray-900 transition"
              title="Abrir lista de produtos"
            >
              <ChevronDown className={cn("h-3.5 w-3.5 transition-transform duration-200", isOpen && "rotate-180")} />
            </button>
          </div>
        </div>

        {/* Dropdown Suggestions Panel */}
        {isOpen && (
          <div className="absolute left-0 right-0 top-full mt-1.5 z-50 bg-popover border border-border/80 rounded-lg shadow-2xl p-2 animate-in fade-in-0 zoom-in-95 duration-100">
            {/* If user typed custom text not currently in catalog */}
            {inputText.trim().length >= 2 && !hasExactMatch && (
              <div className="mb-2 p-1">
                <button
                  type="button"
                  disabled={isCreatingQuick}
                  onClick={() => handleCreateQuick(inputText)}
                  className="w-full text-left p-2 rounded-md bg-indigo-50 hover:bg-indigo-100/90 border border-indigo-200 text-indigo-950 transition flex items-center justify-between group shadow-xs"
                >
                  <div className="flex items-center gap-2 overflow-hidden">
                    {isCreatingQuick ? (
                      <Loader2 className="h-3.5 w-3.5 text-indigo-600 animate-spin shrink-0" />
                    ) : (
                      <Sparkles className="h-3.5 w-3.5 text-indigo-600 group-hover:scale-110 transition shrink-0" />
                    )}
                    <div className="truncate">
                      <div className="font-bold text-xs text-indigo-950 truncate">
                        Cadastrar novo: <span className="underline decoration-indigo-400 font-extrabold">"{inputText.trim()}"</span>
                      </div>
                      <div className="text-[10px] text-indigo-700/80">
                        Salva no catálogo e seleciona nesta apólice
                      </div>
                    </div>
                  </div>
                  <Badge className="bg-indigo-600 text-white text-[10px] font-bold shrink-0 ml-2">
                    + Cadastrar
                  </Badge>
                </button>
              </div>
            )}

            {/* Product List */}
            <div className="max-h-56 overflow-y-auto space-y-1 pr-1">
              {isLoading ? (
                <div className="p-4 text-center text-xs text-muted-foreground flex items-center justify-center gap-2">
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  Carregando catálogo...
                </div>
              ) : filteredProducts.length > 0 ? (
                <div>
                  <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground px-2 py-1">
                    Produtos Cadastrados ({filteredProducts.length})
                  </div>
                  {filteredProducts.map((prod) => {
                    const isSelected = prod.id === value;
                    return (
                      <button
                        key={prod.id}
                        type="button"
                        onClick={() => {
                          setInputText(prod.nome);
                          onChange(prod.id, prod, prod.nome);
                          if (onCustomValueChange) onCustomValueChange(prod.nome);
                          setIsOpen(false);
                        }}
                        className={cn(
                          "w-full text-left px-2.5 py-2 rounded-md text-xs flex items-center justify-between transition group",
                          isSelected
                            ? "bg-indigo-50 text-indigo-900 font-semibold"
                            : "hover:bg-accent text-gray-800"
                        )}
                      >
                        <div className="flex items-center gap-2 overflow-hidden">
                          <Badge className={cn("text-[9px] uppercase px-1 py-0.2 shrink-0", getCategoryBadgeClass(prod.categoria))}>
                            {prod.categoria}
                          </Badge>
                          <span className="truncate">{prod.nome}</span>
                          {prod.seguradora && (
                            <span className="text-[11px] text-muted-foreground shrink-0 hidden sm:inline">
                              ({prod.seguradora})
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2 shrink-0 ml-2">
                          {prod.comissao_percentual !== null && prod.comissao_percentual !== undefined && (
                            <span className="text-[10px] text-muted-foreground font-mono bg-muted px-1.5 py-0.5 rounded">
                              {prod.comissao_percentual}%
                            </span>
                          )}
                          {isSelected && <Check className="h-3.5 w-3.5 text-indigo-600 shrink-0" />}
                        </div>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="p-3 text-center text-xs text-muted-foreground">
                  Nenhum produto cadastrado com esse nome.
                </div>
              )}

              {/* MedSafe Recommended Core Products Section */}
              {(!inputText || filteredProducts.length < 3) && (
                <div className="pt-2 border-t border-border/40 mt-2">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-indigo-900 px-2 py-1 flex items-center gap-1">
                    <ShieldCheck className="h-3 w-3 text-indigo-600" />
                    Sugestões Rápidas MedSafe
                  </div>
                  <div className="grid grid-cols-1 gap-1">
                    {DEFAULT_MEDSAFE_PRODUCTS.map((sug, idx) => {
                      const alreadyExists = produtos.find((p) => p.nome.toLowerCase() === sug.nome.toLowerCase());
                      return (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            if (alreadyExists) {
                              setInputText(alreadyExists.nome);
                              onChange(alreadyExists.id, alreadyExists, alreadyExists.nome);
                              if (onCustomValueChange) onCustomValueChange(alreadyExists.nome);
                              setIsOpen(false);
                            } else {
                              handleCreateQuick(sug.nome);
                            }
                          }}
                          className="text-left px-2 py-1.5 rounded text-xs hover:bg-indigo-50/60 text-muted-foreground hover:text-indigo-950 flex items-center justify-between transition"
                        >
                          <span className="truncate">
                            {alreadyExists ? "✓ " : "+ "}
                            {sug.nome}
                          </span>
                          <span className="text-[10px] text-muted-foreground font-mono">
                            {sug.comissao}%
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Actions */}
            <div className="pt-2 border-t border-border/40 mt-2 flex items-center justify-between text-xs text-muted-foreground">
              <span className="text-[11px]">
                {produtos.length} {produtos.length === 1 ? "produto ativo" : "produtos ativos"}
              </span>
              <button
                type="button"
                onClick={() => {
                  setModalForm({
                    nome: inputText.trim() || "",
                    categoria: inputText ? inferCategory(inputText) : "rcp",
                    seguradora: defaultSeguradora || "Porto Seguro",
                    comissao_percentual: String(defaultComissao || 20),
                    codigo: "",
                    descricao: "",
                  });
                  setShowFullCreateModal(true);
                  setIsOpen(false);
                }}
                className="text-[11px] font-semibold text-indigo-600 hover:text-indigo-800 underline flex items-center gap-1"
              >
                + Formulário Completo
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Helpful info message below field indicating it is flexible and not blocking */}
      <p className="text-[10px] text-muted-foreground/80 leading-tight">
        {selectedProduct ? (
          <span className="text-indigo-600 font-medium">✓ Vinculado: {selectedProduct.nome}</span>
        ) : inputText.trim() ? (
          <span className="text-indigo-600">✨ Será cadastrado e vinculado como "{inputText.trim()}"</span>
        ) : (
          <span>Opcional: caso não informe, será registrado automaticamente como Seguro Geral.</span>
        )}
      </p>

      {error && <span className="text-xs text-destructive font-medium">{error}</span>}

      {/* Detailed Product Creation Dialog */}
      <Dialog open={showFullCreateModal} onOpenChange={setShowFullCreateModal}>
        <DialogContent className="max-w-md bg-card border-border/70 shadow-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-indigo-950 text-base font-bold">
              <Sparkles className="h-5 w-5 text-indigo-600" />
              Cadastrar Novo Produto
            </DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground">
              Cadastre um novo seguro ou serviço no catálogo da MedSafe e vincule-o imediatamente à proposta.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleDetailedCreateSubmit} className="space-y-3.5 py-2">
            <div className="grid gap-1.5">
              <Label htmlFor="nome_prod" className="text-xs font-bold uppercase text-muted-foreground">
                Nome do Produto *
              </Label>
              <Input
                id="nome_prod"
                required
                value={modalForm.nome}
                onChange={(e) => setModalForm({ ...modalForm, nome: e.target.value })}
                placeholder="Ex: RCP Médico Profissional, Seguro DIT..."
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label htmlFor="cat_prod" className="text-xs font-bold uppercase text-muted-foreground">
                  Categoria *
                </Label>
                <Select
                  value={modalForm.categoria}
                  onValueChange={(v) => setModalForm({ ...modalForm, categoria: v })}
                >
                  <SelectTrigger id="cat_prod">
                    <SelectValue placeholder="Categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rcp">RCP (Médico / Saúde)</SelectItem>
                    <SelectItem value="dit">DIT (Incapacidade)</SelectItem>
                    <SelectItem value="vida">Vida</SelectItem>
                    <SelectItem value="saude">Saúde / Odonto</SelectItem>
                    <SelectItem value="empresarial">Empresarial / Consultório</SelectItem>
                    <SelectItem value="auto">Automóvel</SelectItem>
                    <SelectItem value="residencial">Residencial</SelectItem>
                    <SelectItem value="outros">Outros</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-1.5">
                <Label htmlFor="seg_prod" className="text-xs font-bold uppercase text-muted-foreground">
                  Seguradora Padrão
                </Label>
                <Input
                  id="seg_prod"
                  value={modalForm.seguradora}
                  onChange={(e) => setModalForm({ ...modalForm, seguradora: e.target.value })}
                  placeholder="Ex: Porto Seguro, Akad..."
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-1.5">
                <Label htmlFor="com_prod" className="text-xs font-bold uppercase text-muted-foreground">
                  Comissão Padrão (%)
                </Label>
                <div className="relative">
                  <Input
                    id="com_prod"
                    type="number"
                    step="0.01"
                    value={modalForm.comissao_percentual}
                    onChange={(e) => setModalForm({ ...modalForm, comissao_percentual: e.target.value })}
                    placeholder="Ex: 20"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-muted-foreground">%</span>
                </div>
              </div>

              <div className="grid gap-1.5">
                <Label htmlFor="cod_prod" className="text-xs font-bold uppercase text-muted-foreground">
                  Código (Opcional)
                </Label>
                <Input
                  id="cod_prod"
                  value={modalForm.codigo}
                  onChange={(e) => setModalForm({ ...modalForm, codigo: e.target.value })}
                  placeholder="Ex: RCP-MED"
                />
              </div>
            </div>

            <div className="grid gap-1.5">
              <Label htmlFor="desc_prod" className="text-xs font-bold uppercase text-muted-foreground">
                Descrição Breve (Opcional)
              </Label>
              <Input
                id="desc_prod"
                value={modalForm.descricao}
                onChange={(e) => setModalForm({ ...modalForm, descricao: e.target.value })}
                placeholder="Ex: Cobertura completa para processos éticos e civis"
              />
            </div>

            <DialogFooter className="pt-3 border-t flex gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setShowFullCreateModal(false)}
                disabled={isCreatingQuick}
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                size="sm"
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold"
                disabled={isCreatingQuick || !modalForm.nome.trim()}
              >
                {isCreatingQuick && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Salvar e Selecionar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
