import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableFooter,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Wallet, Plus, Pencil, Trash2, Building, Briefcase, Wrench, Megaphone, FileText, HelpCircle, Loader2 } from "lucide-react";
import { useCustosFixos, CustoFixoInsert } from "@/hooks/useCustosFixos";

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
};

const categoriasCustoFixo = [
  { value: 'salarios', label: 'Salários' },
  { value: 'aluguel', label: 'Aluguel' },
  { value: 'ferramentas', label: 'Ferramentas' },
  { value: 'marketing', label: 'Marketing' },
  { value: 'impostos', label: 'Impostos' },
  { value: 'outros', label: 'Outros' },
];

const getCategoriaIcon = (categoria: string) => {
  const icons: Record<string, React.ElementType> = {
    salarios: Briefcase,
    aluguel: Building,
    ferramentas: Wrench,
    marketing: Megaphone,
    impostos: FileText,
    outros: HelpCircle,
  };
  return icons[categoria] || HelpCircle;
};

const getCategoriaLabel = (categoria: string) => {
  return categoriasCustoFixo.find(c => c.value === categoria)?.label || categoria;
};

const getRecorrenciaLabel = (recorrencia: string) => {
  const labels: Record<string, string> = {
    mensal: 'Mensal',
    anual: 'Anual',
    trimestral: 'Trimestral',
  };
  return labels[recorrencia] || recorrencia;
};

export function CustosFixosTab() {
  const { custosFixos, isLoading, createCusto, updateCusto, deleteCusto, isCreating, isUpdating } = useCustosFixos();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCustoId, setEditingCustoId] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    categoria: 'outros',
    descricao: '',
    valor: '',
    recorrencia: 'mensal',
    status: 'ativo',
  });

  const totalMensal = useMemo(() => {
    return custosFixos
      .filter(c => c.status === 'ativo')
      .reduce((sum, c) => {
        if (c.recorrencia === 'mensal') return sum + c.valor;
        if (c.recorrencia === 'anual') return sum + (c.valor / 12);
        if (c.recorrencia === 'trimestral') return sum + (c.valor / 3);
        return sum;
      }, 0);
  }, [custosFixos]);

  const handleOpenDialog = (custoId?: string) => {
    if (custoId) {
      const custo = custosFixos.find(c => c.id === custoId);
      if (custo) {
        setEditingCustoId(custoId);
        setFormData({
          categoria: custo.categoria,
          descricao: custo.descricao,
          valor: custo.valor.toString(),
          recorrencia: custo.recorrencia,
          status: custo.status,
        });
      }
    } else {
      setEditingCustoId(null);
      setFormData({
        categoria: 'outros',
        descricao: '',
        valor: '',
        recorrencia: 'mensal',
        status: 'ativo',
      });
    }
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    const valor = parseFloat(formData.valor.replace(/[^\d,]/g, '').replace(',', '.'));
    
    if (!formData.descricao || isNaN(valor) || valor <= 0) {
      return;
    }

    const custoData: CustoFixoInsert = {
      categoria: formData.categoria,
      descricao: formData.descricao,
      valor,
      recorrencia: formData.recorrencia,
      status: formData.status,
      responsavel_id: null,
    };

    if (editingCustoId) {
      updateCusto({ id: editingCustoId, ...custoData });
    } else {
      createCusto(custoData);
    }
    
    setIsDialogOpen(false);
  };

  const handleDelete = (id: string) => {
    deleteCusto(id);
  };

  const handleToggleStatus = (id: string, currentStatus: string) => {
    updateCusto({ 
      id, 
      status: currentStatus === 'ativo' ? 'inativo' : 'ativo' 
    });
  };

  if (isLoading) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-4">
          <Skeleton className="h-6 w-40" />
        </CardHeader>
        <CardContent className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50 bg-card">
      <CardHeader className="pb-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Wallet className="h-5 w-5 text-warning" />
            Custos Fixos
          </CardTitle>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Total Mensal</p>
              <p className="text-xl font-bold text-warning">{formatCurrency(totalMensal)}</p>
            </div>
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={() => handleOpenDialog()}>
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>{editingCustoId ? 'Editar Custo Fixo' : 'Novo Custo Fixo'}</DialogTitle>
                  <DialogDescription>
                    {editingCustoId ? 'Atualize os dados do custo fixo.' : 'Adicione um novo custo fixo recorrente.'}
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="categoria">Categoria</Label>
                    <Select
                      value={formData.categoria}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, categoria: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {categoriasCustoFixo.map(cat => (
                          <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="descricao">Descrição</Label>
                    <Input
                      id="descricao"
                      value={formData.descricao}
                      onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
                      placeholder="Ex: Aluguel do escritório"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="valor">Valor (R$)</Label>
                    <Input
                      id="valor"
                      value={formData.valor}
                      onChange={(e) => setFormData(prev => ({ ...prev, valor: e.target.value }))}
                      placeholder="0,00"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label>Recorrência</Label>
                      <Select
                        value={formData.recorrencia}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, recorrencia: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="mensal">Mensal</SelectItem>
                          <SelectItem value="trimestral">Trimestral</SelectItem>
                          <SelectItem value="anual">Anual</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label>Status</Label>
                      <Select
                        value={formData.status}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="ativo">Ativo</SelectItem>
                          <SelectItem value="inativo">Inativo</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancelar</Button>
                  <Button onClick={handleSave} disabled={isCreating || isUpdating}>
                    {(isCreating || isUpdating) && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                    Salvar
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-[50px]"></TableHead>
                <TableHead className="min-w-[120px]">Categoria</TableHead>
                <TableHead className="min-w-[200px]">Descrição</TableHead>
                <TableHead className="text-right w-[120px]">Valor</TableHead>
                <TableHead className="w-[100px]">Recorrência</TableHead>
                <TableHead className="w-[90px]">Status</TableHead>
                <TableHead className="w-[100px] text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {custosFixos.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    Nenhum custo fixo cadastrado
                  </TableCell>
                </TableRow>
              ) : (
                custosFixos.map((custo) => {
                  const Icon = getCategoriaIcon(custo.categoria);
                  return (
                    <TableRow key={custo.id} className={custo.status === 'inativo' ? 'opacity-50' : ''}>
                      <TableCell>
                        <div className="p-2 rounded-lg bg-muted/50">
                          <Icon className="h-4 w-4 text-muted-foreground" />
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">
                        {getCategoriaLabel(custo.categoria)}
                      </TableCell>
                      <TableCell>{custo.descricao}</TableCell>
                      <TableCell className="text-right font-medium tabular-nums">
                        {formatCurrency(custo.valor)}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{getRecorrenciaLabel(custo.recorrencia)}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={custo.status === 'ativo' 
                            ? 'bg-success/20 text-success border-success/30 cursor-pointer' 
                            : 'bg-muted text-muted-foreground cursor-pointer'}
                          onClick={() => handleToggleStatus(custo.id, custo.status)}
                        >
                          {custo.status === 'ativo' ? 'Ativo' : 'Inativo'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => handleOpenDialog(custo.id)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={() => handleDelete(custo.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
            <TableFooter>
              <TableRow className="bg-muted/30">
                <TableCell colSpan={3} className="font-semibold">Total Mensal Estimado</TableCell>
                <TableCell className="text-right font-bold tabular-nums text-warning">
                  {formatCurrency(totalMensal)}
                </TableCell>
                <TableCell colSpan={3}></TableCell>
              </TableRow>
            </TableFooter>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
