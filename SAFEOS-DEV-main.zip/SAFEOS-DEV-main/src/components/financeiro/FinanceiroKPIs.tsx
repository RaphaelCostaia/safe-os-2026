import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Receipt, 
  Wallet, 
  Calculator, 
  RefreshCw, 
  AlertTriangle,
  ShieldCheck,
  Coins,
  CheckCircle2
} from "lucide-react";
import { useFinanceiroRealtime } from "@/hooks/useFinanceiroRealtime";

// Smart currency formatter that adapts to value size while keeping precision
const formatCurrency = (value: number, compact: boolean = false) => {
  const abs = Math.abs(value);
  
  if (compact) {
    if (abs >= 1000000) {
      return `R$ ${(value / 1000000).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 2 })}M`;
    }
    if (abs >= 100000) {
      return `R$ ${(value / 1000).toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 1 })}k`;
    }
  }
  
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
};

interface KPICardProps {
  title: string;
  badge?: string;
  value: number;
  icon: React.ElementType;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  iconColor: string;
  isLoading?: boolean;
  compact?: boolean;
}

const KPICard = ({ title, badge, value, icon: Icon, trend, trendValue, iconColor, isLoading, compact = false }: KPICardProps) => (
  <Card className="border-border/50 bg-card hover:border-primary/30 transition-all duration-300 min-w-0 shadow-sm">
    <CardContent className="p-3.5 sm:p-4.5">
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 flex-nowrap">
            <p className="text-xs sm:text-sm font-medium text-muted-foreground whitespace-nowrap overflow-hidden text-ellipsis" title={title}>
              {title}
            </p>
            {badge && (
              <span className="text-[9px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded bg-muted text-muted-foreground shrink-0">
                {badge}
              </span>
            )}
          </div>
          {isLoading ? (
            <Skeleton className="h-7 sm:h-8 w-20 sm:w-24 mt-1.5" />
          ) : (
            <p 
              className="text-base sm:text-xl lg:text-2xl font-bold mt-1.5 tabular-nums leading-tight tracking-tight text-foreground"
              title={`R$ ${value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`}
            >
              {formatCurrency(value, compact)}
            </p>
          )}
          {trendValue && !isLoading && (
            <div className="flex items-center gap-1 mt-1.5 sm:mt-2">
              {trend === 'up' && <TrendingUp className="h-3 w-3 text-emerald-600 shrink-0" />}
              {trend === 'down' && <TrendingDown className="h-3 w-3 text-rose-600 shrink-0" />}
              <span className={`text-[10px] sm:text-xs truncate font-medium ${trend === 'up' ? 'text-emerald-600' : trend === 'down' ? 'text-rose-600' : 'text-muted-foreground'}`}>
                {trendValue}
              </span>
            </div>
          )}
        </div>
        <div className={`p-2 sm:p-2.5 rounded-xl shrink-0 ${iconColor.replace('text-', 'bg-')}/10 border border-current/10`}>
          <Icon className={`h-4 w-4 sm:h-5 sm:w-5 ${iconColor}`} />
        </div>
      </div>
    </CardContent>
  </Card>
);

export function FinanceiroKPIs() {
  const { data, isLoading, isFetching, error } = useFinanceiroRealtime();
  const kpis = data?.kpis;

  if (error) {
    return (
      <Card className="border-destructive/50 bg-destructive/5">
        <CardContent className="py-6 text-center">
          <AlertTriangle className="h-6 w-6 text-destructive mx-auto mb-2" />
          <p className="text-sm text-destructive">Erro ao carregar KPIs</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5">
            <Coins className="h-3.5 w-3.5 text-emerald-600" />
            Demonstrativo de Comissões & Produção de Seguros
          </span>
        </div>
        {isFetching && !isLoading && (
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <RefreshCw className="h-3 w-3 animate-spin text-primary" />
            Sincronizando dados...
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-3 sm:gap-4">
        {/* Receita Mensal de Comissões */}
        <KPICard
          title="Receita Mensal"
          badge="Comissão"
          value={kpis?.receitaRecorrenteMensal || 0}
          icon={DollarSign}
          iconColor="text-emerald-600"
          trend="up"
          trendValue={kpis ? `${kpis.totalApolicesAtivas} apólice(s) ativas` : undefined}
          isLoading={isLoading}
        />

        {/* Receita Anual de Comissões */}
        <KPICard
          title="Receita Anual"
          badge="Comissão"
          value={kpis?.receitaRecorrenteAnual || 0}
          icon={TrendingUp}
          iconColor="text-indigo-600"
          trend="neutral"
          trendValue="Projeção 12m corretora"
          isLoading={isLoading}
        />

        {/* Marcador Fundamental: Prêmio Emitido das Seguradoras */}
        <KPICard
          title="Prêmio Emitido"
          badge="Produção"
          value={kpis?.totalPremioEmitido || 0}
          icon={ShieldCheck}
          iconColor="text-blue-600"
          trend="neutral"
          trendValue={kpis?.premioMensalEquivalente ? `~${formatCurrency(kpis.premioMensalEquivalente)}/mês seguradora` : "Volume bruto emitido"}
          isLoading={isLoading}
        />

        {/* Comissões a Receber no Mês (Previstas) */}
        <KPICard
          title="A Receber"
          badge="Comissões"
          value={kpis?.comissoesPrevistasMes || 0}
          icon={Receipt}
          iconColor="text-amber-600"
          trend="neutral"
          trendValue={kpis?.comissoesPrevistasMes ? "Previsto no mês" : "Nenhuma parcela"}
          isLoading={isLoading}
        />

        {/* Comissões Recebidas no Mês (Liquidadas) */}
        <KPICard
          title="Recebidas"
          badge="Comissões"
          value={kpis?.comissoesRecebidasMes || 0}
          icon={CheckCircle2}
          iconColor="text-emerald-600"
          trend={kpis && kpis.comissoesRecebidasMes > 0 ? "up" : "neutral"}
          trendValue={kpis?.comissoesRecebidasMes ? "Liquidado no mês" : "Aguardando baixa"}
          isLoading={isLoading}
        />

        {/* Custos Fixos Operacionais */}
        <KPICard
          title="Custos Fixos"
          badge="Despesas"
          value={kpis?.custosFixosMes || 0}
          icon={Wallet}
          iconColor="text-rose-600"
          trend="neutral"
          trendValue={kpis?.custosFixosMes ? "Despesas cadastradas" : "Nenhum custo cadastrado"}
          isLoading={isLoading}
        />

        {/* Resultado Operacional Líquido */}
        <KPICard
          title="Resultado Líq."
          badge="Líquido"
          value={kpis?.resultadoOperacional || 0}
          icon={Calculator}
          iconColor={kpis && kpis.resultadoOperacional >= 0 ? "text-emerald-600" : "text-rose-600"}
          trend={kpis && kpis.resultadoOperacional >= 0 ? "up" : "down"}
          trendValue={kpis && kpis.resultadoOperacional >= 0 ? "Superávit mensal" : "Déficit mensal"}
          isLoading={isLoading}
        />
      </div>
    </div>
  );
}

