import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, BarChart, Bar } from "recharts";
import { TrendingUp, Calendar, ChartBar, TableIcon } from "lucide-react";
import { gerarProjecoes, ProjecaoMensal } from "@/data/financeiroMockData";

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

const formatCompact = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    notation: 'compact',
    maximumFractionDigits: 1,
  }).format(value);
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-popover border border-border rounded-lg p-3 shadow-lg">
        <p className="font-medium mb-2">{label}</p>
        {payload.map((entry: any, index: number) => (
          <div key={index} className="flex items-center gap-2 text-sm">
            <div
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: entry.color }}
            />
            <span className="text-muted-foreground">{entry.name}:</span>
            <span className="font-medium">{formatCurrency(entry.value)}</span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

type Horizonte = 12 | 24 | 36;
type ViewMode = 'chart' | 'table';

export function ProjecoesTab() {
  const [horizonte, setHorizonte] = useState<Horizonte>(12);
  const [viewMode, setViewMode] = useState<ViewMode>('chart');

  const projecoes = useMemo(() => gerarProjecoes(horizonte), [horizonte]);

  const totais = useMemo(() => {
    return {
      receita: projecoes.reduce((sum, p) => sum + p.receitaEstimada, 0),
      custos: projecoes.reduce((sum, p) => sum + p.custosEstimados, 0),
      resultado: projecoes.reduce((sum, p) => sum + p.resultado, 0),
    };
  }, [projecoes]);

  const mediasMensais = useMemo(() => {
    const count = projecoes.length;
    return {
      receita: totais.receita / count,
      custos: totais.custos / count,
      resultado: totais.resultado / count,
    };
  }, [projecoes, totais]);

  // Agrupar por trimestre para visualização mais limpa em horizontes longos
  const dadosAgrupados = useMemo(() => {
    if (horizonte === 12) return projecoes;
    
    const trimestres: ProjecaoMensal[] = [];
    for (let i = 0; i < projecoes.length; i += 3) {
      const grupo = projecoes.slice(i, i + 3);
      trimestres.push({
        mes: `T${Math.floor(i / 3) + 1}/${projecoes[i].mes.split('/')[1]}`,
        receitaEstimada: grupo.reduce((s, p) => s + p.receitaEstimada, 0),
        custosEstimados: grupo.reduce((s, p) => s + p.custosEstimados, 0),
        resultado: grupo.reduce((s, p) => s + p.resultado, 0),
      });
    }
    return trimestres;
  }, [projecoes, horizonte]);

  return (
    <div className="space-y-6">
      {/* Controls */}
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <CardTitle className="flex items-center gap-2 text-lg">
              <TrendingUp className="h-5 w-5 text-primary" />
              Projeções Financeiras
            </CardTitle>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1 bg-muted/50 rounded-lg p-1">
                <Button
                  variant={viewMode === 'chart' ? 'secondary' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('chart')}
                >
                  <ChartBar className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'table' ? 'secondary' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('table')}
                >
                  <TableIcon className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex items-center gap-1 bg-muted/50 rounded-lg p-1">
                {([12, 24, 36] as Horizonte[]).map((h) => (
                  <Button
                    key={h}
                    variant={horizonte === h ? 'secondary' : 'ghost'}
                    size="sm"
                    onClick={() => setHorizonte(h)}
                  >
                    <Calendar className="h-4 w-4 mr-1" />
                    {h} meses
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-border/50 bg-card">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Receita Total Projetada</p>
                <p className="text-2xl font-bold text-success mt-1">{formatCurrency(totais.receita)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Média mensal: {formatCurrency(mediasMensais.receita)}
                </p>
              </div>
              <Badge variant="outline" className="bg-success/10 text-success border-success/30">
                {horizonte} meses
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Custos Totais Projetados</p>
                <p className="text-2xl font-bold text-warning mt-1">{formatCurrency(totais.custos)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Média mensal: {formatCurrency(mediasMensais.custos)}
                </p>
              </div>
              <Badge variant="outline" className="bg-warning/10 text-warning border-warning/30">
                {horizonte} meses
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Resultado Projetado</p>
                <p className="text-2xl font-bold text-primary mt-1">{formatCurrency(totais.resultado)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Margem: {((totais.resultado / totais.receita) * 100).toFixed(1)}%
                </p>
              </div>
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30">
                {horizonte} meses
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Chart or Table */}
      <Card className="border-border/50 bg-card">
        <CardContent className="p-6">
          {viewMode === 'chart' ? (
            <div className="h-[400px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                {horizonte === 12 ? (
                  <AreaChart
                    data={dadosAgrupados}
                    margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient id="colorReceitaProj" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--success))" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="hsl(var(--success))" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorResultadoProj" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis
                      dataKey="mes"
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={11}
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={11}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={formatCompact}
                      width={65}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend
                      verticalAlign="top"
                      height={36}
                      formatter={(value) => <span className="text-sm text-muted-foreground">{value}</span>}
                    />
                    <Area
                      type="monotone"
                      dataKey="receitaEstimada"
                      name="Receita"
                      stroke="hsl(var(--success))"
                      fillOpacity={1}
                      fill="url(#colorReceitaProj)"
                      strokeWidth={2}
                    />
                    <Area
                      type="monotone"
                      dataKey="resultado"
                      name="Resultado"
                      stroke="hsl(var(--primary))"
                      fillOpacity={1}
                      fill="url(#colorResultadoProj)"
                      strokeWidth={2}
                    />
                  </AreaChart>
                ) : (
                  <BarChart
                    data={dadosAgrupados}
                    margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis
                      dataKey="mes"
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={10}
                      tickLine={false}
                      axisLine={false}
                      interval={0}
                      angle={-45}
                      textAnchor="end"
                      height={60}
                    />
                    <YAxis
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={11}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={formatCompact}
                      width={65}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend
                      verticalAlign="top"
                      height={36}
                      formatter={(value) => <span className="text-sm text-muted-foreground">{value}</span>}
                    />
                    <Bar dataKey="receitaEstimada" name="Receita" fill="hsl(var(--success))" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="custosEstimados" name="Custos" fill="hsl(var(--warning))" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="resultado" name="Resultado" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                )}
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="overflow-x-auto max-h-[400px]">
              <Table>
                <TableHeader className="sticky top-0 bg-card z-10">
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="w-[120px]">Período</TableHead>
                    <TableHead className="text-right">Receita Estimada</TableHead>
                    <TableHead className="text-right">Custos Estimados</TableHead>
                    <TableHead className="text-right">Resultado</TableHead>
                    <TableHead className="text-right w-[100px]">Margem</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {projecoes.map((proj, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-medium">{proj.mes}</TableCell>
                      <TableCell className="text-right tabular-nums text-success">
                        {formatCurrency(proj.receitaEstimada)}
                      </TableCell>
                      <TableCell className="text-right tabular-nums text-warning">
                        {formatCurrency(proj.custosEstimados)}
                      </TableCell>
                      <TableCell className="text-right tabular-nums font-medium text-primary">
                        {formatCurrency(proj.resultado)}
                      </TableCell>
                      <TableCell className="text-right tabular-nums text-muted-foreground">
                        {((proj.resultado / proj.receitaEstimada) * 100).toFixed(1)}%
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
