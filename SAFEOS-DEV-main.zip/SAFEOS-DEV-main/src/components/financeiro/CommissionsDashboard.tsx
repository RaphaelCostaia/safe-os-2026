import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from "recharts";
import { 
  TrendingUp, 
  Users, 
  DollarSign, 
  ChevronDown, 
  ChevronRight,
  Download,
  Calendar,
  MapPin,
  Briefcase,
  AlertTriangle,
  Trophy,
  FileSpreadsheet,
  FileText,
  Percent,
  Coins,
} from "lucide-react";
import { useCommissionsDashboard, useCommissionFilters, ClientCommissionHistory } from "@/hooks/useCommissionsDashboard";
import { exportToExcel, exportToCSV, ExportData } from "@/lib/exportUtils";
import { toast } from "sonner";
import { format, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";

const formatCurrency = (value: number) => {
  if (value >= 1000000) {
    return `R$ ${(value / 1000000).toFixed(1)}M`;
  }
  if (value >= 1000) {
    return `R$ ${(value / 1000).toFixed(1)}k`;
  }
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value);
};

const formatCurrencyFull = (value: number) => {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value);
};

const COLORS = ["#3b82f6", "#22c55e", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4", "#ec4899"];

const chartConfig: ChartConfig = {
  projected: {
    label: "Projetado",
    color: "hsl(var(--primary))",
  },
  realized: {
    label: "Realizado",
    color: "hsl(var(--success))",
  },
};

function KPICard({ 
  title, 
  value, 
  icon: Icon, 
  subtitle,
  loading,
}: { 
  title: string; 
  value: string; 
  icon: React.ElementType; 
  subtitle?: string;
  loading?: boolean;
}) {
  if (loading) {
    return (
      <Card className="border-border/50 bg-card">
        <CardContent className="p-4">
          <Skeleton className="h-4 w-24 mb-2" />
          <Skeleton className="h-8 w-32" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50 bg-card">
      <CardContent className="p-4">
        <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
          <Icon className="h-4 w-4" />
          <span>{title}</span>
        </div>
        <div className="text-2xl font-bold text-foreground">{value}</div>
        {subtitle && (
          <div className="text-xs text-muted-foreground mt-1">{subtitle}</div>
        )}
      </CardContent>
    </Card>
  );
}

function TopClientsCard({ 
  clients, 
  loading 
}: { 
  clients: { name: string; projected: number; uf: string }[];
  loading?: boolean;
}) {
  if (loading) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-3">
          <Skeleton className="h-5 w-32" />
        </CardHeader>
        <CardContent className="space-y-2">
          {[1, 2, 3, 4, 5].map(i => (
            <Skeleton key={i} className="h-8 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50 bg-card">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <Trophy className="h-4 w-4 text-warning" />
          Top 5 Clientes (Comissão Projetada)
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {clients.length === 0 ? (
          <div className="text-center py-4 text-muted-foreground text-sm">
            Nenhum dado disponível
          </div>
        ) : (
          clients.map((client, index) => (
            <div key={index} className="flex items-center justify-between py-1">
              <div className="flex items-center gap-2 min-w-0">
                <span className="text-xs text-muted-foreground w-5">{index + 1}º</span>
                <span className="font-medium text-sm truncate">{client.name}</span>
                {client.uf && (
                  <Badge variant="outline" className="text-xs shrink-0">{client.uf}</Badge>
                )}
              </div>
              <span className="font-semibold text-sm text-primary shrink-0 ml-2">
                {formatCurrency(client.projected)}
              </span>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}

function ClientHistoryRow({ client }: { client: ClientCommissionHistory }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <TableRow className="hover:bg-muted/30">
        <TableCell>
          <CollapsibleTrigger className="flex items-center gap-1 hover:text-primary">
            {isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </CollapsibleTrigger>
        </TableCell>
        <TableCell>
          <Tooltip>
            <TooltipTrigger asChild>
              <span className="font-medium truncate block max-w-[140px]">{client.clientName}</span>
            </TooltipTrigger>
            <TooltipContent>{client.clientName}</TooltipContent>
          </Tooltip>
        </TableCell>
        <TableCell>
          <span className="text-sm text-muted-foreground">
            {client.city && client.uf ? `${client.city}/${client.uf}` : client.uf || "-"}
          </span>
        </TableCell>
        <TableCell>
          <div className="flex flex-wrap gap-1">
            {client.productsCategories.slice(0, 2).map(cat => (
              <Badge key={cat} variant="outline" className="text-xs">{cat}</Badge>
            ))}
            {client.productsCategories.length > 2 && (
              <Badge variant="outline" className="text-xs">+{client.productsCategories.length - 2}</Badge>
            )}
          </div>
        </TableCell>
        <TableCell className="text-right">
          {client.currentPercent !== null ? (
            <span className="font-medium">{client.currentPercent}%</span>
          ) : (
            <Badge variant="outline" className="text-xs text-warning">N/C</Badge>
          )}
        </TableCell>
        <TableCell className="text-right font-medium tabular-nums">
          {formatCurrencyFull(client.projectedMonthly)}
        </TableCell>
        <TableCell className="text-sm text-muted-foreground">
          {format(parseISO(client.lastModified), "dd/MM/yy", { locale: ptBR })}
        </TableCell>
      </TableRow>
      <CollapsibleContent asChild>
        <TableRow className="bg-muted/20">
          <TableCell colSpan={7} className="p-4">
            <div className="space-y-2">
              <div className="text-xs font-medium text-muted-foreground">Histórico de Comissões</div>
              <div className="grid gap-2">
                {client.terms.map((term, idx) => (
                  <div key={term.id} className="flex items-center gap-4 text-sm bg-background/50 rounded-lg p-2">
                    <Badge variant={term.isActive ? "default" : "secondary"} className="text-xs">
                      {term.isActive ? "Ativo" : "Encerrado"}
                    </Badge>
                    <span>
                      {term.model === "percentual" && term.percent !== null && `${term.percent}%`}
                      {term.model === "fixo" && term.fixedAmount !== null && formatCurrencyFull(term.fixedAmount)}
                      {term.model === "misto" && `${term.percent || 0}% + ${formatCurrencyFull(term.fixedAmount || 0)}`}
                    </span>
                    <span className="text-muted-foreground">
                      {term.startsAt && `Desde: ${format(parseISO(term.startsAt), "dd/MM/yy")}`}
                      {term.endsAt && ` até ${format(parseISO(term.endsAt), "dd/MM/yy")}`}
                    </span>
                  </div>
                ))}
                {client.terms.length === 0 && (
                  <div className="text-sm text-muted-foreground">Nenhum histórico de comissão</div>
                )}
              </div>
            </div>
          </TableCell>
        </TableRow>
      </CollapsibleContent>
    </Collapsible>
  );
}

export function CommissionsDashboard() {
  const [filters, setFilters] = useState<{
    periodo: "atual" | "90dias" | "12meses";
    produto: string;
    profissao: string;
    uf: string;
  }>({
    periodo: "12meses",
    produto: "all",
    profissao: "all",
    uf: "all",
  });

  const { data, isLoading, error } = useCommissionsDashboard(filters);
  const { data: filterOptions } = useCommissionFilters();

  const getExportData = (): ExportData => {
    if (!data) {
      return { headers: [], rows: [], title: "", subtitle: "" };
    }
    
    // Build filters description for subtitle
    const filterDesc = [];
    if (filters.periodo !== "12meses") filterDesc.push(`Período: ${filters.periodo === "atual" ? "Mês Atual" : "90 Dias"}`);
    if (filters.produto !== "all") filterDesc.push(`Produto: ${filters.produto}`);
    if (filters.profissao !== "all") filterDesc.push(`Profissão: ${filters.profissao}`);
    if (filters.uf !== "all") filterDesc.push(`UF: ${filters.uf}`);
    
    return {
      title: "Relatório de Comissões por Cliente",
      subtitle: `Total: ${data.clientHistory.length} clientes | Projetado 12 meses: ${formatCurrencyFull(data.projected12Months)}${filterDesc.length > 0 ? ` | Filtros: ${filterDesc.join(", ")}` : ""}`,
      headers: ["Cliente", "UF", "Cidade", "Profissão", "Produtos", "Comissão (%)", "Projeção Mensal (R$)", "Prêmio Total (R$)", "Última Alteração"],
      rows: data.clientHistory.map(c => [
        c.clientName,
        c.uf || "-",
        c.city || "-",
        c.profissao || "-",
        c.productsCategories.join(", ") || "-",
        c.currentPercent !== null ? `${c.currentPercent}%` : "N/C",
        c.projectedMonthly,
        c.totalPremio,
        format(parseISO(c.lastModified), "dd/MM/yyyy"),
      ]),
    };
  };

  const handleExportCSV = () => {
    if (!data) return;
    const exportData = getExportData();
    exportToCSV(exportData, `comissoes-clientes-${format(new Date(), "yyyyMMdd")}`);
    toast.success("CSV exportado com sucesso!");
  };

  const handleExportExcel = () => {
    if (!data) return;
    const exportData = getExportData();
    exportToExcel(exportData, `comissoes-clientes-${format(new Date(), "yyyyMMdd")}`);
    toast.success("Excel exportado com sucesso!");
  };

  if (error) {
    return (
      <Card className="border-border/50 bg-card">
        <CardContent className="py-8 text-center">
          <AlertTriangle className="h-8 w-8 text-destructive mx-auto mb-2" />
          <p className="text-destructive">Erro ao carregar dados</p>
          <p className="text-sm text-muted-foreground">{(error as Error).message}</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <Select 
          value={filters.periodo} 
          onValueChange={(v) => setFilters(prev => ({ ...prev, periodo: v as typeof prev.periodo }))}
        >
          <SelectTrigger className="w-[140px]">
            <Calendar className="h-4 w-4 mr-2" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="atual">Mês Atual</SelectItem>
            <SelectItem value="90dias">90 Dias</SelectItem>
            <SelectItem value="12meses">12 Meses</SelectItem>
          </SelectContent>
        </Select>

        <Select 
          value={filters.produto} 
          onValueChange={(v) => setFilters(prev => ({ ...prev, produto: v }))}
        >
          <SelectTrigger className="w-[140px]">
            <Briefcase className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Produto" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos</SelectItem>
            {filterOptions?.produtos.map(p => (
              <SelectItem key={p} value={p}>{p}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select 
          value={filters.profissao} 
          onValueChange={(v) => setFilters(prev => ({ ...prev, profissao: v }))}
        >
          <SelectTrigger className="w-[140px]">
            <Users className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Profissão" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas</SelectItem>
            {filterOptions?.profissoes.map(p => (
              <SelectItem key={p} value={p}>{p}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select 
          value={filters.uf} 
          onValueChange={(v) => setFilters(prev => ({ ...prev, uf: v }))}
        >
          <SelectTrigger className="w-[100px]">
            <MapPin className="h-4 w-4 mr-2" />
            <SelectValue placeholder="UF" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas</SelectItem>
            {filterOptions?.ufs.map(uf => (
              <SelectItem key={uf} value={uf}>{uf}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" disabled={!data || isLoading}>
              <Download className="h-4 w-4 mr-2" />
              Exportar
              <ChevronDown className="h-4 w-4 ml-1" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={handleExportCSV}>
              <FileText className="h-4 w-4 mr-2" />
              Exportar CSV
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleExportExcel}>
              <FileSpreadsheet className="h-4 w-4 mr-2" />
              Exportar Excel
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* KPIs */}
      <div className="flex flex-col gap-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <KPICard
            title="Comissão Projetada (Mês)"
            value={data ? formatCurrency(data.projectedCurrentMonth) : "-"}
            icon={DollarSign}
            subtitle="Previsão para o mês atual"
            loading={isLoading}
          />
          <KPICard
            title="Comissão Projetada (12 meses)"
            value={data ? formatCurrency(data.projected12Months) : "-"}
            icon={TrendingUp}
            subtitle="Projeção anual"
            loading={isLoading}
          />
          <KPICard
            title="Ticket Médio Comissão"
            value={data ? formatCurrency(data.ticketMedioComissao) : "-"}
            icon={DollarSign}
            subtitle="Média por cliente/mês"
            loading={isLoading}
          />
          <KPICard
            title="Clientes com Comissão"
            value={data ? `${data.clientsWithCommission}/${data.totalClients}` : "-"}
            icon={Users}
            subtitle={data && data.totalClients > 0 
              ? `${((data.clientsWithCommission / data.totalClients) * 100).toFixed(0)}% do total`
              : undefined
            }
            loading={isLoading}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <KPICard
            title="Comissão Média Realizada"
            value={data ? `${data.comissaoMediaRealizada.toFixed(2)}%` : "-"}
            icon={Percent}
            subtitle="Ponderada de apólices vigentes"
            loading={isLoading}
          />
          <KPICard
            title="Comissão Média Prevista"
            value={data ? `${data.comissaoMediaPrevista.toFixed(2)}%` : "-"}
            icon={Percent}
            subtitle="Estimada de propostas em andamento"
            loading={isLoading}
          />
          <KPICard
            title="Receita Realizada (Comissão)"
            value={data ? formatCurrency(data.receitaRealizada) : "-"}
            icon={Coins}
            subtitle="Total ganho em apólices ativas"
            loading={isLoading}
          />
          <KPICard
            title="Receita Prevista (Comissão)"
            value={data ? formatCurrency(data.receitaPrevista) : "-"}
            icon={Coins}
            subtitle="Estimada de propostas / pipeline"
            loading={isLoading}
          />
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Monthly Projection Chart */}
        <Card className="lg:col-span-2 border-border/50 bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Projeção Mensal de Comissões (12 meses)</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-[250px] w-full" />
            ) : data?.monthlyProjections.length === 0 ? (
              <div className="h-[250px] flex items-center justify-center text-muted-foreground">
                Dados insuficientes para projeção
              </div>
            ) : (
              <ChartContainer config={chartConfig} className="h-[250px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data?.monthlyProjections || []}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis 
                      dataKey="monthLabel" 
                      tick={{ fontSize: 11 }} 
                      className="fill-muted-foreground"
                    />
                    <YAxis 
                      tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`}
                      tick={{ fontSize: 11 }}
                      className="fill-muted-foreground"
                    />
                    <ChartTooltip 
                      content={<ChartTooltipContent />}
                      formatter={(value) => formatCurrencyFull(Number(value))}
                    />
                    <Bar dataKey="projected" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            )}
          </CardContent>
        </Card>

        {/* Top Clients */}
        <TopClientsCard clients={data?.topClients || []} loading={isLoading} />
      </div>

      {/* Product Breakdown + History Table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* By Product */}
        <Card className="border-border/50 bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Comissão por Produto (12 meses)</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-[200px] w-full" />
            ) : data?.byProduct.length === 0 ? (
              <div className="h-[200px] flex items-center justify-center text-muted-foreground text-sm">
                Nenhum dado disponível
              </div>
            ) : (
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={data?.byProduct || []}
                      dataKey="projected"
                      nameKey="category"
                      cx="50%"
                      cy="50%"
                      outerRadius={70}
                      label={({ category, percent }) => `${category} ${(percent * 100).toFixed(0)}%`}
                      labelLine={false}
                    >
                      {data?.byProduct.map((entry, index) => (
                        <Cell key={entry.category} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <ChartTooltip 
                      formatter={(value) => formatCurrencyFull(Number(value))} 
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
            {/* Legend */}
            {data?.byProduct && data.byProduct.length > 0 && (
              <div className="flex flex-wrap justify-center gap-2 mt-2">
                {data.byProduct.map((item, index) => (
                  <div key={item.category} className="flex items-center gap-1 text-xs">
                    <div 
                      className="w-2 h-2 rounded-full" 
                      style={{ backgroundColor: COLORS[index % COLORS.length] }}
                    />
                    <span>{item.category}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Client History Table */}
        <Card className="lg:col-span-2 border-border/50 bg-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Histórico por Cliente</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-4 space-y-2">
                {[1, 2, 3, 4, 5].map(i => (
                  <Skeleton key={i} className="h-10 w-full" />
                ))}
              </div>
            ) : data?.clientHistory.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground text-sm">
                Nenhum cliente com comissão configurada
              </div>
            ) : (
              <div className="overflow-x-auto max-h-[400px]">
                <Table>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead className="w-8"></TableHead>
                      <TableHead>Cliente</TableHead>
                      <TableHead>Local</TableHead>
                      <TableHead>Produtos</TableHead>
                      <TableHead className="text-right">%</TableHead>
                      <TableHead className="text-right">Projeção/Mês</TableHead>
                      <TableHead>Alterado</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data?.clientHistory.slice(0, 20).map(client => (
                      <ClientHistoryRow key={client.clientId} client={client} />
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
