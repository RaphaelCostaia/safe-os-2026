import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertTriangle, Clock, AlertCircle, TrendingDown, ChevronRight, CheckCircle } from "lucide-react";
import { useFinanceiroRealtime, AlertaFinanceiro } from "@/hooks/useFinanceiroRealtime";
import { cn } from "@/lib/utils";

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

const getAlertIcon = (tipo: AlertaFinanceiro['tipo']) => {
  switch (tipo) {
    case 'vencida':
      return AlertTriangle;
    case 'queda_receita':
      return TrendingDown;
    default:
      return Clock;
  }
};

const getAlertColor = (tipo: AlertaFinanceiro['tipo']) => {
  switch (tipo) {
    case 'vencida':
      return 'text-destructive bg-destructive/10 border-destructive/20';
    case 'vencer_7':
      return 'text-warning bg-warning/10 border-warning/20';
    case 'queda_receita':
      return 'text-destructive bg-destructive/10 border-destructive/20';
    default:
      return 'text-muted-foreground bg-muted/50 border-border';
  }
};

export function FinanceiroAlertas() {
  const { data, isLoading, error } = useFinanceiroRealtime();
  const alertas = data?.alertas || [];

  if (isLoading) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <AlertCircle className="h-5 w-5 text-warning" />
            Alertas Financeiros
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-16 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <AlertCircle className="h-5 w-5 text-warning" />
            Alertas Financeiros
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center py-8">
          <AlertTriangle className="h-8 w-8 text-destructive mb-2" />
          <p className="text-destructive text-sm">Erro ao carregar alertas</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50 bg-card">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <AlertCircle className="h-5 w-5 text-warning" />
          Alertas Financeiros
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {alertas.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <div className="p-3 rounded-full bg-success/10 mb-3">
              <CheckCircle className="h-6 w-6 text-success" />
            </div>
            <p className="font-medium text-success">Tudo em dia!</p>
            <p className="text-sm text-muted-foreground">Nenhum alerta financeiro no momento</p>
          </div>
        ) : (
          alertas.map((alerta) => {
            const Icon = getAlertIcon(alerta.tipo);
            const colorClasses = getAlertColor(alerta.tipo);
            
            return (
              <div
                key={alerta.id}
                className={cn(
                  "flex items-center justify-between p-3 rounded-lg border cursor-pointer hover:opacity-80 transition-opacity",
                  colorClasses
                )}
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <Icon className="h-4 w-4 shrink-0" />
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-sm truncate">{alerta.titulo}</p>
                    {alerta.quantidade && (
                      <p className="text-xs opacity-80">{alerta.quantidade} {alerta.quantidade === 1 ? 'conta' : 'contas'}</p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {alerta.valor && (
                    <span className="font-semibold text-sm">{formatCurrency(alerta.valor)}</span>
                  )}
                  <ChevronRight className="h-4 w-4 opacity-50" />
                </div>
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}
