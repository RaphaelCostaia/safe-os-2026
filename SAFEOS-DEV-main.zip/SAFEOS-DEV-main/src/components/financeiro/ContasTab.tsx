import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  ArrowDownCircle, 
  ArrowUpCircle, 
  Search, 
  MoreVertical, 
  Check, 
  Pencil, 
  Archive,
  AlertTriangle,
  Clock,
  Plus,
  Loader2
} from "lucide-react";
import { useContas, Conta, ContaInsert } from "@/hooks/useContas";
import { format, parseISO, differenceInDays, isBefore } from "date-fns";
import { ptBR } from "date-fns/locale";

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
};

const categorias = [
  { value: 'operacional', label: 'Operacional' },
  { value: 'fornecedores', label: 'Fornecedores' },
  { value: 'impostos', label: 'Impostos' },
  { value: 'comissao', label: 'Comissão' },
  { value: 'servicos', label: 'Serviços' },
  { value: 'outros', label: 'Outros' },
];

const getStatusBadge = (status: string, vencimento: string) => {
  const today = new Date();
  const vencDate = parseISO(vencimento);
  const diasRestantes = differenceInDays(vencDate, today);
  
  if (status === 'pago') {
    return <Badge className="bg-success/20 text-success border-success/30">Pago</Badge>;
  }
  if (status === 'atrasado' || (status === 'pendente' && isBefore(vencDate, today))) {
    return <Badge className="bg-destructive/20 text-destructive border-destructive/30">Atrasado</Badge>;
  }
  if (diasRestantes <= 7) {
    return <Badge className="bg-warning/20 text-warning border-warning/30">Vence em breve</Badge>;
  }
  return <Badge className="bg-primary/20 text-primary border-primary/30">Pendente</Badge>;
};

const getRowHighlight = (status: string, vencimento: string) => {
  const today = new Date();
  const vencDate = parseISO(vencimento);
  const diasRestantes = differenceInDays(vencDate, today);
  
  if (status === 'atrasado' || (status === 'pendente' && isBefore(vencDate, today))) {
    return 'bg-destructive/5 hover:bg-destructive/10';
  }
  if (status === 'pendente' && diasRestantes <= 7) {
    return 'bg-warning/5 hover:bg-warning/10';
  }
  return '';
};

export function ContasTab() {
  const { contas, isLoading, createConta, updateConta, deleteConta, marcarComoPago, isCreating } = useContas();
  const [search, setSearch] = useState("");
  const [subTab, setSubTab] = useState<'pagar' | 'receber'>('pagar');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingContaId, setEditingContaId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    tipo: 'pagar' as 'pagar' | 'receber',
    descricao: '',
    categoria: 'operacional',
    valor: '',
    vencimento: '',
    observacoes: '',
  });

  const filteredContas = useMemo(() => {
    return contas
      .filter(c => c.tipo === subTab)
      .filter(c => 
        c.descricao.toLowerCase().includes(search.toLowerCase()) ||
        c.categoria.toLowerCase().includes(search.toLowerCase())
      )
      .sort((a, b) => {
        if (a.status === 'atrasado' && b.status !== 'atrasado') return -1;
        if (b.status === 'atrasado' && a.status !== 'atrasado') return 1;
        return parseISO(a.vencimento).getTime() - parseISO(b.vencimento).getTime();
      });
  }, [contas, search, subTab]);

  const totais = useMemo(() => {
    const contasTipo = contas.filter(c => c.tipo === subTab);
    return {
      total: contasTipo.reduce((sum, c) => sum + c.valor, 0),
      pendente: contasTipo.filter(c => c.status === 'pendente').reduce((sum, c) => sum + c.valor, 0),
      atrasado: contasTipo.filter(c => c.status === 'atrasado' || (c.status === 'pendente' && isBefore(parseISO(c.vencimento), new Date()))).reduce((sum, c) => sum + c.valor, 0),
      pago: contasTipo.filter(c => c.status === 'pago').reduce((sum, c) => sum + c.valor, 0),
    };
  }, [contas, subTab]);

  const handleOpenDialog = (contaId?: string) => {
    if (contaId) {
      const conta = contas.find(c => c.id === contaId);
      if (conta) {
        setEditingContaId(contaId);
        setFormData({
          tipo: conta.tipo,
          descricao: conta.descricao,
          categoria: conta.categoria,
          valor: conta.valor.toString(),
          vencimento: conta.vencimento,
          observacoes: conta.observacoes || '',
        });
      }
    } else {
      setEditingContaId(null);
      setFormData({
        tipo: subTab,
        descricao: '',
        categoria: 'operacional',
        valor: '',
        vencimento: '',
        observacoes: '',
      });
    }
    setIsDialogOpen(true);
  };

  const handleSave = () => {
    const valor = parseFloat(formData.valor.replace(/[^\d,]/g, '').replace(',', '.'));
    
    if (!formData.descricao || isNaN(valor) || valor <= 0 || !formData.vencimento) {
      return;
    }

    const contaData: ContaInsert = {
      tipo: formData.tipo,
      descricao: formData.descricao,
      categoria: formData.categoria,
      valor,
      vencimento: formData.vencimento,
      status: 'pendente',
      responsavel_id: null,
      cliente_id: null,
      apolice_id: null,
      observacoes: formData.observacoes || null,
      data_pagamento: null,
    };

    if (editingContaId) {
      updateConta({ id: editingContaId, ...contaData });
    } else {
      createConta(contaData);
    }
    
    setIsDialogOpen(false);
  };

  const handleMarcarPago = (id: string) => {
    marcarComoPago(id);
  };

  const handleArquivar = (id: string) => {
    deleteConta(id);
  };

  if (isLoading) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-4">
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50 bg-card">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg">
          <div className="flex items-center gap-2">
            <ArrowDownCircle className="h-5 w-5 text-destructive" />
            <span>/</span>
            <ArrowUpCircle className="h-5 w-5 text-success" />
          </div>
          Contas a Pagar/Receber
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <Tabs value={subTab} onValueChange={(v) => setSubTab(v as 'pagar' | 'receber')}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <TabsList>
              <TabsTrigger value="pagar" className="gap-2">
                <ArrowDownCircle className="h-4 w-4" />
                Contas a Pagar
              </TabsTrigger>
              <TabsTrigger value="receber" className="gap-2">
                <ArrowUpCircle className="h-4 w-4" />
                Contas a Receber
              </TabsTrigger>
            </TabsList>
            
            <div className="flex items-center gap-2">
              <div className="relative max-w-sm flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button onClick={() => handleOpenDialog()}>
                    <Plus className="h-4 w-4 mr-2" />
                    Nova Conta
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle>{editingContaId ? 'Editar Conta' : 'Nova Conta'}</DialogTitle>
                    <DialogDescription>
                      {editingContaId ? 'Atualize os dados da conta.' : 'Adicione uma nova conta a pagar ou receber.'}
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label>Tipo</Label>
                      <Select
                        value={formData.tipo}
                        onValueChange={(value: 'pagar' | 'receber') => setFormData(prev => ({ ...prev, tipo: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pagar">Conta a Pagar</SelectItem>
                          <SelectItem value="receber">Conta a Receber</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="descricao">Descrição</Label>
                      <Input
                        id="descricao"
                        value={formData.descricao}
                        onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
                        placeholder="Ex: Pagamento fornecedor"
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label>Categoria</Label>
                      <Select
                        value={formData.categoria}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, categoria: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {categorias.map(cat => (
                            <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="valor">Valor (R$)</Label>
                        <Input
                          id="valor"
                          value={formData.valor}
                          onChange={(e) => setFormData(prev => ({ ...prev, valor: e.target.value }))}
                          placeholder="0,00"
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="vencimento">Vencimento</Label>
                        <Input
                          id="vencimento"
                          type="date"
                          value={formData.vencimento}
                          onChange={(e) => setFormData(prev => ({ ...prev, vencimento: e.target.value }))}
                        />
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="observacoes">Observações</Label>
                      <Input
                        id="observacoes"
                        value={formData.observacoes}
                        onChange={(e) => setFormData(prev => ({ ...prev, observacoes: e.target.value }))}
                        placeholder="Observações opcionais"
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancelar</Button>
                    <Button onClick={handleSave} disabled={isCreating}>
                      {isCreating && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                      Salvar
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-4">
            <div className="p-3 rounded-lg bg-muted/30 border border-border/50">
              <p className="text-xs text-muted-foreground">Total</p>
              <p className="text-lg font-bold">{formatCurrency(totais.total)}</p>
            </div>
            <div className="p-3 rounded-lg bg-primary/10 border border-primary/20">
              <p className="text-xs text-muted-foreground">Pendente</p>
              <p className="text-lg font-bold text-primary">{formatCurrency(totais.pendente)}</p>
            </div>
            <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20">
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <AlertTriangle className="h-3 w-3" /> Atrasado
              </p>
              <p className="text-lg font-bold text-destructive">{formatCurrency(totais.atrasado)}</p>
            </div>
            <div className="p-3 rounded-lg bg-success/10 border border-success/20">
              <p className="text-xs text-muted-foreground">{subTab === 'pagar' ? 'Pago' : 'Recebido'}</p>
              <p className="text-lg font-bold text-success">{formatCurrency(totais.pago)}</p>
            </div>
          </div>

          <TabsContent value="pagar" className="mt-0">
            <ContasTable 
              contas={filteredContas} 
              onMarcarPago={handleMarcarPago}
              onArquivar={handleArquivar}
              onEdit={handleOpenDialog}
              tipo="pagar"
            />
          </TabsContent>
          
          <TabsContent value="receber" className="mt-0">
            <ContasTable 
              contas={filteredContas} 
              onMarcarPago={handleMarcarPago}
              onArquivar={handleArquivar}
              onEdit={handleOpenDialog}
              tipo="receber"
            />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

interface ContasTableProps {
  contas: Conta[];
  onMarcarPago: (id: string) => void;
  onArquivar: (id: string) => void;
  onEdit: (id: string) => void;
  tipo: 'pagar' | 'receber';
}

function ContasTable({ contas, onMarcarPago, onArquivar, onEdit, tipo }: ContasTableProps) {
  if (contas.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="p-4 rounded-full bg-muted/50 mb-4">
          {tipo === 'pagar' ? (
            <ArrowDownCircle className="h-8 w-8 text-muted-foreground" />
          ) : (
            <ArrowUpCircle className="h-8 w-8 text-muted-foreground" />
          )}
        </div>
        <h3 className="font-medium mb-1">Nenhuma conta encontrada</h3>
        <p className="text-sm text-muted-foreground">
          {tipo === 'pagar' 
            ? 'Não há contas a pagar no momento.' 
            : 'Não há contas a receber no momento.'}
        </p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-lg border border-border/50">
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-transparent">
            <TableHead className="min-w-[200px]">Descrição</TableHead>
            <TableHead className="w-[120px]">Categoria</TableHead>
            <TableHead className="text-right w-[120px]">Valor</TableHead>
            <TableHead className="w-[120px]">Vencimento</TableHead>
            <TableHead className="w-[120px]">Status</TableHead>
            <TableHead className="w-[60px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {contas.map((conta) => (
            <TableRow key={conta.id} className={getRowHighlight(conta.status, conta.vencimento)}>
              <TableCell>
                <div className="flex items-center gap-2">
                  {(conta.status === 'atrasado' || 
                    (conta.status === 'pendente' && isBefore(parseISO(conta.vencimento), new Date()))) && (
                    <AlertTriangle className="h-4 w-4 text-destructive shrink-0" />
                  )}
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span className="font-medium truncate max-w-[180px]">{conta.descricao}</span>
                    </TooltipTrigger>
                    <TooltipContent>{conta.descricao}</TooltipContent>
                  </Tooltip>
                </div>
              </TableCell>
              <TableCell>
                <Badge variant="outline">{conta.categoria}</Badge>
              </TableCell>
              <TableCell className="text-right font-medium tabular-nums">
                {formatCurrency(conta.valor)}
              </TableCell>
              <TableCell>
                <div className="flex items-center gap-1.5">
                  <Clock className="h-3 w-3 text-muted-foreground" />
                  <span className="text-sm">
                    {format(parseISO(conta.vencimento), 'dd/MM/yyyy', { locale: ptBR })}
                  </span>
                </div>
              </TableCell>
              <TableCell>
                {getStatusBadge(conta.status, conta.vencimento)}
              </TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-popover border border-border">
                    {conta.status !== 'pago' && (
                      <DropdownMenuItem onClick={() => onMarcarPago(conta.id)}>
                        <Check className="h-4 w-4 mr-2" />
                        Marcar como {tipo === 'pagar' ? 'pago' : 'recebido'}
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem onClick={() => onEdit(conta.id)}>
                      <Pencil className="h-4 w-4 mr-2" />
                      Editar
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onArquivar(conta.id)}>
                      <Archive className="h-4 w-4 mr-2" />
                      Arquivar
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
