import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, BarChart, Bar, type TooltipProps } from "recharts";
import { TrendingUp, Calendar, ChartBar, TableIcon, AlertTriangle, FileText } from "lucide-react";
import { useFinanceiroProjecoes, HorizonteProjecao, useHasProjectionData } from "@/hooks/useFinanceiroProjecoes";

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

const formatCompact = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    notation: 'compact',
    maximumFractionDigits: 1,
  }).format(value);
};

const CustomTooltip = ({ active, payload, label }: TooltipProps<number, string>) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-popover border border-border rounded-lg p-3 shadow-lg">
        <p className="font-medium mb-2">{label}</p>
        {payload.map((entry, index) => (
          <div key={index} className="flex items-center gap-2 text-sm">
            <div
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: entry.color }}
            />
            <span className="text-muted-foreground">{entry.name}:</span>
            <span className="font-medium">{formatCurrency(entry.value)}</span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

type ViewMode = 'chart' | 'table';

export function ProjecoesTabReal() {
  const [horizonte, setHorizonte] = useState<HorizonteProjecao>(12);
  const [viewMode, setViewMode] = useState<ViewMode>('chart');

  const { data: projecoes = [], isLoading, error } = useFinanceiroProjecoes(horizonte);
  const { data: hasData, isLoading: checkingData } = useHasProjectionData();

  const totais = useMemo(() => {
    return {
      receita: projecoes.reduce((sum, p) => sum + p.receitaEstimada, 0),
      custos: projecoes.reduce((sum, p) => sum + p.custosEstimados, 0),
      resultado: projecoes.reduce((sum, p) => sum + p.resultado, 0),
    };
  }, [projecoes]);

  const mediasMensais = useMemo(() => {
    const count = projecoes.length || 1;
    return {
      receita: totais.receita / count,
      custos: totais.custos / count,
      resultado: totais.resultado / count,
    };
  }, [projecoes, totais]);

  // Group by quarter for longer horizons
  const dadosAgrupados = useMemo(() => {
    if (horizonte === 12) return projecoes;
    
    const trimestres: typeof projecoes = [];
    for (let i = 0; i < projecoes.length; i += 3) {
      const grupo = projecoes.slice(i, i + 3);
      if (grupo.length > 0) {
        trimestres.push({
          mes: `T${Math.floor(i / 3) + 1}/${projecoes[i].mes.split('-')[0]}`,
          mesLabel: `T${Math.floor(i / 3) + 1}`,
          receitaEstimada: grupo.reduce((s, p) => s + p.receitaEstimada, 0),
          custosEstimados: grupo.reduce((s, p) => s + p.custosEstimados, 0),
          resultado: grupo.reduce((s, p) => s + p.resultado, 0),
          apolicesVigentes: grupo[grupo.length - 1]?.apolicesVigentes || 0,
          apolicesVencendo: grupo.reduce((s, p) => s + p.apolicesVencendo, 0),
        });
      }
    }
    return trimestres;
  }, [projecoes, horizonte]);

  if (isLoading || checkingData) {
    return (
      <div className="space-y-6">
        <Card className="border-border/50 bg-card">
          <CardHeader className="pb-4">
            <Skeleton className="h-6 w-48" />
          </CardHeader>
        </Card>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="border-border/50 bg-card">
              <CardContent className="p-5">
                <Skeleton className="h-4 w-24 mb-2" />
                <Skeleton className="h-8 w-32" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Card className="border-destructive/50 bg-destructive/5">
        <CardContent className="py-8 text-center">
          <AlertTriangle className="h-8 w-8 text-destructive mx-auto mb-2" />
          <p className="text-destructive">Erro ao carregar projeções</p>
          <p className="text-sm text-muted-foreground">{(error as Error).message}</p>
        </CardContent>
      </Card>
    );
  }

  // Empty state
  if (!hasData) {
    return (
      <Card className="border-border/50 bg-card">
        <CardContent className="py-12 text-center">
          <div className="p-4 rounded-full bg-muted/50 w-fit mx-auto mb-4">
            <TrendingUp className="h-8 w-8 text-muted-foreground" />
          </div>
          <h3 className="font-medium mb-2">Sem dados para projeção</h3>
          <p className="text-sm text-muted-foreground max-w-sm mx-auto">
            Cadastre apólices ativas para visualizar as projeções financeiras.
          </p>
          <Button variant="outline" className="mt-4 gap-2" asChild>
            <a href="/apolices">
              <FileText className="h-4 w-4" />
              Ir para Apólices
            </a>
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Controls */}
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <CardTitle className="flex items-center gap-2 text-lg">
              <TrendingUp className="h-5 w-5 text-primary" />
              Projeções Financeiras
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30">
                Dados Reais
              </Badge>
            </CardTitle>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1 bg-muted/50 rounded-lg p-1">
                <Button
                  variant={viewMode === 'chart' ? 'secondary' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('chart')}
                >
                  <ChartBar className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'table' ? 'secondary' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('table')}
                >
                  <TableIcon className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex items-center gap-1 bg-muted/50 rounded-lg p-1">
                {([12, 24, 36] as HorizonteProjecao[]).map((h) => (
                  <Button
                    key={h}
                    variant={horizonte === h ? 'secondary' : 'ghost'}
                    size="sm"
                    onClick={() => setHorizonte(h)}
                  >
                    <Calendar className="h-4 w-4 mr-1" />
                    {h}m
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-border/50 bg-card">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div className="min-w-0">
                <p className="text-sm text-muted-foreground">Receita Total Projetada</p>
                <p className="text-2xl font-bold text-success mt-1 tabular-nums">{formatCurrency(totais.receita)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Média: {formatCurrency(mediasMensais.receita)}/mês
                </p>
              </div>
              <Badge variant="outline" className="bg-success/10 text-success border-success/30 shrink-0">
                {horizonte} meses
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div className="min-w-0">
                <p className="text-sm text-muted-foreground">Custos Totais Projetados</p>
                <p className="text-2xl font-bold text-warning mt-1 tabular-nums">{formatCurrency(totais.custos)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Média: {formatCurrency(mediasMensais.custos)}/mês
                </p>
              </div>
              <Badge variant="outline" className="bg-warning/10 text-warning border-warning/30 shrink-0">
                {horizonte} meses
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div className="min-w-0">
                <p className="text-sm text-muted-foreground">Resultado Projetado</p>
                <p className="text-2xl font-bold text-primary mt-1 tabular-nums">{formatCurrency(totais.resultado)}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Margem: {totais.receita > 0 ? ((totais.resultado / totais.receita) * 100).toFixed(1) : 0}%
                </p>
              </div>
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30 shrink-0">
                {horizonte} meses
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Chart or Table */}
      <Card className="border-border/50 bg-card">
        <CardContent className="p-6">
          {viewMode === 'chart' ? (
            <div className="h-[400px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                {horizonte === 12 ? (
                  <AreaChart
                    data={dadosAgrupados}
                    margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient id="colorReceitaProj" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--success))" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="hsl(var(--success))" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorResultadoProj" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis
                      dataKey="mesLabel"
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={11}
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={11}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={formatCompact}
                      width={65}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend
                      verticalAlign="top"
                      height={36}
                      formatter={(value) => <span className="text-sm text-muted-foreground">{value}</span>}
                    />
                    <Area
                      type="monotone"
                      dataKey="receitaEstimada"
                      name="Receita"
                      stroke="hsl(var(--success))"
                      fillOpacity={1}
                      fill="url(#colorReceitaProj)"
                      strokeWidth={2}
                    />
                    <Area
                      type="monotone"
                      dataKey="resultado"
                      name="Resultado"
                      stroke="hsl(var(--primary))"
                      fillOpacity={1}
                      fill="url(#colorResultadoProj)"
                      strokeWidth={2}
                    />
                  </AreaChart>
                ) : (
                  <BarChart
                    data={dadosAgrupados}
                    margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis
                      dataKey="mesLabel"
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={10}
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={11}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={formatCompact}
                      width={65}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend
                      verticalAlign="top"
                      height={36}
                      formatter={(value) => <span className="text-sm text-muted-foreground">{value}</span>}
                    />
                    <Bar dataKey="receitaEstimada" name="Receita" fill="hsl(var(--success))" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="custosEstimados" name="Custos" fill="hsl(var(--warning))" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="resultado" name="Resultado" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                )}
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="overflow-x-auto max-h-[400px]">
              <Table>
                <TableHeader className="sticky top-0 bg-card z-10">
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="w-[100px]">Período</TableHead>
                    <TableHead className="text-right">Receita</TableHead>
                    <TableHead className="text-right">Custos</TableHead>
                    <TableHead className="text-right">Resultado</TableHead>
                    <TableHead className="text-right">Apólices</TableHead>
                    <TableHead className="text-right w-[100px]">Margem</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {projecoes.map((proj, index) => (
                    <TableRow key={index}>
                      <TableCell className="font-medium">{proj.mesLabel}</TableCell>
                      <TableCell className="text-right tabular-nums text-success">
                        {formatCurrency(proj.receitaEstimada)}
                      </TableCell>
                      <TableCell className="text-right tabular-nums text-warning">
                        {formatCurrency(proj.custosEstimados)}
                      </TableCell>
                      <TableCell className="text-right tabular-nums font-medium text-primary">
                        {formatCurrency(proj.resultado)}
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {proj.apolicesVigentes}
                        {proj.apolicesVencendo > 0 && (
                          <span className="text-warning text-xs ml-1">(-{proj.apolicesVencendo})</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right tabular-nums text-muted-foreground">
                        {proj.receitaEstimada > 0 
                          ? ((proj.resultado / proj.receitaEstimada) * 100).toFixed(1)
                          : 0}%
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
