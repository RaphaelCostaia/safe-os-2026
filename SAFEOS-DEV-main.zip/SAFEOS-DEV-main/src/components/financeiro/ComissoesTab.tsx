import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableFooter,
} from "@/components/ui/table";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Search, Download, Receipt, AlertTriangle, CheckCircle2, RotateCcw, TrendingUp, DollarSign } from "lucide-react";
import { useComissoes, useMarkComissaoRecebida, useRevertComissaoStatus, ComissaoCalculada } from "@/hooks/useComissoes";
import { exportToPDF, exportToExcel } from "@/lib/exportUtils";
import { toast } from "sonner";

const formatCurrency = (value: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
};

const formatCompetencia = (competencia: string) => {
  const [year, month] = competencia.split('-');
  const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
  return `${months[parseInt(month) - 1]}/${year}`;
};

const getStatusBadge = (status: ComissaoCalculada['status']) => {
  switch (status) {
    case 'recebida':
      return <Badge className="bg-emerald-500/15 text-emerald-600 border-emerald-500/30 font-medium">Recebida</Badge>;
    case 'prevista':
      return <Badge className="bg-blue-500/15 text-blue-600 border-blue-500/30 font-medium">Prevista</Badge>;
    case 'atrasada':
      return <Badge className="bg-amber-500/15 text-amber-600 border-amber-500/30 font-medium">Atrasada</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

const getProdutoBadge = (categoria: string) => {
  const colors: Record<string, string> = {
    'RCP': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    'Vida': 'bg-green-500/20 text-green-400 border-green-500/30',
    'DIT': 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    'Auto': 'bg-orange-500/20 text-orange-400 border-orange-500/30',
    'Residencial': 'bg-teal-500/20 text-teal-400 border-teal-500/30',
    'Empresarial': 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30',
  };
  return <Badge className={colors[categoria] || 'bg-gray-500/20 text-gray-400 border-gray-500/30'}>{categoria}</Badge>;
};

export function ComissoesTab() {
  const { data: comissoes = [], isLoading, error } = useComissoes();
  const markAsRecebida = useMarkComissaoRecebida();
  const revertComissao = useRevertComissaoStatus();

  const [search, setSearch] = useState("");
  const [filterProduto, setFilterProduto] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterPeriodo, setFilterPeriodo] = useState<string>("all");

  // Extract unique values for filters
  const periodos = useMemo(() => {
    return Array.from(new Set(comissoes.map(c => c.competencia))).sort().reverse();
  }, [comissoes]);

  const produtos = useMemo(() => {
    return Array.from(new Set(comissoes.map(c => c.produtoCategoria))).sort();
  }, [comissoes]);

  const filteredComissoes = useMemo(() => {
    return comissoes.filter((item) => {
      const matchSearch = item.clienteNome.toLowerCase().includes(search.toLowerCase()) ||
        item.numeroApolice.toLowerCase().includes(search.toLowerCase()) ||
        item.seguradora.toLowerCase().includes(search.toLowerCase());
      const matchProduto = filterProduto === "all" || item.produtoCategoria === filterProduto;
      const matchStatus = filterStatus === "all" || item.status === filterStatus;
      const matchPeriodo = filterPeriodo === "all" || item.competencia === filterPeriodo;
      
      return matchSearch && matchProduto && matchStatus && matchPeriodo;
    });
  }, [comissoes, search, filterProduto, filterStatus, filterPeriodo]);

  const totais = useMemo(() => {
    return filteredComissoes.reduce(
      (acc, item) => ({
        prevista: acc.prevista + item.comissaoPrevista,
        recebida: acc.recebida + item.comissaoRecebida,
      }),
      { prevista: 0, recebida: 0 }
    );
  }, [filteredComissoes]);

  // Count items without configured commission
  const semComissaoConfigurada = useMemo(() => {
    return filteredComissoes.filter(c => c.percentualComissao === null || c.percentualComissao === 0).length;
  }, [filteredComissoes]);

  const handleExport = (format: 'pdf' | 'excel') => {
    const data = {
      title: "Relatório de Comissões",
      subtitle: `Total: ${filteredComissoes.length} comissões | Previsto: ${formatCurrency(totais.prevista)} | Recebido: ${formatCurrency(totais.recebida)}`,
      headers: ["Cliente", "Produto", "Apólice", "Seguradora", "Competência", "% Comissão", "Prevista", "Recebida", "Status"],
      rows: filteredComissoes.map(c => [
        c.clienteNome,
        c.produtoCategoria,
        c.numeroApolice,
        c.seguradora,
        formatCompetencia(c.competencia),
        c.percentualComissao ? `${c.percentualComissao}%` : 'N/C',
        c.comissaoPrevista,
        c.comissaoRecebida,
        c.status === 'recebida' ? 'Recebida' : c.status === 'atrasada' ? 'Atrasada' : 'Prevista',
      ]),
    };

    if (format === 'pdf') {
      exportToPDF(data, 'comissoes');
    } else {
      exportToExcel(data, 'comissoes');
    }
    toast.success(`Relatório exportado em ${format.toUpperCase()}`);
  };

  if (isLoading) {
    return (
      <Card className="border-border/50 bg-card">
        <CardHeader className="pb-4">
          <Skeleton className="h-6 w-32" />
        </CardHeader>
        <CardContent className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="border-border/50 bg-card">
        <CardContent className="py-8 text-center">
          <AlertTriangle className="h-8 w-8 text-destructive mx-auto mb-2" />
          <p className="text-destructive">Erro ao carregar comissões</p>
          <p className="text-sm text-muted-foreground">{(error as Error).message}</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-3.5 rounded-lg border border-border/50 bg-card flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground font-medium">Total Previsto no Filtro</p>
            <p className="text-lg font-bold text-foreground tabular-nums">{formatCurrency(totais.prevista)}</p>
          </div>
          <div className="h-9 w-9 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-600">
            <DollarSign className="h-4 w-4" />
          </div>
        </div>

        <div className="p-3.5 rounded-lg border border-border/50 bg-card flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground font-medium">Total Recebido (Baixado)</p>
            <p className="text-lg font-bold text-emerald-600 tabular-nums">{formatCurrency(totais.recebida)}</p>
          </div>
          <div className="h-9 w-9 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-600">
            <CheckCircle2 className="h-4 w-4" />
          </div>
        </div>

        <div className="p-3.5 rounded-lg border border-border/50 bg-card flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground font-medium">Saldo Restante a Receber</p>
            <p className="text-lg font-bold text-amber-600 tabular-nums">{formatCurrency(Math.max(0, totais.prevista - totais.recebida))}</p>
          </div>
          <div className="h-9 w-9 rounded-full bg-amber-500/10 flex items-center justify-center text-amber-600">
            <TrendingUp className="h-4 w-4" />
          </div>
        </div>
      </div>

      <Card className="border-border/50 bg-card">
      <CardHeader className="pb-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Receipt className="h-5 w-5 text-accent" />
              Comissões
            </CardTitle>
            {semComissaoConfigurada > 0 && (
              <Tooltip>
                <TooltipTrigger>
                  <Badge variant="outline" className="bg-warning/10 text-warning border-warning/30 gap-1">
                    <AlertTriangle className="h-3 w-3" />
                    {semComissaoConfigurada} sem %
                  </Badge>
                </TooltipTrigger>
                <TooltipContent>
                  {semComissaoConfigurada} apólice(s) sem percentual de comissão configurado no produto
                </TooltipContent>
              </Tooltip>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => handleExport('pdf')}>
              <Download className="h-4 w-4 mr-2" />
              PDF
            </Button>
            <Button variant="outline" size="sm" onClick={() => handleExport('excel')}>
              <Download className="h-4 w-4 mr-2" />
              Excel
            </Button>
          </div>
        </div>
        
        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 mt-4">
          <div className="relative flex-1 min-w-[200px] max-w-sm">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar cliente, apólice, seguradora..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          
          <Select value={filterPeriodo} onValueChange={setFilterPeriodo}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              {periodos.map(p => (
                <SelectItem key={p} value={p}>{formatCompetencia(p)}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filterProduto} onValueChange={setFilterProduto}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Produto" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              {produtos.map(p => (
                <SelectItem key={p} value={p}>{p}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-[130px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="prevista">Prevista</SelectItem>
              <SelectItem value="recebida">Recebida</SelectItem>
              <SelectItem value="atrasada">Atrasada</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="min-w-[160px]">Cliente</TableHead>
                <TableHead className="w-[100px]">Produto</TableHead>
                <TableHead className="min-w-[110px]">Apólice</TableHead>
                <TableHead className="min-w-[110px]">Seguradora</TableHead>
                <TableHead className="w-[90px]">Competência</TableHead>
                <TableHead className="text-right w-[70px]">%</TableHead>
                <TableHead className="text-right w-[110px]">Prevista</TableHead>
                <TableHead className="text-right w-[110px]">Recebida</TableHead>
                <TableHead className="w-[95px]">Status</TableHead>
                <TableHead className="w-[100px] text-right">Ação</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredComissoes.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={10} className="text-center py-12">
                    <div className="flex flex-col items-center gap-2">
                      <Receipt className="h-8 w-8 text-muted-foreground" />
                      <p className="text-muted-foreground">Nenhuma comissão encontrada</p>
                      <p className="text-sm text-muted-foreground">
                        Verifique se existem apólices ativas com produtos configurados
                      </p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                filteredComissoes.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span className="font-medium truncate block max-w-[160px]">{item.clienteNome}</span>
                        </TooltipTrigger>
                        <TooltipContent>{item.clienteNome}</TooltipContent>
                      </Tooltip>
                    </TableCell>
                    <TableCell>{getProdutoBadge(item.produtoCategoria)}</TableCell>
                    <TableCell>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span className="font-mono text-sm truncate block max-w-[100px]">{item.numeroApolice}</span>
                        </TooltipTrigger>
                        <TooltipContent>{item.numeroApolice}</TooltipContent>
                      </Tooltip>
                    </TableCell>
                    <TableCell>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span className="truncate block max-w-[100px]">{item.seguradora}</span>
                        </TooltipTrigger>
                        <TooltipContent>{item.seguradora}</TooltipContent>
                      </Tooltip>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {formatCompetencia(item.competencia)}
                    </TableCell>
                    <TableCell className="text-right">
                      {item.percentualComissao !== null && item.percentualComissao > 0 ? (
                        <span className="text-sm font-medium">{item.percentualComissao}%</span>
                      ) : (
                        <Tooltip>
                          <TooltipTrigger>
                            <Badge variant="outline" className="bg-warning/10 text-warning border-warning/30 text-xs">
                              N/C
                            </Badge>
                          </TooltipTrigger>
                          <TooltipContent>Percentual não configurado no produto</TooltipContent>
                        </Tooltip>
                      )}
                    </TableCell>
                    <TableCell className="text-right font-medium tabular-nums">
                      {item.comissaoPrevista > 0 ? formatCurrency(item.comissaoPrevista) : '-'}
                    </TableCell>
                    <TableCell className="text-right font-medium tabular-nums">
                      {item.comissaoRecebida > 0 ? (
                        <span className="text-emerald-600 font-semibold">{formatCurrency(item.comissaoRecebida)}</span>
                      ) : '-'}
                    </TableCell>
                    <TableCell>{getStatusBadge(item.status)}</TableCell>
                    <TableCell className="text-right">
                      {item.status === 'recebida' ? (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-xs h-7 px-2 text-muted-foreground hover:text-amber-600"
                          onClick={() => revertComissao.mutate(item)}
                          disabled={revertComissao.isPending}
                          title="Desfazer recebimento"
                        >
                          <RotateCcw className="h-3 w-3 mr-1" />
                          Desfazer
                        </Button>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-xs h-7 px-2.5 bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/20 hover:text-emerald-700 border-emerald-500/30 font-medium"
                          onClick={() => markAsRecebida.mutate(item)}
                          disabled={markAsRecebida.isPending}
                          title="Dar baixa e marcar como recebida"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5 mr-1 text-emerald-600" />
                          Receber
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
            {filteredComissoes.length > 0 && (
              <TableFooter>
                <TableRow className="bg-muted/30">
                  <TableCell colSpan={6} className="font-semibold">Totais</TableCell>
                  <TableCell className="text-right font-bold tabular-nums">
                    {formatCurrency(totais.prevista)}
                  </TableCell>
                  <TableCell className="text-right font-bold tabular-nums text-emerald-600">
                    {formatCurrency(totais.recebida)}
                  </TableCell>
                  <TableCell></TableCell>
                  <TableCell></TableCell>
                </TableRow>
              </TableFooter>
            )}
          </Table>
        </div>
      </CardContent>
    </Card>
    </div>
  );
}
