import { useState, useMemo, useCallback, useEffect } from "react";
import { AlertTriangle, User, FileText, Calendar, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";
import {
  EntitySelectWithCreate,
  type EntityOption,
} from "@/components/ui/entity-select-with-create";

interface SinistroFormModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: SinistroFormData) => void;
  clientes: Array<{ id: string; nome: string; cpf: string; tipoProfissional: string }>;
  apolices: Array<{ id: string; numero: string; produto: string; clienteId: string; seguradora: string }>;
  responsaveis: Array<{ id: string; nome: string }>;
  editData?: SinistroFormData | null;
}

export interface SinistroFormData {
  id?: string;
  clienteId: string;
  produto: string;
  apoliceId?: string;
  seguradora?: string;
  dataOcorrencia: string;
  dataAviso: string;
  descricaoResumida: string;
  descricaoDetalhada: string;
  criticidade: string;
  status: string;
  responsavel: string;
  protocolo?: string;
  valorEstimado?: number;
  valorPago?: number;
}

const produtos = [
  { value: "rcp", label: "RCP - Responsabilidade Civil Profissional" },
  { value: "vida", label: "Seguro de Vida" },
  { value: "dit", label: "DIT / Renda Protegida" },
  { value: "auto", label: "Seguro Auto" },
  { value: "residencial", label: "Seguro Residencial" },
  { value: "consorcio", label: "Consórcio" },
  { value: "outros", label: "Outros" },
];

const criticidades = [
  { value: "baixa", label: "Baixa", color: "bg-slate-500" },
  { value: "media", label: "Média", color: "bg-amber-500" },
  { value: "alta", label: "Alta", color: "bg-orange-500" },
  { value: "critica", label: "Crítica", color: "bg-rose-500" },
];

const statusOptions = [
  { value: "aberto", label: "Aberto" },
  { value: "em_andamento", label: "Em Andamento" },
  { value: "aguardando_cliente", label: "Aguardando Cliente" },
  { value: "aguardando_seguradora", label: "Aguardando Seguradora" },
  { value: "encerrado", label: "Encerrado" },
  { value: "arquivado", label: "Arquivado" },
];

// Type for responsavel creation data
type ResponsavelCreateData = Record<string, string> & {
  full_name: string;
  email: string;
}

export function SinistroFormModal({ 
  open, 
  onOpenChange, 
  onSubmit, 
  clientes, 
  apolices,
  responsaveis,
  editData 
}: SinistroFormModalProps) {
  const queryClient = useQueryClient();
  
  const getDefaultFormData = useCallback((): SinistroFormData => ({
    clienteId: "",
    produto: "",
    apoliceId: "",
    seguradora: "",
    dataOcorrencia: "",
    dataAviso: new Date().toISOString().split('T')[0],
    descricaoResumida: "",
    descricaoDetalhada: "",
    criticidade: "media",
    status: "aberto",
    responsavel: "",
    protocolo: "",
    valorEstimado: undefined,
    valorPago: undefined,
  }), []);

  const [formData, setFormData] = useState<SinistroFormData>(getDefaultFormData);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Sync form data when editData changes or modal opens
  useEffect(() => {
    if (open) {
      if (editData) {
        setFormData(editData);
      } else {
        setFormData(getDefaultFormData());
      }
      setErrors({});
    }
  }, [open, editData, getDefaultFormData]);

  const selectedCliente = clientes.find(c => c.id === formData.clienteId);
  const clienteApolices = apolices.filter(a => a.clienteId === formData.clienteId);

  // Transform responsaveis to EntityOption format
  const responsaveisOptions: EntityOption[] = useMemo(() => 
    responsaveis.map(r => ({ id: r.id, label: r.nome })),
    [responsaveis]
  );

  // Create responsavel handler - insert into team_members instead of profiles
  const handleCreateResponsavel = useCallback(async (data: ResponsavelCreateData): Promise<{ id: string } | null> => {
    const { data: created, error } = await supabase
      .from('team_members')
      .insert({
        full_name: data.full_name.trim(),
        email: data.email?.trim().toLowerCase() || null,
        role: 'colaborador',
        is_active: true,
      })
      .select('id')
      .single();
    
    if (error) {
      throw new Error(error.message || "Erro ao criar responsável");
    }
    
    return created;
  }, []);

  // Check for duplicate responsavel
  const checkDuplicateResponsavel = useCallback((
    data: ResponsavelCreateData, 
    options: EntityOption[]
  ): EntityOption | null => {
    const emailLower = data.email.trim().toLowerCase();
    // Check by name (case insensitive)
    const byName = options.find(
      o => o.label.toLowerCase() === data.full_name.trim().toLowerCase()
    );
    return byName || null;
  }, []);

  // Invalidate team-members query after creation
  const handleResponsavelCreated = useCallback(async () => {
    await queryClient.invalidateQueries({ queryKey: ['team-members'] });
  }, [queryClient]);

  // Handle responsavel change
  const handleResponsavelChange = useCallback((id: string) => {
    setFormData(prev => ({ ...prev, responsavel: id }));
    // Clear error when value changes
    if (errors.responsavel) {
      setErrors(prev => {
        const updated = { ...prev };
        delete updated.responsavel;
        return updated;
      });
    }
  }, [errors.responsavel]);

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.clienteId) newErrors.clienteId = "Cliente é obrigatório";
    if (!formData.produto) newErrors.produto = "Produto é obrigatório";
    if (!formData.dataOcorrencia) newErrors.dataOcorrencia = "Data de ocorrência é obrigatória";
    if (!formData.dataAviso) newErrors.dataAviso = "Data de aviso é obrigatória";
    if (!formData.descricaoResumida.trim()) newErrors.descricaoResumida = "Descrição resumida é obrigatória";
    if (formData.descricaoResumida.length > 200) newErrors.descricaoResumida = "Máximo 200 caracteres";
    if (!formData.criticidade) newErrors.criticidade = "Criticidade é obrigatória";
    if (!formData.status) newErrors.status = "Status é obrigatório";
    if (!formData.responsavel) newErrors.responsavel = "Responsável é obrigatório";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validateForm()) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    onSubmit(formData);
    onOpenChange(false);
    toast.success(editData ? "Sinistro atualizado com sucesso" : "Sinistro registrado com sucesso");
  };

  const handleClienteChange = (clienteId: string) => {
    setFormData(prev => ({ 
      ...prev, 
      clienteId,
      apoliceId: "", // Reset apólice when client changes
    }));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            {editData ? "Editar Sinistro" : "Novo Sinistro"}
          </DialogTitle>
          <DialogDescription>
            {editData ? "Atualize as informações do sinistro" : "Preencha as informações para registrar um novo sinistro"}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Cliente e Produto */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <User className="h-4 w-4" />
              Identificação
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="cliente">Cliente *</Label>
                <Select value={formData.clienteId} onValueChange={handleClienteChange}>
                  <SelectTrigger className={cn(errors.clienteId && "border-destructive")}>
                    <SelectValue placeholder="Selecione o cliente" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover">
                    {clientes.map((cliente) => (
                      <SelectItem key={cliente.id} value={cliente.id}>
                        <div className="flex items-center gap-2">
                          <span>{cliente.nome}</span>
                          <span className="text-xs text-muted-foreground">({cliente.cpf})</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.clienteId && <p className="text-xs text-destructive">{errors.clienteId}</p>}
                {selectedCliente && (
                  <Badge variant="outline" className="text-xs">
                    {selectedCliente.tipoProfissional}
                  </Badge>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="produto">Produto *</Label>
                <Select value={formData.produto} onValueChange={(v) => setFormData(prev => ({ ...prev, produto: v }))}>
                  <SelectTrigger className={cn(errors.produto && "border-destructive")}>
                    <SelectValue placeholder="Selecione o produto" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover">
                    {produtos.map((p) => (
                      <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.produto && <p className="text-xs text-destructive">{errors.produto}</p>}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="apolice">Apólice Vinculada</Label>
                <Select 
                  value={formData.apoliceId} 
                  onValueChange={(v) => {
                    const apolice = apolices.find(a => a.id === v);
                    setFormData(prev => ({ 
                      ...prev, 
                      apoliceId: v,
                      seguradora: apolice?.seguradora || prev.seguradora 
                    }));
                  }}
                  disabled={!formData.clienteId}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={formData.clienteId ? "Selecione a apólice" : "Selecione um cliente primeiro"} />
                  </SelectTrigger>
                  <SelectContent className="bg-popover">
                    {clienteApolices.map((apolice) => (
                      <SelectItem key={apolice.id} value={apolice.id}>
                        {apolice.numero} - {apolice.produto}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="seguradora">Seguradora</Label>
                <Input
                  id="seguradora"
                  value={formData.seguradora || ""}
                  onChange={(e) => setFormData(prev => ({ ...prev, seguradora: e.target.value }))}
                  placeholder="Nome da seguradora"
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Datas e Protocolo */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <Calendar className="h-4 w-4" />
              Datas e Protocolo
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="dataOcorrencia">Data de Ocorrência *</Label>
                <Input
                  id="dataOcorrencia"
                  type="date"
                  value={formData.dataOcorrencia}
                  onChange={(e) => setFormData(prev => ({ ...prev, dataOcorrencia: e.target.value }))}
                  className={cn(errors.dataOcorrencia && "border-destructive")}
                />
                {errors.dataOcorrencia && <p className="text-xs text-destructive">{errors.dataOcorrencia}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="dataAviso">Data de Aviso *</Label>
                <Input
                  id="dataAviso"
                  type="date"
                  value={formData.dataAviso}
                  onChange={(e) => setFormData(prev => ({ ...prev, dataAviso: e.target.value }))}
                  className={cn(errors.dataAviso && "border-destructive")}
                />
                {errors.dataAviso && <p className="text-xs text-destructive">{errors.dataAviso}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="protocolo">Protocolo / Nº Aviso</Label>
                <Input
                  id="protocolo"
                  value={formData.protocolo || ""}
                  onChange={(e) => setFormData(prev => ({ ...prev, protocolo: e.target.value }))}
                  placeholder="Ex: SIN-2024-001"
                />
              </div>
            </div>
          </div>

          <Separator />

          {/* Descrições */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <FileText className="h-4 w-4" />
              Descrição do Sinistro
            </div>

            <div className="space-y-2">
              <Label htmlFor="descricaoResumida">Descrição Resumida * (máx. 200 caracteres)</Label>
              <Input
                id="descricaoResumida"
                value={formData.descricaoResumida}
                onChange={(e) => setFormData(prev => ({ ...prev, descricaoResumida: e.target.value }))}
                placeholder="Breve descrição do sinistro"
                maxLength={200}
                className={cn(errors.descricaoResumida && "border-destructive")}
              />
              <div className="flex justify-between">
                {errors.descricaoResumida && <p className="text-xs text-destructive">{errors.descricaoResumida}</p>}
                <p className="text-xs text-muted-foreground ml-auto">{formData.descricaoResumida.length}/200</p>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="descricaoDetalhada">Descrição Detalhada</Label>
              <Textarea
                id="descricaoDetalhada"
                value={formData.descricaoDetalhada}
                onChange={(e) => setFormData(prev => ({ ...prev, descricaoDetalhada: e.target.value }))}
                placeholder="Detalhes completos do sinistro, circunstâncias, envolvidos, etc."
                rows={4}
              />
            </div>
          </div>

          <Separator />

          {/* Status, Criticidade e Responsável */}
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Criticidade *</Label>
                <div className="flex gap-2 flex-wrap">
                  {criticidades.map((c) => (
                    <Button
                      key={c.value}
                      type="button"
                      variant={formData.criticidade === c.value ? "default" : "outline"}
                      size="sm"
                      onClick={() => setFormData(prev => ({ ...prev, criticidade: c.value }))}
                      className={cn(
                        formData.criticidade === c.value && c.color,
                        formData.criticidade === c.value && "text-white"
                      )}
                    >
                      {c.label}
                    </Button>
                  ))}
                </div>
                {errors.criticidade && <p className="text-xs text-destructive">{errors.criticidade}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status *</Label>
                <Select value={formData.status} onValueChange={(v) => setFormData(prev => ({ ...prev, status: v }))}>
                  <SelectTrigger className={cn(errors.status && "border-destructive")}>
                    <SelectValue placeholder="Selecione o status" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover">
                    {statusOptions.map((s) => (
                      <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.status && <p className="text-xs text-destructive">{errors.status}</p>}
              </div>

              {/* Responsável Interno - Using EntitySelectWithCreate */}
              <EntitySelectWithCreate<ResponsavelCreateData>
                value={formData.responsavel}
                onChange={handleResponsavelChange}
                options={responsaveisOptions}
                placeholder="Selecione o responsável"
                label="Responsável Interno"
                required
                error={errors.responsavel}
                createModal={{
                  title: "Novo Responsável Interno",
                  description: "Adicione um novo membro da equipe como responsável",
                  addButtonText: "Adicionar novo responsável",
                  createButtonText: "Criar e selecionar",
                  fields: [
                    {
                      name: "full_name",
                      label: "Nome completo",
                      type: "text",
                      placeholder: "Nome do responsável",
                      required: true,
                    },
                    {
                      name: "email",
                      label: "E-mail",
                      type: "email",
                      placeholder: "email@exemplo.com",
                      required: true,
                    },
                  ],
                  onCreate: handleCreateResponsavel,
                  checkDuplicate: checkDuplicateResponsavel,
                }}
                onCreated={handleResponsavelCreated}
              />
            </div>
          </div>

          <Separator />

          {/* Valores */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <DollarSign className="h-4 w-4" />
              Valores (Opcionais)
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="valorEstimado">Valor Estimado (R$)</Label>
                <Input
                  id="valorEstimado"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.valorEstimado || ""}
                  onChange={(e) => setFormData(prev => ({ ...prev, valorEstimado: parseFloat(e.target.value) || undefined }))}
                  placeholder="0,00"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="valorPago">Valor Pago (R$)</Label>
                <Input
                  id="valorPago"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.valorPago || ""}
                  onChange={(e) => setFormData(prev => ({ ...prev, valorPago: parseFloat(e.target.value) || undefined }))}
                  placeholder="0,00"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSubmit} className="gap-2">
            <AlertTriangle className="h-4 w-4" />
            {editData ? "Salvar Alterações" : "Registrar Sinistro"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
