import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { 
  Paperclip, 
  FileText, 
  Image, 
  File, 
  Download, 
  Eye,
  Clock,
  Loader2,
  Plus
} from "lucide-react";
import { cn } from "@/lib/utils";
import { 
  useSinistroDocuments, 
  useSinistroDocumentUrl,
  typeConfig,
  formatFileSize,
  getFileIconType,
} from "@/hooks/useSinistroDocuments";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface SinistroDocumentsSectionProps {
  sinistroId: string;
  onOpenModal: () => void;
}

const FileIcon = ({ type }: { type: 'image' | 'pdf' | 'doc' | 'file' }) => {
  const config = {
    image: { Icon: Image, color: "text-success", bg: "bg-success/10" },
    pdf: { Icon: FileText, color: "text-destructive", bg: "bg-destructive/10" },
    doc: { Icon: FileText, color: "text-primary", bg: "bg-primary/10" },
    file: { Icon: File, color: "text-muted-foreground", bg: "bg-secondary" },
  };
  
  const { Icon, color, bg } = config[type];
  
  return (
    <div className={cn("p-1.5 rounded", bg)}>
      <Icon className={cn("h-4 w-4", color)} />
    </div>
  );
};

export function SinistroDocumentsSection({
  sinistroId,
  onOpenModal,
}: SinistroDocumentsSectionProps) {
  const [loadingDocId, setLoadingDocId] = useState<string | null>(null);
  
  const { data: documents = [], isLoading } = useSinistroDocuments(sinistroId);
  const getDocumentUrl = useSinistroDocumentUrl();

  const handleView = async (docId: string, url: string) => {
    setLoadingDocId(docId);
    try {
      const signedUrl = await getDocumentUrl.mutateAsync(url);
      window.open(signedUrl, '_blank');
    } catch (err) {
      console.error("Error viewing document:", err);
    } finally {
      setLoadingDocId(null);
    }
  };

  const handleDownload = async (docId: string, url: string, fileName: string) => {
    setLoadingDocId(docId);
    try {
      const signedUrl = await getDocumentUrl.mutateAsync(url);
      
      const response = await fetch(signedUrl);
      if (!response.ok) throw new Error("Failed to download");
      
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(downloadUrl);
    } catch (err) {
      console.error("Error downloading document:", err);
    } finally {
      setLoadingDocId(null);
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Paperclip className="h-4 w-4 text-muted-foreground" />
          <p className="text-sm font-medium">Documentos do Sinistro</p>
          {!isLoading && (
            <Badge variant="secondary" className="text-xs">
              {documents.length}
            </Badge>
          )}
        </div>
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-7 text-xs gap-1"
          onClick={onOpenModal}
        >
          <Plus className="h-3 w-3" />
          Anexar
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-2">
          {[1, 2].map((i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </div>
      ) : documents.length === 0 ? (
        <div className="text-center py-6 border border-dashed rounded-lg">
          <Paperclip className="h-8 w-8 mx-auto mb-2 text-muted-foreground/40" />
          <p className="text-sm text-muted-foreground">Nenhum documento anexado</p>
          <Button 
            variant="link" 
            size="sm" 
            className="mt-1 text-xs"
            onClick={onOpenModal}
          >
            Anexar primeiro documento
          </Button>
        </div>
      ) : (
        <div className="space-y-2">
          {documents.slice(0, 5).map((doc) => {
            const fileType = getFileIconType(doc.nome);
            const config = typeConfig[doc.tipo] || typeConfig.outros;
            const isLoadingThis = loadingDocId === doc.id;
            
            return (
              <div
                key={doc.id}
                className="flex items-center gap-2 p-2 rounded-lg border border-border/50 bg-card/50 hover:bg-secondary/20 transition-colors group"
              >
                <FileIcon type={fileType} />
                
                <div className="flex-1 min-w-0">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <p className="text-xs font-medium truncate">
                          {doc.nome}
                        </p>
                      </TooltipTrigger>
                      <TooltipContent side="top">
                        <p className="text-xs">{doc.nome}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className={cn("text-[9px] px-1 h-4", config.color)}>
                      {config.label}
                    </Badge>
                    <span className="text-[9px] text-muted-foreground">
                      {formatFileSize(doc.tamanho)}
                    </span>
                    <div className="flex items-center gap-0.5 text-[9px] text-muted-foreground">
                      <Clock className="h-2 w-2" />
                      {format(new Date(doc.data_documento), "dd/MM/yy", { locale: ptBR })}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-6 w-6"
                    onClick={() => handleView(doc.id, doc.url)}
                    disabled={isLoadingThis}
                  >
                    {isLoadingThis ? (
                      <Loader2 className="h-3 w-3 animate-spin" />
                    ) : (
                      <Eye className="h-3 w-3" />
                    )}
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-6 w-6"
                    onClick={() => handleDownload(doc.id, doc.url, doc.nome)}
                    disabled={isLoadingThis}
                  >
                    <Download className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            );
          })}
          
          {documents.length > 5 && (
            <Button 
              variant="ghost" 
              size="sm" 
              className="w-full text-xs h-8"
              onClick={onOpenModal}
            >
              Ver todos ({documents.length} documentos)
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
