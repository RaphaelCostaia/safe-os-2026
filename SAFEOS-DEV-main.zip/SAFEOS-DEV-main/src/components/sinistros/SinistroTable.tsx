import { useState } from "react";
import { 
  MoreHorizontal, 
  Eye, 
  Edit, 
  UserPlus, 
  ArrowUpDown,
  AlertTriangle,
  Clock,
  CheckCircle2,
  AlertCircle,
  Archive,
  Users,
  Paperclip
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { format, differenceInDays } from "date-fns";
import { ptBR } from "date-fns/locale";

export interface Sinistro {
  id: string;
  clienteNome: string;
  clienteCpf: string;
  tipoProfissional: string;
  produto: string;
  apoliceNumero?: string;
  seguradora?: string;
  status: string;
  criticidade: string;
  dataOcorrencia: string;
  dataAviso: string;
  sla?: string;
  responsavel: string;
  responsavelId?: string;
  ultimaAtualizacao: string;
  protocolo?: string;
  valorEstimado?: number;
  valorPago?: number;
  descricaoResumida: string;
}

interface SinistroTableProps {
  sinistros: Sinistro[];
  onView: (sinistro: Sinistro) => void;
  onEdit: (sinistro: Sinistro) => void;
  onChangeResponsavel: (sinistro: Sinistro) => void;
  onChangeStatus: (sinistro: Sinistro, status: string) => void;
  onAttachDocuments?: (sinistro: Sinistro) => void;
}

const statusConfig: Record<string, { label: string; icon: React.ElementType; color: string; bgColor: string }> = {
  aberto: { label: "Aberto", icon: AlertCircle, color: "text-blue-400", bgColor: "bg-blue-500/10" },
  em_andamento: { label: "Em Andamento", icon: Clock, color: "text-amber-400", bgColor: "bg-amber-500/10" },
  aguardando_cliente: { label: "Aguard. Cliente", icon: Users, color: "text-purple-400", bgColor: "bg-purple-500/10" },
  aguardando_seguradora: { label: "Aguard. Seguradora", icon: Clock, color: "text-cyan-400", bgColor: "bg-cyan-500/10" },
  encerrado: { label: "Encerrado", icon: CheckCircle2, color: "text-emerald-400", bgColor: "bg-emerald-500/10" },
  arquivado: { label: "Arquivado", icon: Archive, color: "text-slate-400", bgColor: "bg-slate-500/10" },
};

const criticidadeConfig: Record<string, { label: string; color: string; bgColor: string }> = {
  baixa: { label: "Baixa", color: "text-slate-400", bgColor: "bg-slate-500/20" },
  media: { label: "Média", color: "text-amber-400", bgColor: "bg-amber-500/20" },
  alta: { label: "Alta", color: "text-orange-400", bgColor: "bg-orange-500/20" },
  critica: { label: "Crítica", color: "text-rose-400", bgColor: "bg-rose-500/20" },
};

const produtoLabels: Record<string, string> = {
  rcp: "RCP",
  vida: "Vida",
  dit: "DIT",
  auto: "Auto",
  residencial: "Residencial",
  consorcio: "Consórcio",
  outros: "Outros",
};

export function SinistroTable({ sinistros, onView, onEdit, onChangeResponsavel, onChangeStatus, onAttachDocuments }: SinistroTableProps) {
  const [sortField, setSortField] = useState<keyof Sinistro>("ultimaAtualizacao");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");

  const handleSort = (field: keyof Sinistro) => {
    if (sortField === field) {
      setSortDirection(prev => prev === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("desc");
    }
  };

  const sortedSinistros = [...sinistros].sort((a, b) => {
    const aVal = a[sortField];
    const bVal = b[sortField];
    const modifier = sortDirection === "asc" ? 1 : -1;
    
    if (typeof aVal === "string" && typeof bVal === "string") {
      return aVal.localeCompare(bVal) * modifier;
    }
    return 0;
  });

  const isAtrasado = (sinistro: Sinistro) => {
    if (sinistro.sla) {
      const slaDate = new Date(sinistro.sla);
      return slaDate < new Date() && !["encerrado", "arquivado"].includes(sinistro.status);
    }
    return false;
  };

  return (
    <div className="rounded-lg border border-border/50 bg-card/30 backdrop-blur-sm overflow-x-auto">
      <div className="min-w-[1200px]">
        <Table>
          <TableHeader>
          <TableRow className="hover:bg-transparent border-border/50">
            <TableHead className="w-[180px]">
              <Button variant="ghost" size="sm" onClick={() => handleSort("clienteNome")} className="gap-1 -ml-2">
                Cliente
                <ArrowUpDown className="h-3 w-3" />
              </Button>
            </TableHead>
            <TableHead className="w-[100px]">Tipo</TableHead>
            <TableHead className="w-[80px]">Produto</TableHead>
            <TableHead className="w-[120px]">Apólice</TableHead>
            <TableHead className="w-[140px]">
              <Button variant="ghost" size="sm" onClick={() => handleSort("status")} className="gap-1 -ml-2">
                Status
                <ArrowUpDown className="h-3 w-3" />
              </Button>
            </TableHead>
            <TableHead className="w-[90px]">
              <Button variant="ghost" size="sm" onClick={() => handleSort("criticidade")} className="gap-1 -ml-2">
                Criticidade
                <ArrowUpDown className="h-3 w-3" />
              </Button>
            </TableHead>
            <TableHead className="w-[100px]">
              <Button variant="ghost" size="sm" onClick={() => handleSort("dataOcorrencia")} className="gap-1 -ml-2">
                Ocorrência
                <ArrowUpDown className="h-3 w-3" />
              </Button>
            </TableHead>
            <TableHead className="w-[90px]">Prazo</TableHead>
            <TableHead className="w-[110px]">Responsável</TableHead>
            <TableHead className="w-[110px]">
              <Button variant="ghost" size="sm" onClick={() => handleSort("ultimaAtualizacao")} className="gap-1 -ml-2">
                Atualização
                <ArrowUpDown className="h-3 w-3" />
              </Button>
            </TableHead>
            <TableHead className="w-[50px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedSinistros.map((sinistro) => {
            const status = statusConfig[sinistro.status] || statusConfig.aberto;
            const criticidade = criticidadeConfig[sinistro.criticidade] || criticidadeConfig.media;
            const StatusIcon = status.icon;
            const atrasado = isAtrasado(sinistro);
            const isCritico = sinistro.criticidade === "critica";

            return (
              <TableRow 
                key={sinistro.id}
                className={cn(
                  "border-border/30 cursor-pointer hover:bg-muted/30 transition-colors",
                  isCritico && "bg-rose-500/5 hover:bg-rose-500/10",
                  atrasado && !isCritico && "bg-orange-500/5 hover:bg-orange-500/10"
                )}
                onClick={() => onView(sinistro)}
              >
                <TableCell>
                  <div>
                    <p className="font-medium text-foreground truncate">{sinistro.clienteNome}</p>
                    <p className="text-xs text-muted-foreground">{sinistro.clienteCpf}</p>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="text-xs">
                    {sinistro.tipoProfissional}
                  </Badge>
                </TableCell>
                <TableCell>
                  <span className="text-sm font-medium">
                    {produtoLabels[sinistro.produto] || sinistro.produto}
                  </span>
                </TableCell>
                <TableCell>
                  {sinistro.apoliceNumero ? (
                    <div>
                      <p className="text-sm">{sinistro.apoliceNumero}</p>
                      {sinistro.seguradora && (
                        <p className="text-xs text-muted-foreground truncate">{sinistro.seguradora}</p>
                      )}
                    </div>
                  ) : (
                    <span className="text-xs text-muted-foreground">-</span>
                  )}
                </TableCell>
                <TableCell>
                  <div className={cn("flex items-center gap-1.5 px-2 py-1 rounded-md w-fit", status.bgColor)}>
                    <StatusIcon className={cn("h-3.5 w-3.5", status.color)} />
                    <span className={cn("text-xs font-medium", status.color)}>{status.label}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge className={cn("text-xs border-0", criticidade.bgColor, criticidade.color)}>
                    {isCritico && <AlertTriangle className="h-3 w-3 mr-1" />}
                    {criticidade.label}
                  </Badge>
                </TableCell>
                <TableCell>
                  <span className="text-sm">
                    {format(new Date(sinistro.dataOcorrencia), "dd/MM/yyyy", { locale: ptBR })}
                  </span>
                </TableCell>
                <TableCell>
                  {sinistro.sla ? (
                    <div className={cn("text-sm", atrasado && "text-rose-400 font-medium")}>
                      {atrasado && <AlertTriangle className="h-3 w-3 inline mr-1" />}
                      {format(new Date(sinistro.sla), "dd/MM/yy", { locale: ptBR })}
                    </div>
                  ) : (
                    <span className="text-xs text-muted-foreground">-</span>
                  )}
                </TableCell>
                <TableCell>
                  <span className="text-sm">{sinistro.responsavel}</span>
                </TableCell>
                <TableCell>
                  <div className="text-xs text-muted-foreground">
                    {format(new Date(sinistro.ultimaAtualizacao), "dd/MM/yy HH:mm", { locale: ptBR })}
                  </div>
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onView(sinistro); }}>
                        <Eye className="h-4 w-4 mr-2" />
                        Ver Detalhes
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onEdit(sinistro); }}>
                        <Edit className="h-4 w-4 mr-2" />
                        Editar
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onChangeResponsavel(sinistro); }}>
                        <UserPlus className="h-4 w-4 mr-2" />
                        Alterar Responsável
                      </DropdownMenuItem>
                      {onAttachDocuments && (
                        <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onAttachDocuments(sinistro); }}>
                          <Paperclip className="h-4 w-4 mr-2" />
                          Anexar Documentos
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuSeparator />
                      {Object.entries(statusConfig).map(([key, config]) => (
                        key !== sinistro.status && (
                          <DropdownMenuItem 
                            key={key}
                            onClick={(e) => { e.stopPropagation(); onChangeStatus(sinistro, key); }}
                          >
                            <config.icon className={cn("h-4 w-4 mr-2", config.color)} />
                            Marcar como {config.label}
                          </DropdownMenuItem>
                        )
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
      
        {sinistros.length === 0 && (
          <div className="p-8 text-center text-muted-foreground">
            <AlertTriangle className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>Nenhum sinistro encontrado</p>
            <p className="text-sm">Ajuste os filtros ou registre um novo sinistro</p>
          </div>
        )}
      </div>
    </div>
  );
}
