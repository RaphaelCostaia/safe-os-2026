import { Search, Filter, X, AlertTriangle, Clock } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { useState } from "react";

export interface SinistroFiltersState {
  search: string;
  status: string;
  criticidade: string;
  produto: string;
  tipoProfissional: string;
  responsavel: string;
  dataOcorrenciaInicio?: Date;
  dataOcorrenciaFim?: Date;
  somentesCriticos: boolean;
  somentesAtrasados: boolean;
}

interface SinistroFiltersProps {
  filters: SinistroFiltersState;
  onFiltersChange: (filters: SinistroFiltersState) => void;
  responsaveis: Array<{ id: string; nome: string }>;
}

const statusOptions = [
  { value: "todos", label: "Todos" },
  { value: "aberto", label: "Aberto" },
  { value: "em_andamento", label: "Em Andamento" },
  { value: "aguardando_cliente", label: "Aguardando Cliente" },
  { value: "aguardando_seguradora", label: "Aguardando Seguradora" },
  { value: "encerrado", label: "Encerrado" },
  { value: "arquivado", label: "Arquivado" },
];

const criticidadeOptions = [
  { value: "todos", label: "Todas" },
  { value: "baixa", label: "Baixa" },
  { value: "media", label: "Média" },
  { value: "alta", label: "Alta" },
  { value: "critica", label: "Crítica" },
];

const produtoOptions = [
  { value: "todos", label: "Todos" },
  { value: "rcp", label: "RCP" },
  { value: "vida", label: "Vida" },
  { value: "dit", label: "DIT" },
  { value: "auto", label: "Auto" },
  { value: "residencial", label: "Residencial" },
  { value: "consorcio", label: "Consórcio" },
  { value: "outros", label: "Outros" },
];

const profissionalOptions = [
  { value: "todos", label: "Todos" },
  { value: "medico", label: "Médico" },
  { value: "dentista", label: "Dentista" },
  { value: "outro", label: "Outro" },
];

export function SinistroFilters({ filters, onFiltersChange, responsaveis }: SinistroFiltersProps) {
  const [showDatePicker, setShowDatePicker] = useState(false);

  const activeFiltersCount = [
    filters.status !== "todos",
    filters.criticidade !== "todos",
    filters.produto !== "todos",
    filters.tipoProfissional !== "todos",
    filters.responsavel !== "todos",
    filters.dataOcorrenciaInicio,
    filters.somentesCriticos,
    filters.somentesAtrasados,
  ].filter(Boolean).length;

  const clearFilters = () => {
    onFiltersChange({
      search: "",
      status: "todos",
      criticidade: "todos",
      produto: "todos",
      tipoProfissional: "todos",
      responsavel: "todos",
      dataOcorrenciaInicio: undefined,
      dataOcorrenciaFim: undefined,
      somentesCriticos: false,
      somentesAtrasados: false,
    });
  };

  return (
    <div className="space-y-4">
      {/* Search and Quick Actions */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar por cliente, CPF, apólice ou protocolo..."
            value={filters.search}
            onChange={(e) => onFiltersChange({ ...filters, search: e.target.value })}
            className="pl-10 bg-background/50"
          />
        </div>

        <div className="flex gap-2">
          <Button
            variant={filters.somentesCriticos ? "destructive" : "outline"}
            size="sm"
            onClick={() => onFiltersChange({ ...filters, somentesCriticos: !filters.somentesCriticos })}
            className="gap-2"
          >
            <AlertTriangle className="h-4 w-4" />
            Críticos
          </Button>

          <Button
            variant={filters.somentesAtrasados ? "default" : "outline"}
            size="sm"
            onClick={() => onFiltersChange({ ...filters, somentesAtrasados: !filters.somentesAtrasados })}
            className={cn("gap-2", filters.somentesAtrasados && "bg-orange-600 hover:bg-orange-700")}
          >
            <Clock className="h-4 w-4" />
            Atrasados
          </Button>
        </div>
      </div>

      {/* Filter Selects */}
      <div className="flex flex-wrap gap-3">
        <Select
          value={filters.status}
          onValueChange={(value) => onFiltersChange({ ...filters, status: value })}
        >
          <SelectTrigger className="w-[160px] bg-background/50">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            {statusOptions.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={filters.criticidade}
          onValueChange={(value) => onFiltersChange({ ...filters, criticidade: value })}
        >
          <SelectTrigger className="w-[140px] bg-background/50">
            <SelectValue placeholder="Criticidade" />
          </SelectTrigger>
          <SelectContent>
            {criticidadeOptions.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={filters.produto}
          onValueChange={(value) => onFiltersChange({ ...filters, produto: value })}
        >
          <SelectTrigger className="w-[140px] bg-background/50">
            <SelectValue placeholder="Produto" />
          </SelectTrigger>
          <SelectContent>
            {produtoOptions.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={filters.tipoProfissional}
          onValueChange={(value) => onFiltersChange({ ...filters, tipoProfissional: value })}
        >
          <SelectTrigger className="w-[150px] bg-background/50">
            <SelectValue placeholder="Tipo Profissional" />
          </SelectTrigger>
          <SelectContent>
            {profissionalOptions.map((opt) => (
              <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={filters.responsavel}
          onValueChange={(value) => onFiltersChange({ ...filters, responsavel: value })}
        >
          <SelectTrigger className="w-[160px] bg-background/50">
            <SelectValue placeholder="Responsável" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos</SelectItem>
            {responsaveis.map((resp) => (
              <SelectItem key={resp.id} value={resp.id}>{resp.nome}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Popover open={showDatePicker} onOpenChange={setShowDatePicker}>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm" className="gap-2 bg-background/50">
              <Filter className="h-4 w-4" />
              {filters.dataOcorrenciaInicio ? (
                <>
                  {format(filters.dataOcorrenciaInicio, "dd/MM/yy", { locale: ptBR })}
                  {filters.dataOcorrenciaFim && ` - ${format(filters.dataOcorrenciaFim, "dd/MM/yy", { locale: ptBR })}`}
                </>
              ) : (
                "Período"
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-4" align="start">
            <div className="space-y-3">
              <div>
                <Label className="text-xs text-muted-foreground">Data Inicial</Label>
                <Calendar
                  mode="single"
                  selected={filters.dataOcorrenciaInicio}
                  onSelect={(date) => onFiltersChange({ ...filters, dataOcorrenciaInicio: date })}
                  locale={ptBR}
                  className="rounded-md border"
                />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Data Final</Label>
                <Calendar
                  mode="single"
                  selected={filters.dataOcorrenciaFim}
                  onSelect={(date) => onFiltersChange({ ...filters, dataOcorrenciaFim: date })}
                  locale={ptBR}
                  className="rounded-md border"
                />
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full"
                onClick={() => {
                  onFiltersChange({ 
                    ...filters, 
                    dataOcorrenciaInicio: undefined, 
                    dataOcorrenciaFim: undefined 
                  });
                  setShowDatePicker(false);
                }}
              >
                Limpar Período
              </Button>
            </div>
          </PopoverContent>
        </Popover>

        {activeFiltersCount > 0 && (
          <Button variant="ghost" size="sm" onClick={clearFilters} className="gap-2 text-muted-foreground">
            <X className="h-4 w-4" />
            Limpar ({activeFiltersCount})
          </Button>
        )}
      </div>
    </div>
  );
}
