import { AlertTriangle, Clock, CheckCircle2, AlertCircle, TrendingUp, Users } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface KPIData {
  abertos: number;
  emAndamento: number;
  aguardandoCliente: number;
  aguardandoSeguradora: number;
  encerrados: number;
  criticos: number;
  atrasados: number;
  valorEstimadoTotal: number;
  valorPagoTotal: number;
}

interface SinistroKPIsProps {
  data: KPIData;
}

export function SinistroKPIs({ data }: SinistroKPIsProps) {
  const kpis = [
    {
      label: "Abertos",
      value: data.abertos,
      icon: AlertCircle,
      color: "text-blue-400",
      bgColor: "bg-blue-500/10",
    },
    {
      label: "Em Andamento",
      value: data.emAndamento,
      icon: Clock,
      color: "text-amber-400",
      bgColor: "bg-amber-500/10",
    },
    {
      label: "Aguard. Cliente",
      value: data.aguardandoCliente,
      icon: Users,
      color: "text-purple-400",
      bgColor: "bg-purple-500/10",
    },
    {
      label: "Aguard. Seguradora",
      value: data.aguardandoSeguradora,
      icon: Clock,
      color: "text-cyan-400",
      bgColor: "bg-cyan-500/10",
    },
    {
      label: "Encerrados",
      value: data.encerrados,
      icon: CheckCircle2,
      color: "text-emerald-400",
      bgColor: "bg-emerald-500/10",
    },
    {
      label: "Críticos",
      value: data.criticos,
      icon: AlertTriangle,
      color: "text-rose-400",
      bgColor: "bg-rose-500/10",
      highlight: data.criticos > 0,
    },
    {
      label: "Atrasados",
      value: data.atrasados,
      icon: AlertTriangle,
      color: "text-orange-400",
      bgColor: "bg-orange-500/10",
      highlight: data.atrasados > 0,
    },
  ];

  return (
    <div className="space-y-4">
      {/* Status KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-3">
        {kpis.map((kpi) => (
          <Card 
            key={kpi.label} 
            className={cn(
              "border-border/50 bg-card/50 backdrop-blur-sm transition-all hover:border-border",
              kpi.highlight && "border-rose-500/50 animate-pulse-subtle"
            )}
          >
            <CardContent className="p-3">
              <div className="flex items-center gap-2">
                <div className={cn("p-1.5 rounded-lg", kpi.bgColor)}>
                  <kpi.icon className={cn("h-4 w-4", kpi.color)} />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground truncate">{kpi.label}</p>
                  <p className={cn("text-xl font-bold", kpi.color)}>{kpi.value}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Financial Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Valor Estimado Total</p>
                <p className="text-2xl font-bold text-foreground">
                  {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(data.valorEstimadoTotal)}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-amber-500/10">
                <TrendingUp className="h-6 w-6 text-amber-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Valor Pago Total</p>
                <p className="text-2xl font-bold text-emerald-400">
                  {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(data.valorPagoTotal)}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-emerald-500/10">
                <CheckCircle2 className="h-6 w-6 text-emerald-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
