import { useState } from "react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  MessageSquare,
  Lightbulb,
  Plus,
  Pin,
  PinOff,
  Trash2,
  Edit2,
  Loader2,
  Tag,
  ExternalLink,
  Lock,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import {
  useSinistroNotes,
  useCreateSinistroNote,
  useUpdateSinistroNote,
  useDeleteSinistroNote,
  useTogglePinNote,
} from "@/hooks/useSinistroNotes";
import { useSinistroTips } from "@/hooks/useSinistroTips";

interface SinistroNotesAndTipsProps {
  sinistroId: string;
  produtoCategoria?: string | null;
}

const TAG_OPTIONS = ["urgente", "jurídico", "cliente", "seguradora", "pendente", "resolvido"];

export function SinistroNotesAndTips({ sinistroId, produtoCategoria }: SinistroNotesAndTipsProps) {
  const [showNoteModal, setShowNoteModal] = useState(false);
  const [editingNote, setEditingNote] = useState<string | null>(null);
  const [deleteNoteId, setDeleteNoteId] = useState<string | null>(null);
  const [noteForm, setNoteForm] = useState({
    conteudo: "",
    tags: [] as string[],
    is_private: false,
  });

  const { data: notes = [], isLoading: notesLoading } = useSinistroNotes(sinistroId);
  const { data: tips = [], isLoading: tipsLoading } = useSinistroTips(produtoCategoria);
  const createNote = useCreateSinistroNote();
  const updateNote = useUpdateSinistroNote();
  const deleteNote = useDeleteSinistroNote();
  const togglePin = useTogglePinNote();

  const handleOpenNewNote = () => {
    setEditingNote(null);
    setNoteForm({ conteudo: "", tags: [], is_private: false });
    setShowNoteModal(true);
  };

  const handleEditNote = (note: typeof notes[0]) => {
    setEditingNote(note.id);
    setNoteForm({
      conteudo: note.conteudo,
      tags: note.tags || [],
      is_private: note.is_private || false,
    });
    setShowNoteModal(true);
  };

  const handleSaveNote = () => {
    if (!noteForm.conteudo.trim()) return;

    if (editingNote) {
      updateNote.mutate({
        id: editingNote,
        sinistroId,
        conteudo: noteForm.conteudo,
        tags: noteForm.tags,
        is_private: noteForm.is_private,
      }, {
        onSuccess: () => {
          setShowNoteModal(false);
          setEditingNote(null);
        }
      });
    } else {
      createNote.mutate({
        sinistro_id: sinistroId,
        conteudo: noteForm.conteudo,
        tags: noteForm.tags,
        is_private: noteForm.is_private,
      }, {
        onSuccess: () => {
          setShowNoteModal(false);
        }
      });
    }
  };

  const handleDeleteNote = () => {
    if (!deleteNoteId) return;
    deleteNote.mutate({ id: deleteNoteId, sinistroId }, {
      onSuccess: () => setDeleteNoteId(null)
    });
  };

  const toggleTag = (tag: string) => {
    setNoteForm(prev => ({
      ...prev,
      tags: prev.tags.includes(tag)
        ? prev.tags.filter(t => t !== tag)
        : [...prev.tags, tag]
    }));
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium">Anotações e Tips</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <Tabs defaultValue="notas" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="notas" className="gap-2">
              <MessageSquare className="h-4 w-4" />
              Anotações
            </TabsTrigger>
            <TabsTrigger value="tips" className="gap-2">
              <Lightbulb className="h-4 w-4" />
              Tips
            </TabsTrigger>
          </TabsList>

          <TabsContent value="notas" className="mt-0">
            <div className="flex justify-end mb-3">
              <Button size="sm" variant="outline" onClick={handleOpenNewNote} className="gap-1">
                <Plus className="h-3 w-3" />
                Nova Anotação
              </Button>
            </div>

            {notesLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              </div>
            ) : notes.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Nenhuma anotação ainda</p>
                <Button variant="link" size="sm" className="mt-2" onClick={handleOpenNewNote}>
                  Adicionar primeira anotação
                </Button>
              </div>
            ) : (
              <ScrollArea className="h-[250px]">
                <div className="space-y-3 pr-4">
                  {notes.map((note) => (
                    <div
                      key={note.id}
                      className={`p-3 rounded-lg border ${note.is_pinned ? 'bg-primary/5 border-primary/20' : 'bg-muted/30'}`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          {note.is_pinned && (
                            <Pin className="h-3 w-3 text-primary" />
                          )}
                          {note.is_private && (
                            <Tooltip>
                              <TooltipTrigger>
                                <Lock className="h-3 w-3 text-muted-foreground" />
                              </TooltipTrigger>
                              <TooltipContent>Nota privada</TooltipContent>
                            </Tooltip>
                          )}
                          {note.tags?.map((tag) => (
                            <Badge key={tag} variant="secondary" className="text-xs px-1.5 py-0">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 w-7 p-0"
                            onClick={() => togglePin.mutate({
                              id: note.id,
                              sinistroId,
                              isPinned: note.is_pinned || false
                            })}
                          >
                            {note.is_pinned ? (
                              <PinOff className="h-3 w-3" />
                            ) : (
                              <Pin className="h-3 w-3" />
                            )}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 w-7 p-0"
                            onClick={() => handleEditNote(note)}
                          >
                            <Edit2 className="h-3 w-3" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 w-7 p-0 text-destructive hover:text-destructive"
                            onClick={() => setDeleteNoteId(note.id)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      <p className="text-sm whitespace-pre-wrap">{note.conteudo}</p>
                      <p className="text-xs text-muted-foreground mt-2">
                        {format(new Date(note.created_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </TabsContent>

          <TabsContent value="tips" className="mt-0">
            {tipsLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              </div>
            ) : tips.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Lightbulb className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Nenhuma dica disponível</p>
              </div>
            ) : (
              <ScrollArea className="h-[250px]">
                <div className="space-y-3 pr-4">
                  {tips.map((tip) => (
                    <div
                      key={tip.id}
                      className="p-3 rounded-lg bg-amber-500/5 border border-amber-500/20"
                    >
                      <div className="flex items-start gap-2">
                        <Lightbulb className="h-4 w-4 text-amber-500 mt-0.5 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-sm">{tip.titulo}</span>
                            {tip.categoria && (
                              <Badge variant="outline" className="text-xs px-1.5 py-0">
                                {tip.categoria}
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">{tip.conteudo}</p>
                          {tip.link_interno && (
                            <Button variant="link" size="sm" className="h-auto p-0 mt-1 text-xs gap-1">
                              <ExternalLink className="h-3 w-3" />
                              Ver mais
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>

      {/* Note Modal */}
      <Dialog open={showNoteModal} onOpenChange={setShowNoteModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingNote ? "Editar Anotação" : "Nova Anotação"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="conteudo">Conteúdo *</Label>
              <Textarea
                id="conteudo"
                placeholder="Digite sua anotação..."
                value={noteForm.conteudo}
                onChange={(e) => setNoteForm(prev => ({ ...prev, conteudo: e.target.value }))}
                rows={4}
              />
            </div>

            <div className="space-y-2">
              <Label>Tags</Label>
              <div className="flex flex-wrap gap-2">
                {TAG_OPTIONS.map((tag) => (
                  <Badge
                    key={tag}
                    variant={noteForm.tags.includes(tag) ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => toggleTag(tag)}
                  >
                    <Tag className="h-3 w-3 mr-1" />
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="private" className="cursor-pointer">
                Nota privada
              </Label>
              <Switch
                id="private"
                checked={noteForm.is_private}
                onCheckedChange={(checked) => setNoteForm(prev => ({ ...prev, is_private: checked }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNoteModal(false)}>
              Cancelar
            </Button>
            <Button
              onClick={handleSaveNote}
              disabled={!noteForm.conteudo.trim() || createNote.isPending || updateNote.isPending}
            >
              {(createNote.isPending || updateNote.isPending) && (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              )}
              {editingNote ? "Salvar" : "Criar"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteNoteId} onOpenChange={() => setDeleteNoteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir anotação?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação não pode ser desfeita. A anotação será removida permanentemente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteNote}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteNote.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
