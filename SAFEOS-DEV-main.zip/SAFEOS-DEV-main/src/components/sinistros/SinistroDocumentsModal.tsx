import { useState, useRef } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { 
  Paperclip, 
  Upload, 
  FileText, 
  Image, 
  File, 
  Download, 
  Trash2, 
  Eye,
  Clock,
  Loader2,
  AlertCircle,
  FileWarning,
  Edit3,
  Check,
  X
} from "lucide-react";
import { cn } from "@/lib/utils";
import { 
  useSinistroDocuments, 
  useUploadSinistroDocument, 
  useDeleteSinistroDocument,
  useUpdateSinistroDocument,
  useSinistroDocumentUrl,
  sinistroDocumentTypes,
  typeConfig,
  formatFileSize,
  getFileIconType,
  type SinistroDocument
} from "@/hooks/useSinistroDocuments";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface SinistroDocumentsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sinistroId: string;
  clientId: string;
  apoliceId?: string | null;
  sinistroNumero?: string;
}

const FileIcon = ({ type }: { type: 'image' | 'pdf' | 'doc' | 'file' }) => {
  const config = {
    image: { Icon: Image, color: "text-success", bg: "bg-success/10" },
    pdf: { Icon: FileText, color: "text-destructive", bg: "bg-destructive/10" },
    doc: { Icon: FileText, color: "text-primary", bg: "bg-primary/10" },
    file: { Icon: File, color: "text-muted-foreground", bg: "bg-secondary" },
  };
  
  const { Icon, color, bg } = config[type];
  
  return (
    <div className={cn("p-2 rounded-lg", bg)}>
      <Icon className={cn("h-5 w-5", color)} />
    </div>
  );
};

export function SinistroDocumentsModal({
  open,
  onOpenChange,
  sinistroId,
  clientId,
  apoliceId,
  sinistroNumero,
}: SinistroDocumentsModalProps) {
  const [selectedType, setSelectedType] = useState("outros");
  const [descricao, setDescricao] = useState("");
  const [dataDocumento, setDataDocumento] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [isDragging, setIsDragging] = useState(false);
  const [loadingDocId, setLoadingDocId] = useState<string | null>(null);
  const [editingDocId, setEditingDocId] = useState<string | null>(null);
  const [editDescricao, setEditDescricao] = useState("");
  const [deleteConfirmDoc, setDeleteConfirmDoc] = useState<SinistroDocument | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: documents = [], isLoading, error } = useSinistroDocuments(sinistroId);
  const uploadDocument = useUploadSinistroDocument();
  const deleteDocument = useDeleteSinistroDocument();
  const updateDocument = useUpdateSinistroDocument();
  const getDocumentUrl = useSinistroDocumentUrl();

  const handleFileSelect = (files: FileList | null) => {
    if (!files) return;
    
    // Validate description
    if (!descricao.trim()) {
      return; // Will show error on UI
    }
    
    Array.from(files).forEach(file => {
      // Validate size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        return;
      }
      
      // Validate type
      const validTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/gif', 'image/webp', 
                          'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
      if (!validTypes.includes(file.type)) {
        return;
      }
      
      uploadDocument.mutate({
        sinistroId,
        clientId,
        apoliceId,
        file,
        tipo: selectedType,
        descricao: descricao.trim(),
        dataDocumento,
      }, {
        onSuccess: () => {
          setDescricao("");
          if (fileInputRef.current) {
            fileInputRef.current.value = "";
          }
        }
      });
    });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (!descricao.trim()) {
      return;
    }
    
    handleFileSelect(e.dataTransfer.files);
  };

  const handleDelete = (doc: SinistroDocument) => {
    setDeleteConfirmDoc(doc);
  };

  const confirmDelete = () => {
    if (deleteConfirmDoc) {
      deleteDocument.mutate({ 
        id: deleteConfirmDoc.id, 
        sinistroId, 
        url: deleteConfirmDoc.url 
      });
      setDeleteConfirmDoc(null);
    }
  };

  const handleView = async (doc: SinistroDocument) => {
    setLoadingDocId(doc.id);
    try {
      const signedUrl = await getDocumentUrl.mutateAsync(doc.url);
      window.open(signedUrl, '_blank');
    } catch (err) {
      console.error("Error viewing document:", err);
    } finally {
      setLoadingDocId(null);
    }
  };

  const handleDownload = async (doc: SinistroDocument) => {
    setLoadingDocId(doc.id);
    try {
      const signedUrl = await getDocumentUrl.mutateAsync(doc.url);
      
      const response = await fetch(signedUrl);
      if (!response.ok) {
        throw new Error("Failed to download file");
      }
      
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = doc.nome;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(downloadUrl);
    } catch (err) {
      console.error("Error downloading document:", err);
    } finally {
      setLoadingDocId(null);
    }
  };

  const startEditDescription = (doc: SinistroDocument) => {
    setEditingDocId(doc.id);
    setEditDescricao(doc.descricao || "");
  };

  const saveEditDescription = (doc: SinistroDocument) => {
    updateDocument.mutate({
      id: doc.id,
      sinistroId,
      descricao: editDescricao,
    }, {
      onSuccess: () => {
        setEditingDocId(null);
        setEditDescricao("");
      }
    });
  };

  const cancelEditDescription = () => {
    setEditingDocId(null);
    setEditDescricao("");
  };

  const isDescricaoValid = descricao.trim().length > 0;
  const isDescricaoTooLong = descricao.length > 200;

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Paperclip className="h-5 w-5 text-primary" />
              Documentos do Sinistro
            </DialogTitle>
            <DialogDescription>
              {sinistroNumero ? `Sinistro: ${sinistroNumero}` : "Anexe e gerencie documentos relacionados ao sinistro"}
            </DialogDescription>
          </DialogHeader>

          <div className="flex-1 space-y-4 overflow-hidden flex flex-col">
            {/* Upload Section */}
            <div className="space-y-3 border rounded-lg p-4 bg-muted/20">
              <p className="text-sm font-medium text-foreground">Novo documento</p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs">Tipo do documento *</Label>
                  <Select value={selectedType} onValueChange={setSelectedType}>
                    <SelectTrigger className="h-9">
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent className="bg-popover">
                      {sinistroDocumentTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-1.5">
                  <Label className="text-xs">Data do documento</Label>
                  <Input
                    type="date"
                    value={dataDocumento}
                    onChange={(e) => setDataDocumento(e.target.value)}
                    className="h-9"
                  />
                </div>
                
                <div className="space-y-1.5">
                  <Label className={cn("text-xs", !isDescricaoValid && "text-destructive")}>
                    Descrição curta * ({descricao.length}/200)
                  </Label>
                  <Input
                    value={descricao}
                    onChange={(e) => setDescricao(e.target.value.slice(0, 200))}
                    placeholder="Ex: Boletim de ocorrência"
                    className={cn("h-9", (!isDescricaoValid || isDescricaoTooLong) && "border-destructive")}
                    maxLength={200}
                  />
                </div>
              </div>
              
              <div 
                className={cn(
                  "border-2 border-dashed rounded-lg p-4 text-center transition-colors",
                  !isDescricaoValid 
                    ? "border-border/30 bg-muted/10 cursor-not-allowed opacity-60"
                    : isDragging 
                      ? "border-primary bg-primary/5 cursor-pointer" 
                      : "border-border/50 hover:border-primary/50 hover:bg-primary/5 cursor-pointer"
                )}
                onClick={() => isDescricaoValid && fileInputRef.current?.click()}
                onDragOver={(e) => { e.preventDefault(); if (isDescricaoValid) setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
              >
                {uploadDocument.isPending ? (
                  <Loader2 className="h-6 w-6 mx-auto mb-1 text-primary animate-spin" />
                ) : (
                  <Upload className="h-6 w-6 mx-auto mb-1 text-muted-foreground" />
                )}
                <p className="text-sm font-medium">
                  {uploadDocument.isPending 
                    ? "Enviando..." 
                    : !isDescricaoValid 
                      ? "Preencha a descrição primeiro"
                      : "Clique ou arraste arquivos"
                  }
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  PDF, JPG, PNG, DOC até 10MB
                </p>
              </div>
              
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept=".pdf,.jpg,.jpeg,.png,.gif,.doc,.docx"
                className="hidden"
                onChange={(e) => handleFileSelect(e.target.files)}
                disabled={!isDescricaoValid}
              />
            </div>

            {/* Error State */}
            {error && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>Erro ao carregar documentos. Tente novamente.</span>
              </div>
            )}

            {/* Documents List */}
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-muted-foreground">
                {documents.length} documento{documents.length !== 1 ? 's' : ''} anexado{documents.length !== 1 ? 's' : ''}
              </p>
            </div>

            <ScrollArea className="flex-1 pr-2">
              {isLoading ? (
                <div className="space-y-2">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-20 w-full" />
                  ))}
                </div>
              ) : documents.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <FileWarning className="h-12 w-12 mx-auto mb-3 opacity-30" />
                  <p className="font-medium">Nenhum documento anexado</p>
                  <p className="text-sm mt-1">Preencha os campos acima e faça o upload do primeiro documento</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {documents.map((doc) => {
                    const fileType = getFileIconType(doc.nome);
                    const config = typeConfig[doc.tipo] || typeConfig.outros;
                    const isLoadingThis = loadingDocId === doc.id;
                    const isEditingThis = editingDocId === doc.id;
                    
                    return (
                      <div
                        key={doc.id}
                        className="flex items-start gap-3 p-3 rounded-lg border border-border/50 bg-card hover:bg-secondary/20 transition-colors group"
                      >
                        <FileIcon type={fileType} />
                        
                        <div className="flex-1 min-w-0 space-y-1">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <p className="text-sm font-medium truncate max-w-[300px]">
                                  {doc.nome}
                                </p>
                              </TooltipTrigger>
                              <TooltipContent side="top" className="max-w-[400px]">
                                <p className="break-all">{doc.nome}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                          
                          {isEditingThis ? (
                            <div className="flex items-center gap-2">
                              <Input
                                value={editDescricao}
                                onChange={(e) => setEditDescricao(e.target.value.slice(0, 200))}
                                className="h-7 text-xs flex-1"
                                maxLength={200}
                                autoFocus
                              />
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={() => saveEditDescription(doc)}
                                disabled={updateDocument.isPending}
                              >
                                <Check className="h-3.5 w-3.5 text-success" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={cancelEditDescription}
                              >
                                <X className="h-3.5 w-3.5 text-destructive" />
                              </Button>
                            </div>
                          ) : (
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <p className="text-xs text-muted-foreground truncate max-w-[300px] cursor-default">
                                    {doc.descricao || "Sem descrição"}
                                  </p>
                                </TooltipTrigger>
                                {doc.descricao && doc.descricao.length > 40 && (
                                  <TooltipContent side="bottom" className="max-w-[300px]">
                                    <p>{doc.descricao}</p>
                                  </TooltipContent>
                                )}
                              </Tooltip>
                            </TooltipProvider>
                          )}
                          
                          <div className="flex items-center gap-2 flex-wrap">
                            <Badge variant="outline" className={cn("text-[10px] px-1.5 h-5", config.color)}>
                              {config.label}
                            </Badge>
                            <span className="text-[10px] text-muted-foreground">
                              {formatFileSize(doc.tamanho)}
                            </span>
                            <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                              <Clock className="h-2.5 w-2.5" />
                              {format(new Date(doc.data_documento), "dd/MM/yyyy", { locale: ptBR })}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="h-7 w-7"
                                  onClick={() => handleView(doc)}
                                  disabled={isLoadingThis}
                                >
                                  {isLoadingThis ? (
                                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                                  ) : (
                                    <Eye className="h-3.5 w-3.5" />
                                  )}
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Visualizar</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                          
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="h-7 w-7"
                                  onClick={() => handleDownload(doc)}
                                  disabled={isLoadingThis}
                                >
                                  <Download className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Baixar</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                          
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="h-7 w-7"
                                  onClick={() => startEditDescription(doc)}
                                  disabled={isLoadingThis}
                                >
                                  <Edit3 className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Editar descrição</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                          
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="h-7 w-7 text-destructive hover:text-destructive"
                                  onClick={() => handleDelete(doc)}
                                  disabled={deleteDocument.isPending || isLoadingThis}
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </Button>
                              </TooltipTrigger>
                              <TooltipContent>Excluir</TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </ScrollArea>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteConfirmDoc} onOpenChange={() => setDeleteConfirmDoc(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir documento?</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir "{deleteConfirmDoc?.nome}"? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
