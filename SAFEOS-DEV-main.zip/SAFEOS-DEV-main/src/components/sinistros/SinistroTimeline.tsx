import { useState } from "react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { 
  Clock, 
  Filter, 
  Plus, 
  ArrowUpDown,
  FileText,
  AlertTriangle,
  UserCheck,
  DollarSign,
  CheckCircle,
  MessageSquare,
  RefreshCw,
  Loader2
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  useSinistroActivities, 
  useCreateSinistroActivity,
  type ActivityType 
} from "@/hooks/useSinistroActivities";

interface SinistroTimelineProps {
  sinistroId: string;
}

const ACTIVITY_CONFIG: Record<ActivityType, { icon: React.ElementType; color: string; label: string }> = {
  criacao: { icon: Plus, color: "text-blue-500", label: "Criação" },
  status: { icon: RefreshCw, color: "text-purple-500", label: "Status" },
  criticidade: { icon: AlertTriangle, color: "text-amber-500", label: "Criticidade" },
  responsavel: { icon: UserCheck, color: "text-cyan-500", label: "Responsável" },
  documento: { icon: FileText, color: "text-emerald-500", label: "Documento" },
  valor: { icon: DollarSign, color: "text-yellow-500", label: "Valor" },
  encerramento: { icon: CheckCircle, color: "text-green-500", label: "Encerramento" },
  interacao: { icon: MessageSquare, color: "text-indigo-500", label: "Interação" },
};

export function SinistroTimeline({ sinistroId }: SinistroTimelineProps) {
  const [sortAsc, setSortAsc] = useState(false);
  const [filters, setFilters] = useState<Set<ActivityType>>(new Set());
  const [showAddModal, setShowAddModal] = useState(false);
  const [newInteraction, setNewInteraction] = useState({ titulo: "", descricao: "" });

  const { data: activities = [], isLoading } = useSinistroActivities(sinistroId);
  const createActivity = useCreateSinistroActivity();

  const filteredActivities = activities
    .filter(a => filters.size === 0 || filters.has(a.tipo as ActivityType))
    .sort((a, b) => {
      const dateA = new Date(a.created_at).getTime();
      const dateB = new Date(b.created_at).getTime();
      return sortAsc ? dateA - dateB : dateB - dateA;
    });

  const handleAddInteraction = () => {
    if (!newInteraction.titulo.trim()) return;

    createActivity.mutate({
      sinistro_id: sinistroId,
      tipo: "interacao",
      titulo: newInteraction.titulo,
      descricao: newInteraction.descricao || undefined,
    }, {
      onSuccess: () => {
        setShowAddModal(false);
        setNewInteraction({ titulo: "", descricao: "" });
      }
    });
  };

  const toggleFilter = (tipo: ActivityType) => {
    const newFilters = new Set(filters);
    if (newFilters.has(tipo)) {
      newFilters.delete(tipo);
    } else {
      newFilters.add(tipo);
    }
    setFilters(newFilters);
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-medium flex items-center gap-2">
            <Clock className="h-4 w-4 text-primary" />
            Linha do tempo
          </CardTitle>
          <div className="flex items-center gap-1">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 px-2">
                  <Filter className="h-4 w-4" />
                  {filters.size > 0 && (
                    <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-xs">
                      {filters.size}
                    </Badge>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {Object.entries(ACTIVITY_CONFIG).map(([tipo, config]) => (
                  <DropdownMenuCheckboxItem
                    key={tipo}
                    checked={filters.has(tipo as ActivityType)}
                    onCheckedChange={() => toggleFilter(tipo as ActivityType)}
                  >
                    <config.icon className={`h-4 w-4 mr-2 ${config.color}`} />
                    {config.label}
                  </DropdownMenuCheckboxItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 px-2"
              onClick={() => setSortAsc(!sortAsc)}
            >
              <ArrowUpDown className="h-4 w-4" />
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="h-8 gap-1"
              onClick={() => setShowAddModal(true)}
            >
              <Plus className="h-3 w-3" />
              Interação
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : filteredActivities.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">Sem atividades registradas</p>
            <Button 
              variant="link" 
              size="sm" 
              className="mt-2"
              onClick={() => setShowAddModal(true)}
            >
              Adicionar primeira interação
            </Button>
          </div>
        ) : (
          <ScrollArea className="h-[300px] pr-4">
            <div className="relative pl-6 border-l-2 border-muted space-y-4">
              {filteredActivities.map((activity) => {
                const config = ACTIVITY_CONFIG[activity.tipo as ActivityType] || ACTIVITY_CONFIG.interacao;
                const Icon = config.icon;

                return (
                  <div key={activity.id} className="relative">
                    <div className={`absolute -left-[25px] p-1 rounded-full bg-background border-2 border-muted ${config.color}`}>
                      <Icon className="h-3 w-3" />
                    </div>
                    <div className="ml-2">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="font-medium text-sm">{activity.titulo}</span>
                        <Badge variant="outline" className="text-xs px-1.5 py-0">
                          {config.label}
                        </Badge>
                      </div>
                      {activity.descricao && (
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {activity.descricao}
                        </p>
                      )}
                      <p className="text-xs text-muted-foreground mt-1">
                        {format(new Date(activity.created_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        )}
      </CardContent>

      {/* Add Interaction Modal */}
      <Dialog open={showAddModal} onOpenChange={setShowAddModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Nova Interação</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="titulo">Título *</Label>
              <Input
                id="titulo"
                placeholder="Ex: Contato com seguradora"
                value={newInteraction.titulo}
                onChange={(e) => setNewInteraction(prev => ({ ...prev, titulo: e.target.value }))}
                maxLength={100}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="descricao">Descrição</Label>
              <Textarea
                id="descricao"
                placeholder="Detalhes da interação..."
                value={newInteraction.descricao}
                onChange={(e) => setNewInteraction(prev => ({ ...prev, descricao: e.target.value }))}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddModal(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleAddInteraction}
              disabled={!newInteraction.titulo.trim() || createActivity.isPending}
            >
              {createActivity.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Adicionar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
