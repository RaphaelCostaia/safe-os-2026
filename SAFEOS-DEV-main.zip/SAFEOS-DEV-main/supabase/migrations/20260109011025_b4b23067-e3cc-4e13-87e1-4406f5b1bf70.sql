-- Table for sinistro activity timeline (audit log)
CREATE TABLE public.sinistro_activities (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    sinistro_id UUID NOT NULL REFERENCES public.sinistros(id) ON DELETE CASCADE,
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    tipo TEXT NOT NULL, -- 'criacao', 'status', 'criticidade', 'responsavel', 'documento', 'valor', 'encerramento', 'interacao'
    titulo TEXT NOT NULL,
    descricao TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Table for sinistro notes
CREATE TABLE public.sinistro_notes (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    sinistro_id UUID NOT NULL REFERENCES public.sinistros(id) ON DELETE CASCADE,
    autor_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    conteudo TEXT NOT NULL,
    tags TEXT[] DEFAULT '{}',
    is_private BOOLEAN DEFAULT false,
    is_pinned BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Table for tips (structure ready for future persistence)
CREATE TABLE public.sinistro_tips (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    titulo TEXT NOT NULL,
    conteudo TEXT NOT NULL,
    categoria TEXT, -- produto category like 'RCP', 'Vida', 'DIT'
    link_interno TEXT,
    ativo BOOLEAN DEFAULT true,
    ordem INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.sinistro_activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sinistro_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sinistro_tips ENABLE ROW LEVEL SECURITY;

-- RLS Policies for sinistro_activities
CREATE POLICY "Authenticated users can view sinistro activities"
ON public.sinistro_activities FOR SELECT
USING (true);

CREATE POLICY "Authenticated users can insert sinistro activities"
ON public.sinistro_activities FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL);

-- RLS Policies for sinistro_notes
CREATE POLICY "Authenticated users can view sinistro notes"
ON public.sinistro_notes FOR SELECT
USING (auth.uid() IS NOT NULL AND (is_private = false OR autor_id = auth.uid()));

CREATE POLICY "Authenticated users can insert sinistro notes"
ON public.sinistro_notes FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL AND autor_id = auth.uid());

CREATE POLICY "Users can update their own notes"
ON public.sinistro_notes FOR UPDATE
USING (auth.uid() = autor_id);

CREATE POLICY "Admins can delete notes"
ON public.sinistro_notes FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role) OR auth.uid() = autor_id);

-- RLS Policies for sinistro_tips
CREATE POLICY "Everyone can view active tips"
ON public.sinistro_tips FOR SELECT
USING (ativo = true);

CREATE POLICY "Admins can manage tips"
ON public.sinistro_tips FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Indexes for performance
CREATE INDEX idx_sinistro_activities_sinistro_id ON public.sinistro_activities(sinistro_id);
CREATE INDEX idx_sinistro_activities_created_at ON public.sinistro_activities(created_at DESC);
CREATE INDEX idx_sinistro_notes_sinistro_id ON public.sinistro_notes(sinistro_id);
CREATE INDEX idx_sinistro_tips_categoria ON public.sinistro_tips(categoria);

-- Trigger for updated_at on notes
CREATE TRIGGER update_sinistro_notes_updated_at
BEFORE UPDATE ON public.sinistro_notes
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Trigger for updated_at on tips
CREATE TRIGGER update_sinistro_tips_updated_at
BEFORE UPDATE ON public.sinistro_tips
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert some default tips
INSERT INTO public.sinistro_tips (titulo, conteudo, categoria, ordem) VALUES
('Documentação inicial', 'Sempre solicite o B.O. e fotos do sinistro nas primeiras 24h', NULL, 1),
('Prazo seguradora', 'A seguradora tem até 30 dias para análise após documentação completa', NULL, 2),
('Contato com cliente', 'Mantenha o cliente informado a cada 7 dias sobre o andamento', NULL, 3),
('RCP - Laudo obrigatório', 'Para sinistros de RC Profissional, exija laudo técnico detalhado', 'RCP', 1),
('Vida - Certidão de óbito', 'Sinistros de vida requerem certidão de óbito original', 'Vida', 1),
('Auto - Orçamentos', 'Solicite 3 orçamentos de oficinas credenciadas', 'Auto', 1);