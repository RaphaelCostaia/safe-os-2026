-- Create table for policy documents
CREATE TABLE public.apolice_documents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  apolice_id UUID NOT NULL REFERENCES public.apolices(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  tipo TEXT NOT NULL,
  url TEXT NOT NULL,
  tamanho INTEGER,
  uploaded_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.apolice_documents ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Authenticated users can view apolice documents"
  ON public.apolice_documents FOR SELECT TO authenticated USING (true);

CREATE POLICY "Authenticated users can upload apolice documents"
  ON public.apolice_documents FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Admins can delete apolice documents"
  ON public.apolice_documents FOR DELETE TO authenticated
  USING (has_role(auth.uid(), 'admin'));

-- Create storage bucket for policy documents
INSERT INTO storage.buckets (id, name, public) 
VALUES ('apolice-documents', 'apolice-documents', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies
CREATE POLICY "Authenticated users can view apolice documents storage"
  ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'apolice-documents');

CREATE POLICY "Authenticated users can upload apolice documents storage"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'apolice-documents');

CREATE POLICY "Admins can delete apolice documents storage"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'apolice-documents' AND has_role(auth.uid(), 'admin'));