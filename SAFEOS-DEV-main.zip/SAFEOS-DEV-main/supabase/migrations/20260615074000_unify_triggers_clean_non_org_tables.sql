-- Migration: Unify Triggers and Cleanup Non-Org Tables to prevent "record NEW has no field organization_id" errors

-- 1. DROP OLD TRIGGERS EXPLICITLY ON TABLES WITHOUT ORGANIZATION_ID TO PREVENT ANY RUNTIME CRASHES
DROP TRIGGER IF EXISTS tr_set_org_apolice_documents ON public.apolice_documents;
DROP TRIGGER IF EXISTS tr_set_org_sinistro_documents ON public.sinistro_documents;
DROP TRIGGER IF EXISTS tr_set_org_sinistro_activities ON public.sinistro_activities;
DROP TRIGGER IF EXISTS tr_set_org_sinistro_notes ON public.sinistro_notes;
DROP TRIGGER IF EXISTS tr_set_org_sinistro_tips ON public.sinistro_tips;
DROP TRIGGER IF EXISTS tr_set_org_user_notes ON public.user_notes;
DROP TRIGGER IF EXISTS tr_set_org_user_tips ON public.user_tips;
DROP TRIGGER IF EXISTS tr_set_org_comissoes ON public.comissoes;

-- 2. DYNAMICALLY REMOVE TR_SET_ORG FROM ANY TABLE THAT LACKS THE COLUMN organization_id
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN 
    SELECT 
      event_object_table AS table_name,
      trigger_name
    FROM information_schema.triggers
    WHERE trigger_schema = 'public'
      AND trigger_name LIKE 'tr_set_org_%'
  LOOP
    -- If the table does not have an 'organization_id' column, drop it
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns 
      WHERE table_schema = 'public' 
        AND table_name = r.table_name 
        AND column_name = 'organization_id'
    ) THEN
      EXECUTE format('DROP TRIGGER IF EXISTS %I ON public.%I CASCADE', r.trigger_name, r.table_name);
    END IF;
  END LOOP;
END $$;

-- 3. RE-DEFINE THE AUDIT LOG TRIGGER FUNCTION USING DYNAMIC FIELD RESOLUTION (SUPER SAFETY)
CREATE OR REPLACE FUNCTION public.fn_audit_log_trigger()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_org_id UUID;
  v_user_id UUID := auth.uid();
  v_record_id UUID;
  v_old_data JSONB := NULL;
  v_new_data JSONB := NULL;
BEGIN
  -- Determine correct organization context and data safely based on TG_OP using JSONB to avoid compiler or unassigned record exceptions
  v_org_id := NULL;
  BEGIN
    IF TG_OP = 'DELETE' THEN
      v_org_id := (to_jsonb(OLD) ->> 'organization_id')::uuid;
      v_old_data := to_jsonb(OLD);
      v_record_id := (to_jsonb(OLD) ->> 'id')::uuid;
    ELSIF TG_OP = 'UPDATE' THEN
      v_org_id := (to_jsonb(NEW) ->> 'organization_id')::uuid;
      v_old_data := to_jsonb(OLD);
      v_new_data := to_jsonb(NEW);
      v_record_id := (to_jsonb(NEW) ->> 'id')::uuid;
    ELSIF TG_OP = 'INSERT' THEN
      v_org_id := (to_jsonb(NEW) ->> 'organization_id')::uuid;
      v_new_data := to_jsonb(NEW);
      v_record_id := (to_jsonb(NEW) ->> 'id')::uuid;
    END IF;
  EXCEPTION WHEN others THEN
    v_org_id := NULL;
  END;

  -- Safe fallback to user's profile organization if not found in record
  IF v_org_id IS NULL AND v_user_id IS NOT NULL THEN
    BEGIN
      SELECT organization_id INTO v_org_id FROM public.profiles WHERE id = v_user_id LIMIT 1;
    EXCEPTION WHEN others THEN
      v_org_id := NULL;
    END;
  END IF;

  -- Ensure record ID is set fallback from TG_OP if JSONB extraction yielded NULL
  IF v_record_id IS NULL THEN
    BEGIN
      IF TG_OP = 'DELETE' THEN
        v_record_id := (to_jsonb(OLD) ->> 'id')::uuid;
      ELSE
        v_record_id := (to_jsonb(NEW) ->> 'id')::uuid;
      END IF;
    EXCEPTION WHEN others THEN
      v_record_id := NULL;
    END;
  END IF;

  -- Wrap in insulated exception handler to ensure auditing never blocks business transactions
  BEGIN
    INSERT INTO public.audit_logs (
      organization_id,
      user_id,
      action,
      table_name,
      record_id,
      old_data,
      new_data
    ) VALUES (
      COALESCE(v_org_id, public.get_my_org_id()),
      v_user_id,
      TG_OP,
      TG_TABLE_NAME,
      v_record_id,
      v_old_data,
      v_new_data
    );
  EXCEPTION WHEN others THEN
    -- Completely insulated
    NULL;
  END;

  IF (TG_OP = 'DELETE') THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;

-- 4. RE-DEFINE THE ORGANIZATION ID SETTER FUNCTION (SAFELY EXCLUDES NON-ORG TABLES)
CREATE OR REPLACE FUNCTION public.fn_set_organization_id()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_org_id UUID;
  v_email TEXT;
  v_is_master BOOLEAN := false;
  v_has_org BOOLEAN := false;
BEGIN
  -- Check if organization_id exists in the trigger's table to prevent compiler/assignment exceptions
  SELECT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = TG_TABLE_SCHEMA AND table_name = TG_TABLE_NAME AND column_name = 'organization_id'
  ) INTO v_has_org;

  -- If table has no organization_id column, bypass organization check and return NEW
  IF NOT v_has_org THEN
    RETURN NEW;
  END IF;

  -- Otherwise, proceed with setting the organization_id safely
  v_user_org_id := public.get_my_org_id();

  v_email := LOWER(auth.jwt() ->> 'email');
  IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
    v_is_master := true;
  END IF;

  IF NOT v_is_master AND auth.uid() IS NOT NULL THEN
    SELECT LOWER(email) INTO v_email FROM auth.users WHERE id = auth.uid() LIMIT 1;
    IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
      v_is_master := true;
    END IF;
  END IF;

  IF NEW.organization_id IS NOT NULL THEN
    -- If user has admin authority, respect their requested organization_id input
    IF v_is_master OR public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'admin'::app_role) THEN
      NULL;
    ELSE
      -- Force common users' records into their actual tenant organization
      IF v_user_org_id IS NOT NULL THEN
        NEW.organization_id := v_user_org_id;
      END IF;
    END IF;
  ELSE
    -- If organization_id is NULL, automatically resolve tenant
    IF v_user_org_id IS NOT NULL THEN
      NEW.organization_id := v_user_org_id;
    ELSE
      -- Resolves default fallbacks safely
      BEGIN
        SELECT id INTO NEW.organization_id FROM public.organizations WHERE slug = 'organizacao-padrao' LIMIT 1;
      EXCEPTION WHEN others THEN
        NEW.organization_id := NULL;
      END;
      IF NEW.organization_id IS NULL THEN
        BEGIN
          SELECT id INTO NEW.organization_id FROM public.organizations ORDER BY created_at ASC LIMIT 1;
          EXCEPTION WHEN others THEN
            NEW.organization_id := NULL;
        END;
      END IF;
    END IF;
  END IF;

  -- Prevent standard tenant switching on updates
  IF (TG_OP = 'UPDATE') THEN
    IF (OLD.organization_id IS DISTINCT FROM NEW.organization_id) AND 
       NOT (v_is_master OR public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'admin'::app_role)) THEN
      NEW.organization_id := OLD.organization_id;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;
