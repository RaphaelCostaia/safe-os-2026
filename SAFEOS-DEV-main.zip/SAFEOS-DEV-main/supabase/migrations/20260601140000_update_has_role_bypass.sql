-- Redefine has_role to support master emails bypass, preventing RLS block on master users.
-- This is a critical security fix ensuring the absolute admin/owner bypass for the designated master developers.

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email TEXT;
  v_is_master BOOLEAN := false;
BEGIN
  -- 1. Checks if it's the master user via subquery against auth.users
  IF _user_id IS NOT NULL THEN
    SELECT LOWER(email) INTO v_email FROM auth.users WHERE id = _user_id LIMIT 1;
    IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
      v_is_master := true;
    END IF;
  END IF;

  -- 2. Master users bypass all role restrictions (treated as having any role requested)
  IF v_is_master THEN
    RETURN true;
  END IF;

  -- 3. Default check against user_roles table for normal users
  RETURN EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  );
END;
$$;
