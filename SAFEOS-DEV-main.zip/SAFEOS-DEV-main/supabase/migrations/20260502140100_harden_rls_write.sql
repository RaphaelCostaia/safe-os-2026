-- HARDEN RLS FOR ALL SENSITIVE TABLES
-- Ensuring that even if Frontend fails, the DB protects the data.

-- =====================================================
-- 1. CLIENTS
-- =====================================================
DROP POLICY IF EXISTS "Authenticated users can insert clients" ON public.clients;
CREATE POLICY "Role based clients insert"
  ON public.clients FOR INSERT TO authenticated
  WITH CHECK (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role) OR
    has_role(auth.uid(), 'administrativo'::app_role) OR
    (has_role(auth.uid(), 'vendedor'::app_role) AND (responsavel_id IS NULL OR responsavel_id = auth.uid()))
  );

DROP POLICY IF EXISTS "Authenticated users can update clients" ON public.clients;
CREATE POLICY "Role based clients update"
  ON public.clients FOR UPDATE TO authenticated
  USING (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role) OR
    has_role(auth.uid(), 'administrativo'::app_role) OR
    (has_role(auth.uid(), 'vendedor'::app_role) AND responsavel_id = auth.uid())
  );

-- =====================================================
-- 2. APOLICES
-- =====================================================
DROP POLICY IF EXISTS "Authenticated users can insert apolices" ON public.apolices;
CREATE POLICY "Role based apolices insert"
  ON public.apolices FOR INSERT TO authenticated
  WITH CHECK (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role) OR
    has_role(auth.uid(), 'administrativo'::app_role) OR
    (
      has_role(auth.uid(), 'vendedor'::app_role) AND
      EXISTS (
        SELECT 1 FROM public.clients c 
        WHERE c.id = apolices.client_id AND c.responsavel_id = auth.uid()
      )
    )
  );

DROP POLICY IF EXISTS "Authenticated users can update apolices" ON public.apolices;
CREATE POLICY "Role based apolices update"
  ON public.apolices FOR UPDATE TO authenticated
  USING (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role) OR
    has_role(auth.uid(), 'administrativo'::app_role) OR
    (
      has_role(auth.uid(), 'vendedor'::app_role) AND
      EXISTS (
        SELECT 1 FROM public.clients c 
        WHERE c.id = apolices.client_id AND c.responsavel_id = auth.uid()
      )
    )
  );

-- =====================================================
-- 3. RENOVACOES
-- =====================================================
DROP POLICY IF EXISTS "Authenticated users can insert renovacoes" ON public.renovacoes;
CREATE POLICY "Role based renovacoes insert"
  ON public.renovacoes FOR INSERT TO authenticated
  WITH CHECK (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role) OR
    has_role(auth.uid(), 'administrativo'::app_role) OR
    (
      has_role(auth.uid(), 'vendedor'::app_role) AND
      EXISTS (
        SELECT 1 FROM public.apolices a 
        JOIN public.clients c ON c.id = a.client_id
        WHERE a.id = renovacoes.apolice_id AND c.responsavel_id = auth.uid()
      )
    )
  );

DROP POLICY IF EXISTS "Authenticated users can update renovacoes" ON public.renovacoes;
CREATE POLICY "Role based renovacoes update"
  ON public.renovacoes FOR UPDATE TO authenticated
  USING (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role) OR
    has_role(auth.uid(), 'administrativo'::app_role) OR
    (
      has_role(auth.uid(), 'vendedor'::app_role) AND
      EXISTS (
        SELECT 1 FROM public.apolices a 
        JOIN public.clients c ON c.id = a.client_id
        WHERE a.id = renovacoes.apolice_id AND c.responsavel_id = auth.uid()
      )
    )
  );

-- =====================================================
-- 4. SINISTROS
-- =====================================================
DROP POLICY IF EXISTS "Authenticated users can insert sinistros" ON public.sinistros;
CREATE POLICY "Role based sinistros insert"
  ON public.sinistros FOR INSERT TO authenticated
  WITH CHECK (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role) OR
    has_role(auth.uid(), 'administrativo'::app_role) OR
    (
      has_role(auth.uid(), 'vendedor'::app_role) AND
      EXISTS (
        SELECT 1 FROM public.clients c 
        WHERE c.id = sinistros.client_id AND c.responsavel_id = auth.uid()
      )
    )
  );

DROP POLICY IF EXISTS "Authenticated users can update sinistros" ON public.sinistros;
CREATE POLICY "Role based sinistros update"
  ON public.sinistros FOR UPDATE TO authenticated
  USING (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role) OR
    has_role(auth.uid(), 'administrativo'::app_role) OR
    (
      has_role(auth.uid(), 'vendedor'::app_role) AND
      EXISTS (
        SELECT 1 FROM public.clients c 
        WHERE c.id = sinistros.client_id AND c.responsavel_id = auth.uid()
      )
    )
  );

-- =====================================================
-- 5. COMMISSION TERMS
-- =====================================================
DROP POLICY IF EXISTS "Role based commission_terms insert" ON public.client_commission_terms;
CREATE POLICY "Harden commission_terms insert"
  ON public.client_commission_terms FOR INSERT TO authenticated
  WITH CHECK (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role) OR
    has_role(auth.uid(), 'administrativo'::app_role)
    -- Vendedores NÃO podem inserir comissões livremente
  );

DROP POLICY IF EXISTS "Role based commission_terms update" ON public.client_commission_terms;
CREATE POLICY "Harden commission_terms update"
  ON public.client_commission_terms FOR UPDATE TO authenticated
  USING (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role) OR
    has_role(auth.uid(), 'administrativo'::app_role)
    -- Vendedores NÃO podem atualizar comissões
  );

-- =====================================================
-- 6. FINANCEIRO (CONTAS, CUSTOS, HISTORICO)
-- =====================================================
DROP POLICY IF EXISTS "Authenticated users can insert contas" ON public.contas;
CREATE POLICY "Harden contas insert"
  ON public.contas FOR INSERT TO authenticated
  WITH CHECK (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role) OR
    has_role(auth.uid(), 'administrativo'::app_role)
  );

DROP POLICY IF EXISTS "Authenticated users can update contas" ON public.contas;
CREATE POLICY "Harden contas update"
  ON public.contas FOR UPDATE TO authenticated
  USING (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role) OR
    has_role(auth.uid(), 'administrativo'::app_role)
  );

DROP POLICY IF EXISTS "Authenticated users can insert custos_fixos" ON public.custos_fixos;
CREATE POLICY "Harden custos_fixos insert"
  ON public.custos_fixos FOR INSERT TO authenticated
  WITH CHECK (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role)
  );

DROP POLICY IF EXISTS "Authenticated users can update custos_fixos" ON public.custos_fixos;
CREATE POLICY "Harden custos_fixos update"
  ON public.custos_fixos FOR UPDATE TO authenticated
  USING (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role)
  );

DROP POLICY IF EXISTS "Admins and gestores can insert financeiro_historico" ON public.financeiro_historico;
CREATE POLICY "Harden financeiro_historico insert"
  ON public.financeiro_historico FOR INSERT TO authenticated
  WITH CHECK (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role)
  );

DROP POLICY IF EXISTS "Admins and gestores can update financeiro_historico" ON public.financeiro_historico;
CREATE POLICY "Harden financeiro_historico update"
  ON public.financeiro_historico FOR UPDATE TO authenticated
  USING (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role)
  );
