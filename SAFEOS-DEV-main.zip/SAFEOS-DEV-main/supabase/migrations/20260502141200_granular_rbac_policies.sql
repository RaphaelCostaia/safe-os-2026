
-- REFINEMENT OF GRANULAR RBAC POLICIES (SUPABASE/POSTGRES)
-- This migration implements the exact role-based logic requested.

-- Helper function to check if user has ANY of the specified roles
CREATE OR REPLACE FUNCTION public.has_any_role(p_user_id UUID, p_roles app_role[])
RETURNS BOOLEAN AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = p_user_id AND role = ANY(p_roles)
  );
$$ LANGUAGE sql STABLE SECURITY DEFINER;

-- 1. CLIENTS POLICIES
DROP POLICY IF EXISTS "Clients isolation and role check" ON public.clients;
DROP POLICY IF EXISTS "Clients write access" ON public.clients;

-- Select Clients
CREATE POLICY "Clients granular select" ON public.clients
FOR SELECT USING (
  organization_id = public.get_my_org_id() AND (
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'gestor'::app_role, 'administrativo'::app_role, 'financeiro'::app_role, 'suporte'::app_role, 'leitura'::app_role]) OR
    (public.has_any_role(auth.uid(), ARRAY['vendedor'::app_role, 'corretor'::app_role]) AND responsavel_id = auth.uid())
  )
);

-- Insert/Update Clients
CREATE POLICY "Clients granular write" ON public.clients
FOR ALL TO authenticated
USING (
  organization_id = public.get_my_org_id() AND (
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'gestor'::app_role, 'administrativo'::app_role, 'suporte'::app_role]) OR
    (public.has_any_role(auth.uid(), ARRAY['vendedor'::app_role, 'corretor'::app_role]) AND (responsavel_id = auth.uid() OR responsavel_id IS NULL))
  )
)
WITH CHECK (organization_id = public.get_my_org_id());


-- 2. APOLICES POLICIES
DROP POLICY IF EXISTS "Org isolation apolices" ON public.apolices;

CREATE POLICY "Apolices granular select" ON public.apolices
FOR SELECT USING (
  organization_id = public.get_my_org_id() AND (
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'gestor'::app_role, 'administrativo'::app_role, 'financeiro'::app_role, 'leitura'::app_role, 'suporte'::app_role]) OR
    (public.has_any_role(auth.uid(), ARRAY['vendedor'::app_role, 'corretor'::app_role]) AND 
      EXISTS (SELECT 1 FROM public.clients c WHERE c.id = apolices.client_id AND c.responsavel_id = auth.uid())
    )
  )
);

CREATE POLICY "Apolices granular write" ON public.apolices
FOR ALL TO authenticated
USING (
  organization_id = public.get_my_org_id() AND 
  public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'gestor'::app_role, 'administrativo'::app_role])
);


-- 3. FINANCEIRO (CONTAS & COMISSÕES)
DROP POLICY IF EXISTS "Org isolation contas" ON public.contas;
DROP POLICY IF EXISTS "Org isolation client_commission_terms" ON public.client_commission_terms;

CREATE POLICY "Financeiro selective access" ON public.client_commission_terms
FOR ALL TO authenticated
USING (
  organization_id = public.get_my_org_id() AND 
  public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'financeiro'::app_role])
)
WITH CHECK (organization_id = public.get_my_org_id());

CREATE POLICY "Financeiro read-only for others" ON public.client_commission_terms
FOR SELECT USING (
  organization_id = public.get_my_org_id() AND 
  public.has_any_role(auth.uid(), ARRAY['gestor'::app_role, 'administrativo'::app_role])
);


-- 4. SINISTROS
DROP POLICY IF EXISTS "Org isolation sinistros" ON public.sinistros;

CREATE POLICY "Sinistros granular select" ON public.sinistros
FOR SELECT USING (
  organization_id = public.get_my_org_id() AND (
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'gestor'::app_role, 'administrativo'::app_role, 'suporte'::app_role, 'leitura'::app_role]) OR
    (public.has_any_role(auth.uid(), ARRAY['vendedor'::app_role, 'corretor'::app_role]) AND 
      EXISTS (SELECT 1 FROM public.clients c WHERE c.id = sinistros.client_id AND c.responsavel_id = auth.uid())
    )
  )
);

CREATE POLICY "Sinistros granular write" ON public.sinistros
FOR ALL TO authenticated
USING (
  organization_id = public.get_my_org_id() AND 
  public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'gestor'::app_role, 'administrativo'::app_role, 'suporte'::app_role])
);


-- 5. AUDIT LOGS (ADMIN ONLY)
DROP POLICY IF EXISTS "Only admins/owners view audit logs" ON public.audit_logs;
CREATE POLICY "Strict audit logs access" ON public.audit_logs
FOR SELECT USING (
  organization_id = public.get_my_org_id() AND 
  public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role])
);

-- Ensure all deletion is restricted to owner/admin
DO $$
DECLARE
  t TEXT;
BEGIN
  FOR t IN SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' 
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS "Delete only admin_owner %I" ON public.%I', t, t);
    EXECUTE format('CREATE POLICY "Delete only admin_owner %I" ON public.%I FOR DELETE USING (organization_id = public.get_my_org_id() AND public.has_any_role(auth.uid(), ARRAY[%L, %L]))', t, t, 'owner', 'admin');
  END LOOP;
END $$;
