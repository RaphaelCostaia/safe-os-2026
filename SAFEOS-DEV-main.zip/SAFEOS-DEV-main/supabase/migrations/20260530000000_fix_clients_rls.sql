-- Corrige as políticas de RLS para a tabela public.clients
-- Garante que vendedores/corretores possam selecionar e inserir clientes sem violações de RLS

DROP POLICY IF EXISTS "Clients granular select" ON public.clients;
DROP POLICY IF EXISTS "Clients granular write" ON public.clients;
DROP POLICY IF EXISTS "Clients select policy" ON public.clients;
DROP POLICY IF EXISTS "Clients insert policy" ON public.clients;
DROP POLICY IF EXISTS "Clients update policy" ON public.clients;
DROP POLICY IF EXISTS "Clients delete policy" ON public.clients;

-- 1. Política de Seleção (SELECT)
CREATE POLICY "Clients granular select" ON public.clients
FOR SELECT TO authenticated
USING (
  organization_id = public.get_my_org_id() AND (
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'gestor'::app_role, 'administrativo'::app_role, 'financeiro'::app_role, 'suporte'::app_role, 'leitura'::app_role]) OR
    (public.has_any_role(auth.uid(), ARRAY['vendedor'::app_role, 'corretor'::app_role]) AND (responsavel_id = auth.uid() OR responsavel_id IS NULL))
  )
);

-- 2. Política de Inserção (INSERT)
CREATE POLICY "Clients granular insert" ON public.clients
FOR INSERT TO authenticated
WITH CHECK (
  organization_id = public.get_my_org_id() AND (
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'gestor'::app_role, 'administrativo'::app_role, 'suporte'::app_role]) OR
    (public.has_any_role(auth.uid(), ARRAY['vendedor'::app_role, 'corretor'::app_role]) AND (responsavel_id = auth.uid() OR responsavel_id IS NULL))
  )
);

-- 3. Política de Atualização (UPDATE)
CREATE POLICY "Clients granular update" ON public.clients
FOR UPDATE TO authenticated
USING (
  organization_id = public.get_my_org_id() AND (
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'gestor'::app_role, 'administrativo'::app_role, 'suporte'::app_role]) OR
    (public.has_any_role(auth.uid(), ARRAY['vendedor'::app_role, 'corretor'::app_role]) AND (responsavel_id = auth.uid() OR responsavel_id IS NULL))
  )
)
WITH CHECK (
  organization_id = public.get_my_org_id() AND (
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'gestor'::app_role, 'administrativo'::app_role, 'suporte'::app_role]) OR
    (public.has_any_role(auth.uid(), ARRAY['vendedor'::app_role, 'corretor'::app_role]) AND (responsavel_id = auth.uid() OR responsavel_id IS NULL))
  )
);

-- 4. Política de Exclusão (DELETE)
CREATE POLICY "Clients granular delete" ON public.clients
FOR DELETE TO authenticated
USING (
  organization_id = public.get_my_org_id() AND (
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role])
  )
);
