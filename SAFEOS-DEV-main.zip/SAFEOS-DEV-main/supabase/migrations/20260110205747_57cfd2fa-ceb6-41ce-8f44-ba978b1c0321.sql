-- Drop existing RLS policies for team_members
DROP POLICY IF EXISTS "Admins and gestores can insert team members" ON public.team_members;
DROP POLICY IF EXISTS "Admins and gestores can update team members" ON public.team_members;
DROP POLICY IF EXISTS "Admins can delete team members" ON public.team_members;

-- Create more permissive policies that include 'administrativo' role
CREATE POLICY "Admins gestores and administrativo can insert team members"
  ON public.team_members FOR INSERT
  WITH CHECK (
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'gestor') OR 
    has_role(auth.uid(), 'administrativo')
  );

CREATE POLICY "Admins gestores and administrativo can update team members"
  ON public.team_members FOR UPDATE
  USING (
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'gestor') OR 
    has_role(auth.uid(), 'administrativo')
  );

CREATE POLICY "Admins gestores and administrativo can delete team members"
  ON public.team_members FOR DELETE
  USING (
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'gestor') OR 
    has_role(auth.uid(), 'administrativo')
  );