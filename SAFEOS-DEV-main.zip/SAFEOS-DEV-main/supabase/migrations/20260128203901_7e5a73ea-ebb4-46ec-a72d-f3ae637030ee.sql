-- SECURITY FIX: Restringir acesso às tabelas sensíveis por role
-- Corrigir vulnerabilidades identificadas no security scan

-- 1. APOLICES - Restringir para admin, gestor, administrativo e vendedor (apenas seus clientes)
DROP POLICY IF EXISTS "Authenticated users can view apolices" ON public.apolices;

CREATE POLICY "Role based apolices select"
ON public.apolices
FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::app_role) OR
  has_role(auth.uid(), 'gestor'::app_role) OR
  has_role(auth.uid(), 'administrativo'::app_role) OR
  (
    has_role(auth.uid(), 'vendedor'::app_role) AND
    EXISTS (
      SELECT 1 FROM public.clients c 
      WHERE c.id = apolices.client_id AND c.responsavel_id = auth.uid()
    )
  )
);

-- 2. CONTAS - Restringir para admin, gestor e administrativo apenas
DROP POLICY IF EXISTS "Authenticated users can view contas" ON public.contas;

CREATE POLICY "Role based contas select"
ON public.contas
FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::app_role) OR
  has_role(auth.uid(), 'gestor'::app_role) OR
  has_role(auth.uid(), 'administrativo'::app_role)
);

-- 3. CUSTOS_FIXOS - Restringir para admin e gestor apenas
DROP POLICY IF EXISTS "Authenticated users can view custos_fixos" ON public.custos_fixos;

CREATE POLICY "Role based custos_fixos select"
ON public.custos_fixos
FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::app_role) OR
  has_role(auth.uid(), 'gestor'::app_role)
);

-- 4. FINANCEIRO_HISTORICO - Restringir para admin e gestor apenas (já tem RLS, mas SELECT precisa de ajuste)
DROP POLICY IF EXISTS "Authenticated users can view financeiro_historico" ON public.financeiro_historico;

CREATE POLICY "Role based financeiro_historico select"
ON public.financeiro_historico
FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::app_role) OR
  has_role(auth.uid(), 'gestor'::app_role)
);

-- 5. CLIENT_COMMISSION_TERMS - Restringir para admin, gestor, e vendedor (apenas seus clientes)
DROP POLICY IF EXISTS "Authenticated users can view commission terms" ON public.client_commission_terms;

CREATE POLICY "Role based commission_terms select"
ON public.client_commission_terms
FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::app_role) OR
  has_role(auth.uid(), 'gestor'::app_role) OR
  has_role(auth.uid(), 'administrativo'::app_role) OR
  (
    has_role(auth.uid(), 'vendedor'::app_role) AND
    EXISTS (
      SELECT 1 FROM public.clients c 
      WHERE c.id = client_commission_terms.client_id AND c.responsavel_id = auth.uid()
    )
  )
);

-- 6. RENOVACOES - Restringir para admin, gestor, administrativo e vendedor (apenas suas apólices)
DROP POLICY IF EXISTS "Authenticated users can view renovacoes" ON public.renovacoes;

CREATE POLICY "Role based renovacoes select"
ON public.renovacoes
FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::app_role) OR
  has_role(auth.uid(), 'gestor'::app_role) OR
  has_role(auth.uid(), 'administrativo'::app_role) OR
  (
    has_role(auth.uid(), 'vendedor'::app_role) AND
    EXISTS (
      SELECT 1 FROM public.apolices a 
      JOIN public.clients c ON c.id = a.client_id
      WHERE a.id = renovacoes.apolice_id AND c.responsavel_id = auth.uid()
    )
  )
);

-- 7. SINISTROS - Restringir para admin, gestor, administrativo e vendedor (apenas seus clientes)
DROP POLICY IF EXISTS "Authenticated users can view sinistros" ON public.sinistros;

CREATE POLICY "Role based sinistros select"
ON public.sinistros
FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::app_role) OR
  has_role(auth.uid(), 'gestor'::app_role) OR
  has_role(auth.uid(), 'administrativo'::app_role) OR
  (
    has_role(auth.uid(), 'vendedor'::app_role) AND
    EXISTS (
      SELECT 1 FROM public.clients c 
      WHERE c.id = sinistros.client_id AND c.responsavel_id = auth.uid()
    )
  )
);

-- 8. CLIENT_DOCUMENTS - Restringir para admin, gestor, administrativo e vendedor (apenas seus clientes)
DROP POLICY IF EXISTS "Authenticated users can view documents" ON public.client_documents;

CREATE POLICY "Role based client_documents select"
ON public.client_documents
FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::app_role) OR
  has_role(auth.uid(), 'gestor'::app_role) OR
  has_role(auth.uid(), 'administrativo'::app_role) OR
  (
    has_role(auth.uid(), 'vendedor'::app_role) AND
    EXISTS (
      SELECT 1 FROM public.clients c 
      WHERE c.id = client_documents.client_id AND c.responsavel_id = auth.uid()
    )
  )
);

-- 9. APOLICE_DOCUMENTS - Restringir para admin, gestor, administrativo e vendedor (apenas suas apólices)
DROP POLICY IF EXISTS "Authenticated users can view apolice documents" ON public.apolice_documents;

CREATE POLICY "Role based apolice_documents select"
ON public.apolice_documents
FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::app_role) OR
  has_role(auth.uid(), 'gestor'::app_role) OR
  has_role(auth.uid(), 'administrativo'::app_role) OR
  (
    has_role(auth.uid(), 'vendedor'::app_role) AND
    EXISTS (
      SELECT 1 FROM public.apolices a
      JOIN public.clients c ON c.id = a.client_id
      WHERE a.id = apolice_documents.apolice_id AND c.responsavel_id = auth.uid()
    )
  )
);

-- 10. SINISTRO_DOCUMENTS - Restringir para admin, gestor, administrativo e vendedor (apenas seus sinistros)
DROP POLICY IF EXISTS "Authenticated users can view sinistro documents" ON public.sinistro_documents;

CREATE POLICY "Role based sinistro_documents select"
ON public.sinistro_documents
FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::app_role) OR
  has_role(auth.uid(), 'gestor'::app_role) OR
  has_role(auth.uid(), 'administrativo'::app_role) OR
  (
    has_role(auth.uid(), 'vendedor'::app_role) AND
    EXISTS (
      SELECT 1 FROM public.clients c 
      WHERE c.id = sinistro_documents.client_id AND c.responsavel_id = auth.uid()
    )
  )
);

-- 11. CLIENT_NOTES - Restringir para admin, gestor, administrativo e vendedor (apenas seus clientes)
DROP POLICY IF EXISTS "Authenticated users can view notes" ON public.client_notes;

CREATE POLICY "Role based client_notes select"
ON public.client_notes
FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::app_role) OR
  has_role(auth.uid(), 'gestor'::app_role) OR
  has_role(auth.uid(), 'administrativo'::app_role) OR
  (
    has_role(auth.uid(), 'vendedor'::app_role) AND
    EXISTS (
      SELECT 1 FROM public.clients c 
      WHERE c.id = client_notes.client_id AND c.responsavel_id = auth.uid()
    )
  )
);

-- 12. SINISTRO_ACTIVITIES - Restringir para admin, gestor, administrativo e vendedor (apenas seus sinistros)
DROP POLICY IF EXISTS "Authenticated users can view sinistro activities" ON public.sinistro_activities;

CREATE POLICY "Role based sinistro_activities select"
ON public.sinistro_activities
FOR SELECT
USING (
  has_role(auth.uid(), 'admin'::app_role) OR
  has_role(auth.uid(), 'gestor'::app_role) OR
  has_role(auth.uid(), 'administrativo'::app_role) OR
  (
    has_role(auth.uid(), 'vendedor'::app_role) AND
    EXISTS (
      SELECT 1 FROM public.sinistros s
      JOIN public.clients c ON c.id = s.client_id
      WHERE s.id = sinistro_activities.sinistro_id AND c.responsavel_id = auth.uid()
    )
  )
);