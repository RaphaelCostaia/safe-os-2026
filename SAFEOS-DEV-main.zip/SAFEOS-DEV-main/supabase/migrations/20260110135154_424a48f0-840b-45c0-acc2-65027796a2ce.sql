-- Add audit fields to client_commission_terms for history tracking
ALTER TABLE public.client_commission_terms
ADD COLUMN IF NOT EXISTS ends_at date DEFAULT NULL,
ADD COLUMN IF NOT EXISTS created_by uuid DEFAULT NULL REFERENCES auth.users(id);

-- Add comment for documentation
COMMENT ON COLUMN public.client_commission_terms.ends_at IS 'Data de encerramento do termo (null = ainda ativo)';
COMMENT ON COLUMN public.client_commission_terms.created_by IS 'Usuário que criou/alterou o termo';

-- Create index for history queries
CREATE INDEX IF NOT EXISTS idx_commission_terms_history 
ON public.client_commission_terms(client_id, created_at DESC);