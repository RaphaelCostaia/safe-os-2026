-- Reset total do SafeOS - Limpar todos os dados para estado inicial
-- ORDEM IMPORTA: Deletar primeiro as tabelas com chaves estrangeiras

-- Documentos e atividades de sinistros
DELETE FROM sinistro_documents;
DELETE FROM sinistro_activities;
DELETE FROM sinistro_notes;

-- Sinistros (dependem de apolices e clients)
DELETE FROM sinistros;

-- Documentos de apólices
DELETE FROM apolice_documents;

-- Renovações (dependem de apolices)
DELETE FROM renovacoes;

-- Apólices (dependem de clients e produtos)
DELETE FROM apolices;

-- Documentos e notas de clientes
DELETE FROM client_documents;
DELETE FROM client_notes;
DELETE FROM client_commission_terms;

-- Clientes
DELETE FROM clients;

-- Financeiro
DELETE FROM contas;
DELETE FROM custos_fixos;
DELETE FROM financeiro_historico;

-- Produtos
DELETE FROM produtos;

-- Tarefas e notas do usuário
DELETE FROM tasks;
DELETE FROM user_notes;
DELETE FROM user_tips;

-- Activity log (manter estrutura, limpar dados)
DELETE FROM activity_log;

-- Sinistro tips (são configurações, não dados)
-- DELETE FROM sinistro_tips; -- Comentado pois são configurações do sistema

-- NÃO deletar:
-- profiles (são de usuários reais)
-- team_members (são de usuários reais)
-- user_roles (são permissões de usuários reais)