
-- 1. Create enum for user roles
CREATE TYPE public.app_role AS ENUM ('admin', 'gestor', 'vendedor', 'administrativo');

-- 2. Create profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  phone TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- 3. Create user_roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- 4. Security definer function for role checking
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- 5. Create clients table
CREATE TABLE public.clients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  nome TEXT NOT NULL,
  email TEXT,
  telefone TEXT,
  cpf_cnpj TEXT UNIQUE,
  tipo_pessoa TEXT NOT NULL DEFAULT 'fisica' CHECK (tipo_pessoa IN ('fisica', 'juridica')),
  endereco TEXT,
  cidade TEXT,
  estado TEXT,
  cep TEXT,
  data_nascimento DATE,
  profissao TEXT,
  observacoes TEXT,
  status TEXT NOT NULL DEFAULT 'ativo' CHECK (status IN ('ativo', 'inativo', 'prospecto')),
  responsavel_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;

-- 6. Create produtos (insurance products) table
CREATE TABLE public.produtos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  codigo TEXT UNIQUE NOT NULL,
  nome TEXT NOT NULL,
  descricao TEXT,
  seguradora TEXT NOT NULL,
  categoria TEXT NOT NULL,
  comissao_percentual DECIMAL(5,2) DEFAULT 0,
  ativo BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.produtos ENABLE ROW LEVEL SECURITY;

-- 7. Create apolices (policies) table
CREATE TABLE public.apolices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  numero_apolice TEXT UNIQUE NOT NULL,
  client_id UUID REFERENCES public.clients(id) ON DELETE CASCADE NOT NULL,
  produto_id UUID REFERENCES public.produtos(id) ON DELETE RESTRICT NOT NULL,
  seguradora TEXT NOT NULL,
  valor_premio DECIMAL(12,2) NOT NULL,
  valor_cobertura DECIMAL(12,2),
  data_inicio DATE NOT NULL,
  data_fim DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'ativa' CHECK (status IN ('ativa', 'cancelada', 'expirada', 'pendente', 'em_renovacao')),
  forma_pagamento TEXT,
  parcelas INTEGER DEFAULT 1,
  responsavel_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.apolices ENABLE ROW LEVEL SECURITY;

-- 8. Create sinistros (claims) table
CREATE TABLE public.sinistros (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  numero_sinistro TEXT UNIQUE NOT NULL,
  apolice_id UUID REFERENCES public.apolices(id) ON DELETE CASCADE NOT NULL,
  client_id UUID REFERENCES public.clients(id) ON DELETE CASCADE NOT NULL,
  data_ocorrencia DATE NOT NULL,
  data_aviso DATE NOT NULL DEFAULT CURRENT_DATE,
  descricao_resumida TEXT NOT NULL,
  descricao_detalhada TEXT,
  status TEXT NOT NULL DEFAULT 'aberto' CHECK (status IN ('aberto', 'em_analise', 'documentacao_pendente', 'aprovado', 'negado', 'pago', 'fechado')),
  criticidade TEXT NOT NULL DEFAULT 'media' CHECK (criticidade IN ('baixa', 'media', 'alta', 'critica')),
  valor_estimado DECIMAL(12,2),
  valor_aprovado DECIMAL(12,2),
  valor_pago DECIMAL(12,2),
  responsavel_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  protocolo_seguradora TEXT,
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.sinistros ENABLE ROW LEVEL SECURITY;

-- 9. Create renovacoes (renewals) table
CREATE TABLE public.renovacoes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  apolice_id UUID REFERENCES public.apolices(id) ON DELETE CASCADE NOT NULL,
  data_vencimento DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'pendente' CHECK (status IN ('pendente', 'em_negociacao', 'renovada', 'cancelada', 'perdida')),
  valor_anterior DECIMAL(12,2),
  valor_novo DECIMAL(12,2),
  responsavel_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  observacoes TEXT,
  data_contato DATE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.renovacoes ENABLE ROW LEVEL SECURITY;

-- 10. Create client_documents table
CREATE TABLE public.client_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID REFERENCES public.clients(id) ON DELETE CASCADE NOT NULL,
  nome TEXT NOT NULL,
  tipo TEXT NOT NULL,
  url TEXT NOT NULL,
  tamanho INTEGER,
  uploaded_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.client_documents ENABLE ROW LEVEL SECURITY;

-- 11. Create client_notes table
CREATE TABLE public.client_notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID REFERENCES public.clients(id) ON DELETE CASCADE NOT NULL,
  conteudo TEXT NOT NULL,
  autor_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.client_notes ENABLE ROW LEVEL SECURITY;

-- 12. Create activity_log table for timeline
CREATE TABLE public.activity_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_type TEXT NOT NULL,
  entity_id UUID NOT NULL,
  action TEXT NOT NULL,
  description TEXT,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  metadata JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.activity_log ENABLE ROW LEVEL SECURITY;

-- 13. Update timestamp function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- 14. Create triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_clients_updated_at BEFORE UPDATE ON public.clients FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_produtos_updated_at BEFORE UPDATE ON public.produtos FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_apolices_updated_at BEFORE UPDATE ON public.apolices FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_sinistros_updated_at BEFORE UPDATE ON public.sinistros FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_renovacoes_updated_at BEFORE UPDATE ON public.renovacoes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_client_notes_updated_at BEFORE UPDATE ON public.client_notes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 15. Function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.raw_user_meta_data ->> 'name', 'Usuário')
  );
  
  -- Assign default role based on signup metadata or 'vendedor' as default
  INSERT INTO public.user_roles (user_id, role)
  VALUES (
    NEW.id,
    COALESCE((NEW.raw_user_meta_data ->> 'role')::app_role, 'vendedor')
  );
  
  RETURN NEW;
END;
$$;

-- 16. Trigger for auto profile creation
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 17. RLS Policies for profiles
CREATE POLICY "Users can view their own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update their own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Admins can view all profiles" ON public.profiles FOR SELECT USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Gestores can view all profiles" ON public.profiles FOR SELECT USING (public.has_role(auth.uid(), 'gestor'));

-- 18. RLS Policies for user_roles
CREATE POLICY "Users can view their own roles" ON public.user_roles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Admins can manage all roles" ON public.user_roles FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- 19. RLS Policies for clients (all authenticated users can access)
CREATE POLICY "Authenticated users can view clients" ON public.clients FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert clients" ON public.clients FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update clients" ON public.clients FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Admins can delete clients" ON public.clients FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- 20. RLS Policies for produtos
CREATE POLICY "Everyone can view active produtos" ON public.produtos FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage produtos" ON public.produtos FOR ALL USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Gestores can manage produtos" ON public.produtos FOR ALL USING (public.has_role(auth.uid(), 'gestor'));

-- 21. RLS Policies for apolices
CREATE POLICY "Authenticated users can view apolices" ON public.apolices FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert apolices" ON public.apolices FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update apolices" ON public.apolices FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Admins can delete apolices" ON public.apolices FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- 22. RLS Policies for sinistros
CREATE POLICY "Authenticated users can view sinistros" ON public.sinistros FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert sinistros" ON public.sinistros FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update sinistros" ON public.sinistros FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Admins can delete sinistros" ON public.sinistros FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- 23. RLS Policies for renovacoes
CREATE POLICY "Authenticated users can view renovacoes" ON public.renovacoes FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert renovacoes" ON public.renovacoes FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update renovacoes" ON public.renovacoes FOR UPDATE TO authenticated USING (true);
CREATE POLICY "Admins can delete renovacoes" ON public.renovacoes FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- 24. RLS Policies for client_documents
CREATE POLICY "Authenticated users can view documents" ON public.client_documents FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can upload documents" ON public.client_documents FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Admins can delete documents" ON public.client_documents FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- 25. RLS Policies for client_notes
CREATE POLICY "Authenticated users can view notes" ON public.client_notes FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can create notes" ON public.client_notes FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Users can update their own notes" ON public.client_notes FOR UPDATE USING (auth.uid() = autor_id);
CREATE POLICY "Admins can delete notes" ON public.client_notes FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- 26. RLS Policies for activity_log
CREATE POLICY "Authenticated users can view activity" ON public.activity_log FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can log activity" ON public.activity_log FOR INSERT TO authenticated WITH CHECK (true);

-- 27. Create indexes for better performance
CREATE INDEX idx_clients_responsavel ON public.clients(responsavel_id);
CREATE INDEX idx_clients_status ON public.clients(status);
CREATE INDEX idx_apolices_client ON public.apolices(client_id);
CREATE INDEX idx_apolices_status ON public.apolices(status);
CREATE INDEX idx_apolices_data_fim ON public.apolices(data_fim);
CREATE INDEX idx_sinistros_apolice ON public.sinistros(apolice_id);
CREATE INDEX idx_sinistros_client ON public.sinistros(client_id);
CREATE INDEX idx_sinistros_status ON public.sinistros(status);
CREATE INDEX idx_renovacoes_apolice ON public.renovacoes(apolice_id);
CREATE INDEX idx_renovacoes_data_vencimento ON public.renovacoes(data_vencimento);
CREATE INDEX idx_activity_log_entity ON public.activity_log(entity_type, entity_id);
