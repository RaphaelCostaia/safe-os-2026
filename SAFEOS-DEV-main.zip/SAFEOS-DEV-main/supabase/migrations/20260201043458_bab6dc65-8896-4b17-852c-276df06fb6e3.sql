-- =============================================
-- PARTE A: Corrigir RLS para tabela produtos
-- Problema: policies restritivas causando conflito
-- =============================================

-- 1. Remover todas as policies existentes (conflitantes)
DROP POLICY IF EXISTS "Admins can manage produtos" ON public.produtos;
DROP POLICY IF EXISTS "Authenticated users can insert produtos" ON public.produtos;
DROP POLICY IF EXISTS "Authenticated users can update produtos" ON public.produtos;
DROP POLICY IF EXISTS "Authenticated users can view active produtos" ON public.produtos;
DROP POLICY IF EXISTS "Gestores can manage produtos" ON public.produtos;

-- 2. Criar novas policies PERMISSIVAS e corretas

-- SELECT: Qualquer usuário autenticado pode ver produtos ativos
-- Admin e Gestor podem ver todos (incluindo inativos)
CREATE POLICY "produtos_select_active"
  ON public.produtos FOR SELECT
  USING (
    (auth.uid() IS NOT NULL AND ativo = true) OR
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role)
  );

-- INSERT: Apenas admin e gestor podem criar produtos
CREATE POLICY "produtos_insert_admin_gestor"
  ON public.produtos FOR INSERT
  WITH CHECK (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role)
  );

-- UPDATE: Apenas admin e gestor podem atualizar produtos
CREATE POLICY "produtos_update_admin_gestor"
  ON public.produtos FOR UPDATE
  USING (
    has_role(auth.uid(), 'admin'::app_role) OR
    has_role(auth.uid(), 'gestor'::app_role)
  );

-- DELETE: Apenas admin pode excluir produtos
CREATE POLICY "produtos_delete_admin"
  ON public.produtos FOR DELETE
  USING (has_role(auth.uid(), 'admin'::app_role));