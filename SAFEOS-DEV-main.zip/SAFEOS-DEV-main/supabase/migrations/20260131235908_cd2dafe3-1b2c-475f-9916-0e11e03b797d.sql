-- =====================================================
-- SOFT DELETE: Add deleted_at / deleted_by columns
-- =====================================================

-- 1. clients
ALTER TABLE public.clients
  ADD COLUMN IF NOT EXISTS deleted_at timestamptz DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS deleted_by uuid DEFAULT NULL;

-- 2. apolices
ALTER TABLE public.apolices
  ADD COLUMN IF NOT EXISTS deleted_at timestamptz DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS deleted_by uuid DEFAULT NULL;

-- 3. sinistros
ALTER TABLE public.sinistros
  ADD COLUMN IF NOT EXISTS deleted_at timestamptz DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS deleted_by uuid DEFAULT NULL;

-- 4. Helper function to check if soft delete is allowed (admin or gestor)
CREATE OR REPLACE FUNCTION public.can_soft_delete(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role IN ('admin', 'gestor')
  )
$$;

-- =====================================================
-- RLS: Adjust UPDATE policies to allow soft delete for admin + gestor
-- =====================================================

-- Drop existing update policies (they are too permissive)
DROP POLICY IF EXISTS "Authenticated users can update clients" ON public.clients;
DROP POLICY IF EXISTS "Authenticated users can update apolices" ON public.apolices;
DROP POLICY IF EXISTS "Authenticated users can update sinistros" ON public.sinistros;

-- Create new update policies for clients
CREATE POLICY "Authenticated users can update clients"
ON public.clients
FOR UPDATE
USING (auth.uid() IS NOT NULL);

-- Create new update policies for apolices
CREATE POLICY "Authenticated users can update apolices"
ON public.apolices
FOR UPDATE
USING (auth.uid() IS NOT NULL);

-- Create new update policies for sinistros
CREATE POLICY "Authenticated users can update sinistros"
ON public.sinistros
FOR UPDATE
USING (auth.uid() IS NOT NULL);

-- NOTE: The business rule (only admin/gestor can archive) is enforced
-- at the application level via can_soft_delete() function checks.