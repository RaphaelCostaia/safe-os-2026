-- Recria de forma extremamente robusta a função de atribuição de tenancy
-- e as políticas de RLS para a tabela public.clients evitando divergências de validação.

CREATE OR REPLACE FUNCTION public.fn_set_organization_id()
RETURNS TRIGGER AS $$
BEGIN
  -- Se organization_id for nulo, buscamos robustamente baseado na função de apoio
  -- que encapsula JWT, profiles, user_roles e o fallback padrão.
  IF NEW.organization_id IS NULL THEN
    NEW.organization_id := public.get_my_org_id();
  END IF;
  
  -- Garantia absoluta de fallback se por algum motivo ainda persistir nulo
  IF NEW.organization_id IS NULL THEN
    NEW.organization_id := (SELECT id FROM public.organizations WHERE slug = 'organizacao-padrao' LIMIT 1);
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Remove as políticas anteriores para evitar duplicações/conflitos
DROP POLICY IF EXISTS "Clients granular select" ON public.clients;
DROP POLICY IF EXISTS "Clients granular insert" ON public.clients;
DROP POLICY IF EXISTS "Clients granular update" ON public.clients;
DROP POLICY IF EXISTS "Clients granular delete" ON public.clients;

-- 1. Política de Seleção (SELECT)
CREATE POLICY "Clients granular select" ON public.clients
FOR SELECT TO authenticated
USING (
  (organization_id = public.get_my_org_id() OR organization_id IS NULL) AND (
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'gestor'::app_role, 'administrativo'::app_role, 'financeiro'::app_role, 'suporte'::app_role, 'leitura'::app_role]) OR
    (public.has_any_role(auth.uid(), ARRAY['vendedor'::app_role, 'corretor'::app_role]) AND (responsavel_id = auth.uid() OR responsavel_id IS NULL))
  )
);

-- 2. Política de Inserção (INSERT)
CREATE POLICY "Clients granular insert" ON public.clients
FOR INSERT TO authenticated
WITH CHECK (
  -- Desenvolvedores master e administradores possuem bypass completo para facilitar criação
  public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]) OR
  (
    -- Permite se a org for compatível, ou se for nula (o trigger preencherá adequadamente no BEFORE INSERT)
    (organization_id = public.get_my_org_id() OR organization_id IS NULL) AND (
      public.has_any_role(auth.uid(), ARRAY['gestor'::app_role, 'administrativo'::app_role, 'suporte'::app_role]) OR
      (public.has_any_role(auth.uid(), ARRAY['vendedor'::app_role, 'corretor'::app_role]) AND (responsavel_id = auth.uid() OR responsavel_id IS NULL))
    )
  )
);

-- 3. Política de Atualização (UPDATE)
CREATE POLICY "Clients granular update" ON public.clients
FOR UPDATE TO authenticated
USING (
  (organization_id = public.get_my_org_id() OR organization_id IS NULL) AND (
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'gestor'::app_role, 'administrativo'::app_role, 'suporte'::app_role]) OR
    (public.has_any_role(auth.uid(), ARRAY['vendedor'::app_role, 'corretor'::app_role]) AND (responsavel_id = auth.uid() OR responsavel_id IS NULL))
  )
)
WITH CHECK (
  public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role]) OR
  (
    (organization_id = public.get_my_org_id() OR organization_id IS NULL) AND (
      public.has_any_role(auth.uid(), ARRAY['gestor'::app_role, 'administrativo'::app_role, 'suporte'::app_role]) OR
      (public.has_any_role(auth.uid(), ARRAY['vendedor'::app_role, 'corretor'::app_role]) AND (responsavel_id = auth.uid() OR responsavel_id IS NULL))
    )
  )
);

-- 4. Política de Exclusão (DELETE)
CREATE POLICY "Clients granular delete" ON public.clients
FOR DELETE TO authenticated
USING (
  (organization_id = public.get_my_org_id() OR organization_id IS NULL) AND (
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role])
  )
);
