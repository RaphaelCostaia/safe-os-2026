-- Fix foreign key for responsavel_id to enable PostgREST joins to profiles
ALTER TABLE public.clients 
  DROP CONSTRAINT IF EXISTS clients_responsavel_id_fkey;

ALTER TABLE public.clients
  ADD CONSTRAINT clients_responsavel_id_fkey 
  FOREIGN KEY (responsavel_id) 
  REFERENCES public.profiles(id) 
  ON DELETE SET NULL;

-- Ensure indexes are present
CREATE INDEX IF NOT EXISTS idx_clients_responsavel_v2 ON public.clients(responsavel_id);
