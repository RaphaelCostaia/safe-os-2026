-- Migration: Create marketing_campaigns table and RLS policies
CREATE TABLE IF NOT EXISTS public.marketing_campaigns (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  nome TEXT NOT NULL,
  spend NUMERIC NOT NULL DEFAULT 0,
  leads INTEGER NOT NULL DEFAULT 0,
  conversions INTEGER NOT NULL DEFAULT 0,
  revenue NUMERIC NOT NULL DEFAULT 0,
  categoria TEXT NOT NULL DEFAULT 'Geral',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.marketing_campaigns ENABLE ROW LEVEL SECURITY;

-- Check if policies exist, and create them
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'marketing_campaigns' AND policyname = 'Authenticated users can view marketing_campaigns'
  ) THEN
    CREATE POLICY "Authenticated users can view marketing_campaigns"
    ON public.marketing_campaigns FOR SELECT
    USING (auth.uid() IS NOT NULL);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'marketing_campaigns' AND policyname = 'Authenticated users can insert marketing_campaigns'
  ) THEN
    CREATE POLICY "Authenticated users can insert marketing_campaigns"
    ON public.marketing_campaigns FOR INSERT
    WITH CHECK (auth.uid() IS NOT NULL);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'marketing_campaigns' AND policyname = 'Authenticated users can update marketing_campaigns'
  ) THEN
    CREATE POLICY "Authenticated users can update marketing_campaigns"
    ON public.marketing_campaigns FOR UPDATE
    USING (auth.uid() IS NOT NULL);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'marketing_campaigns' AND policyname = 'Authenticated users can delete marketing_campaigns'
  ) THEN
    CREATE POLICY "Authenticated users can delete marketing_campaigns"
    ON public.marketing_campaigns FOR DELETE
    USING (auth.uid() IS NOT NULL);
  END IF;
END
$$;

-- Trigger to automatically update updated_at
CREATE OR REPLACE TRIGGER update_marketing_campaigns_updated_at
BEFORE UPDATE ON public.marketing_campaigns
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
