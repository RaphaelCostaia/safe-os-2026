-- First, update existing data to use canonical status values if needed
-- (currently only 'aberto' exists which is valid)

-- Drop the old constraint
ALTER TABLE public.sinistros DROP CONSTRAINT IF EXISTS sinistros_status_check;

-- Add the new constraint with canonical status values matching the front-end
ALTER TABLE public.sinistros 
ADD CONSTRAINT sinistros_status_check 
CHECK (status = ANY (ARRAY[
  'aberto'::text, 
  'em_andamento'::text, 
  'aguardando_cliente'::text, 
  'aguardando_seguradora'::text, 
  'encerrado'::text, 
  'arquivado'::text
]));