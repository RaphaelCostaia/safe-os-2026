-- Create table for client commission terms
CREATE TABLE public.client_commission_terms (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
    model TEXT NOT NULL CHECK (model IN ('percentual', 'fixo', 'misto')),
    percent NUMERIC,
    fixed_amount NUMERIC,
    starts_at DATE,
    notes TEXT,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    
    -- Validate that the appropriate field is set based on model
    CONSTRAINT check_model_values CHECK (
        (model = 'percentual' AND percent IS NOT NULL AND percent > 0) OR
        (model = 'fixo' AND fixed_amount IS NOT NULL AND fixed_amount > 0) OR
        (model = 'misto' AND percent IS NOT NULL AND percent > 0 AND fixed_amount IS NOT NULL AND fixed_amount > 0)
    )
);

-- Enable Row Level Security
ALTER TABLE public.client_commission_terms ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Authenticated users can view commission terms"
ON public.client_commission_terms
FOR SELECT
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can insert commission terms"
ON public.client_commission_terms
FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update commission terms"
ON public.client_commission_terms
FOR UPDATE
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admins can delete commission terms"
ON public.client_commission_terms
FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_client_commission_terms_updated_at
BEFORE UPDATE ON public.client_commission_terms
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create index for faster lookups
CREATE INDEX idx_client_commission_terms_client_id ON public.client_commission_terms(client_id);
CREATE INDEX idx_client_commission_terms_active ON public.client_commission_terms(client_id, is_active) WHERE is_active = true;