-- Corrige as políticas da tabela public.clients para evitar erros de RLS no fluxo de criação e edição de clientes.
-- Permite que qualquer usuário autenticado gerencie os clientes de seu próprio tenant (SaaS Isolation), eliminando quebras por trocas de corretores ou falta de papéis.
-- O trigger tr_set_org_clients garante que a organização correta (get_my_org_id) seja automaticamente atribuída caso seja enviada como nula.

DROP POLICY IF EXISTS "Clients granular insert" ON public.clients;
DROP POLICY IF EXISTS "Clients granular update" ON public.clients;
DROP POLICY IF EXISTS "Clients granular select" ON public.clients;

-- 1. Política de Inserção Simplificada e Resiliente
CREATE POLICY "Clients granular insert" ON public.clients
FOR INSERT TO authenticated
WITH CHECK (
  (organization_id = public.get_my_org_id() OR organization_id IS NULL)
);

-- 2. Política de Atualização Simplificada e Resiliente
CREATE POLICY "Clients granular update" ON public.clients
FOR UPDATE TO authenticated
USING (
  (organization_id = public.get_my_org_id() OR organization_id IS NULL)
)
WITH CHECK (
  (organization_id = public.get_my_org_id() OR organization_id IS NULL)
);

-- 3. Política de Seleção Simplificada e Resiliente
CREATE POLICY "Clients granular select" ON public.clients
FOR SELECT TO authenticated
USING (
  (organization_id = public.get_my_org_id() OR organization_id IS NULL)
);

