-- =====================================================
-- SECURITY HARDENING - Phase 3: Document access controls
-- =====================================================

-- 1. Restrict sinistro_documents UPDATE to only owner or admin/gestor
DROP POLICY IF EXISTS "Authenticated users can update sinistro documents" ON public.sinistro_documents;

CREATE POLICY "Role based sinistro_documents update" 
ON public.sinistro_documents 
FOR UPDATE 
USING (
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'gestor'::app_role) OR 
  uploaded_by = auth.uid()
);