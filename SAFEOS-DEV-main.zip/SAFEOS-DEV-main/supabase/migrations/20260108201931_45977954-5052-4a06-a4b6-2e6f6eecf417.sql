-- Allow admins and gestores to insert new profiles
CREATE POLICY "Admins and gestores can insert profiles"
ON public.profiles
FOR INSERT
WITH CHECK (
  has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'gestor'::app_role)
);