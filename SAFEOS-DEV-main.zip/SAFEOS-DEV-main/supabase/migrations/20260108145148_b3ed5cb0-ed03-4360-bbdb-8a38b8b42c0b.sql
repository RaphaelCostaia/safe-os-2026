-- Reforçar segurança RLS com políticas baseadas em roles

-- =====================================================
-- CLIENTS - Apenas gestores e admins podem excluir
-- =====================================================

-- Atualizar política de INSERT para incluir uploaded_by
DROP POLICY IF EXISTS "Authenticated users can insert clients" ON public.clients;
CREATE POLICY "Authenticated users can insert clients"
  ON public.clients FOR INSERT TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

-- Atualizar política de UPDATE para ser mais restritiva
DROP POLICY IF EXISTS "Authenticated users can update clients" ON public.clients;
CREATE POLICY "Authenticated users can update clients"
  ON public.clients FOR UPDATE TO authenticated
  USING (auth.uid() IS NOT NULL);

-- =====================================================
-- APOLICES - Reforçar políticas
-- =====================================================

DROP POLICY IF EXISTS "Authenticated users can insert apolices" ON public.apolices;
CREATE POLICY "Authenticated users can insert apolices"
  ON public.apolices FOR INSERT TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Authenticated users can update apolices" ON public.apolices;
CREATE POLICY "Authenticated users can update apolices"
  ON public.apolices FOR UPDATE TO authenticated
  USING (auth.uid() IS NOT NULL);

-- =====================================================
-- SINISTROS - Reforçar políticas
-- =====================================================

DROP POLICY IF EXISTS "Authenticated users can insert sinistros" ON public.sinistros;
CREATE POLICY "Authenticated users can insert sinistros"
  ON public.sinistros FOR INSERT TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Authenticated users can update sinistros" ON public.sinistros;
CREATE POLICY "Authenticated users can update sinistros"
  ON public.sinistros FOR UPDATE TO authenticated
  USING (auth.uid() IS NOT NULL);

-- =====================================================
-- RENOVACOES - Reforçar políticas
-- =====================================================

DROP POLICY IF EXISTS "Authenticated users can insert renovacoes" ON public.renovacoes;
CREATE POLICY "Authenticated users can insert renovacoes"
  ON public.renovacoes FOR INSERT TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Authenticated users can update renovacoes" ON public.renovacoes;
CREATE POLICY "Authenticated users can update renovacoes"
  ON public.renovacoes FOR UPDATE TO authenticated
  USING (auth.uid() IS NOT NULL);

-- =====================================================
-- CLIENT_DOCUMENTS - Reforçar políticas
-- =====================================================

DROP POLICY IF EXISTS "Authenticated users can upload documents" ON public.client_documents;
CREATE POLICY "Authenticated users can upload documents"
  ON public.client_documents FOR INSERT TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL AND uploaded_by = auth.uid());

-- =====================================================
-- APOLICE_DOCUMENTS - Reforçar políticas
-- =====================================================

DROP POLICY IF EXISTS "Authenticated users can upload apolice documents" ON public.apolice_documents;
CREATE POLICY "Authenticated users can upload apolice documents"
  ON public.apolice_documents FOR INSERT TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL AND uploaded_by = auth.uid());

-- =====================================================
-- CLIENT_NOTES - Reforçar políticas
-- =====================================================

DROP POLICY IF EXISTS "Authenticated users can create notes" ON public.client_notes;
CREATE POLICY "Authenticated users can create notes"
  ON public.client_notes FOR INSERT TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL AND autor_id = auth.uid());

-- =====================================================
-- ACTIVITY_LOG - Reforçar políticas
-- =====================================================

DROP POLICY IF EXISTS "Authenticated users can log activity" ON public.activity_log;
CREATE POLICY "Authenticated users can log activity"
  ON public.activity_log FOR INSERT TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL AND user_id = auth.uid());

-- =====================================================
-- PRODUTOS - Reforçar políticas
-- =====================================================

DROP POLICY IF EXISTS "Authenticated users can insert produtos" ON public.produtos;
CREATE POLICY "Authenticated users can insert produtos"
  ON public.produtos FOR INSERT TO authenticated
  WITH CHECK (
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'gestor')
  );

DROP POLICY IF EXISTS "Authenticated users can update produtos" ON public.produtos;
CREATE POLICY "Authenticated users can update produtos"
  ON public.produtos FOR UPDATE TO authenticated
  USING (
    has_role(auth.uid(), 'admin') OR 
    has_role(auth.uid(), 'gestor')
  );