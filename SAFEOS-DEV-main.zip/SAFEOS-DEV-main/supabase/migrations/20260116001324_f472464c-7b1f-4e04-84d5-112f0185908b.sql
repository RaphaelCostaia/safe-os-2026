-- Correção de segurança: Restringir acesso às tabelas profiles e clients

-- 1. PROFILES TABLE - Remover políticas permissivas e criar políticas restritivas

-- Remover políticas existentes que são muito permissivas
DROP POLICY IF EXISTS "Administrativo can view all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Gestores can view all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Role based profiles select" ON public.profiles;
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;

-- Nova política única e segura para SELECT em profiles
-- Usuário pode ver seu próprio perfil OU admins/gestores podem ver todos
CREATE POLICY "Secure profiles select" 
ON public.profiles 
FOR SELECT 
USING (
  auth.uid() = id 
  OR has_role(auth.uid(), 'admin'::app_role) 
  OR has_role(auth.uid(), 'gestor'::app_role)
);

-- 2. CLIENTS TABLE - Restringir acesso baseado em roles

-- Remover política permissiva atual
DROP POLICY IF EXISTS "Authenticated users can view clients" ON public.clients;

-- Criar política restritiva para SELECT em clients
-- Admins e Gestores podem ver todos os clientes
-- Vendedores só veem clientes onde são responsáveis
-- Administrativo pode ver todos (necessário para operações)
CREATE POLICY "Role based clients select" 
ON public.clients 
FOR SELECT 
USING (
  has_role(auth.uid(), 'admin'::app_role) 
  OR has_role(auth.uid(), 'gestor'::app_role)
  OR has_role(auth.uid(), 'administrativo'::app_role)
  OR (has_role(auth.uid(), 'vendedor'::app_role) AND responsavel_id = auth.uid())
);