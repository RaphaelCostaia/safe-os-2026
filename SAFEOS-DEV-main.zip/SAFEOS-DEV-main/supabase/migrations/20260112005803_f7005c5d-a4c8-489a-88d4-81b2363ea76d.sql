-- =============================================
-- FASE 1: CORREÇÕES DE SEGURANÇA CRÍTICAS
-- =============================================

-- 1.1 Restringir acesso à tabela team_members
-- Remover policy atual muito permissiva
DROP POLICY IF EXISTS "Authenticated users can view team members" ON public.team_members;

-- Nova policy: Admins/gestores/administrativo veem todos, vendedores veem apenas ativos
CREATE POLICY "Role based team_members select" ON public.team_members
FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::app_role) OR 
  public.has_role(auth.uid(), 'gestor'::app_role) OR 
  public.has_role(auth.uid(), 'administrativo'::app_role) OR
  (is_active = true) -- Vendedores veem apenas membros ativos
);

-- 1.2 Restringir acesso à tabela activity_log
-- Remover policies atuais
DROP POLICY IF EXISTS "Authenticated users can view activity" ON public.activity_log;
DROP POLICY IF EXISTS "Activity log viewable by authenticated users" ON public.activity_log;

-- Nova policy: Admins/gestores veem tudo, outros veem apenas próprias ações
CREATE POLICY "Role based activity_log select" ON public.activity_log
FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::app_role) OR 
  public.has_role(auth.uid(), 'gestor'::app_role) OR
  user_id = auth.uid()
);

-- 1.3 Atualizar policy de profiles para admins/gestores
-- Remover policy atual se existir
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Profiles are viewable by users who created them" ON public.profiles;

-- Nova policy: Admins/gestores veem todos, outros veem apenas próprio
CREATE POLICY "Role based profiles select" ON public.profiles
FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::app_role) OR 
  public.has_role(auth.uid(), 'gestor'::app_role) OR
  id = auth.uid()
);