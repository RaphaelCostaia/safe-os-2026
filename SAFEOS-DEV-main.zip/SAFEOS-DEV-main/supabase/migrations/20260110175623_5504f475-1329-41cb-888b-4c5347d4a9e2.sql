-- =============================================
-- PARTE 1: Criar tabela TASKS (Tarefas do usuário)
-- =============================================
CREATE TABLE public.tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  titulo TEXT NOT NULL,
  descricao TEXT,
  prioridade TEXT NOT NULL DEFAULT 'media',
  prazo DATE,
  status TEXT NOT NULL DEFAULT 'pendente',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  
  CONSTRAINT tasks_prioridade_check CHECK (prioridade IN ('baixa', 'media', 'alta', 'critica')),
  CONSTRAINT tasks_status_check CHECK (status IN ('pendente', 'concluida', 'cancelada'))
);

-- Comentários
COMMENT ON TABLE public.tasks IS 'Tarefas pessoais do usuário para o painel Ações do Dia';
COMMENT ON COLUMN public.tasks.prioridade IS 'baixa, media, alta, critica';
COMMENT ON COLUMN public.tasks.status IS 'pendente, concluida, cancelada';

-- Índices
CREATE INDEX idx_tasks_user_id ON public.tasks(user_id);
CREATE INDEX idx_tasks_status ON public.tasks(status);
CREATE INDEX idx_tasks_prazo ON public.tasks(prazo);

-- RLS
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own tasks"
ON public.tasks FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own tasks"
ON public.tasks FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own tasks"
ON public.tasks FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own tasks"
ON public.tasks FOR DELETE
USING (auth.uid() = user_id);

-- Trigger para updated_at
CREATE TRIGGER update_tasks_updated_at
BEFORE UPDATE ON public.tasks
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- =============================================
-- PARTE 2: Criar tabela USER_NOTES (Anotações pessoais)
-- =============================================
CREATE TABLE public.user_notes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  conteudo TEXT NOT NULL,
  tags TEXT[] DEFAULT '{}',
  visibilidade TEXT NOT NULL DEFAULT 'pessoal',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  
  CONSTRAINT user_notes_visibilidade_check CHECK (visibilidade IN ('pessoal', 'equipe'))
);

-- Comentários
COMMENT ON TABLE public.user_notes IS 'Anotações pessoais do usuário para o painel Ações do Dia';
COMMENT ON COLUMN public.user_notes.visibilidade IS 'pessoal (só o usuário vê), equipe (todos veem)';

-- Índices
CREATE INDEX idx_user_notes_user_id ON public.user_notes(user_id);
CREATE INDEX idx_user_notes_created_at ON public.user_notes(created_at DESC);

-- RLS
ALTER TABLE public.user_notes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own notes"
ON public.user_notes FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can view team notes"
ON public.user_notes FOR SELECT
USING (visibilidade = 'equipe');

CREATE POLICY "Users can insert own notes"
ON public.user_notes FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own notes"
ON public.user_notes FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own notes"
ON public.user_notes FOR DELETE
USING (auth.uid() = user_id);

-- Trigger para updated_at
CREATE TRIGGER update_user_notes_updated_at
BEFORE UPDATE ON public.user_notes
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- =============================================
-- PARTE 3: Criar tabela USER_TIPS (Tips pessoais e globais)
-- =============================================
CREATE TABLE public.user_tips (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  titulo TEXT NOT NULL,
  descricao TEXT,
  categoria TEXT,
  is_global BOOLEAN NOT NULL DEFAULT false,
  ativo BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Comentários
COMMENT ON TABLE public.user_tips IS 'Tips pessoais ou globais para o painel Ações do Dia';
COMMENT ON COLUMN public.user_tips.is_global IS 'Se true, visível para todos os usuários';
COMMENT ON COLUMN public.user_tips.categoria IS 'Processo, Venda, Renovação, Sinistro, etc.';

-- Índices
CREATE INDEX idx_user_tips_user_id ON public.user_tips(user_id);
CREATE INDEX idx_user_tips_is_global ON public.user_tips(is_global);
CREATE INDEX idx_user_tips_created_at ON public.user_tips(created_at DESC);

-- RLS
ALTER TABLE public.user_tips ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own tips"
ON public.user_tips FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can view global tips"
ON public.user_tips FOR SELECT
USING (is_global = true AND ativo = true);

CREATE POLICY "Users can insert own tips"
ON public.user_tips FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own tips"
ON public.user_tips FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own tips"
ON public.user_tips FOR DELETE
USING (auth.uid() = user_id);