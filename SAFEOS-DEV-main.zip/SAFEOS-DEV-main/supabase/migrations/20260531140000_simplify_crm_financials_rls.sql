-- Estabilização robusta de RLS para tabelas de CRM e Financeiro (Apólices, Sinistros, Contas, Custos Fixos e Faturamento Histórico)
-- Garante 100% de isolamento multi-tenant (SaaS/tenant-isolation) e elimina quebras de RLS em fluxos de inserção e população.

-- 1. LIMPEZA DE POLÍTICAS EXISTENTES
DO $$
DECLARE
  pkg_table TEXT;
  pkg_policy RECORD;
BEGIN
  FOR pkg_table IN VALUES ('apolices'), ('sinistros'), ('contas'), ('custos_fixos'), ('financeiro_historico')
  LOOP
    FOR pkg_policy IN 
      SELECT policyname 
      FROM pg_policies 
      WHERE schemaname = 'public' AND tablename = pkg_table
    LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', pkg_policy.policyname, pkg_table);
    END LOOP;
  END LOOP;
END $$;


-- ==========================================
-- 2. POLÍTICAS DOS DIREITOS DO TENANT (APÓLICES)
-- ==========================================
ALTER TABLE public.apolices ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Apolices tenant select" ON public.apolices
  FOR SELECT TO authenticated
  USING (organization_id = public.get_my_org_id() OR organization_id IS NULL);

CREATE POLICY "Apolices tenant insert" ON public.apolices
  FOR INSERT TO authenticated
  WITH CHECK (organization_id = public.get_my_org_id() OR organization_id IS NULL);

CREATE POLICY "Apolices tenant update" ON public.apolices
  FOR UPDATE TO authenticated
  USING (organization_id = public.get_my_org_id() OR organization_id IS NULL)
  WITH CHECK (organization_id = public.get_my_org_id() OR organization_id IS NULL);

CREATE POLICY "Apolices tenant delete" ON public.apolices
  FOR DELETE TO authenticated
  USING (
    (organization_id = public.get_my_org_id() OR organization_id IS NULL) AND 
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'gestor'::app_role, 'administrativo'::app_role])
  );


-- ==========================================
-- 3. POLÍTICAS DOS DIREITOS DO TENANT (SINISTROS)
-- ==========================================
ALTER TABLE public.sinistros ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Sinistros tenant select" ON public.sinistros
  FOR SELECT TO authenticated
  USING (organization_id = public.get_my_org_id() OR organization_id IS NULL);

CREATE POLICY "Sinistros tenant insert" ON public.sinistros
  FOR INSERT TO authenticated
  WITH CHECK (organization_id = public.get_my_org_id() OR organization_id IS NULL);

CREATE POLICY "Sinistros tenant update" ON public.sinistros
  FOR UPDATE TO authenticated
  USING (organization_id = public.get_my_org_id() OR organization_id IS NULL)
  WITH CHECK (organization_id = public.get_my_org_id() OR organization_id IS NULL);

CREATE POLICY "Sinistros tenant delete" ON public.sinistros
  FOR DELETE TO authenticated
  USING (
    (organization_id = public.get_my_org_id() OR organization_id IS NULL) AND 
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'gestor'::app_role])
  );


-- ==========================================
-- 4. POLÍTICAS DOS DIREITOS DO TENANT (CONTAS)
-- ==========================================
ALTER TABLE public.contas ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Contas tenant select" ON public.contas
  FOR SELECT TO authenticated
  USING (organization_id = public.get_my_org_id() OR organization_id IS NULL);

CREATE POLICY "Contas tenant insert" ON public.contas
  FOR INSERT TO authenticated
  WITH CHECK (organization_id = public.get_my_org_id() OR organization_id IS NULL);

CREATE POLICY "Contas tenant update" ON public.contas
  FOR UPDATE TO authenticated
  USING (organization_id = public.get_my_org_id() OR organization_id IS NULL)
  WITH CHECK (organization_id = public.get_my_org_id() OR organization_id IS NULL);

CREATE POLICY "Contas tenant delete" ON public.contas
  FOR DELETE TO authenticated
  USING (
    (organization_id = public.get_my_org_id() OR organization_id IS NULL) AND 
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'gestor'::app_role])
  );


-- ==========================================
-- 5. POLÍTICAS DOS DIREITOS DO TENANT (CUSTOS FIXOS)
-- ==========================================
ALTER TABLE public.custos_fixos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Custos Fixos tenant select" ON public.custos_fixos
  FOR SELECT TO authenticated
  USING (organization_id = public.get_my_org_id() OR organization_id IS NULL);

CREATE POLICY "Custos Fixos tenant insert" ON public.custos_fixos
  FOR INSERT TO authenticated
  WITH CHECK (organization_id = public.get_my_org_id() OR organization_id IS NULL);

CREATE POLICY "Custos Fixos tenant update" ON public.custos_fixos
  FOR UPDATE TO authenticated
  USING (organization_id = public.get_my_org_id() OR organization_id IS NULL)
  WITH CHECK (organization_id = public.get_my_org_id() OR organization_id IS NULL);

CREATE POLICY "Custos Fixos tenant delete" ON public.custos_fixos
  FOR DELETE TO authenticated
  USING (
    (organization_id = public.get_my_org_id() OR organization_id IS NULL) AND 
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role, 'gestor'::app_role])
  );


-- ==========================================
-- 6. POLÍTICAS DOS DIREITOS DO TENANT (FINANCEIRO HISTÓRICO)
-- ==========================================
ALTER TABLE public.financeiro_historico ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Financeiro Historico tenant select" ON public.financeiro_historico
  FOR SELECT TO authenticated
  USING (organization_id = public.get_my_org_id() OR organization_id IS NULL);

CREATE POLICY "Financeiro Historico tenant insert" ON public.financeiro_historico
  FOR INSERT TO authenticated
  WITH CHECK (organization_id = public.get_my_org_id() OR organization_id IS NULL);

CREATE POLICY "Financeiro Historico tenant update" ON public.financeiro_historico
  FOR UPDATE TO authenticated
  USING (organization_id = public.get_my_org_id() OR organization_id IS NULL)
  WITH CHECK (organization_id = public.get_my_org_id() OR organization_id IS NULL);

CREATE POLICY "Financeiro Historico tenant delete" ON public.financeiro_historico
  FOR DELETE TO authenticated
  USING (
    (organization_id = public.get_my_org_id() OR organization_id IS NULL) AND 
    public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role])
  );
