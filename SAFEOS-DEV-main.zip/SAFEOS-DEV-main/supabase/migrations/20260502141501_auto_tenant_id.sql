
-- AUTOMATIC ORGANIZATION_ID SETTER
-- Ensures that any insert by a user automatically gets their organization_id.

CREATE OR REPLACE FUNCTION public.fn_set_organization_id()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.organization_id IS NULL THEN
    NEW.organization_id := (SELECT organization_id FROM public.profiles WHERE id = auth.uid() LIMIT 1);
  END IF;
  
  -- Prevent changing organization_id on update unless admin/owner
  IF (TG_OP = 'UPDATE') THEN
    IF (OLD.organization_id IS DISTINCT FROM NEW.organization_id) AND 
       NOT (public.has_any_role(auth.uid(), ARRAY['owner'::app_role, 'admin'::app_role])) THEN
      RAISE EXCEPTION 'Não é permitido alterar a organização do registro.';
    END IF;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Apply to all sensitive tables
DO $$
DECLARE
  t TEXT;
BEGIN
  FOR t IN SELECT table_name 
           FROM information_schema.tables 
           WHERE table_schema = 'public' 
           AND table_name IN ('profiles', 'clients', 'apolices', 'sinistros', 'produtos', 'renovacoes', 'client_documents', 'client_notes', 'activity_log', 'contas', 'custos_fixos', 'financeiro_historico', 'client_commission_terms', 'user_roles')
  LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS tr_set_org_%I ON public.%I', t, t);
    EXECUTE format('CREATE TRIGGER tr_set_org_%I BEFORE INSERT OR UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.fn_set_organization_id()', t, t);
  END LOOP;
END $$;
