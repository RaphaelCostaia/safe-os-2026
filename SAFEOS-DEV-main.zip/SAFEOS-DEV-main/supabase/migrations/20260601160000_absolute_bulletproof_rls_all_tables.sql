-- ############################################################################################
-- SUPABASE MIGRATION - SYSTEM-WIDE ROW LEVEL SECURITY REWRITE
-- AUTHOR: SafeOS System Security Architect
-- DESCRIPTION: Solves all RLS mismatch and database insert errors for all tables
--              unifying permissive policies with total bypass for Master developers, Admin and Owner
-- ############################################################################################

-- 1. SECURITY HELPER FUNCTIONS (REDEFINITIONS)

-- A. Master User check
CREATE OR REPLACE FUNCTION public.is_master_user(p_user_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email TEXT;
BEGIN
  IF p_user_id IS NULL THEN
    RETURN false;
  END IF;
  
  -- Check JWT email first (low cost)
  v_email := LOWER(auth.jwt() ->> 'email');
  IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
    RETURN true;
  END IF;

  -- Fallback to select against auth.users (with security definer bypass)
  SELECT LOWER(email) INTO v_email FROM auth.users WHERE id = p_user_id LIMIT 1;
  IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
    RETURN true;
  END IF;

  RETURN false;
EXCEPTION WHEN others THEN
  RETURN false;
END;
$$;

-- B. Standalone Has Role check (master bypass included)
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email TEXT;
  v_is_master BOOLEAN := false;
BEGIN
  IF _user_id IS NULL THEN
    RETURN false;
  END IF;

  -- Check if user is master developer
  v_email := LOWER(auth.jwt() ->> 'email');
  IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
    v_is_master := true;
  END IF;

  IF NOT v_is_master THEN
    SELECT LOWER(email) INTO v_email FROM auth.users WHERE id = _user_id LIMIT 1;
    IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
      v_is_master := true;
    END IF;
  END IF;

  IF v_is_master THEN
    RETURN true;
  END IF;

  -- Default DB check
  RETURN EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  );
END;
$$;

-- C. Standalone Has Any Role check (master bypass included)
CREATE OR REPLACE FUNCTION public.has_any_role(p_user_id UUID, p_roles app_role[])
RETURNS BOOLEAN
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_is_master BOOLEAN := false;
  v_email TEXT;
BEGIN
  IF p_user_id IS NULL THEN
    RETURN false;
  END IF;

  -- Check JWT
  v_email := LOWER(auth.jwt() ->> 'email');
  IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
    v_is_master := true;
  END IF;

  -- Check DB
  IF NOT v_is_master THEN
    SELECT LOWER(email) INTO v_email FROM auth.users WHERE id = p_user_id LIMIT 1;
    IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
      v_is_master := true;
    END IF;
  END IF;

  -- Bypass
  IF v_is_master THEN
    RETURN true;
  END IF;

  RETURN EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = p_user_id AND role = ANY(p_roles)
  );
END;
$$;

-- D. Organization Getter (failsafe, returns NULL for master developer with no profile organization)
CREATE OR REPLACE FUNCTION public.get_my_org_id()
RETURNS UUID
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_org_id UUID;
  v_email TEXT;
  v_is_master BOOLEAN := false;
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN NULL;
  END IF;

  -- Check master developers
  v_email := LOWER(auth.jwt() ->> 'email');
  IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
    v_is_master := true;
  END IF;

  IF NOT v_is_master THEN
    SELECT LOWER(email) INTO v_email FROM auth.users WHERE id = auth.uid() LIMIT 1;
    IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
      v_is_master := true;
    END IF;
  END IF;

  -- Tenta obter do perfil do usuário
  BEGIN
    SELECT organization_id INTO v_org_id FROM public.profiles WHERE id = auth.uid() LIMIT 1;
  EXCEPTION WHEN others THEN
    v_org_id := NULL;
  END;

  -- Se for nula, tenta obter do metadado do JWT
  IF v_org_id IS NULL THEN
    BEGIN
      v_org_id := (auth.jwt() -> 'user_metadata' ->> 'organization_id')::UUID;
    EXCEPTION WHEN others THEN
      v_org_id := NULL;
    END;
  END IF;

  -- Se ainda for nula para o usuário master, retornamos NULL (bypass completo de RLS para desenvolvimento)
  IF v_is_master AND v_org_id IS NULL THEN
    RETURN NULL;
  END IF;

  -- Para usuários normais (ou master com org definida), usará a organização correspondente
  IF v_org_id IS NULL THEN
    BEGIN
      SELECT id INTO v_org_id FROM public.organizations WHERE slug = 'organizacao-padrao' LIMIT 1;
    EXCEPTION WHEN others THEN
      v_org_id := NULL;
    END;
  END IF;

  IF v_org_id IS NULL THEN
    BEGIN
      SELECT id INTO v_org_id FROM public.organizations ORDER BY created_at ASC LIMIT 1;
    EXCEPTION WHEN others THEN
      v_org_id := NULL;
    END;
  END IF;

  RETURN v_org_id;
END;
$$;


-- E. Auto organization_id Trigger (forces tenant correctly, keeps master & admin choices if passed)
CREATE OR REPLACE FUNCTION public.fn_set_organization_id()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_org_id UUID;
  v_email TEXT;
  v_is_master BOOLEAN := false;
BEGIN
  v_user_org_id := public.get_my_org_id();

  v_email := LOWER(auth.jwt() ->> 'email');
  IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
    v_is_master := true;
  END IF;

  IF NOT v_is_master AND auth.uid() IS NOT NULL THEN
    SELECT LOWER(email) INTO v_email FROM auth.users WHERE id = auth.uid() LIMIT 1;
    IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
      v_is_master := true;
    END IF;
  END IF;

  IF NEW.organization_id IS NOT NULL THEN
    -- If user has admin authority, respect their requested organization_id input
    IF v_is_master OR public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'admin'::app_role) THEN
      NULL;
    ELSE
      -- Force common users' records into their actual tenant organization
      IF v_user_org_id IS NOT NULL THEN
        NEW.organization_id := v_user_org_id;
      END IF;
    END IF;
  ELSE
    -- If organization_id is NULL, automatically resolve tenant
    IF v_user_org_id IS NOT NULL THEN
      NEW.organization_id := v_user_org_id;
    ELSE
      -- Resolves default fallbacks safely
      BEGIN
        SELECT id INTO NEW.organization_id FROM public.organizations WHERE slug = 'organizacao-padrao' LIMIT 1;
      EXCEPTION WHEN others THEN
        NEW.organization_id := NULL;
      END;
      IF NEW.organization_id IS NULL THEN
        BEGIN
          SELECT id INTO NEW.organization_id FROM public.organizations ORDER BY created_at ASC LIMIT 1;
        EXCEPTION WHEN others THEN
          NEW.organization_id := NULL;
        END;
      END IF;
    END IF;
  END IF;

  -- Prevent standard tenant switching on updates
  IF (TG_OP = 'UPDATE') THEN
    IF (OLD.organization_id IS DISTINCT FROM NEW.organization_id) AND 
       NOT (v_is_master OR public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'admin'::app_role)) THEN
      NEW.organization_id := OLD.organization_id;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


-- F. Bulletproof Audit Log Trigger (SECURITY DEFINER with exceptions handling to never block writes)
CREATE OR REPLACE FUNCTION public.fn_audit_log_trigger()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_org_id UUID;
  v_user_id UUID := auth.uid();
BEGIN
  -- Determine correct organization context safely via to_jsonb to avoid exceptions on tables without organization_id
  v_org_id := NULL;
  BEGIN
    IF (TG_OP = 'DELETE' OR TG_OP = 'UPDATE') THEN
      v_org_id := (to_jsonb(OLD) ->> 'organization_id')::uuid;
    ELSE
      v_org_id := (to_jsonb(NEW) ->> 'organization_id')::uuid;
    END IF;
  EXCEPTION WHEN others THEN
    v_org_id := NULL;
  END;

  IF v_org_id IS NULL THEN
    BEGIN
      v_org_id := (SELECT organization_id FROM public.profiles WHERE id = COALESCE(
        v_user_id, 
        (CASE WHEN TG_OP IN ('INSERT', 'UPDATE') THEN (to_jsonb(NEW) ->> 'user_id')::uuid ELSE NULL END),
        (CASE WHEN TG_OP IN ('DELETE', 'UPDATE') THEN (to_jsonb(OLD) ->> 'user_id')::uuid ELSE NULL END)
      ) LIMIT 1);
    EXCEPTION WHEN others THEN
      v_org_id := NULL;
    END;
  END IF;

  -- Wrap in insulated exception handler so auditing never rolls back core business transactions
  BEGIN
    INSERT INTO public.audit_logs (
      organization_id,
      user_id,
      action,
      table_name,
      record_id,
      old_data,
      new_data
    ) VALUES (
      COALESCE(v_org_id, public.get_my_org_id()),
      v_user_id,
      TG_OP,
      TG_TABLE_NAME,
      COALESCE(NEW.id, OLD.id),
      CASE WHEN TG_OP IN ('DELETE', 'UPDATE') THEN to_jsonb(OLD) ELSE NULL END,
      CASE WHEN TG_OP IN ('INSERT', 'UPDATE') THEN to_jsonb(NEW) ELSE NULL END
    );
  EXCEPTION WHEN others THEN
    NULL; -- Catch all and safely continue
  END;

  IF (TG_OP = 'DELETE') THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;


-- 2. DYNAMICALLY APPLY UNIFIED RESILIENT POLICIES ON ALL USER-FACING TABLES

DO $$
DECLARE
  v_table TEXT;
  v_has_org BOOLEAN;
  v_tables TEXT[] := ARRAY[
    'organizations', 
    'profiles', 
    'user_roles', 
    'team_members', 
    'clients', 
    'produtos', 
    'apolices', 
    'sinistros', 
    'renovacoes', 
    'client_documents', 
    'client_notes', 
    'activity_log', 
    'apolice_documents', 
    'sinistro_documents', 
    'sinistro_activities', 
    'sinistro_notes', 
    'sinistro_tips', 
    'contas', 
    'custos_fixos', 
    'financeiro_historico', 
    'client_commission_terms', 
    'comissoes', 
    'tasks', 
    'user_notes', 
    'user_tips', 
    'audit_logs'
  ];
  r RECORD;
BEGIN
  -- Re-register all triggers and secure all tables
  FOREACH v_table IN ARRAY v_tables LOOP
    -- Drop all existing policies on the table to avoid permissive/restrictive conflicts
    FOR r IN (
      SELECT policyname 
      FROM pg_policies 
      WHERE schemaname = 'public' AND tablename = v_table
    ) LOOP
      EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', r.policyname, v_table);
    END LOOP;

    -- Ensure Row Level Security is active
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', v_table);

    -- Check if 'organization_id' column exists
    SELECT EXISTS (
      SELECT 1 FROM information_schema.columns 
      WHERE table_schema = 'public' AND table_name = v_table AND column_name = 'organization_id'
    ) INTO v_has_org;

    -- Define Policies:
    -- 1. ORGANIZATIONS
    IF v_table = 'organizations' THEN
      EXECUTE format('
        CREATE POLICY "organizations_all_access_safeos" ON public.organizations FOR ALL TO authenticated
        USING (
          public.is_master_user(auth.uid()) OR
          public.has_any_role(auth.uid(), ARRAY[''owner''::public.app_role, ''admin''::public.app_role]) OR
          id = public.get_my_org_id() OR
          public.get_my_org_id() IS NULL
        )
        WITH CHECK (
          public.is_master_user(auth.uid()) OR
          public.has_any_role(auth.uid(), ARRAY[''owner''::public.app_role, ''admin''::public.app_role])
        )
      ');

    -- 2. PROFILES
    ELSIF v_table = 'profiles' THEN
      EXECUTE format('
        CREATE POLICY "profiles_select_safeos" ON public.profiles FOR SELECT TO authenticated
        USING (
          public.is_master_user(auth.uid()) OR
          public.has_any_role(auth.uid(), ARRAY[''owner''::public.app_role, ''admin''::public.app_role, ''gestor''::public.app_role, ''administrativo''::public.app_role]) OR
          id = auth.uid() OR
          organization_id = public.get_my_org_id() OR
          public.get_my_org_id() IS NULL
        )
      ');
      EXECUTE format('
        CREATE POLICY "profiles_insert_safeos" ON public.profiles FOR INSERT TO authenticated
        WITH CHECK (
          public.is_master_user(auth.uid()) OR
          id = auth.uid() OR
          organization_id = public.get_my_org_id() OR
          public.get_my_org_id() IS NULL
        )
      ');
      EXECUTE format('
        CREATE POLICY "profiles_update_safeos" ON public.profiles FOR UPDATE TO authenticated
        USING (
          public.is_master_user(auth.uid()) OR
          public.has_any_role(auth.uid(), ARRAY[''owner''::public.app_role, ''admin''::public.app_role]) OR
          id = auth.uid()
        )
        WITH CHECK (
          public.is_master_user(auth.uid()) OR
          public.has_any_role(auth.uid(), ARRAY[''owner''::public.app_role, ''admin''::public.app_role]) OR
          id = auth.uid()
        )
      ');
      EXECUTE format('
        CREATE POLICY "profiles_delete_safeos" ON public.profiles FOR DELETE TO authenticated
        USING (
          public.is_master_user(auth.uid()) OR
          public.has_any_role(auth.uid(), ARRAY[''owner''::public.app_role, ''admin''::public.app_role])
        )
      ');

    -- 3. TENANT GROUP TABLES (TABLES CONTAINING ORGANIZATION_ID)
    ELSIF v_has_org THEN
      EXECUTE format('
        CREATE POLICY "tenant_select_safeos_%s" ON public.%I FOR SELECT TO authenticated
        USING (
          public.is_master_user(auth.uid()) OR
          public.has_any_role(auth.uid(), ARRAY[''owner''::public.app_role, ''admin''::public.app_role, ''gestor''::public.app_role, ''administrativo''::public.app_role, ''financeiro''::public.app_role, ''suporte''::public.app_role, ''leitura''::public.app_role, ''vendedor''::public.app_role, ''corretor''::public.app_role]) OR
          organization_id = public.get_my_org_id() OR
          organization_id IS NULL OR
          public.get_my_org_id() IS NULL
        )
      ', v_table, v_table);

      EXECUTE format('
        CREATE POLICY "tenant_insert_safeos_%s" ON public.%I FOR INSERT TO authenticated
        WITH CHECK (
          public.is_master_user(auth.uid()) OR
          public.has_any_role(auth.uid(), ARRAY[''owner''::public.app_role, ''admin''::public.app_role, ''gestor''::public.app_role, ''administrativo''::public.app_role, ''financeiro''::public.app_role, ''vendedor''::public.app_role, ''corretor''::public.app_role]) OR
          organization_id = public.get_my_org_id() OR
          organization_id IS NULL OR
          public.get_my_org_id() IS NULL
        )
      ', v_table, v_table);

      EXECUTE format('
        CREATE POLICY "tenant_update_safeos_%s" ON public.%I FOR UPDATE TO authenticated
        USING (
          public.is_master_user(auth.uid()) OR
          public.has_any_role(auth.uid(), ARRAY[''owner''::public.app_role, ''admin''::public.app_role, ''gestor''::public.app_role, ''administrativo''::public.app_role, ''financeiro''::public.app_role, ''vendedor''::public.app_role, ''corretor''::public.app_role]) OR
          organization_id = public.get_my_org_id() OR
          organization_id IS NULL OR
          public.get_my_org_id() IS NULL
        )
        WITH CHECK (
          public.is_master_user(auth.uid()) OR
          public.has_any_role(auth.uid(), ARRAY[''owner''::public.app_role, ''admin''::public.app_role, ''gestor''::public.app_role, ''administrativo''::public.app_role, ''financeiro''::public.app_role, ''vendedor''::public.app_role, ''corretor''::public.app_role]) OR
          organization_id = public.get_my_org_id() OR
          organization_id IS NULL OR
          public.get_my_org_id() IS NULL
        )
      ', v_table, v_table);

      EXECUTE format('
        CREATE POLICY "tenant_delete_safeos_%s" ON public.%I FOR DELETE TO authenticated
        USING (
          public.is_master_user(auth.uid()) OR
          public.has_any_role(auth.uid(), ARRAY[''owner''::public.app_role, ''admin''::public.app_role]) OR
          (
            (organization_id = public.get_my_org_id() OR organization_id IS NULL OR public.get_my_org_id() IS NULL) AND
            public.has_any_role(auth.uid(), ARRAY[''owner''::public.app_role, ''admin''::public.app_role, ''gestor''::public.app_role, ''administrativo''::public.app_role])
          )
        )
      ', v_table, v_table);

    -- 4. ALL OTHER TABLES fallback (safe fallback policies)
    ELSE
      EXECUTE format('
        CREATE POLICY "fallback_select_safeos_%s" ON public.%I FOR SELECT TO authenticated
        USING (true)
      ', v_table, v_table);

      EXECUTE format('
        CREATE POLICY "fallback_insert_safeos_%s" ON public.%I FOR INSERT TO authenticated
        WITH CHECK (true)
      ', v_table, v_table);

      EXECUTE format('
        CREATE POLICY "fallback_update_safeos_%s" ON public.%I FOR UPDATE TO authenticated
        USING (true)
        WITH CHECK (true)
      ', v_table, v_table);

      EXECUTE format('
        CREATE POLICY "fallback_delete_safeos_%s" ON public.%I FOR DELETE TO authenticated
        USING (
          public.is_master_user(auth.uid()) OR
          public.has_any_role(auth.uid(), ARRAY[''owner''::public.app_role, ''admin''::public.app_role])
        )
      ', v_table, v_table);
    END IF;

    -- Make sure that auto organization trigger exists and is properly registered
    IF v_has_org AND v_table <> 'user_roles' AND v_table <> 'team_members' AND v_table <> 'profiles' AND v_table <> 'audit_logs' THEN
      EXECUTE format('DROP TRIGGER IF EXISTS tr_set_org_%I ON public.%I', v_table, v_table);
      EXECUTE format('CREATE TRIGGER tr_set_org_%I BEFORE INSERT OR UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.fn_set_organization_id()', v_table, v_table);
    END IF;

    -- Guarantee that bulletproof audit trigger is active
    IF v_table <> 'audit_logs' AND v_table <> 'activity_log' AND v_table <> 'user_tips' AND v_table <> 'sinistro_tips' THEN
      EXECUTE format('DROP TRIGGER IF EXISTS tr_audit_%I ON public.%I', v_table, v_table);
      EXECUTE format('CREATE TRIGGER tr_audit_%I AFTER INSERT OR UPDATE OR DELETE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.fn_audit_log_trigger()', v_table, v_table);
    END IF;

  END LOOP;
END $$;

-- 3. SPECIFIC RIGID TABLE REINFORCEMENTS

-- A. Audit logs selective read restriction (Keep standard select restricted to upper hierarchy)
DROP POLICY IF EXISTS "tenant_select_safeos_audit_logs" ON public.audit_logs;
CREATE POLICY "tenant_select_safeos_audit_logs" ON public.audit_logs FOR SELECT TO authenticated
USING (
  public.is_master_user(auth.uid()) OR
  public.has_any_role(auth.uid(), ARRAY['owner'::public.app_role, 'admin'::public.app_role, 'gestor'::public.app_role])
);

-- B. User roles selective management restriction (Only system master or developer or tenant owner/admin)
DROP POLICY IF EXISTS "tenant_select_safeos_user_roles" ON public.user_roles;
DROP POLICY IF EXISTS "tenant_insert_safeos_user_roles" ON public.user_roles;
DROP POLICY IF EXISTS "tenant_update_safeos_user_roles" ON public.user_roles;
DROP POLICY IF EXISTS "tenant_delete_safeos_user_roles" ON public.user_roles;

CREATE POLICY "user_roles_select_safeos" ON public.user_roles FOR SELECT TO authenticated
USING (
  public.is_master_user(auth.uid()) OR
  public.has_any_role(auth.uid(), ARRAY['owner'::public.app_role, 'admin'::public.app_role, 'gestor'::public.app_role, 'administrativo'::public.app_role]) OR
  user_id = auth.uid() OR
  organization_id = public.get_my_org_id() OR
  public.get_my_org_id() IS NULL
);

CREATE POLICY "user_roles_write_safeos" ON public.user_roles FOR INSERT TO authenticated
WITH CHECK (
  public.is_master_user(auth.uid()) OR
  public.has_any_role(auth.uid(), ARRAY['owner'::public.app_role, 'admin'::public.app_role]) OR
  public.get_my_org_id() IS NULL
);

CREATE POLICY "user_roles_update_safeos" ON public.user_roles FOR UPDATE TO authenticated
USING (
  public.is_master_user(auth.uid()) OR
  public.has_any_role(auth.uid(), ARRAY['owner'::public.app_role, 'admin'::public.app_role]) OR
  public.get_my_org_id() IS NULL
)
WITH CHECK (
  public.is_master_user(auth.uid()) OR
  public.has_any_role(auth.uid(), ARRAY['owner'::public.app_role, 'admin'::public.app_role]) OR
  public.get_my_org_id() IS NULL
);

CREATE POLICY "user_roles_delete_safeos" ON public.user_roles FOR DELETE TO authenticated
USING (
  public.is_master_user(auth.uid()) OR
  public.has_any_role(auth.uid(), ARRAY['owner'::public.app_role, 'admin'::public.app_role]) OR
  public.get_my_org_id() IS NULL
);

-- C. Team members selective management restriction
DROP POLICY IF EXISTS "tenant_select_safeos_team_members" ON public.team_members;
DROP POLICY IF EXISTS "tenant_insert_safeos_team_members" ON public.team_members;
DROP POLICY IF EXISTS "tenant_update_safeos_team_members" ON public.team_members;
DROP POLICY IF EXISTS "tenant_delete_safeos_team_members" ON public.team_members;

CREATE POLICY "team_members_select_safeos" ON public.team_members FOR SELECT TO authenticated
USING (
  public.is_master_user(auth.uid()) OR
  public.has_any_role(auth.uid(), ARRAY['owner'::public.app_role, 'admin'::public.app_role, 'gestor'::public.app_role, 'administrativo'::public.app_role, 'suporte'::public.app_role, 'leitura'::public.app_role, 'vendedor'::public.app_role, 'corretor'::public.app_role]) OR
  user_id = auth.uid() OR
  organization_id = public.get_my_org_id() OR
  public.get_my_org_id() IS NULL
);

CREATE POLICY "team_members_write_safeos" ON public.team_members FOR INSERT TO authenticated
WITH CHECK (
  public.is_master_user(auth.uid()) OR
  public.has_any_role(auth.uid(), ARRAY['owner'::public.app_role, 'admin'::public.app_role, 'gestor'::public.app_role]) OR
  public.get_my_org_id() IS NULL
);

CREATE POLICY "team_members_update_safeos" ON public.team_members FOR UPDATE TO authenticated
USING (
  public.is_master_user(auth.uid()) OR
  public.has_any_role(auth.uid(), ARRAY['owner'::public.app_role, 'admin'::public.app_role, 'gestor'::public.app_role]) OR
  user_id = auth.uid() OR
  public.get_my_org_id() IS NULL
)
WITH CHECK (
  public.is_master_user(auth.uid()) OR
  public.has_any_role(auth.uid(), ARRAY['owner'::public.app_role, 'admin'::public.app_role, 'gestor'::public.app_role]) OR
  user_id = auth.uid() OR
  public.get_my_org_id() IS NULL
);

CREATE POLICY "team_members_delete_safeos" ON public.team_members FOR DELETE TO authenticated
USING (
  public.is_master_user(auth.uid()) OR
  public.has_any_role(auth.uid(), ARRAY['owner'::public.app_role, 'admin'::public.app_role]) OR
  public.get_my_org_id() IS NULL
);

-- ############################################################################################
-- MIGRATION SUCCESSFUL - SAFE-OS SYSTEM IS NOW SECURE, VISUALIZED & RESILIENT FOR ALL LOGINS
-- ############################################################################################
