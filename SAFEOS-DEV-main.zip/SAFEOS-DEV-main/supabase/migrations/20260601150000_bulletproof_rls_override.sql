-- Bulletproof RLS and Tenant Isolation fix ensuring master users bypass and normal users never experience RLS mismatches on write.

CREATE OR REPLACE FUNCTION public.get_my_org_id()
RETURNS UUID AS $$
DECLARE
  v_org_id UUID;
  v_email TEXT;
  v_is_master BOOLEAN := false;
BEGIN
  -- 0. Retorna NULL imediatamente se não houver usuário autenticado
  IF auth.uid() IS NULL THEN
    RETURN NULL;
  END IF;

  -- Checa se é usuário master
  v_email := LOWER(auth.jwt() ->> 'email');
  IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
    v_is_master := true;
  END IF;

  IF NOT v_is_master THEN
    SELECT LOWER(email) INTO v_email FROM auth.users WHERE id = auth.uid() LIMIT 1;
    IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
      v_is_master := true;
    END IF;
  END IF;

  -- Tenta obter do perfil do usuário
  BEGIN
    SELECT organization_id INTO v_org_id FROM public.profiles WHERE id = auth.uid() LIMIT 1;
  EXCEPTION WHEN others THEN
    v_org_id := NULL;
  END;

  -- Se for nula, tenta obter do metadado do JWT
  IF v_org_id IS NULL THEN
    BEGIN
      v_org_id := (auth.jwt() -> 'user_metadata' ->> 'organization_id')::UUID;
    EXCEPTION WHEN others THEN
      v_org_id := NULL;
    END;
  END IF;

  -- Se ainda for nula para o usuário master, retornamos NULL (bypass completo de RLS para desenvolvimento)
  IF v_is_master AND v_org_id IS NULL THEN
    RETURN NULL;
  END IF;

  -- Para usuários normais (ou master com org definida), usará a organização correspondente
  IF v_org_id IS NULL THEN
    BEGIN
      SELECT id INTO v_org_id FROM public.organizations WHERE slug = 'organizacao-padrao' LIMIT 1;
    EXCEPTION WHEN others THEN
      v_org_id := NULL;
    END;
  END IF;

  IF v_org_id IS NULL THEN
    BEGIN
      SELECT id INTO v_org_id FROM public.organizations ORDER BY created_at ASC LIMIT 1;
    EXCEPTION WHEN others THEN
      v_org_id := NULL;
    END;
  END IF;

  RETURN v_org_id;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER;


CREATE OR REPLACE FUNCTION public.fn_set_organization_id()
RETURNS TRIGGER AS $$
DECLARE
  v_user_org_id UUID;
  v_email TEXT;
  v_is_master BOOLEAN := false;
BEGIN
  -- Obtain user's actual organization ID using get_my_org_id()
  v_user_org_id := public.get_my_org_id();

  -- Get master status
  v_email := LOWER(auth.jwt() ->> 'email');
  IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
    v_is_master := true;
  END IF;

  IF NOT v_is_master AND auth.uid() IS NOT NULL THEN
    SELECT LOWER(email) INTO v_email FROM auth.users WHERE id = auth.uid() LIMIT 1;
    IF v_email IN ('nexusaionline@gmail.com', 'comercial@medsafecorretora.com.br') THEN
      v_is_master := true;
    END IF;
  END IF;

  -- Se o NEW.organization_id for informado pelo cliente
  IF NEW.organization_id IS NOT NULL THEN
    -- Se o usuário for master ou admin, respeitamos o ID de organização que ele passou
    IF v_is_master OR public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'admin'::app_role) THEN
      -- Permite prosseguir sem interferência
      NULL;
    ELSE
      -- Se for usuário comum, forçamos o ID do tenant dele para evitar qualquer mismatch de RLS
      IF v_user_org_id IS NOT NULL THEN
        NEW.organization_id := v_user_org_id;
      END IF;
    END IF;
  ELSE
    -- Se NEW.organization_id for NULL, tentamos preencher com a org correspondente do usuário
    IF v_user_org_id IS NOT NULL THEN
      NEW.organization_id := v_user_org_id;
    ELSE
      -- Fallback se não logado ou sem empresa associada
      BEGIN
        SELECT id INTO NEW.organization_id FROM public.organizations WHERE slug = 'organizacao-padrao' LIMIT 1;
      EXCEPTION WHEN others THEN
        NEW.organization_id := NULL;
      END;
      IF NEW.organization_id IS NULL THEN
        BEGIN
          SELECT id INTO NEW.organization_id FROM public.organizations ORDER BY created_at ASC LIMIT 1;
        EXCEPTION WHEN others THEN
          NEW.organization_id := NULL;
        END;
      END IF;
    END IF;
  END IF;

  -- Impede alteração de organização no UPDATE exceto para Admins/Owners/Masters
  IF (TG_OP = 'UPDATE') THEN
    IF (OLD.organization_id IS DISTINCT FROM NEW.organization_id) AND 
       NOT (v_is_master OR public.has_role(auth.uid(), 'owner'::app_role) OR public.has_role(auth.uid(), 'admin'::app_role)) THEN
      RAISE EXCEPTION 'Não é permitido alterar a organização do registro.';
    END IF;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
