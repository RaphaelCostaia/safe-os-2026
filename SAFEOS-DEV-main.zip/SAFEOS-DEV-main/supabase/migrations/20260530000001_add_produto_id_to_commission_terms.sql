-- Adiciona a coluna produto_id na tabela de termos de comissão de cliente
ALTER TABLE public.client_commission_terms 
ADD COLUMN IF NOT EXISTS produto_id UUID REFERENCES public.produtos(id) ON DELETE CASCADE;

-- Comentário explicativo
COMMENT ON COLUMN public.client_commission_terms.produto_id IS 'Produto específico para o qual esta comissão se aplica. Se NULL, aplica-se como regra geral para o cliente.';

-- Cria índice para melhorias de performance de busca por produto do cliente
CREATE INDEX IF NOT EXISTS idx_client_commission_terms_produto ON public.client_commission_terms(client_id, produto_id);
