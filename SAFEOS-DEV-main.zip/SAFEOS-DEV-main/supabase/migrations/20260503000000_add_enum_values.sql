-- ############################################################################################
-- PASSO 1: ADICIONA NOVOS VALORES AO ENUM ‘app_role’ ANTES DE UTILIZÁ-LOS
-- IMPORTANTE: No PostgreSQL, ALTER TYPE ... ADD VALUE não pode ser executado dentro de uma transação
-- que também tenta usar esses novos valores. Portanto, este passo deve ser commitado primeiro.
-- ############################################################################################

-- Adiciona os novos papéis se eles ainda não existirem
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'owner';
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'financeiro';
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'suporte';
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'leitura';
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'corretor';
