
-- REFINAÇÃO DO TRIGGER DE AUDITORIA PARA CAPTURAR IP E USER AGENT
CREATE OR REPLACE FUNCTION public.fn_audit_log_trigger()
RETURNS TRIGGER AS $$
DECLARE
  v_org_id UUID;
  v_user_id UUID := auth.uid();
  v_ip TEXT;
  v_user_agent TEXT;
  v_headers JSON;
BEGIN
  -- Captura headers da requisição (Supabase expõe isso em settings)
  BEGIN
    v_headers := current_setting('request.headers', true)::json;
    v_ip := v_headers ->> 'x-real-ip';
    v_user_agent := v_headers ->> 'user-agent';
  EXCEPTION WHEN others THEN
    v_ip := NULL;
    v_user_agent := NULL;
  END;

  -- Determina organization_id
  IF (TG_OP = 'DELETE') THEN
    v_org_id := OLD.organization_id;
  ELSE
    v_org_id := NEW.organization_id;
  END IF;

  -- Insere o Log
  INSERT INTO public.audit_logs (
    organization_id,
    user_id,
    action,
    table_name,
    record_id,
    old_data,
    new_data,
    ip_address,
    user_agent
  ) VALUES (
    v_org_id,
    v_user_id,
    TG_OP,
    TG_TABLE_NAME,
    COALESCE(NEW.id, OLD.id),
    CASE WHEN TG_OP = 'DELETE' OR TG_OP = 'UPDATE' THEN to_jsonb(OLD) ELSE NULL END,
    CASE WHEN TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN to_jsonb(NEW) ELSE NULL END,
    COALESCE(v_ip, 'unknown'),
    COALESCE(v_user_agent, 'unknown')
  );

  IF (TG_OP = 'DELETE') THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
