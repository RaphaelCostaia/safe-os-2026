-- =====================================================
-- SECURITY HARDENING - Phase 2: Restrict write access
-- =====================================================

-- 1. Restrict contas INSERT/UPDATE to admin, gestor, and administrativo only
DROP POLICY IF EXISTS "Authenticated users can insert contas" ON public.contas;
DROP POLICY IF EXISTS "Authenticated users can update contas" ON public.contas;

CREATE POLICY "Admin gestor administrativo can insert contas" 
ON public.contas 
FOR INSERT 
WITH CHECK (
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'gestor'::app_role) OR 
  has_role(auth.uid(), 'administrativo'::app_role)
);

CREATE POLICY "Admin gestor administrativo can update contas" 
ON public.contas 
FOR UPDATE 
USING (
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'gestor'::app_role) OR 
  has_role(auth.uid(), 'administrativo'::app_role)
);

-- 2. Restrict client_commission_terms INSERT/UPDATE to admin, gestor, and administrativo only
DROP POLICY IF EXISTS "Authenticated users can insert commission terms" ON public.client_commission_terms;
DROP POLICY IF EXISTS "Authenticated users can update commission terms" ON public.client_commission_terms;

CREATE POLICY "Role based commission_terms insert" 
ON public.client_commission_terms 
FOR INSERT 
WITH CHECK (
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'gestor'::app_role) OR 
  has_role(auth.uid(), 'administrativo'::app_role)
);

CREATE POLICY "Role based commission_terms update" 
ON public.client_commission_terms 
FOR UPDATE 
USING (
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'gestor'::app_role) OR 
  has_role(auth.uid(), 'administrativo'::app_role)
);

-- 3. Restrict produtos SELECT to authenticated users only (protect comissao_percentual)
DROP POLICY IF EXISTS "Everyone can view active produtos" ON public.produtos;

CREATE POLICY "Authenticated users can view active produtos" 
ON public.produtos 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL AND ativo = true
);

-- 4. Restrict sinistro_tips to authenticated users only
DROP POLICY IF EXISTS "Everyone can view active tips" ON public.sinistro_tips;

CREATE POLICY "Authenticated users can view active tips" 
ON public.sinistro_tips 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL AND ativo = true
);