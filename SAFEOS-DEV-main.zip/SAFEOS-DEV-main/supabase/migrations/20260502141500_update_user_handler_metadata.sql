
-- UPDATE handle_new_user TO SUPPORT METADATA ORG_ID
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_org_id UUID;
BEGIN
  -- Try to get org_id from metadata, fallback to default
  BEGIN
    v_org_id := (NEW.raw_user_meta_data ->> 'organization_id')::UUID;
  EXCEPTION WHEN others THEN
    v_org_id := NULL;
  END;
  
  IF v_org_id IS NULL THEN
    SELECT id INTO v_org_id FROM public.organizations WHERE slug = 'organizacao-padrao' LIMIT 1;
  END IF;

  INSERT INTO public.profiles (id, email, full_name, organization_id)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.raw_user_meta_data ->> 'name', 'Usuário'),
    v_org_id
  )
  ON CONFLICT (id) DO UPDATE SET 
    organization_id = EXCLUDED.organization_id,
    full_name = EXCLUDED.full_name;
  
  INSERT INTO public.user_roles (user_id, role, organization_id)
  VALUES (
    NEW.id,
    COALESCE((NEW.raw_user_meta_data ->> 'role')::app_role, 'vendedor'),
    v_org_id
  )
  ON CONFLICT (user_id, role) DO NOTHING;
  
  RETURN NEW;
END;
$$;
