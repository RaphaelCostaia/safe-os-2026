-- Ensure profile/role provisioning happens on signup and backfill existing users

-- 1) Create the auth.users trigger (required for handle_new_user)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_trigger t
    JOIN pg_class c ON c.oid = t.tgrelid
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE t.tgname = 'on_auth_user_created'
      AND n.nspname = 'auth'
      AND c.relname = 'users'
  ) THEN
    CREATE TRIGGER on_auth_user_created
      AFTER INSERT ON auth.users
      FOR EACH ROW
      EXECUTE FUNCTION public.handle_new_user();
  END IF;
END $$;

-- 2) Backfill missing profiles for existing users
INSERT INTO public.profiles (id, email, full_name)
SELECT
  u.id,
  u.email,
  COALESCE(u.raw_user_meta_data ->> 'full_name', u.raw_user_meta_data ->> 'name', 'Usuário')
FROM auth.users u
LEFT JOIN public.profiles p ON p.id = u.id
WHERE p.id IS NULL;

-- 3) Backfill missing user_roles for existing users
INSERT INTO public.user_roles (user_id, role)
SELECT
  u.id,
  COALESCE((u.raw_user_meta_data ->> 'role')::public.app_role, 'vendedor'::public.app_role)
FROM auth.users u
LEFT JOIN public.user_roles ur
  ON ur.user_id = u.id
  AND ur.role = COALESCE((u.raw_user_meta_data ->> 'role')::public.app_role, 'vendedor'::public.app_role)
WHERE ur.id IS NULL;

-- 4) Allow 'administrativo' to view all profiles (needed for selecting responsaveis)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname='public'
      AND tablename='profiles'
      AND policyname='Administrativo can view all profiles'
  ) THEN
    CREATE POLICY "Administrativo can view all profiles"
    ON public.profiles
    FOR SELECT
    USING (has_role(auth.uid(), 'administrativo'::app_role));
  END IF;
END $$;