-- Tabela de custos fixos
CREATE TABLE public.custos_fixos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  categoria TEXT NOT NULL,
  descricao TEXT NOT NULL,
  valor NUMERIC NOT NULL DEFAULT 0,
  recorrencia TEXT NOT NULL DEFAULT 'mensal',
  status TEXT NOT NULL DEFAULT 'ativo',
  responsavel_id UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de contas (pagar/receber)
CREATE TABLE public.contas (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tipo TEXT NOT NULL CHECK (tipo IN ('pagar', 'receber')),
  descricao TEXT NOT NULL,
  categoria TEXT NOT NULL,
  valor NUMERIC NOT NULL DEFAULT 0,
  vencimento DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'pendente',
  responsavel_id UUID REFERENCES auth.users(id),
  cliente_id UUID REFERENCES public.clients(id),
  apolice_id UUID REFERENCES public.apolices(id),
  observacoes TEXT,
  data_pagamento DATE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.custos_fixos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contas ENABLE ROW LEVEL SECURITY;

-- RLS policies for custos_fixos
CREATE POLICY "Authenticated users can view custos_fixos"
ON public.custos_fixos FOR SELECT
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can insert custos_fixos"
ON public.custos_fixos FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update custos_fixos"
ON public.custos_fixos FOR UPDATE
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admins can delete custos_fixos"
ON public.custos_fixos FOR DELETE
USING (has_role(auth.uid(), 'admin'));

-- RLS policies for contas
CREATE POLICY "Authenticated users can view contas"
ON public.contas FOR SELECT
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can insert contas"
ON public.contas FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update contas"
ON public.contas FOR UPDATE
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admins can delete contas"
ON public.contas FOR DELETE
USING (has_role(auth.uid(), 'admin'));

-- Triggers for updated_at
CREATE TRIGGER update_custos_fixos_updated_at
BEFORE UPDATE ON public.custos_fixos
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_contas_updated_at
BEFORE UPDATE ON public.contas
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();