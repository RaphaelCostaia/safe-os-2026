-- Fix: Allow authenticated users to insert produtos (for vendedor and administrativo roles)
CREATE POLICY "Authenticated users can insert produtos" 
ON public.produtos 
FOR INSERT 
TO authenticated
WITH CHECK (true);

-- Allow authenticated users to update produtos they created
CREATE POLICY "Authenticated users can update produtos" 
ON public.produtos 
FOR UPDATE 
TO authenticated
USING (true);