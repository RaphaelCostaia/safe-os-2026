
-- 1. EXPAND USER ROLES
-- Note: PostgreSQL doesn't support ALTER TYPE ADD VALUE in a transaction easily if combined with other things, 
-- but Supabase migrations handle it. We'll use a script to ensure roles exist.
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'app_role') THEN
    CREATE TYPE public.app_role AS ENUM ('admin', 'gestor', 'vendedor', 'administrativo', 'owner', 'financeiro', 'suporte', 'leitura');
  ELSE
    -- Add missing values to existing enum
    BEGIN
      ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'owner';
      ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'financeiro';
      ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'suporte';
      ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'leitura';
      -- 'corretor' will be aliased to 'vendedor' or we can add it too
      ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'corretor';
    EXCEPTION WHEN others THEN
      NULL; -- Ignore if already exists
    END;
  END IF;
END $$;

-- 2. CREATE ORGANIZATIONS TABLE (Saas Multi-tenant)
CREATE TABLE IF NOT EXISTS public.organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  active BOOLEAN DEFAULT true,
  settings JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS on organizations
ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;

-- 3. AUDIT LOG SYSTEM
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES public.organizations(id),
  user_id UUID REFERENCES auth.users(id),
  action TEXT NOT NULL, -- 'INSERT', 'UPDATE', 'DELETE', 'SELECT' (for sensitive)
  table_name TEXT NOT NULL,
  record_id UUID,
  old_data JSONB,
  new_data JSONB,
  ip_address TEXT,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Audit Trigger Function
CREATE OR REPLACE FUNCTION public.fn_audit_log_trigger()
RETURNS TRIGGER AS $$
DECLARE
  v_org_id UUID;
  v_user_id UUID := auth.uid();
BEGIN
  -- Try to get organization_id from NEW or OLD record
  IF (TG_OP = 'DELETE' OR TG_OP = 'UPDATE') THEN
    v_org_id := OLD.organization_id;
  ELSE
    v_org_id := NEW.organization_id;
  END IF;

  INSERT INTO public.audit_logs (
    organization_id,
    user_id,
    action,
    table_name,
    record_id,
    old_data,
    new_data
  ) VALUES (
    v_org_id,
    v_user_id,
    TG_OP,
    TG_TABLE_NAME,
    COALESCE(NEW.id, OLD.id),
    CASE WHEN TG_OP = 'DELETE' OR TG_OP = 'UPDATE' THEN to_jsonb(OLD) ELSE NULL END,
    CASE WHEN TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN to_jsonb(NEW) ELSE NULL END
  );

  IF (TG_OP = 'DELETE') THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 4. LINK TABLES TO ORGANIZATIONS
-- We'll add organization_id to all relevant tables.
-- If data exists, we'll need a default organization.

-- Create a Default Organization for existing data
INSERT INTO public.organizations (name, slug) 
VALUES ('Organização Padrão', 'organizacao-padrao')
ON CONFLICT (slug) DO NOTHING;

DO $$
DECLARE
  v_default_org_id UUID;
  t TEXT;
BEGIN
  SELECT id INTO v_default_org_id FROM public.organizations WHERE slug = 'organizacao-padrao' LIMIT 1;

  FOR t IN SELECT table_name 
           FROM information_schema.tables 
           WHERE table_schema = 'public' 
           AND table_name IN ('profiles', 'clients', 'apolices', 'sinistros', 'produtos', 'renovacoes', 'client_documents', 'client_notes', 'activity_log', 'contas', 'custos_fixos', 'financeiro_historico', 'client_commission_terms', 'user_roles')
  LOOP
    -- Add column if missing
    EXECUTE format('ALTER TABLE public.%I ADD COLUMN IF NOT EXISTS organization_id UUID REFERENCES public.organizations(id)', t);
    
    -- Populate with default org for existing rows
    EXECUTE format('UPDATE public.%I SET organization_id = %L WHERE organization_id IS NULL', t, v_default_org_id);
    
    -- Make it NOT NULL after population (optional, but recommended for SaaS)
    -- EXECUTE format('ALTER TABLE public.%I ALTER COLUMN organization_id SET NOT NULL', t);
    
    -- Add Trigger for Audit
    EXECUTE format('DROP TRIGGER IF EXISTS tr_audit_%I ON public.%I', t, t);
    EXECUTE format('CREATE TRIGGER tr_audit_%I AFTER INSERT OR UPDATE OR DELETE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.fn_audit_log_trigger()', t, t);
  END LOOP;
END $$;

-- 5. REWRITE RLS POLICIES (ORGANIZATION ISOLATION)
-- This is critical to prevent cross-broker access.

-- Global Deny (Safety Net)
-- Supabase handles this if RLS is enabled and no policy matches.

-- Organization Access Function
CREATE OR REPLACE FUNCTION public.get_my_org_id()
RETURNS UUID AS $$
  SELECT organization_id FROM public.profiles WHERE id = auth.uid() LIMIT 1;
$$ LANGUAGE sql STABLE SECURITY DEFINER;

-- POLICIES: ORGANIZATIONS
CREATE POLICY "Users can view their own organization" ON public.organizations
FOR SELECT USING (id = public.get_my_org_id());

-- POLICIES: PROFILES & ROLES
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;
CREATE POLICY "Users can view profiles in their organization" ON public.profiles
FOR SELECT USING (organization_id = public.get_my_org_id());

-- POLICIES: CLIENTS (Role-Based)
DROP POLICY IF EXISTS "Role based clients select" ON public.clients;
DROP POLICY IF EXISTS "Authenticated users can view clients" ON public.clients;

CREATE POLICY "Clients isolation and role check" ON public.clients
FOR SELECT USING (
  organization_id = public.get_my_org_id() AND (
    public.has_role(auth.uid(), 'admin') OR 
    public.has_role(auth.uid(), 'owner') OR 
    public.has_role(auth.uid(), 'gestor') OR 
    public.has_role(auth.uid(), 'administrativo') OR
    public.has_role(auth.uid(), 'financeiro') OR
    public.has_role(auth.uid(), 'suporte') OR
    public.has_role(auth.uid(), 'leitura') OR
    (public.has_role(auth.uid(), 'corretor') AND (responsavel_id = auth.uid())) OR
    (public.has_role(auth.uid(), 'vendedor') AND (responsavel_id = auth.uid()))
  )
);

-- Write Policies for Clients
DROP POLICY IF EXISTS "Role based clients insert" ON public.clients;
CREATE POLICY "Clients write access" ON public.clients
FOR ALL TO authenticated
USING (
  organization_id = public.get_my_org_id() AND (
    NOT public.has_role(auth.uid(), 'leitura') AND
    (
      public.has_role(auth.uid(), 'admin') OR 
      public.has_role(auth.uid(), 'owner') OR 
      public.has_role(auth.uid(), 'gestor') OR 
      public.has_role(auth.uid(), 'administrativo') OR
      (public.has_role(auth.uid(), 'corretor') AND (responsavel_id = auth.uid() OR responsavel_id IS NULL))
    )
  )
)
WITH CHECK (
  organization_id = public.get_my_org_id()
);

-- Repeat for APOLICES, SINISTROS, etc.
-- For brevity of this migration, we'll apply a broad pattern to all others 
-- and then sharpen specific ones if needed.

DO $$
DECLARE
  t TEXT;
BEGIN
  FOR t IN SELECT table_name 
           FROM information_schema.tables 
           WHERE table_schema = 'public' 
           AND table_name IN ('apolices', 'sinistros', 'produtos', 'renovacoes', 'client_documents', 'client_notes', 'contas', 'custos_fixos', 'financeiro_historico', 'client_commission_terms')
  LOOP
    -- Drop existing policies to avoid conflicts
    EXECUTE format('DROP POLICY IF EXISTS "Authenticated users can view %I" ON public.%I', t, t);
    EXECUTE format('DROP POLICY IF EXISTS "Role based %I select" ON public.%I', t, t);
    
    -- New Isolation Policy
    EXECUTE format('CREATE POLICY "Org isolation %I" ON public.%I FOR ALL TO authenticated USING (organization_id = public.get_my_org_id()) WITH CHECK (organization_id = public.get_my_org_id())', t, t);
  END LOOP;
END $$;

-- AUDIT LOGS PROTECTION
CREATE POLICY "Only admins/owners view audit logs" ON public.audit_logs
FOR SELECT USING (
  organization_id = public.get_my_org_id() AND 
  (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'owner'))
);

-- Update handle_new_user to handle default organization
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_default_org_id UUID;
BEGIN
  SELECT id INTO v_default_org_id FROM public.organizations WHERE slug = 'organizacao-padrao' LIMIT 1;

  INSERT INTO public.profiles (id, email, full_name, organization_id)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.raw_user_meta_data ->> 'name', 'Usuário'),
    v_default_org_id
  );
  
  INSERT INTO public.user_roles (user_id, role, organization_id)
  VALUES (
    NEW.id,
    COALESCE((NEW.raw_user_meta_data ->> 'role')::app_role, 'vendedor'),
    v_default_org_id
  );
  
  RETURN NEW;
END;
$$;
