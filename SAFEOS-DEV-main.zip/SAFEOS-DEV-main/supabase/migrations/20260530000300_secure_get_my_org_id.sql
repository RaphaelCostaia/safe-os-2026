-- Security hardening: return NULL if no authenticated user is present.
-- This ensures unauthenticated/anonymous users can never read organizations or bypass RLS.

CREATE OR REPLACE FUNCTION public.get_my_org_id()
RETURNS UUID AS $$
DECLARE
  v_org_id UUID;
BEGIN
  -- 0. Retorna NULL imediatamente se não houver usuário autenticado para proteção absoluta contra leaks de RLS
  IF auth.uid() IS NULL THEN
    RETURN NULL;
  END IF;

  -- 1. Tenta obter do perfil do usuário
  SELECT organization_id INTO v_org_id FROM public.profiles WHERE id = auth.uid() LIMIT 1;
  
  -- 2. Se for nula, tenta obter do metadado do JWT
  IF v_org_id IS NULL THEN
    BEGIN
      v_org_id := (auth.jwt() -> 'user_metadata' ->> 'organization_id')::UUID;
    EXCEPTION WHEN others THEN
      v_org_id := NULL;
    END;
  END IF;

  -- 3. Se ainda for nula, pega do primeiro registro nas user_roles
  IF v_org_id IS NULL THEN
    SELECT organization_id INTO v_org_id FROM public.user_roles WHERE user_id = auth.uid() LIMIT 1;
  END IF;

  -- 4. Em terceiro caso, tenta por slug 'organizacao-padrao'
  IF v_org_id IS NULL THEN
    SELECT id INTO v_org_id FROM public.organizations WHERE slug = 'organizacao-padrao' LIMIT 1;
  END IF;

  -- 5. Fallback absoluto de emergência: a primeira organização cadastrada na tabela
  IF v_org_id IS NULL THEN
    SELECT id INTO v_org_id FROM public.organizations ORDER BY created_at ASC LIMIT 1;
  END IF;

  RETURN v_org_id;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER;
