-- Remover policy antiga que ainda tem USING (true)
DROP POLICY IF EXISTS "Authenticated users can view activity" ON public.activity_log;

-- Agora precisamos corrigir os warnings de sinistro_documents que tem USING (true) para INSERT/UPDATE/DELETE
-- Estas são necessárias para o negócio mas devem ter controle mínimo

-- Remover policies atuais
DROP POLICY IF EXISTS "Authenticated users can insert sinistro documents" ON public.sinistro_documents;
DROP POLICY IF EXISTS "Authenticated users can update sinistro documents" ON public.sinistro_documents;
DROP POLICY IF EXISTS "Authenticated users can delete sinistro documents" ON public.sinistro_documents;

-- Recriar com controle adequado
CREATE POLICY "Authenticated users can insert sinistro documents" ON public.sinistro_documents
FOR INSERT TO authenticated
WITH CHECK (auth.uid() IS NOT NULL AND uploaded_by = auth.uid());

CREATE POLICY "Authenticated users can update sinistro documents" ON public.sinistro_documents
FOR UPDATE TO authenticated
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admins gestores can delete sinistro documents" ON public.sinistro_documents
FOR DELETE TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::app_role) OR 
  public.has_role(auth.uid(), 'gestor'::app_role) OR
  uploaded_by = auth.uid()
);