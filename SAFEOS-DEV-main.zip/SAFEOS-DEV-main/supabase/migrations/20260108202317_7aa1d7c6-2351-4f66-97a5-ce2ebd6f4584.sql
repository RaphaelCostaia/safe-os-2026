-- Allow 'administrativo' role to insert profiles (needed for creating internal responsibles)
CREATE POLICY "Administrativo can insert profiles"
ON public.profiles
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'administrativo'::app_role));