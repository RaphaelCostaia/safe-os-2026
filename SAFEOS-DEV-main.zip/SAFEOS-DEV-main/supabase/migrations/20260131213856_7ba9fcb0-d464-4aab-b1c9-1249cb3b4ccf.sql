-- =====================================================
-- SECURITY HARDENING: Restrict PII access
-- =====================================================

-- 1. Restrict team_members access to admin, gestor, administrativo only
-- Drop the existing permissive policy first
DROP POLICY IF EXISTS "Role based team_members select" ON public.team_members;

-- Create more restrictive policy - only admin/gestor/administrativo can view team members
CREATE POLICY "Role based team_members select" 
ON public.team_members 
FOR SELECT 
USING (
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'gestor'::app_role) OR 
  has_role(auth.uid(), 'administrativo'::app_role)
);

-- 2. Tighten profiles access - users can only see their own profile
-- Drop existing policy
DROP POLICY IF EXISTS "Secure profiles select" ON public.profiles;

-- Create stricter policy - users see only their own profile, admins/gestores can see all
CREATE POLICY "Secure profiles select" 
ON public.profiles 
FOR SELECT 
USING (
  auth.uid() = id OR 
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'gestor'::app_role)
);

-- 3. Update sinistro_notes to ensure non-private notes are still protected by role
DROP POLICY IF EXISTS "Authenticated users can view sinistro notes" ON public.sinistro_notes;

CREATE POLICY "Role based sinistro_notes select" 
ON public.sinistro_notes 
FOR SELECT 
USING (
  -- User is the author (can see their own notes including private)
  auth.uid() = autor_id 
  OR 
  -- Non-private notes visible to those with access to the sinistro
  (
    is_private = false AND 
    (
      has_role(auth.uid(), 'admin'::app_role) OR 
      has_role(auth.uid(), 'gestor'::app_role) OR 
      has_role(auth.uid(), 'administrativo'::app_role) OR 
      (has_role(auth.uid(), 'vendedor'::app_role) AND EXISTS (
        SELECT 1 FROM sinistros s
        JOIN clients c ON c.id = s.client_id
        WHERE s.id = sinistro_notes.sinistro_id 
        AND c.responsavel_id = auth.uid()
      ))
    )
  )
);

-- 4. Update user_notes to verify role for team notes
DROP POLICY IF EXISTS "Users can view team notes" ON public.user_notes;

CREATE POLICY "Users can view team notes" 
ON public.user_notes 
FOR SELECT 
USING (
  visibilidade = 'equipe' AND 
  (
    has_role(auth.uid(), 'admin'::app_role) OR 
    has_role(auth.uid(), 'gestor'::app_role) OR 
    has_role(auth.uid(), 'administrativo'::app_role)
  )
);