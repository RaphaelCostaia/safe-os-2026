-- Create sinistro_documents table for claim-related documents
CREATE TABLE public.sinistro_documents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sinistro_id UUID NOT NULL REFERENCES public.sinistros(id) ON DELETE CASCADE,
  client_id UUID NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  apolice_id UUID REFERENCES public.apolices(id) ON DELETE SET NULL,
  nome VARCHAR(255) NOT NULL,
  tipo VARCHAR(50) NOT NULL,
  descricao VARCHAR(200),
  data_documento DATE NOT NULL DEFAULT CURRENT_DATE,
  url TEXT NOT NULL,
  tamanho INTEGER,
  uploaded_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.sinistro_documents ENABLE ROW LEVEL SECURITY;

-- RLS Policies - All authenticated users can manage documents (adjust based on business rules)
CREATE POLICY "Authenticated users can view sinistro documents"
ON public.sinistro_documents
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can insert sinistro documents"
ON public.sinistro_documents
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Authenticated users can update sinistro documents"
ON public.sinistro_documents
FOR UPDATE
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can delete sinistro documents"
ON public.sinistro_documents
FOR DELETE
TO authenticated
USING (true);

-- Create index for faster lookups
CREATE INDEX idx_sinistro_documents_sinistro_id ON public.sinistro_documents(sinistro_id);
CREATE INDEX idx_sinistro_documents_client_id ON public.sinistro_documents(client_id);

-- Create update trigger for updated_at
CREATE TRIGGER update_sinistro_documents_updated_at
BEFORE UPDATE ON public.sinistro_documents
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create storage bucket for sinistro documents if not exists
INSERT INTO storage.buckets (id, name, public)
VALUES ('sinistro-documents', 'sinistro-documents', false)
ON CONFLICT (id) DO NOTHING;

-- Storage RLS policies
CREATE POLICY "Authenticated users can upload sinistro documents"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'sinistro-documents');

CREATE POLICY "Authenticated users can view sinistro documents"
ON storage.objects
FOR SELECT
TO authenticated
USING (bucket_id = 'sinistro-documents');

CREATE POLICY "Authenticated users can delete sinistro documents"
ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id = 'sinistro-documents');