-- Drop existing policies to recreate with correct permissions
DROP POLICY IF EXISTS "produtos_insert_admin_gestor" ON public.produtos;
DROP POLICY IF EXISTS "produtos_update_admin_gestor" ON public.produtos;

-- Recreate INSERT policy for admin, gestor, and administrativo (matching permissions.ts)
CREATE POLICY "produtos_insert_admin_gestor_administrativo" ON public.produtos
FOR INSERT WITH CHECK (
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'gestor'::app_role) OR 
  has_role(auth.uid(), 'administrativo'::app_role)
);

-- Recreate UPDATE policy for admin, gestor, and administrativo
CREATE POLICY "produtos_update_admin_gestor_administrativo" ON public.produtos
FOR UPDATE USING (
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'gestor'::app_role) OR 
  has_role(auth.uid(), 'administrativo'::app_role)
);