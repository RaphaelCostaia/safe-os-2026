-- Corrigir policy SELECT de custos_fixos para incluir administrativo
DROP POLICY IF EXISTS "Role based custos_fixos select" ON public.custos_fixos;

CREATE POLICY "Role based custos_fixos select"
  ON public.custos_fixos FOR SELECT
  USING (
    has_role(auth.uid(), 'admin'::app_role) OR 
    has_role(auth.uid(), 'gestor'::app_role) OR
    has_role(auth.uid(), 'administrativo'::app_role)
  );