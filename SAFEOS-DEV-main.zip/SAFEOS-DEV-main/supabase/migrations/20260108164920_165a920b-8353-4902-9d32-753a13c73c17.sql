-- Tabela para histórico mensal de receitas e custos
-- Permite gráficos de tendência com dados reais persistidos
CREATE TABLE public.financeiro_historico (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  ano INTEGER NOT NULL,
  mes INTEGER NOT NULL CHECK (mes >= 1 AND mes <= 12),
  
  -- Receitas
  receita_premios NUMERIC NOT NULL DEFAULT 0,
  receita_comissoes NUMERIC NOT NULL DEFAULT 0,
  receita_outras NUMERIC NOT NULL DEFAULT 0,
  receita_total NUMERIC NOT NULL DEFAULT 0,
  
  -- Custos
  custos_fixos NUMERIC NOT NULL DEFAULT 0,
  custos_variaveis NUMERIC NOT NULL DEFAULT 0,
  custos_total NUMERIC NOT NULL DEFAULT 0,
  
  -- Resultado
  resultado_operacional NUMERIC NOT NULL DEFAULT 0,
  
  -- Métricas adicionais
  total_apolices_ativas INTEGER DEFAULT 0,
  total_clientes_ativos INTEGER DEFAULT 0,
  ticket_medio NUMERIC DEFAULT 0,
  
  -- Metadados
  observacoes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  
  -- Constraint para garantir um registro único por mês/ano
  CONSTRAINT unique_ano_mes UNIQUE (ano, mes)
);

-- Enable Row Level Security
ALTER TABLE public.financeiro_historico ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Authenticated users can view financeiro_historico"
ON public.financeiro_historico
FOR SELECT
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admins and gestores can insert financeiro_historico"
ON public.financeiro_historico
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'gestor'));

CREATE POLICY "Admins and gestores can update financeiro_historico"
ON public.financeiro_historico
FOR UPDATE
USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'gestor'));

CREATE POLICY "Admins can delete financeiro_historico"
ON public.financeiro_historico
FOR DELETE
USING (has_role(auth.uid(), 'admin'));

-- Trigger para updated_at
CREATE TRIGGER update_financeiro_historico_updated_at
BEFORE UPDATE ON public.financeiro_historico
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Índice para consultas por período
CREATE INDEX idx_financeiro_historico_periodo ON public.financeiro_historico (ano DESC, mes DESC);