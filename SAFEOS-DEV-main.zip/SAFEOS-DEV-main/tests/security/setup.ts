
import { createClient } from '@supabase/supabase-js';

// Usaremos as variáveis de ambiente normais para o cliente "vítima" (anon)
// E precisaremos de uma SERVICE_ROLE para o setup (se disponível)
const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const supabaseKey = process.env.VITE_SUPABASE_PUBLISHABLE_KEY || '';
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

if (!supabaseUrl || !supabaseKey) {
  console.warn("Ambiente Supabase não configurado para testes.");
}

// Cliente com privilégios totais para preparar o cenário (Deletes, Inserts iniciais)
export const adminClient = createClient(supabaseUrl, serviceRoleKey || supabaseKey);

// Cliente que simula um usuário autenticado (JWT será injetado nos testes)
export const createAuthenticatedClient = (token: string) => {
  return createClient(supabaseUrl, supabaseKey, {
    global: {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    },
  });
};

// Helper para criar um contexto de teste limpo
export async function setupSecurityTestData() {
  if (!serviceRoleKey) return null;

  // Criar duas organizações de teste
  const orgA_id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';
  const orgB_id = 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb';

  // Limpeza (opcional, cuidado em produção)
  // await adminClient.from('organizations').delete().in('id', [orgA_id, orgB_id]);

  await adminClient.from('organizations').upsert([
    { id: orgA_id, name: 'Tenant A Test', slug: 'tenant-a-test' },
    { id: orgB_id, name: 'Tenant B Test', slug: 'tenant-b-test' }
  ]);

  return { orgA_id, orgB_id };
}
